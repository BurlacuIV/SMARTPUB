namespace SMARTPUB.Modules.Waiter;

public enum WaiterTableSurfaceState
{
    Free,
    DraftOnly,
    KitchenPending,
    DraftAndKitchen
}

public sealed class WaiterTableStatusUi
{
    public WaiterTableSurfaceState State { get; init; }
    public string StatusLine { get; init; } = "";
    public string? TimeLine { get; init; }
    public decimal TableTotal { get; init; }
    public int ItemCount { get; init; }
}

using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using SMARTPUB.Core.Session;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Modules.Waiter.Views;

public partial class WaiterFloorPage : Page
{
    private readonly FloorPlanRepository _floorRepo = new();
    private readonly List<FloorLevelModel> _levels = new();
    private readonly List<FloorSpaceModel> _spaces = new();
    private readonly List<FloorTableModel> _tables = new();
    private readonly Dictionary<string, WaiterTableVm> _vmByTableId = new(StringComparer.OrdinalIgnoreCase);
    private FloorLevelModel? _currentLevel;
    private readonly DispatcherTimer _refreshTimer;
    private List<KitchenTicket> _activeKitchenTickets = new();

    public WaiterFloorPage()
    {
        InitializeComponent();
        Loaded += OnLoaded;
        Unloaded += OnUnloaded;
        _refreshTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(45) };
        _refreshTimer.Tick += (_, _) => Dispatcher.BeginInvoke(RebuildPlan);
    }

    private bool _kitchenTicketsHooked;

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        if (!_kitchenTicketsHooked)
        {
            KitchenTicketStore.Instance.Changed += OnTicketsChanged;
            _kitchenTicketsHooked = true;
        }

        var opName = AppSession.Current.OperatorName;
        TxtOperatorName.Text = string.IsNullOrWhiteSpace(opName) ? "Ospătar" : opName;

        _refreshTimer.Start();
        ReloadAll();
    }

    private void OnUnloaded(object sender, RoutedEventArgs e)
    {
        if (_kitchenTicketsHooked)
        {
            KitchenTicketStore.Instance.Changed -= OnTicketsChanged;
            _kitchenTicketsHooked = false;
        }

        _refreshTimer.Stop();
    }

    private void OnTicketsChanged(object? sender, EventArgs e) =>
        Dispatcher.BeginInvoke(() =>
        {
            RefreshKitchenTicketCache();
            RebuildPlan();
        });

    private void BtnReload_Click(object sender, RoutedEventArgs e)
    {
        WaiterProductCatalogCache.Instance.Invalidate();
        ReloadAll();
    }

    private void ReloadAll()
    {
        TxtDbError.Visibility = Visibility.Collapsed;
        TxtDbError.Text = "";
        _levels.Clear();
        _spaces.Clear();
        _tables.Clear();

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            var floor = _floorRepo.Load(conn);
            _levels.AddRange(floor.Levels.OrderBy(l => l.SortOrder).ThenBy(l => l.Name));
            _spaces.AddRange(floor.Spaces);
            _tables.AddRange(floor.Tables);

            // Preload catalog în fundal (fără Invalidate aici — altfel fiecare reîncărcare plan golește cache-ul).
            WaiterProductCatalogCache.Instance.PreloadAsync();
        }
        catch (Exception ex)
        {
            TxtDbError.Text = "Nu s-a putut citi planul sală: " + ex.Message;
            TxtDbError.Visibility = Visibility.Visible;
        }

        TabLevels.ItemsSource = null;
        if (_levels.Count > 0)
        {
            TabLevels.ItemsSource = _levels;
            TabLevels.SelectedIndex = 0;
            RefreshKitchenTicketCache();
        }
        else
        {
            PlanCanvas.Children.Clear();
        }
    }

    private void TabLevels_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (TabLevels.SelectedItem is not FloorLevelModel lv)
        {
            _currentLevel = null;
            PlanCanvas.Children.Clear();
            return;
        }

        _currentLevel = lv;
        RebuildVmIndex();
        RebuildPlan();
    }

    private void RebuildVmIndex()
    {
        _vmByTableId.Clear();
        if (_currentLevel == null)
            return;

        var spaceNames = _spaces.ToDictionary(s => s.Id, s => s.Name);
        foreach (var t in _tables.Where(x => x.LevelId == _currentLevel.Id).OrderBy(x => x.Name))
        {
            _vmByTableId[t.Id] = new WaiterTableVm
            {
                TableId = t.Id,
                LevelId = _currentLevel.Id,
                LevelName = _currentLevel.Name,
                SpaceName = SpaceNameLookup(spaceNames, t.SpaceId),
                TableName = t.Name
            };
        }
    }

    private static string? SpaceNameLookup(Dictionary<string, string> names, string? spaceId) =>
        string.IsNullOrWhiteSpace(spaceId) ? null : names.TryGetValue(spaceId, out var n) ? n : null;

    private void RefreshKitchenTicketCache()
    {
        KitchenTicketStore.Instance.SyncFromDisk(raiseChanged: false);
        _activeKitchenTickets = KitchenTicketStore.Instance.GetSnapshot()
            .Where(k => k.Status is not KitchenTicketStatus.Served and not KitchenTicketStatus.Cancelled)
            .ToList();
    }

    private void RebuildPlan()
    {
        if (_currentLevel == null)
            return;

        if (_activeKitchenTickets.Count == 0)
            RefreshKitchenTicketCache();

        WaiterFloorPlanRenderer.RenderWithStatusCards(
            PlanCanvas,
            _currentLevel,
            _spaces,
            _tables,
            StatusFor,
            OnTableClicked);

        UpdateFloorStats();
    }

    private void UpdateFloorStats()
    {
        if (_currentLevel == null)
        {
            TxtFloorStats.Text = "";
            return;
        }

        var levelTables = _tables.Where(t => t.LevelId == _currentLevel.Id).ToList();
        if (levelTables.Count == 0)
        {
            TxtFloorStats.Text = "Nicio masă configurată";
            return;
        }

        var libre = 0;
        var ocupate = 0;
        foreach (var t in levelTables)
        {
            var st = StatusFor(t);
            if (st.State == WaiterTableSurfaceState.Free)
                libre++;
            else
                ocupate++;
        }

        TxtFloorStats.Text = $"  {libre} libere  ·  {ocupate} ocupate din {levelTables.Count}";
    }

    private WaiterTableStatusUi StatusFor(FloorTableModel t)
    {
        var draftCart  = WaiterDraftOrderStore.Instance.GetCart(t.Id);
        var draft      = draftCart.Count > 0;

        var tickets = _activeKitchenTickets
            .Where(k => string.Equals(k.TableId, t.Id, StringComparison.OrdinalIgnoreCase))
            .ToList();

        var pending    = tickets.OrderByDescending(k => k.CreatedAtUtc).FirstOrDefault();
        var tableTotal = tickets.Sum(k => k.Lines.Sum(l => l.Qty * l.UnitPrice))
                       + draftCart.Sum(l => l.LineTotal);
        var itemCount  = tickets.Sum(k => k.Lines.Count) + draftCart.Count;

        if (draft && pending != null)
            return new WaiterTableStatusUi
            {
                State = WaiterTableSurfaceState.DraftAndKitchen,
                StatusLine = "Bucătărie + coș",
                TimeLine = pending.CreatedLocalDisplay.ToString("HH:mm"),
                TableTotal = tableTotal,
                ItemCount = itemCount
            };

        if (pending != null)
            return new WaiterTableStatusUi
            {
                State = WaiterTableSurfaceState.KitchenPending,
                StatusLine = "La bucătărie",
                TimeLine = pending.CreatedLocalDisplay.ToString("HH:mm"),
                TableTotal = tableTotal,
                ItemCount = itemCount
            };

        if (draft)
            return new WaiterTableStatusUi
            {
                State = WaiterTableSurfaceState.DraftOnly,
                StatusLine = "Comandă deschisă",
                TableTotal = tableTotal,
                ItemCount = itemCount
            };

        return new WaiterTableStatusUi { State = WaiterTableSurfaceState.Free, StatusLine = "Liberă" };
    }

    private static bool HasFloorAccess(out string? denyMsg)
    {
        denyMsg = null;
        var ctx = WaiterOperatorContext.Current;
        if (ctx != null)
        {
            if (ctx.HasRight("ACCES_SALA"))
                return true;
            denyMsg = "Nu aveți dreptul „Acces plan sală”.";
            return false;
        }

        var oid = AppSession.Current.OperatorId;
        if (string.IsNullOrWhiteSpace(oid))
            return true;
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            if (PosOperatorRepository.HasRight(conn, oid, "ACCES_SALA"))
                return true;
            denyMsg = "Nu aveți dreptul „Acces plan sală”.";
            return false;
        }
        catch
        {
            return true;
        }
    }

    private static bool CanAccessTable(string tableId, out string? denyMsg)
    {
        denyMsg = null;
        var ctx = WaiterOperatorContext.Current;
        if (ctx != null)
        {
            if (ctx.CanAccessTable(tableId))
                return true;
            denyMsg = ctx.AllowedTableIds?.Count == 0
                ? "Operator fără mese alocate (completați SP_POS_OPERATOR_TABLE sau activați „Toate mesele”)."
                : "Nu aveți acces la această masă (restricție operator).";
            return false;
        }

        var oid = AppSession.Current.OperatorId;
        if (string.IsNullOrWhiteSpace(oid))
            return true;

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            var allowed = PosOperatorRepository.GetAllowedTableIds(conn, oid);
            if (allowed == null)
                return true;
            if (allowed.Count == 0)
            {
                denyMsg = "Operator fără mese alocate (completați SP_POS_OPERATOR_TABLE sau activați „Toate mesele”).";
                return false;
            }

            if (allowed.Contains(tableId))
                return true;
            denyMsg = "Nu aveți acces la această masă (restricție operator).";
            return false;
        }
        catch
        {
            return true;
        }
    }

    private void OnTableClicked(FloorTableModel t)
    {
        if (!HasFloorAccess(out var denyFloor))
        {
            MessageBox.Show(denyFloor ?? "Nu aveți acces la planul sălii.", "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (!CanAccessTable(t.Id, out var denyMsg))
        {
            MessageBox.Show(denyMsg ?? "Acces refuzat la această masă.", "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (!_vmByTableId.TryGetValue(t.Id, out var vm))
            return;

        var args = new WaiterTableNavArgs
        {
            TableId = vm.TableId,
            TableName = vm.TableName,
            LevelName = vm.LevelName,
            SpaceName = vm.SpaceName
        };

        if (NavigationService != null)
            NavigationService.Navigate(new WaiterTableOrderPage(args));
    }

    private sealed class WaiterTableVm
    {
        public string TableId { get; init; } = "";
        public string LevelId { get; init; } = "";
        public string LevelName { get; init; } = "";
        public string? SpaceName { get; init; }
        public string TableName { get; init; } = "";
    }
}

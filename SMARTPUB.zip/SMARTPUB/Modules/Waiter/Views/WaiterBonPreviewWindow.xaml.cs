using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Modules.Waiter.Views;

public partial class WaiterBonPreviewWindow : Window
{
    private static readonly SolidColorBrush InkBrush = BrushFromRgb(0x19, 0x22, 0x2B);
    private static readonly SolidColorBrush MutedBrush = BrushFromRgb(0x5C, 0x68, 0x73);
    private static readonly SolidColorBrush HeaderBrush = BrushFromRgb(0x18, 0x24, 0x2E);
    private static readonly SolidColorBrush HeaderTextBrush = BrushFromRgb(0xFF, 0xFD, 0xF7);
    private static readonly SolidColorBrush ReceiptBorderBrush = BrushFromRgb(0xD8, 0xCF, 0xBF);
    private static readonly SolidColorBrush SoftRowBrush = BrushFromRgb(0xFA, 0xF4, 0xE8);
    private static readonly SolidColorBrush TotalBrush = BrushFromRgb(0xB2, 0x78, 0x2A);

    public WaiterBonPreviewWindow()
    {
        InitializeComponent();
    }

    public void SetDocument(
        string? tableLabel,
        IReadOnlyList<WaiterCartLine> lines,
        string? operatorName)
    {
        var doc = new FlowDocument
        {
            PagePadding = new Thickness(0),
            FontFamily = new FontFamily("Segoe UI"),
            FontSize = 14,
            TextAlignment = TextAlignment.Left,
            Foreground = InkBrush,
            ColumnWidth = 520
        };

        doc.Blocks.Add(new Paragraph(new Run("SMARTPUB"))
        {
            FontSize = 28,
            FontWeight = FontWeights.Bold,
            TextAlignment = TextAlignment.Center,
            Foreground = HeaderBrush,
            Margin = new Thickness(0, 0, 0, 2)
        });
        doc.Blocks.Add(new Paragraph(new Run("Bon de comandă (previzualizare)"))
        {
            FontSize = 12,
            FontWeight = FontWeights.SemiBold,
            Foreground = TotalBrush,
            TextAlignment = TextAlignment.Center,
            Margin = new Thickness(0, 0, 0, 18)
        });

        var ci = CultureInfo.CurrentCulture;
        doc.Blocks.Add(new Paragraph(new Run(DateTime.Now.ToString("dd.MM.yyyy HH:mm", ci)))
        {
            FontSize = 12,
            Foreground = MutedBrush,
            Margin = new Thickness(0, 0, 0, 8)
        });

        if (!string.IsNullOrWhiteSpace(operatorName))
        {
            doc.Blocks.Add(new Paragraph(new Run($"Ospătar: {operatorName}"))
            {
                FontSize = 12,
                Foreground = MutedBrush,
                Margin = new Thickness(0, 0, 0, 4)
            });
        }

        doc.Blocks.Add(new Paragraph(new Run(string.IsNullOrWhiteSpace(tableLabel) ? "— Masă nespecificată —" : tableLabel))
        {
            FontSize = 17,
            FontWeight = FontWeights.Bold,
            Foreground = HeaderBrush,
            Margin = new Thickness(0, 4, 0, 16)
        });

        var table = new Table { CellSpacing = 0 };
        table.Columns.Add(new TableColumn { Width = new GridLength(1, GridUnitType.Star) });
        table.Columns.Add(new TableColumn { Width = new GridLength(52) });
        table.Columns.Add(new TableColumn { Width = new GridLength(72) });
        table.Columns.Add(new TableColumn { Width = new GridLength(72) });

        var hdr = new TableRowGroup();
        var hr = new TableRow { Background = HeaderBrush };
        hr.Cells.Add(H("Articol"));
        hr.Cells.Add(H("Cant."));
        hr.Cells.Add(H("Preț"));
        hr.Cells.Add(H("Total"));
        hdr.Rows.Add(hr);
        table.RowGroups.Add(hdr);

        var body = new TableRowGroup();
        decimal sum = 0;
        foreach (var line in lines)
        {
            var lt = line.LineTotal;
            sum += lt;
            var tr = new TableRow();
            tr.Cells.Add(C(line.ProductName));
            tr.Cells.Add(C(line.Qty.ToString("0.##", ci), TextAlignment.Right));
            tr.Cells.Add(C(line.UnitPrice.ToString("N2", ci) + " lei", TextAlignment.Right));
            tr.Cells.Add(C(lt.ToString("N2", ci) + " lei", TextAlignment.Right, true));
            body.Rows.Add(tr);

            if (!string.IsNullOrWhiteSpace(line.Notes))
            {
                var noteRow = new TableRow();
                var cell = new TableCell(new Paragraph(new Run("Nota: " + line.Notes.Trim()))
                {
                    FontSize = 12,
                    Foreground = MutedBrush,
                    FontStyle = FontStyles.Italic
                })
                {
                    ColumnSpan = 4,
                    Background = SoftRowBrush,
                    BorderBrush = ReceiptBorderBrush,
                    BorderThickness = new Thickness(0.5, 0, 0.5, 0.5),
                    Padding = new Thickness(8, 4, 8, 8)
                };
                noteRow.Cells.Add(cell);
                body.Rows.Add(noteRow);
            }
        }

        table.RowGroups.Add(body);
        doc.Blocks.Add(table);

        doc.Blocks.Add(new Paragraph(new Run($"Total de plată: {sum.ToString("N2", ci)} lei"))
        {
            FontSize = 21,
            FontWeight = FontWeights.Bold,
            Foreground = TotalBrush,
            TextAlignment = TextAlignment.Right,
            Margin = new Thickness(0, 18, 0, 8)
        });

        doc.Blocks.Add(new Paragraph(new Run("Prețurile sunt informative (catalog sincronizat)."))
        {
            FontSize = 11,
            Foreground = MutedBrush,
            TextAlignment = TextAlignment.Center,
            Margin = new Thickness(0, 12, 0, 0)
        });

        DocViewer.Document = doc;
    }

    private static TableCell H(string text) =>
        new(new Paragraph(new Run(text)
        {
            FontWeight = FontWeights.Bold,
            FontSize = 12,
            Foreground = HeaderTextBrush
        }))
        {
            BorderBrush = HeaderBrush,
            BorderThickness = new Thickness(0.5),
            Padding = new Thickness(8, 8, 8, 8)
        };

    private static TableCell C(string text, TextAlignment align = TextAlignment.Left, bool isTotal = false) =>
        new(new Paragraph(new Run(text)
        {
            FontWeight = isTotal ? FontWeights.Bold : FontWeights.Normal,
            Foreground = isTotal ? TotalBrush : InkBrush
        })
        { TextAlignment = align })
        {
            BorderBrush = ReceiptBorderBrush,
            BorderThickness = new Thickness(0.5),
            Padding = new Thickness(8, 7, 8, 7)
        };

    private static SolidColorBrush BrushFromRgb(byte r, byte g, byte b)
    {
        var brush = new SolidColorBrush(Color.FromRgb(r, g, b));
        brush.Freeze();
        return brush;
    }

    private void BtnPrint_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new PrintDialog();
        if (dlg.ShowDialog() != true)
            return;
        dlg.PrintDocument(
            ((IDocumentPaginatorSource)DocViewer.Document).DocumentPaginator,
            "Bon SMARTPUB");
        AuditLogService.Write("WAITER", "BonPrinted", DateTime.Now.ToString("O", CultureInfo.InvariantCulture));
    }

    private void BtnClose_Click(object sender, RoutedEventArgs e) => Close();
}

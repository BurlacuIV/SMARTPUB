using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using System.Windows.Threading;
using SMARTPUB.Core.Session;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Modules.Waiter.Views;

public partial class WaiterTableOrderPage : Page
{
    // ───────── Static palette for category-tinted tiles ─────────
    private static readonly (Color Fg, Color Bg)[] CategoryPalette =
    {
        (Color.FromRgb(0xC9, 0x9B, 0x5D), Color.FromRgb(0xF7, 0xEE, 0xDE)),  // sand
        (Color.FromRgb(0xC9, 0x7C, 0x5D), Color.FromRgb(0xF7, 0xE7, 0xDE)),  // terra
        (Color.FromRgb(0x5D, 0x8D, 0xC9), Color.FromRgb(0xDE, 0xE9, 0xF7)),  // sky
        (Color.FromRgb(0x5F, 0xA3, 0x6C), Color.FromRgb(0xDE, 0xEF, 0xE2)),  // mint
        (Color.FromRgb(0x9C, 0x5D, 0xC9), Color.FromRgb(0xEC, 0xDE, 0xF7)),  // lavender
        (Color.FromRgb(0x5D, 0x70, 0x80), Color.FromRgb(0xE2, 0xE6, 0xEA)),  // slate
        (Color.FromRgb(0xC9, 0x5D, 0x8B), Color.FromRgb(0xF7, 0xDE, 0xE7)),  // rose
        (Color.FromRgb(0x7D, 0xA1, 0x7D), Color.FromRgb(0xE5, 0xEF, 0xE5))   // sage
    };

    // ───────── State ─────────
    private readonly WaiterTableNavArgs _args;
    private readonly ObservableCollection<WaiterCartLine> _cart;
    private readonly List<SentLine> _sentLines = new();
    private List<SyncedProductRow> _allProducts = new();
    private Dictionary<string, SyncedProductRow> _productByCode = new(StringComparer.OrdinalIgnoreCase);
    private string? _activeGroupKey;
    private bool _groupByGrupa = true;
    private bool _muteModeToggle;
    private int _persons = 2;
    private readonly DispatcherTimer _searchDebounce;

    public WaiterTableOrderPage(WaiterTableNavArgs args)
    {
        _args = args;
        _cart = WaiterDraftOrderStore.Instance.GetCart(args.TableId);
        InitializeComponent();
        ItemsDraft.ItemsSource = _cart;
        _cart.CollectionChanged += Cart_CollectionChanged;
        _searchDebounce = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(280) };
        _searchDebounce.Tick += (_, _) =>
        {
            _searchDebounce.Stop();
            ApplyFilters();
        };
        Loaded += OnLoaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        TxtMasaHeader.Text = string.IsNullOrWhiteSpace(_args.TableName)
            ? _args.DisplayTitle
            : $"Masa {_args.TableName}";

        var today = DateTime.Today;
        var n = 1 + KitchenTicketStore.Instance.GetSnapshot()
            .Count(k => string.Equals(k.TableId, _args.TableId, StringComparison.OrdinalIgnoreCase)
                        && k.CreatedLocalDisplay.Date == today);

        var zoneText = string.IsNullOrWhiteSpace(_args.SpaceName) ? _args.LevelName : $"{_args.LevelName} · {_args.SpaceName}";
        if (string.IsNullOrWhiteSpace(zoneText)) zoneText = "—";
        TxtComandaSubtitle.Text = $"Comanda {n} · {today:dd.MM.yyyy}  ·  {zoneText}";

        // Operator badge
        var opName = AppSession.Current.OperatorName;
        if (string.IsNullOrWhiteSpace(opName)) opName = "Ospătar";
        TxtOperatorName.Text = opName;
        TxtOperatorInitial.Text = char.ToUpperInvariant(opName.Trim()[0]).ToString();

        TxtPersons.Text = _persons.ToString();

        TbGrupa.IsChecked = true;
        TbGestiune.IsChecked = false;

        ReloadProductsFromCache();
        TxtSearch.Text = "";
        UpdateSearchUiState();

        LoadSentLines();
        RefreshOrderVisibility();
        UpdateTotals();
    }

    private void Cart_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        RefreshOrderVisibility();
        UpdateTotals();
    }

    // ─────────────────────── Sent lines ──────────────────────────
    private void LoadSentLines()
    {
        _sentLines.Clear();
        var tickets = KitchenTicketStore.Instance.GetSnapshot()
            .Where(k => string.Equals(k.TableId, _args.TableId, StringComparison.OrdinalIgnoreCase))
            .Where(k => k.Status is not KitchenTicketStatus.Served and not KitchenTicketStatus.Cancelled)
            .OrderBy(k => k.CreatedAtUtc)
            .ToList();

        var consumedSent = WaiterTableSplitService.Instance
            .EnsureSession(_args.TableId, _persons).ConsumedSentQty;

        foreach (var ticket in tickets)
            foreach (var line in ticket.Lines)
            {
                var key = WaiterSplitPoolLine.BuildKey(WaiterSplitSourceKind.Sent, line.ProductCode, line.UnitPrice, line.Notes);
                consumedSent.TryGetValue(key, out var alreadyPaid);
                var qty = line.Qty - alreadyPaid;
                if (qty < 0.01m) continue;

                var existing = _sentLines.FirstOrDefault(x =>
                    x.ProductCode == line.ProductCode && x.UnitPrice == line.UnitPrice &&
                    string.Equals(x.GestiuneCode, line.GestiuneCode, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals((x.Notes ?? "").Trim(), (line.Notes ?? "").Trim(), StringComparison.OrdinalIgnoreCase));
                if (existing != null) existing.Qty += qty;
                else
                {
                    _productByCode.TryGetValue(line.ProductCode, out var prod);
                    var tva = prod?.Tva ?? 0;
                    _sentLines.Add(new SentLine
                    {
                        ProductCode = line.ProductCode,
                        ProductName = line.ProductName,
                        GestiuneCode = line.GestiuneCode,
                        GestiuneName = line.GestiuneName,
                        Qty = qty,
                        UnitPrice = line.UnitPrice,
                        TvaPct = tva,
                        Notes = line.Notes
                    });
                }
            }

        SentItemsList.ItemsSource = null;
        SentItemsList.ItemsSource = _sentLines;
    }

    private void RefreshOrderVisibility()
    {
        var hasSent  = _sentLines.Count > 0;
        var hasDraft = _cart.Count > 0;

        SentSection.Visibility = hasSent ? Visibility.Visible : Visibility.Collapsed;
        DraftHeader.Visibility = (hasSent && hasDraft) ? Visibility.Visible : Visibility.Collapsed;
        TxtEmptyHint.Visibility = (!hasSent && !hasDraft) ? Visibility.Visible : Visibility.Collapsed;

        // Sent/draft chips in header
        if (hasSent)
        {
            var sentQty = _sentLines.Sum(x => x.Qty);
            TxtChipSent.Text = $"{sentQty:0.##} trimise";
            TxtSentCount.Text = $"·  {_sentLines.Count} {(_sentLines.Count == 1 ? "articol" : "articole")}";
            ChipSent.Visibility = Visibility.Visible;
        }
        else
        {
            ChipSent.Visibility = Visibility.Collapsed;
            TxtSentCount.Text = "";
        }

        if (hasDraft)
        {
            var draftQty = _cart.Sum(x => x.Qty);
            TxtChipDraft.Text = $"{draftQty:0.##} în coș";
            TxtDraftCount.Text = $"·  {_cart.Count} {(_cart.Count == 1 ? "articol" : "articole")}";
            ChipDraft.Visibility = Visibility.Visible;
        }
        else
        {
            ChipDraft.Visibility = Visibility.Collapsed;
            TxtDraftCount.Text = "";
        }

        // Enable/disable contextual buttons
        BtnSend.Opacity = hasDraft ? 1.0 : 0.55;
        BtnSend.IsEnabled = hasDraft;
        BtnPay.Opacity  = (hasSent || hasDraft) ? 1.0 : 0.55;
        BtnPay.IsEnabled = hasSent || hasDraft;
    }

    // ─────────────────────── Catalog ─────────────────────────────
    private void ReloadProductsFromCache()
    {
        try
        {
            _allProducts = WaiterProductCatalogCache.Instance.GetSnapshotForCurrentOperator().ToList();
        }
        catch
        {
            _allProducts = new List<SyncedProductRow>();
        }

        _productByCode = _allProducts.ToDictionary(p => p.Code, StringComparer.OrdinalIgnoreCase);
        _activeGroupKey = null;
        RebuildGroupChips();
        ApplyFilters();
    }

    private static bool OpHas(string rightCode)
    {
        if (string.IsNullOrWhiteSpace(AppSession.Current.OperatorId))
            return true;
        var ctx = WaiterOperatorContext.Current;
        if (ctx != null)
            return ctx.HasRight(rightCode);
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            return PosOperatorRepository.HasRight(conn, AppSession.Current.OperatorId, rightCode);
        }
        catch
        {
            return true;
        }
    }

    private static void DenyRight() =>
        MessageBox.Show("Nu aveti dreptul pentru aceasta actiune. Configurati drepturile in 'Configurare ospatari'.",
            "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Information);

    private void TbGrupa_OnChecked(object sender, RoutedEventArgs e)
    {
        if (_muteModeToggle) return;
        _muteModeToggle = true; TbGestiune.IsChecked = false; _muteModeToggle = false;
        _groupByGrupa = true;
        _activeGroupKey = null;
        RebuildGroupChips();
        ApplyFilters();
    }

    private void TbGestiune_OnChecked(object sender, RoutedEventArgs e)
    {
        if (_muteModeToggle) return;
        _muteModeToggle = true; TbGrupa.IsChecked = false; _muteModeToggle = false;
        _groupByGrupa = false;
        _activeGroupKey = null;
        RebuildGroupChips();
        ApplyFilters();
    }

    private static string NormalizeGrupa(SyncedProductRow p)
    {
        var g = (p.GrupaAfisat ?? "").Trim();
        if (g.Length > 0) return g;
        g = (p.Grupa ?? "").Trim();
        return g.Length > 0 ? g : "(Fara grupa)";
    }

    private static string NormalizeGestiune(SyncedProductRow p)
    {
        var g = (p.GestiuneAfisat ?? "").Trim();
        if (g.Length > 0) return g;
        g = (p.Gestiune ?? "").Trim();
        return g.Length > 0 ? g : "(Fara gestiune)";
    }

    private void RebuildGroupChips()
    {
        WrapGroups.Children.Clear();
        var toateLabel = _groupByGrupa
            ? $"Toate ({_allProducts.Count})"
            : $"Toate ({_allProducts.Count})";
        AddGroupChip(toateLabel, null, _activeGroupKey == null);

        var groups = _groupByGrupa
            ? _allProducts.GroupBy(NormalizeGrupa).OrderBy(g => g.Key)
            : _allProducts.GroupBy(NormalizeGestiune).OrderBy(g => g.Key);

        foreach (var kv in groups)
            AddGroupChip(kv.Key, kv.Count(), kv.Key,
                string.Equals(_activeGroupKey, kv.Key, StringComparison.OrdinalIgnoreCase));
    }

    private void AddGroupChip(string label, string? key, bool selected)
    {
        var b = new Button
        {
            Content = label,
            Padding = new Thickness(12, 7, 12, 7),
            Margin  = new Thickness(0, 0, 8, 8),
            Tag = key,
            Cursor = Cursors.Hand,
            FontSize = 12, FontWeight = FontWeights.SemiBold,
            BorderThickness = new Thickness(1.5)
        };
        if (selected)
        {
            b.Background = new SolidColorBrush(Color.FromRgb(0xEA, 0xF3, 0xDF));
            b.Foreground = (Brush)Application.Current.FindResource("TextPrimaryBrush");
            b.BorderBrush = (Brush)Application.Current.FindResource("PrimaryPistachioBrush");
        }
        else
        {
            b.Background = Brushes.White;
            b.Foreground = (Brush)Application.Current.FindResource("TextPrimaryBrush");
            b.BorderBrush = new SolidColorBrush(Color.FromRgb(0xE3, 0xE7, 0xDF));
        }
        b.Click += GroupChip_Click;
        WrapGroups.Children.Add(b);
    }

    private void AddGroupChip(string key, int count, string fullKey, bool selected)
    {
        var (fg, bg) = CategoryColorFor(key);
        var b = new Button
        {
            Padding = new Thickness(10, 6, 12, 6),
            Margin  = new Thickness(0, 0, 8, 8),
            Tag = fullKey,
            Cursor = Cursors.Hand,
            BorderThickness = new Thickness(1.5)
        };
        var stack = new StackPanel { Orientation = Orientation.Horizontal };
        stack.Children.Add(new Border
        {
            Width = 8, Height = 8,
            CornerRadius = new CornerRadius(4),
            Background = new SolidColorBrush(fg),
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(0, 0, 8, 0)
        });
        stack.Children.Add(new TextBlock
        {
            Text = key,
            FontSize = 12, FontWeight = FontWeights.SemiBold,
            VerticalAlignment = VerticalAlignment.Center
        });
        stack.Children.Add(new Border
        {
            Background = selected ? new SolidColorBrush(Color.FromRgb(0xD9, 0xEA, 0xCB)) : new SolidColorBrush(bg),
            CornerRadius = new CornerRadius(7),
            Padding = new Thickness(6, 1, 6, 1),
            Margin = new Thickness(8, 0, 0, 0),
            VerticalAlignment = VerticalAlignment.Center,
            Child = new TextBlock
            {
                Text = count.ToString(),
                FontSize = 10, FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(fg)
            }
        });
        b.Content = stack;
        if (selected)
        {
            b.Background = new SolidColorBrush(Color.FromRgb(0xEA, 0xF3, 0xDF));
            b.Foreground = (Brush)Application.Current.FindResource("TextPrimaryBrush");
            b.BorderBrush = (Brush)Application.Current.FindResource("PrimaryPistachioBrush");
        }
        else
        {
            b.Background = Brushes.White;
            b.Foreground = (Brush)Application.Current.FindResource("TextPrimaryBrush");
            b.BorderBrush = new SolidColorBrush(Color.FromRgb(0xE3, 0xE7, 0xDF));
        }
        b.Click += GroupChip_Click;
        WrapGroups.Children.Add(b);
    }

    private void GroupChip_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button btn) return;
        _activeGroupKey = btn.Tag as string;
        RebuildGroupChips();
        ApplyFilters();
    }

    private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
        UpdateSearchUiState();
        _searchDebounce.Stop();
        _searchDebounce.Start();
    }

    private void UpdateSearchUiState()
    {
        var hasText = !string.IsNullOrEmpty(TxtSearch.Text);
        TxtSearchPlaceholder.Visibility = hasText ? Visibility.Collapsed : Visibility.Visible;
        BtnClearSearch.Visibility = hasText ? Visibility.Visible : Visibility.Collapsed;
    }

    private void BtnClearSearch_Click(object sender, RoutedEventArgs e) => TxtSearch.Text = "";

    private void ApplyFilters()
    {
        IEnumerable<SyncedProductRow> rows = _allProducts;
        var q = (TxtSearch.Text ?? "").Trim();
        if (q.Length > 0)
            rows = rows.Where(p =>
                p.Name.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                p.Code.Contains(q, StringComparison.OrdinalIgnoreCase));

        if (!string.IsNullOrEmpty(_activeGroupKey))
        {
            rows = _groupByGrupa
                ? rows.Where(p => string.Equals(NormalizeGrupa(p), _activeGroupKey, StringComparison.OrdinalIgnoreCase))
                : rows.Where(p => string.Equals(NormalizeGestiune(p), _activeGroupKey, StringComparison.OrdinalIgnoreCase));
        }

        var list = rows
            .OrderBy(p => _groupByGrupa ? NormalizeGrupa(p) : NormalizeGestiune(p))
            .ThenBy(p => p.Name)
            .ToList();

        var tiles = list.Select(BuildTileVm).ToList();
        ItemsProducts.ItemsSource = tiles;

        TxtCatalogInfo.Text = $"{list.Count} produse";
    }

    private ProductTileVm BuildTileVm(SyncedProductRow p)
    {
        var cat = _groupByGrupa ? NormalizeGrupa(p) : NormalizeGestiune(p);
        var (fg, bg) = CategoryColorFor(cat);
        return new ProductTileVm
        {
            Product       = p,
            Name          = p.Name,
            Initial       = string.IsNullOrWhiteSpace(p.Name) ? "?" : char.ToUpperInvariant(p.Name.Trim()[0]).ToString(),
            CategoryName  = cat,
            PriceText     = p.PretVanz.ToString("N2", CultureInfo.CurrentCulture) + " lei",
            CategoryBrush   = new SolidColorBrush(fg),
            CategoryBgBrush = new SolidColorBrush(bg)
        };
    }

    private static (Color Fg, Color Bg) CategoryColorFor(string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) return CategoryPalette[5];
        unchecked
        {
            var h = 17;
            foreach (var c in name) h = h * 31 + c;
            var idx = Math.Abs(h) % CategoryPalette.Length;
            return CategoryPalette[idx];
        }
    }

    private void BtnGroupScrollLeft_Click(object sender, RoutedEventArgs e) =>
        ScrollGroupChips.ScrollToHorizontalOffset(Math.Max(0, ScrollGroupChips.HorizontalOffset - 180));

    private void BtnGroupScrollRight_Click(object sender, RoutedEventArgs e)
    {
        var max = Math.Max(0, ScrollGroupChips.ExtentWidth - ScrollGroupChips.ViewportWidth);
        ScrollGroupChips.ScrollToHorizontalOffset(Math.Min(max, ScrollGroupChips.HorizontalOffset + 180));
    }

    // ─────────────────────── Persons stepper ─────────────────────
    private void BtnPersonsMinus_Click(object sender, RoutedEventArgs e)
    {
        _persons = Math.Max(1, _persons - 1);
        TxtPersons.Text = _persons.ToString();
        OnPersonsChanged();
    }
    private void BtnPersonsPlus_Click(object sender, RoutedEventArgs e)
    {
        _persons = Math.Min(99, _persons + 1);
        TxtPersons.Text = _persons.ToString();
        OnPersonsChanged();
    }

    partial void OnPersonsChanged();

    // ─────────────────────── Qty toolbar ─────────────────────────
    private void BtnAddQtyMinus_Click(object sender, RoutedEventArgs e)
    {
        var v = ReadQtyToolbar();
        v = Math.Max(0.5m, v - 1m);
        TxtQty.Text = v.ToString("0.##", CultureInfo.InvariantCulture);
    }
    private void BtnAddQtyPlus_Click(object sender, RoutedEventArgs e)
    {
        var v = ReadQtyToolbar();
        v = Math.Min(999m, v + 1m);
        TxtQty.Text = v.ToString("0.##", CultureInfo.InvariantCulture);
    }

    private decimal ReadQtyToolbar()
    {
        var t = (TxtQty.Text ?? "").Trim().Replace(',', '.');
        return decimal.TryParse(t, NumberStyles.Any, CultureInfo.InvariantCulture, out var v) ? v : 1m;
    }

    // ─────────────────────── Add product ─────────────────────────
    private void ProductTile_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is not FrameworkElement fe || fe.DataContext is not ProductTileVm vm) return;
        e.Handled = true;
        AddProduct(vm.Product);
    }

    private void AddProduct(SyncedProductRow p)
    {
        if (!OpHas("VINDE_ARTICOL")) { DenyRight(); return; }

        var qty = ReadQtyToolbar();
        if (qty <= 0) qty = 1;

        var gestCode = (p.Gestiune ?? "").Trim();
        var gestName = (p.GestiuneAfisat ?? "").Trim();
        if (gestCode.Length == 0)
        {
            var choice = LoadSavedGestiuneForProduct(p.Code) ?? PickGestiuneForProduct(Window.GetWindow(this), p);
            if (choice == null)
                return;

            gestCode = choice.Code;
            gestName = choice.Name;
        }

        var existing = _cart.FirstOrDefault(x =>
            x.ProductCode == p.Code &&
            string.Equals(x.GestiuneCode, gestCode, StringComparison.OrdinalIgnoreCase));
        if (existing != null) { existing.Qty += qty; UpdateTotals(); return; }

        _cart.Add(new WaiterCartLine
        {
            ProductCode = p.Code,
            ProductName = p.Name,
            GestiuneCode = gestCode,
            GestiuneName = gestName,
            UnitPrice   = p.PretVanz,
            TvaPct      = p.Tva,
            Qty         = qty
        });
    }

    // ─────────────────────── Inline line +/-/X ───────────────────
    private void BtnLineMinus_Click(object sender, RoutedEventArgs e)
    {
        if (!OpHas("EDIT_CANTITATE")) { DenyRight(); return; }
        if (sender is not Button b || b.DataContext is not WaiterCartLine line) return;
        if (line.Qty <= 1)
        {
            if (MessageBox.Show($"Sterg linia '{line.ProductName}'?", "Confirmare",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                _cart.Remove(line);
            return;
        }
        line.Qty = Math.Max(0.01m, line.Qty - 1m);
        UpdateTotals();
    }

    private void BtnLinePlus_Click(object sender, RoutedEventArgs e)
    {
        if (!OpHas("EDIT_CANTITATE")) { DenyRight(); return; }
        if (sender is not Button b || b.DataContext is not WaiterCartLine line) return;
        line.Qty += 1m;
        UpdateTotals();
    }

    private void BtnLineRemove_Click(object sender, RoutedEventArgs e)
    {
        if (!OpHas("STERGE_LINIE")) { DenyRight(); return; }
        if (sender is not Button b || b.DataContext is not WaiterCartLine line) return;
        _cart.Remove(line);
    }

    // ─────────────────────── Totals ──────────────────────────────
    private void UpdateTotals()
    {
        var ci = CultureInfo.CurrentCulture;
        var sentSum  = _sentLines.Sum(x => x.LineTotal);
        var draftSum = _cart.Sum(x => x.LineTotal);
        var total = sentSum + draftSum;
        TxtRightTotal.Text   = total.ToString("N2", ci) + " lei";
        TxtBtnPayAmount.Text = total.ToString("N2", ci) + " lei";
    }

    // ─────────────────────── Navigation ──────────────────────────
    private void BtnBack_Click(object sender, RoutedEventArgs e)
    {
        if (NavigationService?.CanGoBack == true) NavigationService.GoBack();
        else NavigationService?.Navigate(new WaiterFloorPage());
    }

    // ─────────────────────── Send to kitchen ─────────────────────
    private void BtnSendKitchen_Click(object sender, RoutedEventArgs e)
    {
        if (!OpHas("TRIMITE_BUCATARIE")) { DenyRight(); return; }
        if (_cart.Count == 0)
        {
            MessageBox.Show("Adauga cel putin un articol.", "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var kitchenLines = new List<WaiterCartLine>();
        var barLines = new List<WaiterCartLine>();
        var fallbackKitchenLines = new List<WaiterCartLine>();
        var printByGestiune = new Dictionary<string, List<WaiterCartLine>>(StringComparer.OrdinalIgnoreCase);
        ProgramSettingsRow settings;
        var useGestiunePrinters = false;

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            var routing = new OrderRoutingRepository();
            var groupMap = routing.LoadGroupMap(conn);
            settings = new ProgramSettingsRepository().Load(conn);
            var saleSettings = new ProgramSaleSettingsRepository().Load(conn);
            useGestiunePrinters = string.Equals(
                saleSettings.TiparireComandaFerma, "Gestiune", StringComparison.OrdinalIgnoreCase);

            if (useGestiunePrinters)
            {
                var gestPrinterRepo = new PosGestiunePrinterRepository();
                var gestPrinters = gestPrinterRepo.LoadMap(conn);
                var artGestiuni = PosGestiunePrinterRepository.LoadArticleGestiuni(
                    conn, _cart.Select(c => c.ProductCode));

                foreach (var line in _cart)
                {
                    var gestCode = (line.GestiuneCode ?? "").Trim();
                    if (gestCode.Length == 0)
                        artGestiuni.TryGetValue(line.ProductCode, out gestCode);
                    gestCode = (gestCode ?? "").Trim();

                    if (gestCode.Length > 0 &&
                        gestPrinters.TryGetValue(gestCode, out var printer) &&
                        !string.IsNullOrWhiteSpace(printer))
                    {
                        if (!printByGestiune.TryGetValue(printer, out var batch))
                        {
                            batch = new List<WaiterCartLine>();
                            printByGestiune[printer] = batch;
                        }

                        batch.Add(line);

                        if (string.Equals(printer, settings.PrinterKitchen, StringComparison.OrdinalIgnoreCase))
                            kitchenLines.Add(line);
                        continue;
                    }

                    var dest = routing.ResolveForArticle(conn, groupMap, line.ProductCode);
                    if (dest == OrderDestination.Bar)
                        barLines.Add(line);
                    else
                    {
                        fallbackKitchenLines.Add(line);
                        kitchenLines.Add(line);
                    }
                }
            }
            else
            {
                foreach (var line in _cart)
                {
                    var dest = routing.ResolveForArticle(conn, groupMap, line.ProductCode);
                    if (dest == OrderDestination.Bar) barLines.Add(line);
                    else kitchenLines.Add(line);
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Nu am putut citi configurarea de rutare.\n" + ex.Message,
                "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        var tableLabel = string.IsNullOrWhiteSpace(_args.TableName) ? _args.DisplayTitle : $"Masa {_args.TableName}";
        var op = AppSession.Current.OperatorName;
        var warnings = new List<string>();

        if (kitchenLines.Count > 0)
        {
            KitchenTicketStore.Instance.AddTicket(new KitchenTicket
            {
                TableId = _args.TableId,
                TableDisplayName = _args.TableName,
                LevelName = _args.LevelName,
                SpaceName = _args.SpaceName,
                SourceOperator = op,
                Lines = kitchenLines.Select(c => new KitchenTicketLine
                {
                    ProductCode = c.ProductCode,
                    ProductName = c.ProductName,
                    GestiuneCode = c.GestiuneCode,
                    GestiuneName = c.GestiuneName,
                    Qty = c.Qty,
                    UnitPrice = c.UnitPrice,
                    Notes = string.IsNullOrWhiteSpace(c.Notes) ? null : c.Notes.Trim()
                }).ToList()
            });
        }

        if (useGestiunePrinters)
        {
            foreach (var kv in printByGestiune)
            {
                try
                {
                    OrderTicketPrintService.Print(kv.Key, kv.Key, tableLabel, op, kv.Value);
                }
                catch (Exception ex)
                {
                    warnings.Add(ex.Message);
                }
            }

            if (barLines.Count > 0)
            {
                try
                {
                    OrderTicketPrintService.Print(settings.PrinterBar, "Bar", tableLabel, op, barLines);
                }
                catch (Exception ex)
                {
                    warnings.Add(ex.Message);
                }
            }

            if (fallbackKitchenLines.Count > 0)
            {
                try
                {
                    OrderTicketPrintService.Print(
                        settings.PrinterKitchen, "Bucătărie", tableLabel, op, fallbackKitchenLines);
                }
                catch (Exception ex)
                {
                    warnings.Add(ex.Message);
                }
            }
        }
        else
        {
            if (kitchenLines.Count > 0)
            {
                try
                {
                    OrderTicketPrintService.Print(settings.PrinterKitchen, "Bucătărie", tableLabel, op, kitchenLines);
                }
                catch (Exception ex)
                {
                    warnings.Add(ex.Message);
                }
            }

            if (barLines.Count > 0)
            {
                try
                {
                    OrderTicketPrintService.Print(settings.PrinterBar, "Bar", tableLabel, op, barLines);
                }
                catch (Exception ex)
                {
                    warnings.Add(ex.Message);
                }
            }
        }

        WaiterDraftOrderStore.Instance.Clear(_args.TableId);

        var printedGest = printByGestiune.Values.Sum(v => v.Count);
        var msg = useGestiunePrinters
            ? $"Comandă trimisă: {printedGest} linii pe imprimante gestiuni, {barLines.Count} la bar (fallback), {kitchenLines.Count} pe KDS."
            : $"Comanda trimisa: {kitchenLines.Count} la bucatarie, {barLines.Count} la bar.";
        if (warnings.Count > 0) msg += "\n\nAtentie:\n• " + string.Join("\n• ", warnings.Distinct());

        MessageBox.Show(msg, "SMARTPUB", MessageBoxButton.OK,
            warnings.Count > 0 ? MessageBoxImage.Warning : MessageBoxImage.Information);

        LoadSentLines();
        RefreshOrderVisibility();
        UpdateTotals();
    }

    // ─────────────────────── Bon previz ──────────────────────────
    private void BtnBon_Click(object sender, RoutedEventArgs e)
    {
        if (!OpHas("BON_PREVIZ")) { DenyRight(); return; }
        var allLines = BuildAllLines();
        if (allLines.Count == 0)
        {
            MessageBox.Show("Nu exista linii pe bon.", "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var w = new WaiterBonPreviewWindow { Owner = Window.GetWindow(this) };
        w.SetDocument(_args.DisplayTitle, allLines, AppSession.Current.OperatorName);
        w.ShowDialog();
    }

    private void BtnClientNote_Click(object sender, RoutedEventArgs e)
    {
        if (!OpHas("NOTA_CLIENT_F7")) { DenyRight(); return; }
        MessageBox.Show(
            "Legarea clientului pentru factura (date firma, CIF) va fi disponibila intr-o versiune urmatoare, integrata cu modulul fiscal.",
            "Nota client", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    // ─────────────────────── Încasare ───────────────────────────
    private void BtnPayment_Click(object sender, RoutedEventArgs e)
    {
        if (!OpHas("INCASARE")) { DenyRight(); return; }
        var allLines = BuildAllLines();
        if (allLines.Count == 0)
        {
            MessageBox.Show("Nu exista linii de incasat.", "Incasare",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (_persons > 1)
        {
            var r = MessageBox.Show(
                $"Masa are {_persons} persoane.\n\nDeschizi Split note PRO pentru încasări separate?\n\nDa = split · Nu = încasare totală o singură dată",
                "Încasare",
                MessageBoxButton.YesNoCancel,
                MessageBoxImage.Question);
            if (r == MessageBoxResult.Cancel) return;
            if (r == MessageBoxResult.Yes)
            {
                OpenSplitMode();
                return;
            }
        }

        var owner = Window.GetWindow(this);
        var total = allLines.Sum(x => x.LineTotal);
        var tableLabel = string.IsNullOrWhiteSpace(_args.TableName) ? _args.DisplayTitle : $"Masa {_args.TableName}";
        var payResult = PickModPlata(owner, total, tableLabel);
        if (payResult == null) return;

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchemaForce(conn);
            var saleId = PosSaleRepository.CreateSaleFromCart(
                conn,
                _args.TableId,
                tableLabel,
                AppSession.Current.OperatorId,
                AppSession.Current.OperatorName,
                payResult.Method,
                allLines,
                BuildPaymentInputs(payResult));

            var activeTicketIds = KitchenTicketStore.Instance.GetSnapshot()
                .Where(k => string.Equals(k.TableId, _args.TableId, StringComparison.OrdinalIgnoreCase))
                .Where(k => k.Status is not KitchenTicketStatus.Served and not KitchenTicketStatus.Cancelled)
                .Select(k => k.Id)
                .ToList();
            foreach (var id in activeTicketIds)
                KitchenTicketStore.Instance.UpdateStatus(id, KitchenTicketStatus.Served);

            WaiterDraftOrderStore.Instance.Clear(_args.TableId);
            WaiterTableSplitService.Instance.ClearSession(_args.TableId);
            _cart.Clear();

            var transferMsg = TryAutoTransferAfterPayment(saleId);
            var confirmMsg = payResult.Method == "Mixt"
                ? $"Incasare inregistrata.\n\n  Card:    {payResult.CardAmount:N2} lei\n  Numerar: {payResult.CashAmount:N2} lei"
                : "Incasarea a fost inregistrata. Vanzarea apare in Administrare → POS Restaurant → Vanzari.";
            if (!string.IsNullOrWhiteSpace(transferMsg))
                confirmMsg += "\n\n" + transferMsg;
            MessageBox.Show(confirmMsg, "Incasare", MessageBoxButton.OK, MessageBoxImage.Information);

            if (NavigationService?.CanGoBack == true) NavigationService.GoBack();
            else NavigationService?.Navigate(new WaiterFloorPage());
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Incasare", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BtnClear_Click(object sender, RoutedEventArgs e)
    {
        if (!OpHas("GOLESTE_COS")) { DenyRight(); return; }
        if (_cart.Count == 0) return;
        if (MessageBox.Show("Golesti toate liniile din cos?", "Confirmare",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;
        _cart.Clear();
    }

    // ─────────────────────── Hotkeys ─────────────────────────────
    private void Page_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.F7) { BtnClientNote_Click(sender, e); e.Handled = true; return; }
        if (e.Key == Key.F11) { AdjustLastLine(-1m); e.Handled = true; return; }
        if (e.Key == Key.F12) { AdjustLastLine(+1m); e.Handled = true; }
    }

    private void AdjustLastLine(decimal delta)
    {
        if (!OpHas("EDIT_CANTITATE")) { DenyRight(); return; }
        if (_cart.Count == 0) return;
        var last = _cart[^1];
        if (delta < 0 && last.Qty <= 1)
        {
            _cart.Remove(last);
            return;
        }
        last.Qty = Math.Max(0.01m, last.Qty + delta);
        UpdateTotals();
    }

    // ─────────────────────── Helpers ─────────────────────────────
    private List<WaiterCartLine> BuildAllLines()
    {
        var lines = _sentLines.Select(s => new WaiterCartLine
        {
            ProductCode = s.ProductCode,
            ProductName = s.ProductName,
            GestiuneCode = s.GestiuneCode,
            GestiuneName = s.GestiuneName,
            UnitPrice   = s.UnitPrice,
            TvaPct      = s.TvaPct,
            Qty         = s.Qty,
            Notes       = s.Notes ?? ""
        }).ToList();
        lines.AddRange(_cart);
        return lines;
    }

    // ─────────────────────── Payment dialog ──────────────────────
    private static PaymentResult? PickModPlata(Window? owner, decimal total, string tableLabel)
    {
        PaymentResult? result = null;

        var dlg = new Window
        {
            Title = "Incasare",
            Width = 520, Height = 440,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            Owner = owner,
            ResizeMode = ResizeMode.NoResize,
            ShowInTaskbar = false,
            Background = new SolidColorBrush(Color.FromRgb(0xF7, 0xF7, 0xF2))
        };

        var root = new Grid { Margin = new Thickness(26, 20, 26, 20) };
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var headerStack = new StackPanel();
        headerStack.Children.Add(new TextBlock
        {
            Text = $"Incasare — {tableLabel}",
            FontSize = 17, FontWeight = FontWeights.SemiBold,
            Foreground = new SolidColorBrush(Color.FromRgb(0x27, 0x32, 0x3A)),
            Margin = new Thickness(0, 0, 0, 10)
        });

        var totalCard = new Border
        {
            CornerRadius = new CornerRadius(12),
            Padding = new Thickness(20, 12, 20, 12),
            Margin = new Thickness(0, 0, 0, 14),
            Effect = new DropShadowEffect { BlurRadius = 14, ShadowDepth = 3, Opacity = 0.14, Color = Color.FromRgb(0x6B, 0x57, 0x32) }
        };
        totalCard.Background = new LinearGradientBrush
        {
            StartPoint = new Point(0, 0), EndPoint = new Point(1, 1),
            GradientStops = { new GradientStop(Color.FromRgb(0xFF,0xFF,0xFF), 0), new GradientStop(Color.FromRgb(0xFF,0xF3,0xDA), 1) }
        };
        var totalPanel = new StackPanel();
        totalPanel.Children.Add(new TextBlock
        {
            Text = "Total de plata",
            FontSize = 11,
            Foreground = new SolidColorBrush(Color.FromRgb(0x66, 0x74, 0x64))
        });
        totalPanel.Children.Add(new TextBlock
        {
            Text = total.ToString("N2", CultureInfo.CurrentCulture) + " lei",
            FontSize = 32, FontWeight = FontWeights.Bold,
            Foreground = new SolidColorBrush(Color.FromRgb(0xD8, 0xB2, 0x6E))
        });
        totalCard.Child = totalPanel;
        headerStack.Children.Add(totalCard);
        Grid.SetRow(headerStack, 0);
        root.Children.Add(headerStack);

        var btnPanel = new Grid { VerticalAlignment = VerticalAlignment.Stretch };
        btnPanel.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        btnPanel.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(10) });
        btnPanel.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        btnPanel.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(10) });
        btnPanel.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        var mixtPanel = new Grid { Visibility = Visibility.Collapsed };
        mixtPanel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        mixtPanel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        mixtPanel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        mixtPanel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var lblCard = new TextBlock
        {
            Text = "Suma platita cu CARD (lei)",
            FontSize = 12, FontWeight = FontWeights.SemiBold,
            Foreground = new SolidColorBrush(Color.FromRgb(0x27, 0x32, 0x3A)),
            Margin = new Thickness(0, 0, 0, 6)
        };
        Grid.SetRow(lblCard, 0);
        mixtPanel.Children.Add(lblCard);

        var txtCard = new TextBox
        {
            FontSize = 28, FontWeight = FontWeights.Bold,
            Text = "0", TextAlignment = TextAlignment.Center,
            Padding = new Thickness(12, 10, 12, 10),
            Margin = new Thickness(0, 0, 0, 14),
            BorderBrush = new SolidColorBrush(Color.FromRgb(0x8B, 0xB4, 0xCE)),
            BorderThickness = new Thickness(2)
        };
        Grid.SetRow(txtCard, 1);
        mixtPanel.Children.Add(txtCard);

        var cashBorder = new Border
        {
            CornerRadius = new CornerRadius(10),
            Padding = new Thickness(16, 10, 16, 10),
            Margin = new Thickness(0, 0, 0, 16),
            Background = new SolidColorBrush(Color.FromRgb(0xEE, 0xF6, 0xE8))
        };
        var cashStack = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center };
        cashStack.Children.Add(new TextBlock { Text = "Numerar: ", FontSize = 14, Foreground = new SolidColorBrush(Color.FromRgb(0x2E, 0x7D, 0x32)) });
        var lblCash = new TextBlock
        {
            Text = total.ToString("N2", CultureInfo.CurrentCulture) + " lei",
            FontSize = 18, FontWeight = FontWeights.Bold,
            Foreground = new SolidColorBrush(Color.FromRgb(0x1B, 0x5E, 0x20))
        };
        cashStack.Children.Add(lblCash);
        cashBorder.Child = cashStack;
        Grid.SetRow(cashBorder, 2);
        mixtPanel.Children.Add(cashBorder);

        txtCard.TextChanged += (_, _) =>
        {
            var s = (txtCard.Text ?? "").Replace(',', '.');
            if (!decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out var cardAmt)) cardAmt = 0;
            cardAmt = Math.Max(0, Math.Min(total, cardAmt));
            lblCash.Text = (total - cardAmt).ToString("N2", CultureInfo.CurrentCulture) + " lei";
        };

        var btnConfirmMixt = new Button
        {
            Content = "Confirma plata mixta",
            FontSize = 14, FontWeight = FontWeights.Bold,
            Padding = new Thickness(20, 12, 20, 12),
            Cursor = Cursors.Hand,
            Style = (Style)Application.Current.FindResource("SuccessButtonStyle"),
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        btnConfirmMixt.Click += (_, _) =>
        {
            var s = (txtCard.Text ?? "").Replace(',', '.');
            decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out var cardAmt);
            cardAmt = Math.Max(0, Math.Min(total, cardAmt));
            result = new PaymentResult("Mixt", cardAmt, total - cardAmt);
            dlg.DialogResult = true; dlg.Close();
        };
        Grid.SetRow(btnConfirmMixt, 3);
        mixtPanel.Children.Add(btnConfirmMixt);

        var contentStack = new StackPanel();
        contentStack.Children.Add(btnPanel);
        contentStack.Children.Add(mixtPanel);
        Grid.SetRow(contentStack, 1);
        root.Children.Add(contentStack);

        void AddPayButton(int col, string label, string subLabel, Color accent, string letter, Color letterFg)
        {
            var normalBg = Color.FromRgb(0xFF, 0xFF, 0xFF);
            var hoverBg  = Color.FromArgb(40, accent.R, accent.G, accent.B);

            var card = new Border
            {
                CornerRadius = new CornerRadius(14),
                Background = new SolidColorBrush(normalBg),
                BorderBrush = new SolidColorBrush(accent),
                BorderThickness = new Thickness(2),
                Cursor = Cursors.Hand,
                Effect = new DropShadowEffect { BlurRadius = 10, ShadowDepth = 2, Opacity = 0.12, Color = Color.FromRgb(0x27, 0x32, 0x3A) }
            };
            var inner = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
                Margin = new Thickness(10, 14, 10, 14)
            };
            inner.Children.Add(new Border
            {
                Width = 52, Height = 52,
                CornerRadius = new CornerRadius(26),
                Background = new SolidColorBrush(accent),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 10),
                Child = new TextBlock
                {
                    Text = letter, FontSize = 22, FontWeight = FontWeights.Bold,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                    Foreground = new SolidColorBrush(letterFg)
                }
            });
            inner.Children.Add(new TextBlock
            {
                Text = label, FontSize = 14, FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(0x27, 0x32, 0x3A)),
                HorizontalAlignment = HorizontalAlignment.Center
            });
            if (!string.IsNullOrEmpty(subLabel))
                inner.Children.Add(new TextBlock
                {
                    Text = subLabel, FontSize = 10,
                    Foreground = new SolidColorBrush(Color.FromArgb(160, 0x27, 0x32, 0x3A)),
                    HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 2, 0, 0)
                });
            card.Child = inner;
            card.MouseEnter += (_, _) => card.Background = new SolidColorBrush(hoverBg);
            card.MouseLeave += (_, _) => card.Background = new SolidColorBrush(normalBg);

            if (label == "Mixt")
                card.MouseLeftButtonDown += (_, _) =>
                {
                    btnPanel.Visibility = Visibility.Collapsed;
                    mixtPanel.Visibility = Visibility.Visible;
                    txtCard.SelectAll(); txtCard.Focus();
                };
            else
                card.MouseLeftButtonDown += (_, _) =>
                {
                    result = new PaymentResult(label, label == "Card" ? total : 0, label == "Numerar" ? total : 0);
                    dlg.DialogResult = true; dlg.Close();
                };

            Grid.SetColumn(card, col);
            btnPanel.Children.Add(card);
        }
        AddPayButton(0, "Numerar", "cash",         Color.FromRgb(0xB8, 0xD8, 0xA8), "N", Color.FromRgb(0x1F, 0x45, 0x22));
        AddPayButton(2, "Card",    "POS",          Color.FromRgb(0x8B, 0xB4, 0xCE), "C", Color.FromRgb(0x0D, 0x2E, 0x4A));
        AddPayButton(4, "Mixt",    "card + cash",  Color.FromRgb(0xD8, 0xB2, 0x6E), "M", Color.FromRgb(0x5A, 0x3C, 0x00));

        var cancelBtn = new Button
        {
            Content = "Renunta", IsCancel = true,
            HorizontalAlignment = HorizontalAlignment.Center,
            MinWidth = 120, Margin = new Thickness(0, 10, 0, 0),
            Padding = new Thickness(20, 10, 20, 10),
            Cursor = Cursors.Hand,
            Style = (Style)Application.Current.FindResource("SoftButtonStyle")
        };
        cancelBtn.Click += (_, _) => { dlg.DialogResult = false; dlg.Close(); };
        Grid.SetRow(cancelBtn, 2);
        root.Children.Add(cancelBtn);

        dlg.Content = root;
        dlg.ShowDialog();
        return result;
    }

    private static IReadOnlyList<PosSalePaymentInput> BuildPaymentInputs(PaymentResult pay)
    {
        var list = new List<PosSalePaymentInput>();
        if (pay.CashAmount > 0)
            list.Add(new PosSalePaymentInput { MethodKey = "NUMERAR", Amount = pay.CashAmount });
        if (pay.CardAmount > 0)
            list.Add(new PosSalePaymentInput { MethodKey = "CARD", Amount = pay.CardAmount });
        if (list.Count == 0)
            list.Add(new PosSalePaymentInput { MethodKey = pay.Method, Amount = 0 });
        return list;
    }

    private static GestiuneChoice? PickGestiuneForProduct(Window? owner, SyncedProductRow product)
    {
        var gestiuni = LoadGestiuniChoices();
        if (gestiuni.Count == 0)
        {
            MessageBox.Show(
                "Articolul nu are gestiune și nu există gestiuni sincronizate.\nSincronizează datele din SAGA, apoi încearcă din nou.",
                "Alege gestiune",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return null;
        }

        GestiuneChoice? result = null;
        var dlg = new Window
        {
            Title = "Alege gestiune",
            Width = 470,
            Height = 330,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            Owner = owner,
            ResizeMode = ResizeMode.NoResize,
            ShowInTaskbar = false,
            Background = Brushes.White
        };

        var root = new Grid { Margin = new Thickness(18) };
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(14) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(18) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(18) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var title = new TextBlock
        {
            Text = "Alege gestiunea pentru vânzare",
            FontSize = 18,
            FontWeight = FontWeights.Bold,
            Foreground = (Brush)Application.Current.FindResource("TextPrimaryBrush")
        };
        root.Children.Add(title);

        var msg = new TextBlock
        {
            Text = $"Articolul {product.Name} nu are gestiune în SAGA. Alege gestiunea în care va fi vândut.",
            FontSize = 13,
            TextWrapping = TextWrapping.Wrap,
            Foreground = (Brush)Application.Current.FindResource("TextSecondaryBrush")
        };
        Grid.SetRow(msg, 2);
        root.Children.Add(msg);

        var cmb = new ComboBox
        {
            ItemsSource = gestiuni,
            DisplayMemberPath = nameof(GestiuneChoice.Display),
            SelectedValuePath = nameof(GestiuneChoice.Code),
            Height = 40,
            FontSize = 14,
            Margin = new Thickness(0),
            VerticalContentAlignment = VerticalAlignment.Center
        };
        cmb.SelectedIndex = 0;
        Grid.SetRow(cmb, 4);
        root.Children.Add(cmb);

        var buttons = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0)
        };
        var ok = new Button
        {
            Content = "Alege",
            Width = 110,
            Margin = new Thickness(0, 0, 8, 0),
            Style = (Style)Application.Current.FindResource("PrimaryButtonStyle")
        };
        ok.Click += (_, _) =>
        {
            result = cmb.SelectedItem as GestiuneChoice;
            if (result != null)
                SaveGestiuneForProduct(product.Code, result);
            dlg.DialogResult = result != null;
        };
        var cancel = new Button
        {
            Content = "Renunță",
            Width = 110,
            Style = (Style)Application.Current.FindResource("SoftButtonStyle")
        };
        cancel.Click += (_, _) => dlg.DialogResult = false;
        buttons.Children.Add(ok);
        buttons.Children.Add(cancel);
        Grid.SetRow(buttons, 6);
        root.Children.Add(buttons);

        dlg.Content = root;
        dlg.ShowDialog();
        return result;
    }

    private static GestiuneChoice? LoadSavedGestiuneForProduct(string productCode)
    {
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchemaForce(conn);
            var saved = new PosProductGestiuneRepository().Load(conn, productCode);
            return saved == null ? null : new GestiuneChoice(saved.Code, saved.Name);
        }
        catch
        {
            return null;
        }
    }

    private static void SaveGestiuneForProduct(string productCode, GestiuneChoice choice)
    {
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchemaForce(conn);
            new PosProductGestiuneRepository().Save(conn, productCode, choice.Code, choice.Name);
        }
        catch
        {
            // Nu blocăm vânzarea dacă memorarea preferinței locale eșuează.
        }
    }

    private static List<GestiuneChoice> LoadGestiuniChoices()
    {
        var list = new List<GestiuneChoice>();
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchema(conn);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
SELECT TRIM(CODE) AS CODE, TRIM(COALESCE(NAME, '')) AS NAME
FROM SP_SAGA_GESTIUNI
ORDER BY CODE";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var code = (rd["CODE"]?.ToString() ?? "").Trim();
                if (code.Length == 0)
                    continue;
                var name = (rd["NAME"]?.ToString() ?? "").Trim();
                list.Add(new GestiuneChoice(code, name));
            }
        }
        catch
        {
            return new List<GestiuneChoice>();
        }

        return list;
    }

    private static string TryAutoTransferAfterPayment(string saleId)
    {
        return SagaVanzariTransferService.ExplainAutoTransferPolicy();
    }

    // ───────── Nested types ─────────
    private sealed record PaymentResult(string Method, decimal CardAmount, decimal CashAmount);

    private sealed record GestiuneChoice(string Code, string Name)
    {
        public string Display => string.IsNullOrWhiteSpace(Name) ? Code : $"{Code} · {Name}";
    }

    private sealed class SentLine
    {
        public string  ProductCode { get; init; } = "";
        public string  ProductName { get; init; } = "";
        public string  GestiuneCode { get; init; } = "";
        public string  GestiuneName { get; init; } = "";
        public decimal Qty         { get; set; }
        public decimal UnitPrice   { get; init; }
        public decimal TvaPct      { get; init; }
        public string? Notes       { get; init; }
        public decimal LineTotal   => Math.Round(Qty * UnitPrice, 2, MidpointRounding.AwayFromZero);
        public string  QtyText     => Qty == Math.Floor(Qty)
            ? ((int)Qty).ToString()
            : Qty.ToString("0.##", CultureInfo.CurrentCulture);
        public string GestiuneDisplay =>
            string.IsNullOrWhiteSpace(GestiuneName)
                ? GestiuneCode
                : $"{GestiuneName} ({GestiuneCode})";
    }

    private sealed class ProductTileVm
    {
        public SyncedProductRow Product { get; init; } = null!;
        public string Name         { get; init; } = "";
        public string Initial      { get; init; } = "";
        public string CategoryName { get; init; } = "";
        public string PriceText    { get; init; } = "";
        public Brush  CategoryBrush   { get; init; } = Brushes.Gray;
        public Brush  CategoryBgBrush { get; init; } = Brushes.WhiteSmoke;
    }
}

using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using SMARTPUB.Core.Session;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Modules.Waiter.Views;

public partial class WaiterTableOrderPage
{
    private WaiterTableSplitService.TableSplitSession? _splitSession;
    private bool _splitDragActive;
    private Point _splitDragStart;
    private readonly HashSet<string> _selectedSplitPoolKeys = new(StringComparer.OrdinalIgnoreCase);
    private string? _pendingSplitPoolClickKey;

    private void BtnSplitNotes_Click(object sender, RoutedEventArgs e)
    {
        if (!OpHas("INCASARE") && !OpHas("BON_PREVIZ")) { DenyRight(); return; }
        var all = BuildAllLines();
        if (all.Count == 0)
        {
            MessageBox.Show("Adaugă articole sau trimite comanda la bucătărie înainte de split.",
                "Split note", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        OpenSplitMode();
    }

    private void BtnCloseSplit_Click(object sender, RoutedEventArgs e) => CloseSplitMode();

    private void BtnSplitEqual_Click(object sender, RoutedEventArgs e)
    {
        if (_splitSession == null) return;
        _splitSession.SplitEquallyAcrossBills();
        WaiterTableSplitService.Instance.Persist(_args.TableId);
        RefreshSplitUi();
    }

    private void OpenSplitMode()
    {
        _splitSession = WaiterTableSplitService.Instance.EnsureSession(_args.TableId, _persons);
        _splitSession.RebuildConsumedSentFromPaidBills();
        RebuildSplitPoolFromTable();
        SplitOverlay.Visibility = Visibility.Visible;
        RefreshSplitUi();
    }

    private void CloseSplitMode()
    {
        SplitOverlay.Visibility = Visibility.Collapsed;
        _selectedSplitPoolKeys.Clear();
        if (_splitSession != null)
            WaiterTableSplitService.Instance.Persist(_args.TableId);
        LoadSentLines();
        RefreshOrderVisibility();
        UpdateTotals();
    }

    private void RebuildSplitPoolFromTable()
    {
        if (_splitSession == null) return;

        var sources = new List<(WaiterSplitSourceKind, string, string, decimal, decimal, decimal, string?)>();

        foreach (var s in _sentLines)
        {
            var key = WaiterSplitPoolLine.BuildKey(WaiterSplitSourceKind.Sent, s.ProductCode, s.UnitPrice, s.Notes);
            _splitSession.ConsumedSentQty.TryGetValue(key, out var consumed);
            var qty = s.Qty - consumed;
            if (qty >= 0.01m)
                sources.Add((WaiterSplitSourceKind.Sent, s.ProductCode, s.ProductName, qty, s.UnitPrice, s.TvaPct, s.Notes));
        }

        foreach (var d in _cart)
            sources.Add((WaiterSplitSourceKind.Draft, d.ProductCode, d.ProductName, d.Qty, d.UnitPrice, d.TvaPct, d.Notes));

        _splitSession.RebuildPool(sources);
    }

    private void RefreshSplitUi()
    {
        if (_splitSession == null) return;
        _splitSession.ReconcileAll();

        var ci = CultureInfo.CurrentCulture;
        var paidTotal = _splitSession.Bills.Where(b => b.IsPaid).Sum(b => b.Total);
        var openTotal = _splitSession.Bills.Where(b => !b.IsPaid).Sum(b => b.Total);
        var unallocated = _splitSession.UnallocatedTotal;
        var tableTotal = paidTotal + openTotal + unallocated;

        TxtUnallocatedTotal.Text = "Nealocat: " + unallocated.ToString("N2", ci) + " lei";
        TxtSplitHint.Text =
            $"{_splitSession.Bills.Count} note · Total masă {tableTotal:N2} lei · " +
            $"Alocat {openTotal + paidTotal:N2} lei · {_splitSession.Bills.Count(b => b.IsPaid)} încasate";

        SplitPoolHost.Children.Clear();
        _selectedSplitPoolKeys.RemoveWhere(k =>
            _splitSession.Pool.All(p => !string.Equals(p.LineKey, k, StringComparison.OrdinalIgnoreCase) || p.AvailableQty < 0.01m));
        foreach (var p in _splitSession.Pool.Where(x => x.AvailableQty >= 0.01m))
            SplitPoolHost.Children.Add(CreatePoolCard(p));

        SplitBillsHost.Children.Clear();
        foreach (var bill in _splitSession.Bills)
            SplitBillsHost.Children.Add(CreateBillColumn(bill));
    }

    private Border CreatePoolCard(WaiterSplitPoolLine line)
    {
        var ci = CultureInfo.CurrentCulture;
        var isSelected = _selectedSplitPoolKeys.Contains(line.LineKey);
        var card = new Border
        {
            Style = (Style)FindResource("SplitLineCard"),
            Tag = line,
            MinHeight = 74,
            Background = isSelected ? new SolidColorBrush(Color.FromRgb(0xEA, 0xF3, 0xDF)) : Brushes.White,
            BorderBrush = isSelected ? (Brush)FindResource("PrimaryPistachioBrush") : (Brush)FindResource("SubtleLineBrush"),
            BorderThickness = new Thickness(isSelected ? 2 : 1)
        };
        var grid = new Grid();
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

        var left = new StackPanel();
        left.Children.Add(new TextBlock
        {
            Text = line.ProductName,
            FontWeight = FontWeights.SemiBold,
            FontSize = 13.5,
            Foreground = (Brush)FindResource("TextPrimaryBrush"),
            TextTrimming = TextTrimming.CharacterEllipsis,
            MaxWidth = 210
        });
        left.Children.Add(new TextBlock
        {
            Text = $"{FormatQty(line.AvailableQty)} buc × {line.UnitPrice:N2} lei · {(line.Source == WaiterSplitSourceKind.Sent ? "trimis" : "coș")}",
            FontSize = 11,
            Foreground = (Brush)FindResource("TextSecondaryBrush"),
            Margin = new Thickness(0, 3, 0, 0)
        });
        Grid.SetColumn(left, 0);
        grid.Children.Add(left);

        var right = new StackPanel { HorizontalAlignment = HorizontalAlignment.Right };
        right.Children.Add(new Border
        {
            Background = line.Source == WaiterSplitSourceKind.Sent
                ? new SolidColorBrush(Color.FromRgb(0xE8, 0xF6, 0xE8))
                : new SolidColorBrush(Color.FromRgb(0xFF, 0xF1, 0xCF)),
            CornerRadius = new CornerRadius(999),
            Padding = new Thickness(8, 3, 8, 3),
            Child = new TextBlock
            {
                Text = line.Source == WaiterSplitSourceKind.Sent ? "KDS" : "NOU",
                FontSize = 9,
                FontWeight = FontWeights.Bold,
                Foreground = line.Source == WaiterSplitSourceKind.Sent
                    ? new SolidColorBrush(Color.FromRgb(0x2E, 0x7D, 0x32))
                    : new SolidColorBrush(Color.FromRgb(0x8A, 0x5D, 0x11))
            }
        });
        right.Children.Add(new TextBlock
        {
            Text = line.LineTotal.ToString("N2", ci) + " lei",
            FontWeight = FontWeights.Bold,
            FontSize = 13,
            Foreground = new SolidColorBrush(Color.FromRgb(0xB7, 0x78, 0x18)),
            Margin = new Thickness(0, 7, 0, 0),
            HorizontalAlignment = HorizontalAlignment.Right
        });
        Grid.SetColumn(right, 1);
        grid.Children.Add(right);

        card.Child = grid;

        card.MouseLeftButtonDown += (_, e) =>
        {
            if (e.ClickCount == 2)
            {
                QuickMoveOneToFirstOpenBill(line);
                e.Handled = true;
                return;
            }

            _pendingSplitPoolClickKey = line.LineKey;
            _splitDragStart = e.GetPosition(card);
            _splitDragActive = false;
        };
        card.MouseMove += PoolCard_MouseMove;
        card.MouseLeftButtonUp += (_, e) =>
        {
            if (!_splitDragActive && _pendingSplitPoolClickKey == line.LineKey)
                ToggleSplitPoolSelection(line.LineKey);

            _pendingSplitPoolClickKey = null;
            _splitDragActive = false;
            e.Handled = true;
        };

        return card;
    }

    private void PoolCard_MouseMove(object sender, MouseEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed || sender is not Border card || card.Tag is not WaiterSplitPoolLine line)
            return;
        var pos = e.GetPosition(card);
        if (!_splitDragActive && (pos - _splitDragStart).Length < 8) return;
        _splitDragActive = true;
        if (!_selectedSplitPoolKeys.Contains(line.LineKey))
        {
            _selectedSplitPoolKeys.Clear();
            _selectedSplitPoolKeys.Add(line.LineKey);
        }

        var selectedKeys = _selectedSplitPoolKeys
            .Where(k => _splitSession?.Pool.Any(p => p.LineKey == k && p.AvailableQty >= 0.01m) == true)
            .ToList();
        if (selectedKeys.Count == 0)
            selectedKeys.Add(line.LineKey);

        var payload = new WaiterSplitDragPayload
        {
            PoolLineKey = line.LineKey,
            PoolLineKeys = selectedKeys,
            FromBillIndex = null,
            Qty = SplitQtyMath.Round(line.AvailableQty)
        };
        DragDrop.DoDragDrop(card, payload, DragDropEffects.Move);
        _pendingSplitPoolClickKey = null;
        _splitDragActive = false;
    }

    private void QuickMoveOneToFirstOpenBill(WaiterSplitPoolLine line)
    {
        if (_splitSession == null) return;
        var bill = _splitSession.Bills.FirstOrDefault(b => !b.IsPaid);
        if (bill == null) return;
        var q = Math.Min(1m, line.AvailableQty);
        if (_splitSession.TryMoveToBill(line.LineKey, bill.BillIndex, q, out _))
        {
            WaiterTableSplitService.Instance.Persist(_args.TableId);
            RefreshSplitUi();
        }
    }

    private Border CreateBillColumn(WaiterSplitBill bill)
    {
        var ci = CultureInfo.CurrentCulture;
        var col = new Border
        {
            Width = 310,
            Margin = new Thickness(0, 0, 14, 0),
            Background = bill.IsPaid ? new SolidColorBrush(Color.FromRgb(0xE8, 0xF6, 0xE8)) : Brushes.White,
            BorderBrush = bill.IsPaid
                ? new SolidColorBrush(Color.FromRgb(0x4C, 0xAF, 0x50))
                : (Brush)FindResource("SubtleBorderBrush"),
            BorderThickness = new Thickness(bill.IsPaid ? 2 : 1),
            CornerRadius = new CornerRadius(14),
            Padding = new Thickness(12),
            AllowDrop = !bill.IsPaid,
            Tag = bill
        };

        if (!bill.IsPaid)
        {
            col.Drop += BillColumn_Drop;
            col.DragOver += BillColumn_DragOver;
        }

        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var header = new Grid { Margin = new Thickness(0, 0, 0, 10) };
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

        var titleStack = new StackPanel();
        titleStack.Children.Add(new TextBlock
        {
            Text = bill.Label,
            FontSize = 16,
            FontWeight = FontWeights.Bold,
            Foreground = (Brush)FindResource("TextPrimaryBrush")
        });
        titleStack.Children.Add(new TextBlock
        {
            Text = bill.StatusText,
            FontSize = 10,
            FontWeight = FontWeights.SemiBold,
            Foreground = bill.IsPaid
                ? new SolidColorBrush(Color.FromRgb(0x2E, 0x7D, 0x32))
                : (Brush)FindResource("TextMutedBrush")
        });
        Grid.SetColumn(titleStack, 0);
        header.Children.Add(titleStack);

        header.Children.Add(new TextBlock
        {
            Text = bill.Total.ToString("N2", ci) + " lei",
            FontSize = 19,
            FontWeight = FontWeights.Bold,
            Foreground = new SolidColorBrush(Color.FromRgb(0xB7, 0x78, 0x18)),
            VerticalAlignment = VerticalAlignment.Top,
            HorizontalAlignment = HorizontalAlignment.Right
        });
        Grid.SetColumn(header.Children[^1], 1);
        Grid.SetRow(header, 0);
        root.Children.Add(header);

        var linesHost = new StackPanel { MinHeight = 120 };
        foreach (var ln in bill.Lines)
            linesHost.Children.Add(CreateAllocCard(bill, ln));
        if (bill.Lines.Count == 0)
            linesHost.Children.Add(new TextBlock
            {
                Text = "Trage produse aici",
                FontSize = 12,
                Foreground = (Brush)FindResource("TextMutedBrush"),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 34, 0, 0)
            });

        var scroll = new ScrollViewer
        {
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            Content = linesHost
        };
        Grid.SetRow(scroll, 1);
        root.Children.Add(scroll);

        if (!bill.IsPaid)
        {
            var btnRow = new Grid { Margin = new Thickness(0, 10, 0, 0) };
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(8) });
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(84) });
            var btnPay = new Button
            {
                Content = "Încasează",
                Style = (Style)FindResource("SuccessButtonStyle"),
                Padding = new Thickness(12, 10, 12, 10),
                IsEnabled = bill.Lines.Count > 0
            };
            btnPay.Click += (_, _) => PaySplitBill(bill);
            var btnPreview = new Button
            {
                Content = "Bon",
                Style = (Style)FindResource("SoftButtonStyle"),
                Padding = new Thickness(10, 10, 10, 10)
            };
            btnPreview.Click += (_, _) => PreviewSplitBill(bill);
            Grid.SetColumn(btnPay, 0);
            Grid.SetColumn(btnPreview, 2);
            btnRow.Children.Add(btnPay);
            btnRow.Children.Add(btnPreview);
            Grid.SetRow(btnRow, 2);
            root.Children.Add(btnRow);
        }
        else
        {
            var paid = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(0xD9, 0xF0, 0xD9)),
                CornerRadius = new CornerRadius(10),
                Padding = new Thickness(12, 10, 12, 10),
                Margin = new Thickness(0, 10, 0, 0),
                Child = new TextBlock
                {
                    Text = "ÎNCASAT",
                    FontSize = 12,
                    FontWeight = FontWeights.Bold,
                    Foreground = new SolidColorBrush(Color.FromRgb(0x2E, 0x7D, 0x32)),
                    HorizontalAlignment = HorizontalAlignment.Center
                }
            };
            Grid.SetRow(paid, 2);
            root.Children.Add(paid);
        }

        col.Child = root;
        return col;
    }

    private Border CreateAllocCard(WaiterSplitBill bill, WaiterSplitAllocLine ln)
    {
        var ci = CultureInfo.CurrentCulture;
        var card = new Border
        {
            Style = (Style)FindResource("SplitLineCard"),
            Margin = new Thickness(0, 0, 0, 4),
            Tag = (bill, ln)
        };
        if (!bill.IsPaid)
        {
            card.MouseLeftButtonDown += (_, e) => { _splitDragStart = e.GetPosition(card); };
            card.MouseMove += AllocCard_MouseMove;
        }

        var grid = new Grid();
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

        var left = new StackPanel();
        left.Children.Add(new TextBlock
        {
            Text = ln.ProductName,
            FontSize = 12.5,
            FontWeight = FontWeights.SemiBold,
            Foreground = (Brush)FindResource("TextPrimaryBrush"),
            TextTrimming = TextTrimming.CharacterEllipsis,
            MaxWidth = 190
        });
        left.Children.Add(new TextBlock
        {
            Text = $"{FormatQty(ln.Qty)} buc × {ln.UnitPrice:N2} lei",
            FontSize = 10,
            Foreground = (Brush)FindResource("TextSecondaryBrush"),
            Margin = new Thickness(0, 2, 0, 0)
        });
        Grid.SetColumn(left, 0);
        grid.Children.Add(left);

        grid.Children.Add(new TextBlock
        {
            Text = ln.LineTotal.ToString("N2", ci),
            FontSize = 12.5,
            FontWeight = FontWeights.Bold,
            Foreground = new SolidColorBrush(Color.FromRgb(0xB7, 0x78, 0x18)),
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(8, 0, 0, 0)
        });
        Grid.SetColumn(grid.Children[^1], 1);

        card.Child = grid;
        return card;
    }

    private void AllocCard_MouseMove(object sender, MouseEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed || sender is not Border card ||
            card.Tag is not (WaiterSplitBill bill, WaiterSplitAllocLine ln) || bill.IsPaid)
            return;
        var pos = e.GetPosition(card);
        if ((pos - _splitDragStart).Length < 8) return;
        var payload = new WaiterSplitDragPayload
        {
            PoolLineKey = ln.PoolLineKey,
            FromBillIndex = bill.BillIndex,
            Qty = ln.Qty
        };
        DragDrop.DoDragDrop(card, payload, DragDropEffects.Move);
    }

    private void BillColumn_DragOver(object sender, DragEventArgs e)
    {
        if (e.Data.GetDataPresent(typeof(WaiterSplitDragPayload)))
            e.Effects = DragDropEffects.Move;
        e.Handled = true;
    }

    private void BillColumn_Drop(object sender, DragEventArgs e)
    {
        if (_splitSession == null || sender is not Border col || col.Tag is not WaiterSplitBill bill)
            return;
        if (!e.Data.GetDataPresent(typeof(WaiterSplitDragPayload))) return;
        var payload = (WaiterSplitDragPayload)e.Data.GetData(typeof(WaiterSplitDragPayload))!;

        if (payload.FromBillIndex == bill.BillIndex) return;

        if (payload.FromBillIndex is int fromIdx)
        {
            _splitSession.TryMoveFromBillToPool(fromIdx, payload.PoolLineKey, payload.Qty, out _);
            var qty = SplitQtyMath.Round(payload.Qty);
            _splitSession.TryMoveToBill(payload.PoolLineKey, bill.BillIndex, qty, out _);
        }
        else
        {
            foreach (var key in payload.EffectivePoolLineKeys)
            {
                var pool = _splitSession.Pool.FirstOrDefault(p => p.LineKey == key);
                var qty = SplitQtyMath.Round(pool?.AvailableQty ?? 0);
                if (qty >= SplitQtyMath.MinQty)
                    _splitSession.TryMoveToBill(key, bill.BillIndex, qty, out _);
            }
            _selectedSplitPoolKeys.Clear();
        }

        WaiterTableSplitService.Instance.Persist(_args.TableId);
        RefreshSplitUi();
        e.Handled = true;
    }

    private void SplitPool_DragOver(object sender, DragEventArgs e)
    {
        if (e.Data.GetDataPresent(typeof(WaiterSplitDragPayload)) &&
            ((WaiterSplitDragPayload)e.Data.GetData(typeof(WaiterSplitDragPayload))!).FromBillIndex is int)
            e.Effects = DragDropEffects.Move;
        e.Handled = true;
    }

    private void SplitPool_Drop(object sender, DragEventArgs e)
    {
        if (_splitSession == null) return;
        if (!e.Data.GetDataPresent(typeof(WaiterSplitDragPayload))) return;
        var payload = (WaiterSplitDragPayload)e.Data.GetData(typeof(WaiterSplitDragPayload))!;
        if (payload.FromBillIndex is not int fromIdx) return;

        _splitSession.TryMoveFromBillToPool(fromIdx, payload.PoolLineKey, null, out _);
        WaiterTableSplitService.Instance.Persist(_args.TableId);
        RefreshSplitUi();
        e.Handled = true;
    }

    private void PreviewSplitBill(WaiterSplitBill bill)
    {
        if (bill.Lines.Count == 0) return;
        var lines = bill.Lines.Select(l => l.ToCartLine()).ToList();
        var w = new WaiterBonPreviewWindow { Owner = Window.GetWindow(this) };
        w.SetDocument($"{_args.DisplayTitle} — {bill.Label}", lines, AppSession.Current.OperatorName);
        w.ShowDialog();
    }

    private void PaySplitBill(WaiterSplitBill bill)
    {
        if (!OpHas("INCASARE")) { DenyRight(); return; }
        if (bill.IsPaid || bill.Lines.Count == 0) return;

        var owner = Window.GetWindow(this);
        var total = bill.Total;
        var tableLabel = string.IsNullOrWhiteSpace(_args.TableName) ? _args.DisplayTitle : $"Masa {_args.TableName}";
        var payResult = PickModPlata(owner, total, $"{tableLabel} — {bill.Label}");
        if (payResult == null) return;

        try
        {
            var lines = bill.Lines.Select(l => l.ToCartLine()).ToList();
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchema(conn);
            var saleId = PosSaleRepository.CreateSaleFromCart(
                conn,
                _args.TableId,
                $"{tableLabel} / {bill.Label}",
                AppSession.Current.OperatorId,
                AppSession.Current.OperatorName,
                payResult.Method,
                lines,
                BuildPaymentInputs(payResult),
                clearTableDraft: false);

            bill.IsPaid = true;
            bill.SaleId = saleId;
            ApplyPaidBillLinesToTable(bill);

            WaiterTableSplitService.Instance.Persist(_args.TableId);
            RebuildSplitPoolFromTable();
            RefreshSplitUi();
            LoadSentLines();
            RefreshOrderVisibility();
            UpdateTotals();

            var transferMsg = TryAutoTransferAfterPayment(saleId);
            var msg = payResult.Method == "Mixt"
                ? $"Nota {bill.BillIndex} încasată.\n\n  Card: {payResult.CardAmount:N2} lei\n  Numerar: {payResult.CashAmount:N2} lei"
                : $"Nota {bill.BillIndex} încasată ({payResult.Method}).";
            if (!string.IsNullOrWhiteSpace(transferMsg))
                msg += "\n\n" + transferMsg;
            MessageBox.Show(msg, "Încasare", MessageBoxButton.OK, MessageBoxImage.Information);

            if (_splitSession != null && IsTableFullySettled())
            {
                FinalizeTableAfterFullPayment();
                CloseSplitMode();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Încasare", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void ApplyPaidBillLinesToTable(WaiterSplitBill bill)
    {
        if (_splitSession == null) return;

        foreach (var ln in bill.Lines)
        {
            if (ln.Source == WaiterSplitSourceKind.Sent)
            {
                _splitSession.ConsumedSentQty.TryGetValue(ln.PoolLineKey, out var cur);
                _splitSession.ConsumedSentQty[ln.PoolLineKey] = cur + ln.Qty;
                continue;
            }

            var remaining = ln.Qty;
            var matches = _cart
                .Where(c => string.Equals(c.ProductCode, ln.ProductCode, StringComparison.OrdinalIgnoreCase)
                            && c.UnitPrice == ln.UnitPrice
                            && string.Equals((c.Notes ?? "").Trim(), ln.Notes.Trim(), StringComparison.OrdinalIgnoreCase))
                .ToList();

            foreach (var c in matches)
            {
                if (remaining <= 0) break;
                if (c.Qty > remaining)
                {
                    c.Qty -= remaining;
                    remaining = 0;
                }
                else
                {
                    remaining -= c.Qty;
                    _cart.Remove(c);
                }
            }
        }
    }

    private bool IsTableFullySettled()
    {
        if (_splitSession == null) return false;
        if (_splitSession.Pool.Any(p => p.AvailableQty >= 0.01m)) return false;
        if (_splitSession.Bills.Any(b => !b.IsPaid && b.Lines.Count > 0)) return false;
        if (_cart.Count > 0) return false;
        if (_sentLines.Any(s =>
            {
                var key = WaiterSplitPoolLine.BuildKey(WaiterSplitSourceKind.Sent, s.ProductCode, s.UnitPrice, s.Notes);
                _splitSession.ConsumedSentQty.TryGetValue(key, out var c);
                return s.Qty - c >= 0.01m;
            }))
            return false;
        return true;
    }

    private void FinalizeTableAfterFullPayment()
    {
        var activeTicketIds = KitchenTicketStore.Instance.GetSnapshot()
            .Where(k => string.Equals(k.TableId, _args.TableId, StringComparison.OrdinalIgnoreCase))
            .Where(k => k.Status is not KitchenTicketStatus.Served and not KitchenTicketStatus.Cancelled)
            .Select(k => k.Id)
            .ToList();
        foreach (var id in activeTicketIds)
            KitchenTicketStore.Instance.UpdateStatus(id, KitchenTicketStatus.Served);

        WaiterDraftOrderStore.Instance.Clear(_args.TableId);
        WaiterTableSplitService.Instance.ClearSession(_args.TableId);
        _cart.Clear();
        _splitSession = null;
    }

    partial void OnPersonsChanged()
    {
        if (_splitSession == null) return;
        _splitSession.EnsureBillCount(_persons);
        WaiterTableSplitService.Instance.Persist(_args.TableId);
        if (SplitOverlay.Visibility == Visibility.Visible)
            RefreshSplitUi();
    }

    private static string FormatQty(decimal qty)
    {
        qty = SplitQtyMath.Round(qty);
        return qty == Math.Floor(qty)
            ? ((int)qty).ToString(CultureInfo.CurrentCulture)
            : qty.ToString("0.##", CultureInfo.CurrentCulture);
    }

    private void ToggleSplitPoolSelection(string lineKey)
    {
        if (!_selectedSplitPoolKeys.Add(lineKey))
            _selectedSplitPoolKeys.Remove(lineKey);
        RefreshSplitUi();
    }
}

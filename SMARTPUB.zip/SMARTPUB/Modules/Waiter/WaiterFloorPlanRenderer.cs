using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using SMARTPUB.Models;

namespace SMARTPUB.Modules.Waiter;

public static class WaiterFloorPlanRenderer
{
    // ───────── Layout constants for the "pro" floor cards ─────────
    private const double CardW       = 220;
    private const double CardH       = 156;
    private const double SlotW       = 256;   // card + chairs + breathing
    private const double SlotH       = 196;
    private const double CardOffsetX = (SlotW - CardW) / 2;
    private const double CardOffsetY = (SlotH - CardH) / 2;

    // ───────── Public entrypoints (signatures unchanged) ──────────
    public static void Render(
        Canvas canvas,
        FloorLevelModel level,
        IReadOnlyList<FloorSpaceModel> spaces,
        IReadOnlyList<FloorTableModel> tables,
        string? selectedTableId,
        Action<FloorTableModel> onTableClick)
    {
        canvas.Children.Clear();
        var levelSpaces = spaces.Where(s => s.LevelId == level.Id).OrderBy(s => s.ZOrder).ToList();
        var levelTables = tables.Where(t => t.LevelId == level.Id).OrderBy(t => t.Name).ToList();

        foreach (var s in levelSpaces) canvas.Children.Add(CreateSpaceVisual(s));

        var autoLayout = levelTables.Count > 0 && levelTables.All(t => Math.Abs(t.X) < 0.01 && Math.Abs(t.Y) < 0.01);
        const double originX = 28, originY = 28;
        var cols = Math.Max(1, (int)Math.Floor((1080 - originX) / SlotW));

        for (var i = 0; i < levelTables.Count; i++)
        {
            var t = levelTables[i];
            var x = autoLayout ? originX + (i % cols) * SlotW : t.X;
            var y = autoLayout ? originY + (i / cols) * SlotH : t.Y;
            var el = CreateSimpleTableCard(t, selectedTableId, onTableClick);
            Canvas.SetLeft(el, x); Canvas.SetTop(el, y); Panel.SetZIndex(el, 200);
            canvas.Children.Add(el);
        }

        SizeCanvas(canvas, levelSpaces, levelTables, autoLayout, cols);
    }

    public static void RenderWithStatusCards(
        Canvas canvas,
        FloorLevelModel level,
        IReadOnlyList<FloorSpaceModel> spaces,
        IReadOnlyList<FloorTableModel> tables,
        Func<FloorTableModel, WaiterTableStatusUi> statusFor,
        Action<FloorTableModel> onTableClick)
    {
        canvas.Children.Clear();
        var levelSpaces = spaces.Where(s => s.LevelId == level.Id).OrderBy(s => s.ZOrder).ToList();
        var levelTables = tables.Where(t => t.LevelId == level.Id).OrderBy(t => t.Name).ToList();

        foreach (var s in levelSpaces) canvas.Children.Add(CreateSpaceVisual(s));

        var autoLayout = levelTables.Count > 0 && levelTables.All(t => Math.Abs(t.X) < 0.01 && Math.Abs(t.Y) < 0.01);
        const double originX = 28, originY = 28;
        var cols = Math.Max(1, (int)Math.Floor((1080 - originX) / SlotW));

        for (var i = 0; i < levelTables.Count; i++)
        {
            var t = levelTables[i];
            var x = autoLayout ? originX + (i % cols) * SlotW : t.X;
            var y = autoLayout ? originY + (i / cols) * SlotH : t.Y;
            var el = CreateProStatusCard(t, statusFor(t), onTableClick);
            Canvas.SetLeft(el, x); Canvas.SetTop(el, y); Panel.SetZIndex(el, 200);
            canvas.Children.Add(el);
        }

        SizeCanvas(canvas, levelSpaces, levelTables, autoLayout, cols);
    }

    private static void SizeCanvas(Canvas canvas, List<FloorSpaceModel> levelSpaces,
        List<FloorTableModel> levelTables, bool autoLayout, int cols)
    {
        var w = 1080d; var h = 720d;
        if (levelSpaces.Count > 0)
        {
            w = Math.Max(w, levelSpaces.Max(s => s.X + s.Width) + 60);
            h = Math.Max(h, levelSpaces.Max(s => s.Y + s.Height) + 60);
        }
        if (levelTables.Count > 0 && !autoLayout)
            foreach (var t in levelTables)
            {
                w = Math.Max(w, t.X + SlotW + 40);
                h = Math.Max(h, t.Y + SlotH + 40);
            }
        else if (autoLayout && levelTables.Count > 0)
        {
            var rows = (levelTables.Count + cols - 1) / cols;
            w = Math.Max(w, 28 + cols * SlotW + 28);
            h = Math.Max(h, 28 + rows * SlotH + 60);
        }
        canvas.Width = w; canvas.Height = h;
    }

    // ════════════════════════════════════════════════════════════════════
    //                  PRO STATUS CARD (the "wow" version)
    // ════════════════════════════════════════════════════════════════════
    private static UIElement CreateProStatusCard(
        FloorTableModel t, WaiterTableStatusUi st, Action<FloorTableModel> onTableClick)
    {
        var p = PaletteFor(st.State);

        // Outer slot (host for chairs + card)
        var host = new Canvas { Width = SlotW, Height = SlotH, Tag = t, Cursor = Cursors.Hand };

        // Chairs around the table perimeter
        AddChairs(host, t.Seats, p.ChairBrush, p.ChairBgBrush);

        // The "table top" — actual card
        var card = new Border
        {
            Width = CardW, Height = CardH,
            CornerRadius = new CornerRadius(18),
            BorderBrush = p.BorderBrush,
            BorderThickness = new Thickness(1),
            SnapsToDevicePixels = true,
            Background = p.CardBgBrush,
            Effect = new DropShadowEffect
            {
                BlurRadius = 22, ShadowDepth = 6, Opacity = 0.22, Color = p.ShadowColor
            }
        };

        var grid = new Grid();
        grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(4) });          // accent strip
        grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // body
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });            // footer

        // ── Accent strip at top (clipped to rounded corner) ──
        var accent = new Border
        {
            CornerRadius = new CornerRadius(18, 18, 0, 0),
            Background = p.AccentBrush
        };
        Grid.SetRow(accent, 0); grid.Children.Add(accent);

        // ── BODY ──
        var body = new Grid { Margin = new Thickness(16, 12, 16, 4) };
        body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        body.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        body.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });   // name + glyph
        body.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });   // status pill
        body.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        body.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });   // time + total

        // Table name (giant)
        var nameTb = new TextBlock
        {
            Text = t.Name,
            FontSize = 22,
            FontWeight = FontWeights.Bold,
            Foreground = p.TextStrongBrush,
            TextTrimming = TextTrimming.CharacterEllipsis,
            VerticalAlignment = VerticalAlignment.Center
        };
        Grid.SetRow(nameTb, 0); Grid.SetColumn(nameTb, 0); body.Children.Add(nameTb);

        // State glyph (top-right circular) — only when occupied
        if (st.State != WaiterTableSurfaceState.Free)
        {
            var glyph = new Border
            {
                Width = 30, Height = 30,
                CornerRadius = new CornerRadius(15),
                Background = p.AccentBrush,
                VerticalAlignment = VerticalAlignment.Top,
                HorizontalAlignment = HorizontalAlignment.Right,
                Effect = new DropShadowEffect { BlurRadius = 8, ShadowDepth = 2, Opacity = 0.30, Color = p.ShadowColor },
                Child = new TextBlock
                {
                    Text = IconForState(st.State),
                    FontFamily = SegoeMdl2,
                    FontSize = 13,
                    Foreground = Brushes.White,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                }
            };
            Grid.SetRow(glyph, 0); Grid.SetColumn(glyph, 1); body.Children.Add(glyph);
        }

        // Status pill (dot + label)
        var pill = new Border
        {
            Background = p.PillBgBrush,
            CornerRadius = new CornerRadius(10),
            Padding = new Thickness(9, 3, 11, 3),
            HorizontalAlignment = HorizontalAlignment.Left,
            Margin = new Thickness(0, 6, 0, 0)
        };
        var pillStack = new StackPanel { Orientation = Orientation.Horizontal };
        pillStack.Children.Add(new Ellipse
        {
            Width = 7, Height = 7,
            Fill = p.AccentBrush,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(0, 0, 7, 0)
        });
        pillStack.Children.Add(new TextBlock
        {
            Text = (st.StatusLine ?? "").Length == 0 ? "Liberă" : st.StatusLine,
            FontSize = 11,
            FontWeight = FontWeights.SemiBold,
            Foreground = p.PillTextBrush,
            VerticalAlignment = VerticalAlignment.Center
        });
        pill.Child = pillStack;
        Grid.SetRow(pill, 1); Grid.SetColumn(pill, 0); Grid.SetColumnSpan(pill, 2);
        body.Children.Add(pill);

        // Time + Total row
        if (!string.IsNullOrEmpty(st.TimeLine) || st.TableTotal > 0)
        {
            var info = new Grid { Margin = new Thickness(0, 0, 0, 0) };
            info.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            info.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            info.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            if (!string.IsNullOrEmpty(st.TimeLine))
            {
                var timeRow = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Bottom };
                timeRow.Children.Add(new TextBlock
                {
                    Text = "",
                    FontFamily = SegoeMdl2,
                    FontSize = 11,
                    Foreground = p.TextMutedBrush,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 4, 0)
                });
                timeRow.Children.Add(new TextBlock
                {
                    Text = st.TimeLine,
                    FontSize = 12,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = p.TextStrongBrush,
                    VerticalAlignment = VerticalAlignment.Center
                });
                Grid.SetColumn(timeRow, 0); info.Children.Add(timeRow);
            }

            if (st.TableTotal > 0)
            {
                var total = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    VerticalAlignment = VerticalAlignment.Bottom,
                    HorizontalAlignment = HorizontalAlignment.Right
                };
                total.Children.Add(new TextBlock
                {
                    Text = st.TableTotal.ToString("N2", CultureInfo.CurrentCulture),
                    FontSize = 18,
                    FontWeight = FontWeights.Bold,
                    Foreground = GoldBrush,
                    VerticalAlignment = VerticalAlignment.Bottom
                });
                total.Children.Add(new TextBlock
                {
                    Text = " lei",
                    FontSize = 10,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = p.TextMutedBrush,
                    VerticalAlignment = VerticalAlignment.Bottom,
                    Margin = new Thickness(2, 0, 0, 2)
                });
                Grid.SetColumn(total, 2); info.Children.Add(total);
            }

            Grid.SetRow(info, 3); Grid.SetColumn(info, 0); Grid.SetColumnSpan(info, 2);
            body.Children.Add(info);
        }

        Grid.SetRow(body, 1); grid.Children.Add(body);

        // ── FOOTER (seats) ──
        var footer = new Border
        {
            Padding = new Thickness(16, 6, 16, 10),
            Background = p.FooterBgBrush,
            CornerRadius = new CornerRadius(0, 0, 18, 18)
        };
        var footStack = new StackPanel { Orientation = Orientation.Horizontal };
        footStack.Children.Add(new TextBlock
        {
            Text = "",
            FontFamily = SegoeMdl2,
            FontSize = 10,
            Foreground = p.TextMutedBrush,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(0, 0, 6, 0)
        });
        footStack.Children.Add(new TextBlock
        {
            Text = t.Seats > 0 ? $"{t.Seats} {(t.Seats == 1 ? "loc" : "locuri")}" : "",
            FontSize = 10,
            FontWeight = FontWeights.SemiBold,
            Foreground = p.TextMutedBrush,
            VerticalAlignment = VerticalAlignment.Center
        });

        if (st.ItemCount > 0)
        {
            footStack.Children.Add(new TextBlock
            {
                Text = "  ·  ",
                FontSize = 10,
                Foreground = p.TextMutedBrush,
                VerticalAlignment = VerticalAlignment.Center
            });
            footStack.Children.Add(new TextBlock
            {
                Text = $"{st.ItemCount} {(st.ItemCount == 1 ? "articol" : "articole")}",
                FontSize = 10,
                FontWeight = FontWeights.SemiBold,
                Foreground = p.TextMutedBrush,
                VerticalAlignment = VerticalAlignment.Center
            });
        }
        footer.Child = footStack;
        Grid.SetRow(footer, 2); grid.Children.Add(footer);

        card.Child = grid;
        Canvas.SetLeft(card, CardOffsetX);
        Canvas.SetTop(card, CardOffsetY);
        host.Children.Add(card);

        // Soft hover lift
        host.MouseEnter += (_, _) => card.Effect = new DropShadowEffect
        {
            BlurRadius = 30, ShadowDepth = 9, Opacity = 0.30, Color = p.ShadowColor
        };
        host.MouseLeave += (_, _) => card.Effect = new DropShadowEffect
        {
            BlurRadius = 22, ShadowDepth = 6, Opacity = 0.22, Color = p.ShadowColor
        };
        host.MouseLeftButtonDown += (_, e) => { e.Handled = true; onTableClick(t); };

        return host;
    }

    private static string IconForState(WaiterTableSurfaceState s) => s switch
    {
        WaiterTableSurfaceState.KitchenPending  => "",   // clock
        WaiterTableSurfaceState.DraftOnly       => "",   // shopping bag
        WaiterTableSurfaceState.DraftAndKitchen => "",   // warning
        _                                        => ""   // check
    };

    // ════════════════════════════════════════════════════════════════════
    //                       CHAIR RENDERING
    // ════════════════════════════════════════════════════════════════════
    private static void AddChairs(Canvas host, int seats, Brush fill, Brush bgFill)
    {
        if (seats <= 0) return;
        seats = Math.Min(seats, 16);

        DistributeChairs(seats, out var top, out var bottom, out var left, out var right);

        const double chairThick = 7;
        const double chairLen   = 26;
        const double gapEdge    = 12;   // distance from card corner

        // TOP
        for (var i = 0; i < top; i++)
        {
            var slotW = CardW - 2 * gapEdge;
            var step = top == 1 ? slotW / 2 : slotW / (top + 1);
            var cx = CardOffsetX + gapEdge + step * (i + 1);
            var ch = MakeChair(chairLen, chairThick, fill, bgFill);
            Canvas.SetLeft(ch, cx - chairLen / 2);
            Canvas.SetTop(ch, CardOffsetY - chairThick - 2);
            host.Children.Add(ch);
        }
        // BOTTOM
        for (var i = 0; i < bottom; i++)
        {
            var slotW = CardW - 2 * gapEdge;
            var step = bottom == 1 ? slotW / 2 : slotW / (bottom + 1);
            var cx = CardOffsetX + gapEdge + step * (i + 1);
            var ch = MakeChair(chairLen, chairThick, fill, bgFill);
            Canvas.SetLeft(ch, cx - chairLen / 2);
            Canvas.SetTop(ch, CardOffsetY + CardH + 2);
            host.Children.Add(ch);
        }
        // LEFT
        for (var i = 0; i < left; i++)
        {
            var slotH = CardH - 2 * gapEdge;
            var step = left == 1 ? slotH / 2 : slotH / (left + 1);
            var cy = CardOffsetY + gapEdge + step * (i + 1);
            var ch = MakeChair(chairThick, chairLen, fill, bgFill);
            Canvas.SetLeft(ch, CardOffsetX - chairThick - 2);
            Canvas.SetTop(ch, cy - chairLen / 2);
            host.Children.Add(ch);
        }
        // RIGHT
        for (var i = 0; i < right; i++)
        {
            var slotH = CardH - 2 * gapEdge;
            var step = right == 1 ? slotH / 2 : slotH / (right + 1);
            var cy = CardOffsetY + gapEdge + step * (i + 1);
            var ch = MakeChair(chairThick, chairLen, fill, bgFill);
            Canvas.SetLeft(ch, CardOffsetX + CardW + 2);
            Canvas.SetTop(ch, cy - chairLen / 2);
            host.Children.Add(ch);
        }
    }

    private static Border MakeChair(double w, double h, Brush fill, Brush bgFill)
    {
        return new Border
        {
            Width = w, Height = h,
            CornerRadius = new CornerRadius(Math.Min(w, h) / 2.5),
            Background = bgFill,
            BorderBrush = fill,
            BorderThickness = new Thickness(1.4),
            IsHitTestVisible = false,
            SnapsToDevicePixels = true
        };
    }

    private static void DistributeChairs(int n, out int top, out int bottom, out int left, out int right)
    {
        if (n <= 4)
        {
            top = (n + 1) / 2;
            bottom = n - top;
            left = right = 0;
            return;
        }
        if (n <= 6)
        {
            top = 2; bottom = 2;
            var extra = n - 4;
            right = (extra + 1) / 2;
            left = extra - right;
            return;
        }
        if (n <= 10)
        {
            top = 3; bottom = 3;
            var extra = n - 6;
            right = (extra + 1) / 2;
            left = extra - right;
            return;
        }
        top = (n + 1) / 2;
        bottom = n - top;
        left = right = 0;
    }

    // ════════════════════════════════════════════════════════════════════
    //                          PALETTE
    // ════════════════════════════════════════════════════════════════════
    private sealed class StylePalette
    {
        public Brush AccentBrush     { get; init; } = Brushes.Gray;
        public Brush CardBgBrush     { get; init; } = Brushes.White;
        public Brush FooterBgBrush   { get; init; } = Brushes.WhiteSmoke;
        public Brush BorderBrush     { get; init; } = Brushes.LightGray;
        public Brush PillBgBrush     { get; init; } = Brushes.WhiteSmoke;
        public Brush PillTextBrush   { get; init; } = Brushes.DimGray;
        public Brush TextStrongBrush { get; init; } = Brushes.Black;
        public Brush TextMutedBrush  { get; init; } = Brushes.Gray;
        public Brush ChairBrush      { get; init; } = Brushes.DimGray;
        public Brush ChairBgBrush    { get; init; } = Brushes.WhiteSmoke;
        public Color ShadowColor     { get; init; }
    }

    private static readonly FontFamily SegoeMdl2 = new("Segoe MDL2 Assets");
    private static readonly Brush GoldBrush      = new SolidColorBrush(Color.FromRgb(0xC9, 0xA4, 0x5F));

    private static StylePalette PaletteFor(WaiterTableSurfaceState s) => s switch
    {
        WaiterTableSurfaceState.KitchenPending => new StylePalette
        {
            AccentBrush     = new SolidColorBrush(Color.FromRgb(0xDC, 0xA6, 0x4F)),
            CardBgBrush     = MakeVGradient(Color.FromRgb(0xFF, 0xFF, 0xFF), Color.FromRgb(0xFD, 0xF3, 0xDC)),
            FooterBgBrush   = new SolidColorBrush(Color.FromRgb(0xFA, 0xEB, 0xCB)),
            BorderBrush     = new SolidColorBrush(Color.FromRgb(0xE9, 0xC9, 0x88)),
            PillBgBrush     = new SolidColorBrush(Color.FromRgb(0xF7, 0xE4, 0xBA)),
            PillTextBrush   = new SolidColorBrush(Color.FromRgb(0x7A, 0x52, 0x1A)),
            TextStrongBrush = new SolidColorBrush(Color.FromRgb(0x3D, 0x2A, 0x10)),
            TextMutedBrush  = new SolidColorBrush(Color.FromRgb(0x8C, 0x6D, 0x32)),
            ChairBrush      = new SolidColorBrush(Color.FromRgb(0xB1, 0x8A, 0x44)),
            ChairBgBrush    = new SolidColorBrush(Color.FromRgb(0xF6, 0xE7, 0xC3)),
            ShadowColor     = Color.FromRgb(0x88, 0x60, 0x20)
        },
        WaiterTableSurfaceState.DraftOnly => new StylePalette
        {
            AccentBrush     = new SolidColorBrush(Color.FromRgb(0x8F, 0xBC, 0x7A)),
            CardBgBrush     = MakeVGradient(Color.FromRgb(0xFF, 0xFF, 0xFF), Color.FromRgb(0xF0, 0xF8, 0xE6)),
            FooterBgBrush   = new SolidColorBrush(Color.FromRgb(0xE8, 0xF3, 0xDC)),
            BorderBrush     = new SolidColorBrush(Color.FromRgb(0xC4, 0xDB, 0xAE)),
            PillBgBrush     = new SolidColorBrush(Color.FromRgb(0xDC, 0xEE, 0xCA)),
            PillTextBrush   = new SolidColorBrush(Color.FromRgb(0x2A, 0x5A, 0x2E)),
            TextStrongBrush = new SolidColorBrush(Color.FromRgb(0x1E, 0x33, 0x21)),
            TextMutedBrush  = new SolidColorBrush(Color.FromRgb(0x55, 0x74, 0x4E)),
            ChairBrush      = new SolidColorBrush(Color.FromRgb(0x7E, 0xA1, 0x6A)),
            ChairBgBrush    = new SolidColorBrush(Color.FromRgb(0xE2, 0xEE, 0xD2)),
            ShadowColor     = Color.FromRgb(0x44, 0x68, 0x3A)
        },
        WaiterTableSurfaceState.DraftAndKitchen => new StylePalette
        {
            AccentBrush     = new SolidColorBrush(Color.FromRgb(0xDD, 0x8A, 0x2A)),
            CardBgBrush     = MakeVGradient(Color.FromRgb(0xFF, 0xFF, 0xFF), Color.FromRgb(0xFC, 0xE5, 0xC6)),
            FooterBgBrush   = new SolidColorBrush(Color.FromRgb(0xF6, 0xDC, 0xB2)),
            BorderBrush     = new SolidColorBrush(Color.FromRgb(0xE6, 0xAE, 0x6E)),
            PillBgBrush     = new SolidColorBrush(Color.FromRgb(0xF8, 0xD2, 0x9D)),
            PillTextBrush   = new SolidColorBrush(Color.FromRgb(0x77, 0x3E, 0x09)),
            TextStrongBrush = new SolidColorBrush(Color.FromRgb(0x38, 0x21, 0x0A)),
            TextMutedBrush  = new SolidColorBrush(Color.FromRgb(0x8A, 0x5C, 0x20)),
            ChairBrush      = new SolidColorBrush(Color.FromRgb(0xC2, 0x7E, 0x2D)),
            ChairBgBrush    = new SolidColorBrush(Color.FromRgb(0xF6, 0xD8, 0xAE)),
            ShadowColor     = Color.FromRgb(0x88, 0x4D, 0x18)
        },
        _ => new StylePalette
        {
            AccentBrush     = new SolidColorBrush(Color.FromRgb(0x9D, 0xC4, 0x86)),
            CardBgBrush     = MakeVGradient(Color.FromRgb(0xFF, 0xFF, 0xFF), Color.FromRgb(0xF7, 0xFB, 0xF1)),
            FooterBgBrush   = new SolidColorBrush(Color.FromRgb(0xEF, 0xF5, 0xE6)),
            BorderBrush     = new SolidColorBrush(Color.FromRgb(0xD7, 0xE2, 0xC5)),
            PillBgBrush     = new SolidColorBrush(Color.FromRgb(0xE3, 0xEF, 0xD3)),
            PillTextBrush   = new SolidColorBrush(Color.FromRgb(0x34, 0x5F, 0x3A)),
            TextStrongBrush = new SolidColorBrush(Color.FromRgb(0x1F, 0x2A, 0x33)),
            TextMutedBrush  = new SolidColorBrush(Color.FromRgb(0x6A, 0x78, 0x6F)),
            ChairBrush      = new SolidColorBrush(Color.FromRgb(0x90, 0xA0, 0x96)),
            ChairBgBrush    = new SolidColorBrush(Color.FromRgb(0xEC, 0xF2, 0xE6)),
            ShadowColor     = Color.FromRgb(0x33, 0x44, 0x3A)
        }
    };

    private static Brush MakeVGradient(Color top, Color bottom) =>
        new LinearGradientBrush
        {
            StartPoint = new Point(0, 0),
            EndPoint   = new Point(0, 1),
            GradientStops =
            {
                new GradientStop(top, 0),
                new GradientStop(bottom, 1)
            }
        };

    // ════════════════════════════════════════════════════════════════════
    //                       SPACE VISUAL (zones)
    // ════════════════════════════════════════════════════════════════════
    private static UIElement CreateSpaceVisual(FloorSpaceModel s)
    {
        var b = new Border
        {
            Width = s.Width, Height = s.Height,
            CornerRadius = new CornerRadius(16),
            BorderThickness = new Thickness(1.5),
            BorderBrush = new SolidColorBrush(Color.FromArgb(70, 0x27, 0x32, 0x3A)),
            Background = new SolidColorBrush(ToColor(s.TintArgb)),
            IsHitTestVisible = false, SnapsToDevicePixels = true,
            Effect = new DropShadowEffect
            { BlurRadius = 12, ShadowDepth = 2, Opacity = 0.10, Color = Color.FromRgb(0x27, 0x32, 0x3A) }
        };
        b.Child = new TextBlock
        {
            Text = s.Name,
            FontSize = 13, FontWeight = FontWeights.SemiBold,
            Foreground = new SolidColorBrush(Color.FromRgb(0x27, 0x32, 0x3A)),
            Margin = new Thickness(14, 10, 14, 0),
            Opacity = 0.80
        };
        Canvas.SetLeft(b, s.X); Canvas.SetTop(b, s.Y);
        Panel.SetZIndex(b, Math.Clamp(s.ZOrder, 0, 80));
        return b;
    }

    // ════════════════════════════════════════════════════════════════════
    //              SIMPLE CARD (used by legacy Render() entry)
    // ════════════════════════════════════════════════════════════════════
    private static UIElement CreateSimpleTableCard(
        FloorTableModel t, string? selectedId, Action<FloorTableModel> onClick)
    {
        var isSel = !string.IsNullOrEmpty(selectedId)
                    && string.Equals(t.Id, selectedId, StringComparison.OrdinalIgnoreCase);

        var fake = new WaiterTableStatusUi
        {
            State = WaiterTableSurfaceState.Free,
            StatusLine = "Liberă"
        };
        var p = PaletteFor(fake.State);

        var host = new Canvas { Width = SlotW, Height = SlotH, Tag = t, Cursor = Cursors.Hand };

        AddChairs(host, t.Seats, p.ChairBrush, p.ChairBgBrush);

        var card = new Border
        {
            Width = CardW, Height = CardH,
            CornerRadius = new CornerRadius(18),
            BorderBrush = isSel ? GoldBrush : p.BorderBrush,
            BorderThickness = new Thickness(isSel ? 2 : 1),
            Background = p.CardBgBrush,
            Effect = new DropShadowEffect
            {
                BlurRadius = 22, ShadowDepth = 6, Opacity = 0.22,
                Color = isSel ? Color.FromRgb(0xD8, 0xB2, 0x6E) : p.ShadowColor
            }
        };

        var grid = new Grid();
        grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(4) });
        grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        grid.Children.Add(new Border
        {
            CornerRadius = new CornerRadius(18, 18, 0, 0),
            Background = p.AccentBrush
        });

        var body = new StackPanel { Margin = new Thickness(16, 16, 16, 4) };
        body.Children.Add(new TextBlock
        {
            Text = t.Name,
            FontSize = 22, FontWeight = FontWeights.Bold,
            Foreground = p.TextStrongBrush
        });
        body.Children.Add(new TextBlock
        {
            Text = "Liberă",
            FontSize = 11, FontWeight = FontWeights.SemiBold,
            Foreground = p.PillTextBrush,
            Margin = new Thickness(0, 4, 0, 0)
        });
        Grid.SetRow(body, 1); grid.Children.Add(body);

        var footer = new Border
        {
            Padding = new Thickness(16, 6, 16, 10),
            Background = p.FooterBgBrush,
            CornerRadius = new CornerRadius(0, 0, 18, 18)
        };
        footer.Child = new TextBlock
        {
            Text = t.Seats > 0 ? $"{t.Seats} {(t.Seats == 1 ? "loc" : "locuri")}" : "",
            FontSize = 10, FontWeight = FontWeights.SemiBold,
            Foreground = p.TextMutedBrush
        };
        Grid.SetRow(footer, 2); grid.Children.Add(footer);

        card.Child = grid;
        Canvas.SetLeft(card, CardOffsetX);
        Canvas.SetTop(card, CardOffsetY);
        host.Children.Add(card);

        host.MouseLeftButtonDown += (_, e) => { e.Handled = true; onClick(t); };
        return host;
    }

    private static Color ToColor(int argb)
    {
        unchecked
        {
            var u = (uint)argb;
            return Color.FromArgb((byte)((u >> 24) & 0xFF), (byte)((u >> 16) & 0xFF),
                (byte)((u >> 8) & 0xFF), (byte)(u & 0xFF));
        }
    }
}

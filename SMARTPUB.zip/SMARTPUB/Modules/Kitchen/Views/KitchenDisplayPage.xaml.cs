using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Modules.Kitchen.Views;

public partial class KitchenDisplayPage : Page
{
    private readonly DispatcherTimer _syncTimer;

    public KitchenDisplayPage()
    {
        InitializeComponent();
        _syncTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(5) };
        _syncTimer.Tick += (_, _) => KitchenTicketStore.Instance.SyncFromDisk();
        Loaded += OnLoaded;
        Unloaded += OnUnloaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        KitchenTicketStore.Instance.Changed += OnTicketsChanged;
        _syncTimer.Start();
        RefreshList();
    }

    private void OnUnloaded(object sender, RoutedEventArgs e)
    {
        KitchenTicketStore.Instance.Changed -= OnTicketsChanged;
        _syncTimer.Stop();
    }

    private void OnTicketsChanged(object? sender, EventArgs e)
    {
        if (Dispatcher.CheckAccess())
            RefreshList();
        else
            Dispatcher.BeginInvoke(RefreshList);
    }

    private void Filter_Changed(object sender, RoutedEventArgs e) => RefreshList();

    private void BtnRefresh_Click(object sender, RoutedEventArgs e)
    {
        KitchenTicketStore.Instance.SyncFromDisk();
        RefreshList();
    }

    private void RefreshList()
    {
        var list = KitchenTicketStore.Instance.GetSnapshot().ToList();
        if (ChkOnlyActive.IsChecked == true)
        {
            list = list
                .Where(t => t.Status is not KitchenTicketStatus.Served
                    and not KitchenTicketStatus.Cancelled)
                .ToList();
        }

        TicketsItems.ItemsSource = list.OrderBy(t => t.CreatedAtUtc).ToList();
        var n = list.Count;
        TxtSubtitle.Text = n == 0 ? "Nicio comandă în listă" : $"{n} comenzi afișate";
    }

    private void BtnStart_Click(object sender, RoutedEventArgs e) =>
        SetStatus(sender, KitchenTicketStatus.InProgress);

    private void BtnReady_Click(object sender, RoutedEventArgs e) =>
        SetStatus(sender, KitchenTicketStatus.Ready);

    private void BtnServed_Click(object sender, RoutedEventArgs e) =>
        SetStatus(sender, KitchenTicketStatus.Served);

    private void BtnCancel_Click(object sender, RoutedEventArgs e) =>
        SetStatus(sender, KitchenTicketStatus.Cancelled);

    private static void SetStatus(object sender, KitchenTicketStatus status)
    {
        if (sender is not Button { Tag: string id })
            return;
        KitchenTicketStore.Instance.UpdateStatus(id, status);
    }
}

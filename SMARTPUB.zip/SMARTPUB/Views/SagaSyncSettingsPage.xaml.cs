using System.IO;
using System.Threading.Tasks;
using System.Windows;
using FirebirdSql.Data.FirebirdClient;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;
using SMARTPUB;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Views;

public partial class SagaSyncSettingsPage : Page
{
    private readonly SagaWorkerClient _worker = new();
    private readonly SagaSyncSettingsRepository _repo = new();
    private readonly SagaSyncImportService _importer = new();
    private List<SagaCompany> _companies = new();
    private SagaCompany? _selectedCompany;
    private string? _lastSagaFbClientPath;
    private SagaConnectionMode _loadedConnectionMode = SagaConnectionMode.Embedded;

    public SagaSyncSettingsPage()
    {
        InitializeComponent();
        DetectFbClient();
        LoadFromSmartpubDb();
    }

    private SagaSyncSettingsData BuildSettingsDataFromUi(FbConnection conn)
    {
        return BuildSettingsData(
            conn,
            TxtSagaPath.Text.Trim(),
            _selectedCompany,
            SagaConnectionDefaults.TryGetPreferredTcpFbClientPath() ?? _lastSagaFbClientPath);
    }

    private SagaSyncSettingsData BuildSettingsData(
        FbConnection conn,
        string sagaRootPath,
        SagaCompany? selectedCompany,
        string? fbClientPath)
    {
        var existing = _repo.LoadData(conn);

        return new SagaSyncSettingsData
        {
            ConnectionMode = SagaConnectionMode.Embedded,
            SagaRootPath = sagaRootPath,
            ServerHost = existing.ServerHost,
            ServerPort = existing.ServerPort <= 0 ? SagaConnectionDefaults.FirebirdServerPort : existing.ServerPort,
            ServerSagaRoot = existing.ServerSagaRoot,
            FbClientPath = fbClientPath,
            Company = selectedCompany
        };
    }

    private void LoadFromSmartpubDb()
    {
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SagaSettingsSchema.EnsureSchema(conn);
            var data = _repo.LoadData(conn);

            _loadedConnectionMode = data.ConnectionMode;

            if (!string.IsNullOrWhiteSpace(data.SagaRootPath))
                TxtSagaPath.Text = data.SagaRootPath;

            if (data.ConnectionMode == SagaConnectionMode.Server)
            {
                TxtSagaModeBanner.Visibility = Visibility.Visible;
                TxtSagaModeBanner.Text =
                    "Există și setări Client–Server salvate, dar această pagină sincronizează local din folderul SAGA selectat mai jos.";
            }
            else
            {
                TxtSagaModeBanner.Visibility = Visibility.Collapsed;
            }

            var prefFb = SagaConnectionDefaults.TryGetPreferredTcpFbClientPath();
            if (!string.IsNullOrWhiteSpace(prefFb))
            {
                _lastSagaFbClientPath = prefFb;
                TxtFbInfo.Text = $"SAGA fbclient (prioritar TCP): {prefFb}";
                TxtFbClientStatus.Text = "fbclient OK";
                TxtFbClientStatus.Foreground = new SolidColorBrush(Color.FromRgb(0x6F, 0xBF, 0x73));
            }
            else
            {
                _lastSagaFbClientPath = data.FbClientPath;
                if (!string.IsNullOrWhiteSpace(data.FbClientPath))
                {
                    TxtFbInfo.Text = $"SAGA fbclient detectat (ultimul salvat): {data.FbClientPath}";
                    TxtFbClientStatus.Text = "SAGA client salvat";
                    TxtFbClientStatus.Foreground = new SolidColorBrush(Color.FromRgb(0x6F, 0xBF, 0x73));
                }
            }

            if (data.Company != null)
            {
                _selectedCompany = data.Company;
                _companies = new List<SagaCompany> { data.Company };
                LvCompanies.ItemsSource = _companies;
                LvCompanies.SelectedItem = data.Company;
            }
        }
        catch (Exception ex)
        {
            ShowStatus(
                "Nu am putut încărca setările din SMARTPUB.FDB.\n" +
                $"DB: {SmartPubDb.DefaultDbPath}\n" +
                ex.Message,
                isError: true);
        }
    }

    private void DetectFbClient()
    {
        try
        {
            var path = FirebirdClientLocator.GetFbClientPath();
            TxtFbInfo.Text = $"Client Firebird aplicație (SMARTPUB): {path}";
            TxtFbClientStatus.Text = "App client OK";
            TxtFbClientStatus.Foreground = new SolidColorBrush(Color.FromRgb(0x6F, 0xBF, 0x73));
        }
        catch (FileNotFoundException ex)
        {
            TxtFbInfo.Text = $"Client Firebird aplicație NU a fost găsit.\n{ex.Message}";
            TxtFbClientStatus.Text = "App client LIPSĂ";
            TxtFbClientStatus.Foreground = new SolidColorBrush(Color.FromRgb(0xC9, 0x4A, 0x4A));
        }
    }

    private void BtnBrowseSaga_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFolderDialog
        {
            Title = "Selectează folderul instalare SAGA",
            Multiselect = false
        };

        if (dlg.ShowDialog() == true)
            TxtSagaPath.Text = dlg.FolderName;
    }

    private void BtnScanCompanies_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var sagaPath = TxtSagaPath.Text.Trim();
            if (string.IsNullOrWhiteSpace(sagaPath) || !Directory.Exists(sagaPath))
            {
                ShowStatus("Calea SAGA nu este validă sau nu există.", isError: true);
                return;
            }

            var configFdb = Path.Combine(sagaPath, "CONFIG.FDB");
            if (!File.Exists(configFdb))
            {
                ShowStatus($"CONFIG.FDB nu a fost găsit în:\n{sagaPath}", isError: true);
                return;
            }

            var localResult = _worker.Scan(sagaPath);
            if (!localResult.Success)
            {
                ShowStatus($"Eroare la scanare:\n{localResult.Error}", isError: true);
                return;
            }

            FinishScanResult(localResult);
        }
        catch (Exception ex)
        {
            ShowStatus($"Eroare la scanare:\n{ex.Message}", isError: true);
        }
    }

    private void FinishScanResult((bool Success, string? Error, string? FbClientPath, List<SagaCompany> Companies) result)
    {
        _lastSagaFbClientPath = result.FbClientPath;
        if (!string.IsNullOrWhiteSpace(result.FbClientPath))
        {
            TxtFbInfo.Text = $"SAGA fbclient folosit de worker: {result.FbClientPath}";
            TxtFbClientStatus.Text = "SAGA worker OK";
            TxtFbClientStatus.Foreground = new SolidColorBrush(Color.FromRgb(0x6F, 0xBF, 0x73));
        }

        _companies = result.Companies;
        LvCompanies.ItemsSource = _companies;

        if (_companies.Count == 0)
            ShowStatus("Nicio firmă găsită în CONFIG.FDB.", isError: true);
        else
            ShowStatus($"{_companies.Count} firmă(e) detectată(e) cu succes.", isError: false);
    }

    private void LvCompanies_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        _selectedCompany = LvCompanies.SelectedItem as SagaCompany;
    }

    private void BtnTestConnection_Click(object sender, RoutedEventArgs e)
    {
        if (_selectedCompany == null)
        {
            ShowStatus("Selectează mai întâi o firmă din lista de sus.", isError: true);
            return;
        }

        try
        {
            var sagaRootArg = TxtSagaPath.Text.Trim();
            if (string.IsNullOrWhiteSpace(sagaRootArg) || !Directory.Exists(sagaRootArg))
            {
                ShowStatus("Calea SAGA locală nu este validă.", isError: true);
                return;
            }

            var result = _worker.Test(
                _selectedCompany.DatabasePath,
                sagaRootArg,
                SagaConnectionMode.Embedded);

            if (!result.Success)
            {
                ShowStatus($"Conexiune eșuată:\n{result.Error}", isError: true);
                return;
            }

            _lastSagaFbClientPath = result.FbClientPath;
            if (!string.IsNullOrWhiteSpace(result.FbClientPath))
            {
                TxtFbInfo.Text = $"SAGA fbclient folosit de worker: {result.FbClientPath}";
                TxtFbClientStatus.Text = "SAGA worker OK";
                TxtFbClientStatus.Foreground = new SolidColorBrush(Color.FromRgb(0x6F, 0xBF, 0x73));
            }

            ShowStatus(
                $"Conexiune reușită la firma: {_selectedCompany}\n" +
                $"Baza de date: {_selectedCompany.DatabasePath}\n" +
                $"Firebird engine: {result.EngineVersion ?? "N/A"}",
                isError: false);
        }
        catch (Exception ex)
        {
            ShowStatus($"Conexiune eșuată:\n{ex.Message}", isError: true);
        }
    }

    private void BtnSaveSettings_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SagaSettingsSchema.EnsureSchema(conn);
            var d = BuildSettingsDataFromUi(conn);
            _repo.Save(conn, d);
            ShowStatus(
                "Setări salvate în SMARTPUB.FDB.\n" +
                $"Mod: {d.ConnectionMode}\n" +
                $"Firma: {_selectedCompany?.ToString() ?? "neselectată"}",
                isError: false);
        }
        catch (Exception ex)
        {
            ShowStatus(
                "Salvarea în SMARTPUB.FDB a eșuat.\n" +
                $"DB: {SmartPubDb.DefaultDbPath}\n" +
                ex.Message,
                isError: true);
        }
    }

    private async void BtnSyncSaga_Click(object sender, RoutedEventArgs e)
    {
        var selectedCompany = _selectedCompany;
        if (selectedCompany == null)
        {
            ShowStatus("Selectează firma SAGA pe care vrei să o sincronizezi.", isError: true);
            return;
        }

        var sagaRootForWorker = TxtSagaPath.Text.Trim();

        if (string.IsNullOrWhiteSpace(sagaRootForWorker) || !Directory.Exists(sagaRootForWorker))
        {
            ShowStatus("Calea SAGA locală nu este validă.", isError: true);
            return;
        }

        // Popup: alege tipurile de articole + preview înainte de sincronizare.
        var listRes = await Task.Run(() => _worker.ListArticles(
            selectedCompany.DatabasePath,
            sagaRootForWorker,
            SagaConnectionMode.Embedded));

        if (!listRes.Success)
        {
            ShowStatus($"Nu am putut citi articolele din SAGA:\n{listRes.Error}", isError: true);
            return;
        }

        var typesDlg = new SagaSyncTypesDialog(listRes.Articles) { Owner = Window.GetWindow(this) };
        if (typesDlg.ShowDialog() != true)
            return;

        var includeDenTip = typesDlg.SelectedDenTip;

        SetSyncBusy(true);
        ShowSyncOverlay(true);
        try
        {
            await SetSyncProgressAsync(5, "Pregătire sincronizare...");
            await SetSyncProgressAsync(15, "Export din SAGA (articole, clienți, rețete)...");

            var export = await Task.Run(() => _worker.Export(
                selectedCompany.DatabasePath,
                sagaRootForWorker,
                SagaConnectionMode.Embedded,
                includeDenTip: includeDenTip));

            if (!export.Success || export.Sync == null)
            {
                ShowStatus($"Export SAGA eșuat:\n{export.Error}", isError: true);
                return;
            }

            _lastSagaFbClientPath = export.FbClientPath;
            if (!string.IsNullOrWhiteSpace(export.FbClientPath))
            {
                TxtFbInfo.Text = $"SAGA fbclient folosit de worker: {export.FbClientPath}";
                TxtFbClientStatus.Text = "SAGA worker OK";
                TxtFbClientStatus.Foreground = new SolidColorBrush(Color.FromRgb(0x6F, 0xBF, 0x73));
            }

            await SetSyncProgressAsync(40, "Export finalizat.");
            await SetSyncProgressAsync(52, "Import în SMARTPUB.FDB...");

            (int Gestiuni, int Articole, int Retete, int ReteteDet, int RecipeLines, int Clienti) counts = default;
            await Task.Run(() =>
            {
                using var conn = SmartPubDb.OpenEmbedded();
                SagaSettingsSchema.EnsureSchema(conn);
                _importer.EnsureSchema(conn);
                counts = _importer.UpsertAll(conn, export.Sync);
                _repo.Save(conn, BuildSettingsData(conn, sagaRootForWorker, selectedCompany, export.FbClientPath));
            });

            WaiterProductCatalogCache.Instance.Invalidate();
            WaiterProductCatalogCache.Instance.PreloadAsync();

            await SetSyncProgressAsync(94, "Finalizare...");
            await SetSyncProgressAsync(100, "Sincronizare completă.");
            await Task.Delay(380);

            ShowStatus(
                "Sincronizare SAGA finalizată cu succes.\n" +
                $"Gestiuni: {counts.Gestiuni}\n" +
                $"Articole: {counts.Articole}\n" +
                $"Rețete: {counts.Retete}\n" +
                $"Detalii rețete: {counts.ReteteDet}\n" +
                $"Linii rețetă (1:1): {counts.RecipeLines}\n" +
                $"Clienți: {counts.Clienti}",
                isError: false);
        }
        catch (Exception ex)
        {
            ShowStatus($"Sincronizare eșuată:\n{ex.Message}", isError: true);
        }
        finally
        {
            ShowSyncOverlay(false);
            SetSyncBusy(false);
        }
    }

    private void SetSyncBusy(bool busy)
    {
        BtnSyncSaga.IsEnabled = !busy;
        BtnScanCompanies.IsEnabled = !busy;
        BtnTestConnection.IsEnabled = !busy;
        BtnSaveSettings.IsEnabled = !busy;
        BtnBrowseSaga.IsEnabled = !busy;
    }

    private void ShowSyncOverlay(bool visible)
    {
        SyncOverlay.Visibility = visible ? Visibility.Visible : Visibility.Collapsed;
        if (!visible)
        {
            SyncProgressRing.Percent = 0;
            TxtSyncPercent.Text = "0%";
            TxtSyncStep.Text = "";
        }
    }

    private async Task SetSyncProgressAsync(int percent, string step)
    {
        percent = Math.Clamp(percent, 0, 100);
        await Dispatcher.InvokeAsync(() =>
        {
            SyncProgressRing.Percent = percent;
            TxtSyncPercent.Text = $"{percent}%";
            TxtSyncStep.Text = step;
        });
        await Task.Delay(25);
    }

    private void ShowStatus(string message, bool isError)
    {
        StatusPanel.Visibility = Visibility.Visible;
        TxtStatus.Text = message;

        if (isError)
        {
            StatusPanel.Background = new SolidColorBrush(Color.FromArgb(0x20, 0xC9, 0x4A, 0x4A));
            TxtStatus.Foreground = new SolidColorBrush(Color.FromRgb(0xC9, 0x4A, 0x4A));
        }
        else
        {
            StatusPanel.Background = new SolidColorBrush(Color.FromArgb(0x20, 0x6F, 0xBF, 0x73));
            TxtStatus.Foreground = new SolidColorBrush(Color.FromRgb(0x3A, 0x7D, 0x3E));
        }
    }
}

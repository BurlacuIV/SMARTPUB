using System.Collections.Generic;
using System.IO;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Printing;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using Microsoft.Win32;
using FirebirdSql.Data.FirebirdClient;
using SMARTPUB;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Views;

public partial class ProgramConfigurationPage : Page
{
    private readonly ProgramSettingsRepository _repo = new();
    private readonly ProgramSaleSettingsRepository _saleRepo = new();
    private readonly ProgramExtendedConfigRepository _extRepo = new();
    private readonly SagaSyncSettingsRepository _sagaRepo = new();
    private readonly SagaWorkerClient _sagaWorker = new();
    private readonly ObservableCollection<NetworkServerRow> _netServers = new();
    private readonly OrderRoutingRepository _routingRepo = new();
    private readonly ObservableCollection<GroupDestRow> _groupDest = new();
    private List<SagaCompany> _sagaCsCompanies = new();
    private SagaCompany? _sagaCsSelected;
    private List<string> _transferClientOptions = new();
    private List<string> _transferAccountOptions = new();
    private readonly Dictionary<ComboBox, List<string>> _comboSearchSources = new();
    private bool _updatingComboFilter;
    private bool _pageDataLoaded;
    private bool _printersLoaded;
    private bool _transferOptionsLoaded;

    public ProgramConfigurationPage()
    {
        InitializeComponent();
        GridNetServers.ItemsSource = _netServers;
        InitGroupDestColumn();
        RegisterTransferSearchCombos();
        Loaded += OnPageLoaded;
        MainTabs.SelectionChanged += MainTabs_SelectionChanged;
    }

    private async void OnPageLoaded(object sender, RoutedEventArgs e)
    {
        if (_pageDataLoaded)
            return;

        try
        {
            await Task.Run(LoadFromDbCore).ConfigureAwait(true);
            await Task.Run(LoadGroupDestCore).ConfigureAwait(true);
            _pageDataLoaded = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Nu am putut încărca setările.\n" + ex.Message,
                "Configurare program",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }
    }

    private void MainTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (MainTabs.SelectedItem is TabItem tab)
        {
            var header = tab.Header?.ToString() ?? "";
            if (!_transferOptionsLoaded &&
                header.Contains("Transfer", StringComparison.OrdinalIgnoreCase))
            {
                _transferOptionsLoaded = true;
                _ = Task.Run(LoadTransferAccountOptionsCore);
            }
        }

        if (_printersLoaded || MainTabs.SelectedItem is not TabItem tab2)
            return;
        if (tab2.Header?.ToString()?.Contains("Perifer", StringComparison.OrdinalIgnoreCase) != true &&
            tab2.Header?.ToString()?.Contains("Imprim", StringComparison.OrdinalIgnoreCase) != true)
            return;

        _printersLoaded = true;
        _ = Task.Run(() =>
        {
            var names = CollectPrinterNames();
            Dispatcher.Invoke(() => ApplyPrinterNamesToCombos(names));
        });
    }

    private void InitGroupDestColumn()
    {
        ColGroupDest.ItemsSource = new[]
        {
            new DestOption { Value = "", Label = "Auto (bucătărie)" },
            new DestOption { Value = OrderDestination.Bar, Label = "Bar" },
            new DestOption { Value = OrderDestination.Kitchen, Label = "Bucătărie" }
        };
        ColGroupDest.SelectedValuePath = "Value";
        ColGroupDest.DisplayMemberPath = "Label";
        GridGroupDest.ItemsSource = _groupDest;
    }

    private void LoadGroupDestCore()
    {
        using var conn = SmartPubDb.OpenEmbedded();
        var map = _routingRepo.LoadGroupMap(conn);
        var groups = new SyncedProductsRepository().ListDistinctGroupsForRouting(conn)
            .Select(g => new GroupDestRow
            {
                Code = g.Code,
                Display = g.Display,
                Destinatie = map.TryGetValue(g.Code, out var d) ? d : ""
            })
            .OrderBy(x => x.Display, StringComparer.OrdinalIgnoreCase)
            .ToList();

        Dispatcher.Invoke(() =>
        {
            _groupDest.Clear();
            foreach (var row in groups)
                _groupDest.Add(row);
        });
    }

    private void BtnAllBar_Click(object sender, RoutedEventArgs e) => SetAllGroupDest(OrderDestination.Bar);

    private void BtnAllKitchen_Click(object sender, RoutedEventArgs e) => SetAllGroupDest(OrderDestination.Kitchen);

    private void SetAllGroupDest(string dest)
    {
        GridGroupDest.CommitEdit(DataGridEditingUnit.Row, true);
        foreach (var row in _groupDest)
            row.Destinatie = dest;
        GridGroupDest.Items.Refresh();
    }

    private void BtnSaveRouting_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            GridGroupDest.CommitEdit(DataGridEditingUnit.Row, true);
            using var conn = SmartPubDb.OpenEmbedded();
            foreach (var row in _groupDest)
                _routingRepo.SaveGroupDestination(conn, row.Code, row.Destinatie);

            WaiterProductCatalogCache.Instance.Invalidate();
            WaiterProductCatalogCache.Instance.PreloadAsync();

            MessageBox.Show("Rutarea comenzilor a fost salvată.", "Rutare comenzi",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Salvarea rutării a eșuat.\n" + ex.Message, "Rutare comenzi",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private sealed class GroupDestRow
    {
        public string Code { get; set; } = "";
        public string Display { get; set; } = "";
        public string Destinatie { get; set; } = "";
    }

    private sealed class DestOption
    {
        public string Value { get; set; } = "";
        public string Label { get; set; } = "";
    }

    private static List<string> CollectPrinterNames()
    {
        var names = new List<string>();
        try
        {
            using var server = new LocalPrintServer();
            foreach (var q in server.GetPrintQueues(new[]
                     {
                         EnumeratedPrintQueueTypes.Local, EnumeratedPrintQueueTypes.Connections
                     }))
            {
                try
                {
                    names.Add(q.Name);
                }
                catch
                {
                    /* ignore broken queue */
                }
            }
        }
        catch
        {
            names.Add("Microsoft Print to PDF");
        }

        names.Sort(StringComparer.OrdinalIgnoreCase);
        return names.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }

    private void ApplyPrinterNamesToCombos(IReadOnlyList<string> names)
    {
        foreach (var cmb in new[] { CmbPrinterFirm, CmbPrinterBill, CmbPrinterInvoice, CmbPrinterBar, CmbPrinterKitchen })
        {
            cmb.Items.Clear();
            foreach (var n in names)
                cmb.Items.Add(n);
        }
    }

    private void LoadFromDbCore()
    {
        using var conn = SmartPubDb.OpenEmbedded();
        var s = _repo.Load(conn);
        var sale = _saleRepo.Load(conn);
        var display = _extRepo.LoadDisplay(conn);
        var transfer = _extRepo.LoadTransfer(conn);
        var fiscal = _extRepo.LoadFiscal(conn);
        var network = _extRepo.LoadNetwork(conn);
        var saga = LoadSagaClientServerData(conn);
        var transferClients = LoadTransferClientOptions(conn);

        Dispatcher.Invoke(() =>
        {
            ApplyTransferClientOptions(transferClients);
            ApplyTransferAccountOptions(GetDefaultTransferAccounts());
            ApplyRowToUi(s);
            ApplySaleToUi(sale);
            ApplyDisplayToUi(display);
            ApplyTransferToUi(transfer);
            ApplyFiscalToUi(fiscal);
            ApplyNetworkToUi(network);
            ApplySagaClientServerToUi(saga);
        });
    }

    private static List<string> LoadTransferClientOptions(FbConnection conn)
    {
        if (!TableExists(conn, "SP_SAGA_CLIENTI"))
            return new List<string>();

        var list = new List<string>();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT TRIM(CODE) AS CODE, TRIM(COALESCE(NAME, '')) AS NAME
FROM SP_SAGA_CLIENTI
WHERE COALESCE(IS_BLOCKED, 0) = 0
ORDER BY NAME, CODE";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var code = (rd["CODE"]?.ToString() ?? "").Trim();
            if (code.Length == 0)
                continue;
            var name = (rd["NAME"]?.ToString() ?? "").Trim();
            list.Add(string.IsNullOrWhiteSpace(name) ? code : $"{code} - {name}");
        }

        return list;
    }

    private static List<string> GetDefaultTransferAccounts() => new()
    {
        "5311 - Casa in lei",
        "5121 - Conturi la banci in lei",
        "5124 - Conturi la banci in valuta"
    };

    private void LoadTransferAccountOptionsCore()
    {
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            var accounts = TryLoadTransferAccountOptions(conn);
            Dispatcher.Invoke(() => ApplyTransferAccountOptions(accounts));
        }
        catch (Exception ex)
        {
            Dispatcher.Invoke(() =>
            {
                ApplyTransferAccountOptions(GetDefaultTransferAccounts());
                MessageBox.Show(
                    "Conturile din SAGA nu au putut fi încărcate; se folosesc valori implicite.\n" + ex.Message,
                    "Transfer date",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            });
        }
    }

    private List<string> TryLoadTransferAccountOptions(FbConnection conn)
    {
        var defaults = GetDefaultTransferAccounts();

        var settings = _sagaRepo.LoadData(conn);
        var company = settings.Company;
        var db = company?.DatabasePath?.Trim();
        if (string.IsNullOrWhiteSpace(db))
            return defaults;

        var root = settings.ConnectionMode == SagaConnectionMode.Server
            ? (settings.ServerSagaRoot ?? settings.SagaRootPath ?? "").Trim()
            : (settings.SagaRootPath ?? "").Trim();

        if (settings.ConnectionMode == SagaConnectionMode.Server &&
            string.IsNullOrWhiteSpace(settings.ServerHost))
            return defaults;

        var result = _sagaWorker.ListAccounts(
            db,
            root,
            settings.ConnectionMode,
            settings.ServerHost,
            settings.ServerPort);

        if (!result.Success || result.Accounts.Count == 0)
            return defaults;

        return result.Accounts
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    private void ApplyTransferClientOptions(List<string> clients)
    {
        _transferClientOptions = clients;
        foreach (var cb in TransferClientCombos())
        {
            var current = cb.Text;
            SetSearchSource(cb, _transferClientOptions);
            cb.Text = current;
        }
    }

    private void ApplyTransferAccountOptions(List<string> accounts)
    {
        _transferAccountOptions = accounts;
        foreach (var cb in TransferAccountCombos())
        {
            var current = cb.Text;
            SetSearchSource(cb, _transferAccountOptions);
            cb.Text = AccountDisplay(current);
        }
    }

    private IEnumerable<ComboBox> TransferClientCombos()
    {
        yield return TransTxtImplicitClient;
        yield return TransCliNumerar;
        yield return TransCliCard;
        yield return TransCliBonuri;
        yield return TransCliCec;
        yield return TransCliModerne;
    }

    private IEnumerable<ComboBox> TransferAccountCombos()
    {
        yield return TransContNumerar;
        yield return TransContCard;
        yield return TransContBonuri;
        yield return TransContCec;
        yield return TransContModerne;
    }

    private void RegisterTransferSearchCombos()
    {
        foreach (var cb in TransferClientCombos().Concat(TransferAccountCombos()))
            cb.AddHandler(TextBoxBase.TextChangedEvent, new TextChangedEventHandler(SearchCombo_TextChanged));
    }

    private void SetSearchSource(ComboBox cb, List<string> source)
    {
        _comboSearchSources[cb] = source;
        cb.ItemsSource = null;
        cb.ItemsSource = source;
    }

    private void SearchCombo_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_updatingComboFilter || sender is not TextBox tb)
            return;
        var combo = FindParentComboBox(tb);
        if (combo == null || !_comboSearchSources.TryGetValue(combo, out var source))
            return;

        var text = tb.Text ?? "";
        var filtered = FilterOptions(source, text).Take(80).ToList();
        _updatingComboFilter = true;
        try
        {
            combo.ItemsSource = filtered.Count == 0 ? source.Take(80).ToList() : filtered;
            combo.IsDropDownOpen = true;
            tb.Text = text;
            tb.CaretIndex = text.Length;
        }
        finally
        {
            _updatingComboFilter = false;
        }
    }

    private static IEnumerable<string> FilterOptions(IEnumerable<string> source, string text)
    {
        var tokens = (text ?? "")
            .Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (tokens.Length == 0)
            return source.Take(80);
        return source.Where(x => tokens.All(t => x.Contains(t, StringComparison.OrdinalIgnoreCase)));
    }

    private static ComboBox? FindParentComboBox(DependencyObject? obj)
    {
        while (obj != null)
        {
            if (obj is ComboBox cb)
                return cb;
            obj = VisualTreeHelper.GetParent(obj);
        }

        return null;
    }

    private SagaSyncSettingsData LoadSagaClientServerData(FbConnection conn)
    {
        SagaSettingsSchema.EnsureSchema(conn);
        return _sagaRepo.LoadData(conn);
    }

    private void ApplySagaClientServerToUi(SagaSyncSettingsData saga)
    {
        TxtSagaServerPort.Text = saga.ServerPort > 0
            ? saga.ServerPort.ToString(CultureInfo.InvariantCulture)
            : SagaConnectionDefaults.FirebirdServerPort.ToString(CultureInfo.InvariantCulture);
        if (!string.IsNullOrWhiteSpace(saga.ServerSagaRoot))
            TxtSagaServerDbPath.Text = saga.ServerSagaRoot;
        if (!string.IsNullOrWhiteSpace(saga.ServerHost))
            TxtSagaServerIp.Text = saga.ServerHost;

        _sagaCsCompanies = saga.Company != null
            ? new List<SagaCompany> { saga.Company }
            : new List<SagaCompany>();
        LvSagaCsCompanies.ItemsSource = null;
        LvSagaCsCompanies.ItemsSource = _sagaCsCompanies;
        _sagaCsSelected = saga.Company;
        if (saga.Company != null)
            LvSagaCsCompanies.SelectedItem = saga.Company;
        TxtSagaCsStatus.Text = _sagaCsCompanies.Count == 0
            ? "Nicio firmă încărcată. Apasă „Scanează firme”."
            : $"Firmă salvată: {_sagaCsCompanies[0].Code} — {_sagaCsCompanies[0].Name}";
    }

    private void ApplySagaClientServerFromDb(FbConnection conn) =>
        ApplySagaClientServerToUi(LoadSagaClientServerData(conn));

    private void ApplyRowToUi(ProgramSettingsRow s)
    {
        SelectSagaMode(s.SagaConnMode);
        TxtSagaServerIp.Text = s.SagaServerIp;
        TxtSagaServerDbPath.Text = s.SagaServerDbFolder;
        SelectPrinterCombo(CmbPrinterFirm, s.PrinterFirmOrder);
        SelectPrinterCombo(CmbPrinterBill, s.PrinterBill);
        SelectPrinterCombo(CmbPrinterInvoice, s.PrinterInvoice);
        SelectPrinterCombo(CmbPrinterBar, s.PrinterBar);
        SelectPrinterCombo(CmbPrinterKitchen, s.PrinterKitchen);
        ChkSingleInstance.IsChecked = s.SingleInstance;
        ChkStartFullscreen.IsChecked = s.StartFullscreen;
        ChkCheckUpdates.IsChecked = s.CheckUpdatesOnStart;
        ChkAutoSyncNom.IsChecked = s.AutoSyncNomenclature;
        ChkAutoLogout.IsChecked = s.AutoLogoutSec >= 0;
        TxtAutoLogoutSec.Text = s.AutoLogoutSec >= 0 ? s.AutoLogoutSec.ToString() : "-1";
        ChkHotelMode.IsChecked = s.HotelMode;
    }

    private void ApplySaleToUi(ProgramSaleSettingsRow s)
    {
        SaleChkUltimaGestiune.IsChecked = s.ArticoleUltimaGestiune;
        SaleChkVindeImediat.IsChecked = s.VindeLaSelectare;
        SaleChkCumulVanzare.IsChecked = s.CumuleazaLaVanzare;
        SaleChkCumulNota.IsChecked = s.CumuleazaPeNota;
        SaleChkCumulBon.IsChecked = s.CumuleazaPeBonFiscal;
        SaleChkStocNegAfis.IsChecked = s.AfiseazaStocNegativ;
        SaleChkStocNegVanzare.IsChecked = s.PermiteVanzareStocNegativ;
        SaleChkIncasareFaraCf.IsChecked = s.IncasareFaraComandaFerma;
        SaleChkAfisBtnCf.IsChecked = s.AfiseazaButonComandaFerma;
        SaleChkTipAutoCf.IsChecked = s.TiparireAutoComandaFermaLaValidare;
        SaleChkIesireDupaVal.IsChecked = s.IesireAutoDupaValidare;
        SaleChkInchideBonAuto.IsChecked = s.InchideBonAutoDupaVanzare;
        SaleChkTipAutoNota.IsChecked = s.TiparireAutoNotaFaraPreview;
        SaleChkTipAutoBonInc.IsChecked = s.TiparireAutoBonLaIncasare;
        SaleChkIesireDupaTipBon.IsChecked = s.IesireAutoDupaTiparireBonFiscal;
        SaleChkGestButoane.IsChecked = s.AfiseazaGestiuneModButoane;
        SaleChkPretButoane.IsChecked = s.AfiseazaPretModButoane;
        SaleChkSunetMonitor.IsChecked = s.SuneteMonitorComenzi;
        SaleChkGestImplicitGrup.IsChecked = s.GestiuneImplicitaLaGrupa;
        SaleChkIncasareRapida.IsChecked = s.IncasareRapida;
        SaleChkTastaturaVirt.IsChecked = s.TastaturaVirtuala;

        if (string.Equals(s.ModVizualizareArticole, "List", StringComparison.OrdinalIgnoreCase))
            SaleRbVizLista.IsChecked = true;
        else
            SaleRbVizButoane.IsChecked = true;

        if (string.Equals(s.ModSortareArticole, "Alphabetical", StringComparison.OrdinalIgnoreCase))
            SaleRbSortAlfa.IsChecked = true;
        else
            SaleRbSortVanzari.IsChecked = true;

        if (string.Equals(s.TiparireComandaFerma, "Printer", StringComparison.OrdinalIgnoreCase))
            SaleRbPrintImprimanta.IsChecked = true;
        else
            SaleRbPrintGestiune.IsChecked = true;

        SaleTxtPlafon.Text = s.PlafonVanzare.ToString("0.00", CultureInfo.InvariantCulture);
        UpdateComandaFermaControls();
    }

    private void SaleChkIncasareFaraCf_OnChanged(object sender, RoutedEventArgs e) =>
        UpdateComandaFermaControls();

    private void UpdateComandaFermaControls()
    {
        var allow = SaleChkIncasareFaraCf.IsChecked == true;
        SaleChkAfisBtnCf.IsEnabled = allow;
        if (!allow)
            SaleChkAfisBtnCf.IsChecked = false;
    }

    private static void SelectPrinterCombo(ComboBox cmb, string? saved)
    {
        var t = (saved ?? "").Trim();
        if (t.Length == 0)
        {
            for (var i = 0; i < cmb.Items.Count; i++)
            {
                if (cmb.Items[i]?.ToString()?.Contains("PDF", StringComparison.OrdinalIgnoreCase) == true)
                {
                    cmb.SelectedIndex = i;
                    return;
                }
            }

            if (cmb.Items.Count > 0)
                cmb.SelectedIndex = 0;
            return;
        }

        for (var i = 0; i < cmb.Items.Count; i++)
        {
            if (string.Equals(cmb.Items[i]?.ToString(), t, StringComparison.OrdinalIgnoreCase))
            {
                cmb.SelectedIndex = i;
                return;
            }
        }

        cmb.Items.Add(t);
        cmb.SelectedItem = t;
    }

    private void SelectSagaMode(string mode)
    {
        var key = mode.Trim();
        if (key.Equals("Web", StringComparison.OrdinalIgnoreCase))
            key = "Web";
        else if (key.Equals("ClientServer", StringComparison.OrdinalIgnoreCase))
            key = "ClientServer";
        else
            key = "Standard";

        foreach (var obj in ListSagaMode.Items)
        {
            if (obj is ListBoxItem li && string.Equals(li.Tag?.ToString(), key, StringComparison.OrdinalIgnoreCase))
            {
                ListSagaMode.SelectedItem = li;
                UpdateSagaModePanels();
                return;
            }
        }

        if (ListSagaMode.Items[0] is ListBoxItem first)
            ListSagaMode.SelectedItem = first;
        UpdateSagaModePanels();
    }

    private string GetSelectedSagaMode()
    {
        if (ListSagaMode.SelectedItem is ListBoxItem li)
            return li.Tag?.ToString() ?? "Standard";
        return "Standard";
    }

    private void ListSagaMode_OnSelectionChanged(object sender, SelectionChangedEventArgs e) =>
        UpdateSagaModePanels();

    private void UpdateSagaModePanels()
    {
        var mode = GetSelectedSagaMode();
        PanelSagaStandard.Visibility = mode == "Standard" ? Visibility.Visible : Visibility.Collapsed;
        PanelSagaClientServer.Visibility = mode == "ClientServer" ? Visibility.Visible : Visibility.Collapsed;
        PanelSagaWeb.Visibility = mode == "Web" ? Visibility.Visible : Visibility.Collapsed;
    }

    private void BtnOpenSagaSync_Click(object sender, RoutedEventArgs e)
    {
        if (NavigationService != null)
            NavigationService.Navigate(new SagaSyncSettingsPage());
    }

    private void BtnValidateSagaConn_Click(object sender, RoutedEventArgs e)
    {
        var ip = TxtSagaServerIp.Text.Trim();
        var root = TxtSagaServerDbPath.Text.Trim();
        if (ip.Length == 0 || root.Length == 0)
        {
            MessageBox.Show(
                "Completați IP server și folderul rădăcină SAGA (CONFIG.FDB).",
                "Validează conexiune",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
            return;
        }

        var port = SagaConnectionDefaults.FirebirdServerPort;
        int.TryParse(TxtSagaServerPort.Text.Trim(), out port);
        if (port <= 0)
            port = SagaConnectionDefaults.FirebirdServerPort;

        var configDb = root.TrimEnd('\\', '/');
        if (!configDb.EndsWith(".fdb", StringComparison.OrdinalIgnoreCase))
            configDb = Path.Combine(configDb, "CONFIG.FDB");

        try
        {
            var test = _sagaWorker.Test(configDb, root, SagaConnectionMode.Server, ip, port);
            if (!test.Success)
            {
                MessageBox.Show(
                    "Conexiune eșuată.\n" + (test.Error ?? ""),
                    "Validează conexiune",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            MessageBox.Show(
                "Conexiune reușită la CONFIG.FDB pe server.\nFirebird: " + (test.EngineVersion ?? "N/A"),
                "Validează conexiune",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Conexiune eșuată.\n" + ex.Message,
                "Validează conexiune",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }
    }

    private void BtnSagaCsScan_Click(object sender, RoutedEventArgs e)
    {
        var ip = TxtSagaServerIp.Text.Trim();
        var root = TxtSagaServerDbPath.Text.Trim();
        if (string.IsNullOrWhiteSpace(ip) || string.IsNullOrWhiteSpace(root))
        {
            MessageBox.Show("Completați IP și folderul rădăcină SAGA.", "SAGA Client–Server", MessageBoxButton.OK,
                MessageBoxImage.Information);
            return;
        }

        var port = SagaConnectionDefaults.FirebirdServerPort;
        int.TryParse(TxtSagaServerPort.Text.Trim(), out port);
        if (port <= 0)
            port = SagaConnectionDefaults.FirebirdServerPort;

        var result = _sagaWorker.ScanServer(ip, port, root);
        if (!result.Success)
        {
            MessageBox.Show(result.Error ?? "Scan eșuat.", "SAGA Client–Server", MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return;
        }

        _sagaCsCompanies = result.Companies;
        LvSagaCsCompanies.ItemsSource = null;
        LvSagaCsCompanies.ItemsSource = _sagaCsCompanies;
        TxtSagaCsStatus.Text = $"{_sagaCsCompanies.Count} firmă(e). Selectează una și „Salvează setări SAGA rețea”.";
        if (_sagaCsCompanies.Count > 0)
            LvSagaCsCompanies.SelectedIndex = 0;
    }

    private void LvSagaCsCompanies_OnSelectionChanged(object sender, SelectionChangedEventArgs e) =>
        _sagaCsSelected = LvSagaCsCompanies.SelectedItem as SagaCompany;

    private void BtnSagaCsTest_Click(object sender, RoutedEventArgs e)
    {
        if (_sagaCsSelected == null)
        {
            MessageBox.Show("Selectează o firmă din listă.", "SAGA Client–Server", MessageBoxButton.OK,
                MessageBoxImage.Information);
            return;
        }

        var ip = TxtSagaServerIp.Text.Trim();
        var root = TxtSagaServerDbPath.Text.Trim();
        var port = SagaConnectionDefaults.FirebirdServerPort;
        int.TryParse(TxtSagaServerPort.Text.Trim(), out port);
        if (port <= 0)
            port = SagaConnectionDefaults.FirebirdServerPort;

        var test = _sagaWorker.Test(_sagaCsSelected.DatabasePath, root, SagaConnectionMode.Server, ip, port);
        if (!test.Success)
        {
            MessageBox.Show(test.Error ?? "Eșuat", "Test conexiune", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        MessageBox.Show(
            "Conexiune reușită.\nEngine: " + (test.EngineVersion ?? "N/A"),
            "Test conexiune",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }

    private void BtnSagaCsSave_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchemaForce(conn);
            SaveSagaClientServerNetworkSettings(conn);
            MessageBox.Show(
                "Setările SAGA (mod rețea) au fost salvate în SMARTPUB.FDB.",
                "SAGA Client–Server",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Salvare eșuată.\n" + ex.Message, "SAGA Client–Server", MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private void SaveSagaClientServerNetworkSettings(FbConnection conn)
    {
        var ip = TxtSagaServerIp.Text.Trim();
        var root = TxtSagaServerDbPath.Text.Trim();
        var port = SagaConnectionDefaults.FirebirdServerPort;
        int.TryParse(TxtSagaServerPort.Text.Trim(), out port);
        if (port <= 0)
            port = SagaConnectionDefaults.FirebirdServerPort;

        var existing = _sagaRepo.LoadData(conn);
        var data = new SagaSyncSettingsData
        {
            ConnectionMode = SagaConnectionMode.Server,
            SagaRootPath = existing.SagaRootPath ?? "",
            ServerHost = ip,
            ServerPort = port,
            ServerSagaRoot = root,
            FbClientPath = SagaConnectionDefaults.TryGetPreferredTcpFbClientPath() ?? existing.FbClientPath,
            Company = _sagaCsSelected ?? existing.Company
        };
        _sagaRepo.Save(conn, data);
    }

    private ProgramSettingsRow ReadUiIntoRow()
    {
        var logoutSec = -1;
        if (ChkAutoLogout.IsChecked == true)
        {
            if (!int.TryParse(TxtAutoLogoutSec.Text.Trim(), out logoutSec))
                logoutSec = 30;
            if (logoutSec >= 0 && logoutSec < 30)
                logoutSec = 30;
        }

        static string? PickPrinter(ComboBox c) =>
            c.SelectedItem is string s && !string.IsNullOrWhiteSpace(s) ? s.Trim() : null;

        return new ProgramSettingsRow
        {
            SagaConnMode = GetSelectedSagaMode(),
            SagaServerIp = TxtSagaServerIp.Text.Trim(),
            SagaServerDbFolder = TxtSagaServerDbPath.Text.Trim(),
            PrinterFirmOrder = PickPrinter(CmbPrinterFirm) ?? "",
            PrinterBill = PickPrinter(CmbPrinterBill) ?? "",
            PrinterInvoice = PickPrinter(CmbPrinterInvoice) ?? "",
            PrinterBar = PickPrinter(CmbPrinterBar) ?? "",
            PrinterKitchen = PickPrinter(CmbPrinterKitchen) ?? "",
            SingleInstance = ChkSingleInstance.IsChecked == true,
            StartFullscreen = ChkStartFullscreen.IsChecked == true,
            CheckUpdatesOnStart = ChkCheckUpdates.IsChecked == true,
            AutoSyncNomenclature = ChkAutoSyncNom.IsChecked == true,
            AutoLogoutSec = logoutSec,
            HotelMode = ChkHotelMode.IsChecked == true
        };
    }

    private ProgramSaleSettingsRow ReadSaleFromUi()
    {
        var plafon = 0m;
        var t = SaleTxtPlafon.Text.Trim().Replace(',', '.');
        if (decimal.TryParse(t, NumberStyles.Any, CultureInfo.InvariantCulture, out var p))
            plafon = p;

        return new ProgramSaleSettingsRow
        {
            ArticoleUltimaGestiune = SaleChkUltimaGestiune.IsChecked == true,
            VindeLaSelectare = SaleChkVindeImediat.IsChecked == true,
            CumuleazaLaVanzare = SaleChkCumulVanzare.IsChecked == true,
            CumuleazaPeNota = SaleChkCumulNota.IsChecked == true,
            CumuleazaPeBonFiscal = SaleChkCumulBon.IsChecked == true,
            AfiseazaStocNegativ = SaleChkStocNegAfis.IsChecked == true,
            PermiteVanzareStocNegativ = SaleChkStocNegVanzare.IsChecked == true,
            IncasareFaraComandaFerma = SaleChkIncasareFaraCf.IsChecked == true,
            AfiseazaButonComandaFerma = SaleChkAfisBtnCf.IsChecked == true,
            TiparireAutoComandaFermaLaValidare = SaleChkTipAutoCf.IsChecked == true,
            IesireAutoDupaValidare = SaleChkIesireDupaVal.IsChecked == true,
            InchideBonAutoDupaVanzare = SaleChkInchideBonAuto.IsChecked == true,
            TiparireAutoNotaFaraPreview = SaleChkTipAutoNota.IsChecked == true,
            TiparireAutoBonLaIncasare = SaleChkTipAutoBonInc.IsChecked == true,
            IesireAutoDupaTiparireBonFiscal = SaleChkIesireDupaTipBon.IsChecked == true,
            AfiseazaGestiuneModButoane = SaleChkGestButoane.IsChecked == true,
            AfiseazaPretModButoane = SaleChkPretButoane.IsChecked == true,
            SuneteMonitorComenzi = SaleChkSunetMonitor.IsChecked == true,
            GestiuneImplicitaLaGrupa = SaleChkGestImplicitGrup.IsChecked == true,
            IncasareRapida = SaleChkIncasareRapida.IsChecked == true,
            TastaturaVirtuala = SaleChkTastaturaVirt.IsChecked == true,
            ModVizualizareArticole = SaleRbVizLista.IsChecked == true ? "List" : "Buttons",
            ModSortareArticole = SaleRbSortAlfa.IsChecked == true ? "Alphabetical" : "SalesOrder",
            TiparireComandaFerma = SaleRbPrintImprimanta.IsChecked == true ? "Printer" : "Gestiune",
            PlafonVanzare = plafon
        };
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var row = ReadUiIntoRow();
            var sale = ReadSaleFromUi();
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchemaForce(conn);
            _repo.Save(conn, row);
            _saleRepo.Save(conn, sale);
            _extRepo.SaveDisplay(conn, ReadDisplayFromUi());
            _extRepo.SaveTransfer(conn, ReadTransferFromUi());
            _extRepo.SaveFiscal(conn, ReadFiscalFromUi());
            _extRepo.SaveNetwork(conn, ReadNetworkFromUi());

            if (string.Equals(row.SagaConnMode, "ClientServer", StringComparison.OrdinalIgnoreCase))
                SaveSagaClientServerNetworkSettings(conn);
            else
            {
                var saga = _sagaRepo.LoadData(conn);
                if (saga.ConnectionMode == SagaConnectionMode.Server)
                {
                    saga.ConnectionMode = SagaConnectionMode.Embedded;
                    _sagaRepo.Save(conn, saga);
                }
            }

            MessageBox.Show(
                "Setările au fost salvate.",
                "Configurare program",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Salvare eșuată.\n" + ex.Message,
                "Configurare program",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private async void BtnCancel_Click(object sender, RoutedEventArgs e) =>
        await Task.Run(LoadFromDbCore).ConfigureAwait(true);

    private void ApplyDisplayToUi(ProgramDisplayConfig c)
    {
        DispTxtGrupHeight.Text = c.GrupPanelHeight.ToString(CultureInfo.InvariantCulture);
        DispTxtArtHeight.Text = c.ArticolPanelHeight.ToString(CultureInfo.InvariantCulture);
    }

    private ProgramDisplayConfig ReadDisplayFromUi()
    {
        var g = ParseInt(DispTxtGrupHeight.Text, 120);
        var a = ParseInt(DispTxtArtHeight.Text, 80);
        return new ProgramDisplayConfig { GrupPanelHeight = g, ArticolPanelHeight = a };
    }

    private void DispBtnResetGrup_Click(object sender, RoutedEventArgs e) =>
        DispTxtGrupHeight.Text = "120";

    private void DispBtnResetArt_Click(object sender, RoutedEventArgs e) =>
        DispTxtArtHeight.Text = "80";

    private void ApplyTransferToUi(ProgramTransferDocConfig c)
    {
        TransTxtImplicitClient.Text = ClientDisplay(c.ImplicitClient);
        TransTxtDefaultGestCode.Text = c.DefaultGestiuneCode;
        TransTxtDefaultGestName.Text = c.DefaultGestiuneName;
        TransTxtContDiscount.Text = c.ContDiscount;
        TransTxtContProtocol.Text = c.ContProtocol;
        TransTxtContBacsis.Text = c.ContBacsis;
        TransTxtSerieFact.Text = c.SerieFacturi;
        TransTxtSerieBon.Text = c.SerieBonuri;
        TransChkAutoTransfer.IsChecked = c.AutoTransferAfterPayment;
        TransChkIncModPeFactura.IsChecked = c.IncludeModIncasarePeFactura;
        TransTxtTextSupl.Text = c.TextSuplimentarFactura;
        TransChkCazNoptii.IsChecked = c.CazareIncludeNoptii;
        TransChkCazPerioada.IsChecked = c.CazareIncludePerioada;
        TransChkCazCamera.IsChecked = c.CazareIncludeCamera;

        void SetRow(string key, ComboBox cli, ComboBox cont)
        {
            var m = c.ModMap.FirstOrDefault(x =>
                string.Equals(x.MethodKey, key, StringComparison.OrdinalIgnoreCase));
            cli.Text = ClientDisplay(m?.ClientCode ?? "");
            cont.Text = AccountDisplay(m?.ContTransfer ?? "");
        }

        SetRow("NUMERAR", TransCliNumerar, TransContNumerar);
        SetRow("CARD", TransCliCard, TransContCard);
        SetRow("BONURI", TransCliBonuri, TransContBonuri);
        SetRow("CEC", TransCliCec, TransContCec);
        SetRow("METODE_MODERNE", TransCliModerne, TransContModerne);
    }

    private ProgramTransferDocConfig ReadTransferFromUi()
    {
        var modMap = new List<TransferModMapRow>
        {
            MkTransferRow("NUMERAR", TransCliNumerar, TransContNumerar),
            MkTransferRow("CARD", TransCliCard, TransContCard),
            MkTransferRow("BONURI", TransCliBonuri, TransContBonuri),
            MkTransferRow("CEC", TransCliCec, TransContCec),
            MkTransferRow("METODE_MODERNE", TransCliModerne, TransContModerne)
        };

        return new ProgramTransferDocConfig
        {
            ImplicitClient = ExtractClientCode(TransTxtImplicitClient.Text),
            DefaultGestiuneCode = TransTxtDefaultGestCode.Text.Trim(),
            DefaultGestiuneName = TransTxtDefaultGestName.Text.Trim(),
            ContDiscount = TransTxtContDiscount.Text.Trim(),
            ContProtocol = TransTxtContProtocol.Text.Trim(),
            ContBacsis = TransTxtContBacsis.Text.Trim(),
            SerieFacturi = TransTxtSerieFact.Text.Trim(),
            SerieBonuri = TransTxtSerieBon.Text.Trim(),
            AutoTransferAfterPayment = TransChkAutoTransfer.IsChecked == true,
            IncludeModIncasarePeFactura = TransChkIncModPeFactura.IsChecked == true,
            TextSuplimentarFactura = TransTxtTextSupl.Text.Trim(),
            CazareIncludeNoptii = TransChkCazNoptii.IsChecked == true,
            CazareIncludePerioada = TransChkCazPerioada.IsChecked == true,
            CazareIncludeCamera = TransChkCazCamera.IsChecked == true,
            ModMap = modMap
        };
    }

    private static TransferModMapRow MkTransferRow(string key, ComboBox cli, ComboBox cont) =>
        new()
        {
            MethodKey = key,
            ClientCode = ExtractClientCode(cli.Text),
            ContTransfer = ExtractCode(cont.Text)
        };

    private string ClientDisplay(string? code)
    {
        var c = (code ?? "").Trim();
        if (c.Length == 0)
            return "";
        return _transferClientOptions.FirstOrDefault(x =>
            x.StartsWith(c + " - ", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(x, c, StringComparison.OrdinalIgnoreCase)) ?? c;
    }

    private static string ExtractClientCode(string? value)
        => ExtractCode(value);

    private string AccountDisplay(string? code)
    {
        var c = ExtractCode(code);
        if (c.Length == 0)
            return "";
        return _transferAccountOptions.FirstOrDefault(x =>
            x.StartsWith(c + " - ", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(x, c, StringComparison.OrdinalIgnoreCase)) ?? c;
    }

    private static string ExtractCode(string? value)
    {
        var t = (value ?? "").Trim();
        if (t.Length == 0)
            return "";
        var dash = t.IndexOf(" - ", StringComparison.Ordinal);
        return (dash > 0 ? t[..dash] : t).Trim();
    }

    private void ApplyFiscalToUi(ProgramFiscalConfig c)
    {
        FisTxtModel.Text = c.Model;
        FisTxtDriver.Text = c.Driver;
        FisTxtMonitorFolder.Text = c.MonitorFolder;
        FisChkTrimiteCardPos.IsChecked = c.TrimiteSumaCardLaPos;
        FisChkAfisOpBon.IsChecked = c.AfiseazaOperatorPeBon;
        FisChkAfisNrComBon.IsChecked = c.AfiseazaNrComandaPeBon;
        FisChkAfisDenArtBon.IsChecked = c.AfiseazaDenumireArticolPeBon;
        FisTxtPublicitar.Text = c.TextPublicitar;

        void SetIdx(string key, TextBox tb)
        {
            tb.Text = (c.PlataIndices.TryGetValue(key, out var i) ? i : 0).ToString(CultureInfo.InvariantCulture);
        }

        SetIdx("NUMERAR", FisIdxNumerar);
        SetIdx("CARD", FisIdxCard);
        SetIdx("BONURI", FisIdxBonuri);
        SetIdx("CEC", FisIdxCec);
        SetIdx("METODE_MODERNE", FisIdxModerne);

        FisTva0.Text = IdxTva(c, 0m).ToString(CultureInfo.InvariantCulture);
        FisTva11.Text = IdxTva(c, 11m).ToString(CultureInfo.InvariantCulture);
        FisTva21.Text = IdxTva(c, 21m).ToString(CultureInfo.InvariantCulture);
    }

    private static int IdxTva(ProgramFiscalConfig c, decimal pct)
    {
        foreach (var kv in c.TvaIndices)
        {
            if (Math.Abs(kv.Key - pct) < 0.01m)
                return kv.Value;
        }

        return pct switch
        {
            0m => 0,
            11m => 2,
            21m => 3,
            _ => 0
        };
    }

    private ProgramFiscalConfig ReadFiscalFromUi()
    {
        var c = new ProgramFiscalConfig
        {
            Model = FisTxtModel.Text.Trim(),
            Driver = FisTxtDriver.Text.Trim(),
            MonitorFolder = FisTxtMonitorFolder.Text.Trim(),
            TrimiteSumaCardLaPos = FisChkTrimiteCardPos.IsChecked == true,
            AfiseazaOperatorPeBon = FisChkAfisOpBon.IsChecked == true,
            AfiseazaNrComandaPeBon = FisChkAfisNrComBon.IsChecked == true,
            AfiseazaDenumireArticolPeBon = FisChkAfisDenArtBon.IsChecked == true,
            TextPublicitar = FisTxtPublicitar.Text.Trim()
        };

        void AddPlata(string k, TextBox tb)
        {
            c.PlataIndices[k] = ParseInt(tb.Text, 0);
        }

        AddPlata("NUMERAR", FisIdxNumerar);
        AddPlata("CARD", FisIdxCard);
        AddPlata("BONURI", FisIdxBonuri);
        AddPlata("CEC", FisIdxCec);
        AddPlata("METODE_MODERNE", FisIdxModerne);

        c.TvaIndices[0m] = ParseInt(FisTva0.Text, 0);
        c.TvaIndices[11m] = ParseInt(FisTva11.Text, 2);
        c.TvaIndices[21m] = ParseInt(FisTva21.Text, 3);
        return c;
    }

    private void BtnFisBrowseFolder_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFolderDialog { Title = "Folder monitorizat casă de marcat" };
        if (dlg.ShowDialog() == true)
            FisTxtMonitorFolder.Text = dlg.FolderName;
    }

    private void BtnFisResetLocal_Click(object sender, RoutedEventArgs e)
    {
        ApplyFiscalToUi(new ProgramFiscalConfig
        {
            Model = "ACTIVA (Activa, Total, Zeka, Tremol)",
            Driver = "FiscalNet",
            MonitorFolder = "",
            PlataIndices =
            {
                ["NUMERAR"] = 0,
                ["BONURI"] = 1,
                ["CARD"] = 3,
                ["CEC"] = 4,
                ["METODE_MODERNE"] = 5
            },
            TvaIndices = { [0m] = 0, [11m] = 2, [21m] = 3 }
        });
        FisChkTrimiteCardPos.IsChecked = false;
        FisChkAfisOpBon.IsChecked = false;
        FisChkAfisNrComBon.IsChecked = false;
        FisChkAfisDenArtBon.IsChecked = false;
        FisTxtPublicitar.Text = "";
    }

    private void ApplyNetworkToUi(ProgramNetworkConfig c)
    {
        _netServers.Clear();
        foreach (var s in c.Servers)
        {
            _netServers.Add(new NetworkServerRow { Name = s.Name, Ip = s.Ip });
        }

        if (_netServers.Count == 0)
            _netServers.Add(new NetworkServerRow { Name = "Network", Ip = "" });

        NetTxtRootPath.Text = c.RootPath;
        NetChkMobilePrint.IsChecked = c.MobilePrintComenziNotaBon;
    }

    private ProgramNetworkConfig ReadNetworkFromUi()
    {
        return new ProgramNetworkConfig
        {
            RootPath = NetTxtRootPath.Text.Trim(),
            MobilePrintComenziNotaBon = NetChkMobilePrint.IsChecked == true,
            Servers = _netServers.ToList()
        };
    }

    private void BtnNetAdd_Click(object sender, RoutedEventArgs e) =>
        _netServers.Add(new NetworkServerRow { Name = "Network", Ip = "" });

    private void BtnNetRemove_Click(object sender, RoutedEventArgs e)
    {
        if (GridNetServers.SelectedItem is NetworkServerRow r)
            _netServers.Remove(r);
    }

    private static int ParseInt(string? s, int fallback)
    {
        if (int.TryParse((s ?? "").Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var v))
            return v;
        if (int.TryParse((s ?? "").Trim(), out v))
            return v;
        return fallback;
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

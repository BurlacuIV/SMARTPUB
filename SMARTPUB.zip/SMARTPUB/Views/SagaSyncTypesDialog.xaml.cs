using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using SMARTPUB.Models;

namespace SMARTPUB.Views;

public partial class SagaSyncTypesDialog : Window
{
    private readonly List<SagaArticleBrief> _all;
    private readonly ObservableCollection<TypeRow> _types = new();

    /// <summary>Tipurile (DEN_TIP) selectate la confirmare. Gol = toate.</summary>
    public List<string> SelectedDenTip { get; private set; } = new();

    public SagaSyncTypesDialog(IEnumerable<SagaArticleBrief> articles)
    {
        InitializeComponent();
        _all = articles?.ToList() ?? new List<SagaArticleBrief>();

        BuildTypes();
        TypesList.ItemsSource = _types;
        TxtHeaderSub.Text =
            $"{_all.Count} articole în firmă. Bifează tipurile pe care vrei să le aduci în SMARTPUB.";

        RefreshPreview();
    }

    private void BuildTypes()
    {
        _types.Clear();
        var groups = _all
            .GroupBy(a => string.IsNullOrWhiteSpace(a.DenTip) ? "(fără tip)" : a.DenTip.Trim())
            .OrderBy(g => g.Key, System.StringComparer.OrdinalIgnoreCase);

        foreach (var g in groups)
        {
            // Materiile prime sunt debifate implicit (rămân doar ca ingrediente în rețete).
            var isRaw = g.Key.IndexOf("materii prime", System.StringComparison.OrdinalIgnoreCase) >= 0;
            _types.Add(new TypeRow
            {
                Name = g.Key,
                Count = g.Count(),
                IsChecked = !isRaw
            });
        }
    }

    private HashSet<string> CheckedTypeNames() =>
        _types.Where(t => t.IsChecked)
              .Select(t => t.Name)
              .ToHashSet(System.StringComparer.OrdinalIgnoreCase);

    private void RefreshPreview()
    {
        var allowed = CheckedTypeNames();
        var term = (TxtSearch?.Text ?? "").Trim();

        IEnumerable<SagaArticleBrief> rows = _all.Where(a =>
            allowed.Contains(string.IsNullOrWhiteSpace(a.DenTip) ? "(fără tip)" : a.DenTip.Trim()));

        if (!string.IsNullOrWhiteSpace(term))
        {
            rows = rows.Where(a =>
                a.Code.Contains(term, System.StringComparison.OrdinalIgnoreCase) ||
                a.Name.Contains(term, System.StringComparison.OrdinalIgnoreCase));
        }

        var list = rows.ToList();
        GridPreview.ItemsSource = list;

        var totalSel = _all.Count(a =>
            allowed.Contains(string.IsNullOrWhiteSpace(a.DenTip) ? "(fără tip)" : a.DenTip.Trim()));
        TxtSummary.Text = $"{totalSel} produse vor fi sincronizate ({allowed.Count} tipuri selectate)";
    }

    private void TypeCheck_Click(object sender, RoutedEventArgs e) => RefreshPreview();

    private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e) => RefreshPreview();

    private void BtnAll_Click(object sender, RoutedEventArgs e)
    {
        foreach (var t in _types) t.IsChecked = true;
        RefreshPreview();
    }

    private void BtnNone_Click(object sender, RoutedEventArgs e)
    {
        foreach (var t in _types) t.IsChecked = false;
        RefreshPreview();
    }

    private void BtnCancel_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }

    private void BtnSync_Click(object sender, RoutedEventArgs e)
    {
        var selected = CheckedTypeNames();
        if (selected.Count == 0)
        {
            MessageBox.Show(this, "Selectează cel puțin un tip de articol.", "Sincronizare SAGA",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        // „(fără tip)” => DEN_TIP gol în SAGA, deci trimitem "" în filtru. Toate bifate => gol = aducem tot.
        SelectedDenTip = _types
            .Where(t => t.IsChecked)
            .Select(t => t.Name == "(fără tip)" ? "" : t.Name)
            .ToList();

        if (_types.All(t => t.IsChecked))
            SelectedDenTip = new List<string>();

        DialogResult = true;
        Close();
    }

    private sealed class TypeRow : INotifyPropertyChanged
    {
        private bool _isChecked;
        public string Name { get; set; } = "";
        public int Count { get; set; }

        public bool IsChecked
        {
            get => _isChecked;
            set
            {
                if (_isChecked == value) return;
                _isChecked = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsChecked)));
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}

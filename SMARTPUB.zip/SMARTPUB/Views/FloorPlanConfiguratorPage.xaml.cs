using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Views;

public partial class FloorPlanConfiguratorPage : Page
{
    // ─────────────────────────── Constants ──────────────────────────────
    private const double CanvasW   = 2400;
    private const double CanvasH   = 1600;
    private const double SnapPx    = 24;
    private const double HandleSz  = 11;
    private const double MinTblPx  = 36;
    private const double MaxTblPx  = 520;
    private const double MinZonePx = 80;

    private static readonly int[] TintPalette =
    {
        unchecked((int)0x40B8D8A8),  // pistachio
        unchecked((int)0x40E0C896),  // sand
        unchecked((int)0x40A8C8E0),  // sky
        unchecked((int)0x40C8A8D8),  // mauve
        unchecked((int)0x40E0B0A0),  // coral
        unchecked((int)0x40CFD3CB)   // mist
    };

    private static readonly Brush SelGoldBrush = new SolidColorBrush(Color.FromRgb(0xD4, 0xA5, 0x4A));
    private static readonly Brush ZoneIdleBorder = new SolidColorBrush(Color.FromArgb(100, 0x27, 0x32, 0x3A));
    private static readonly Brush TableRim = new SolidColorBrush(Color.FromRgb(0x9D, 0xA8, 0x9C));

    private static string NormId(string? s) => (s ?? "").Trim();

    // ─────────────────────────── State ──────────────────────────────────
    private readonly FloorPlanRepository _repo = new();
    private readonly List<FloorLevelModel> _levels = new();
    private readonly List<FloorSpaceModel> _spaces = new();
    private readonly List<FloorTableModel> _tables = new();

    private string _currentLevelId = "";
    private bool _suspendLevelTab;
    private bool _suspendLevelName;
    private bool _suspendProps;
    private bool _suspendShapeToggle;
    private bool _dirty;

    private FrameworkElement? _dragEl;
    private Point _dragOffset;
    private bool _dragging;

    private bool _resizing;
    private ResizeCorner _resizeCorner;
    private Point _resizeStartMouse;
    private double _resizeSx, _resizeSy, _resizeSw, _resizeSh;
    private double _resizeCx, _resizeCy;
    private bool _resizeIsRound;
    private object? _resizeModel;

    private object? _selectedModel;
    private FrameworkElement? _selectedEl;

    // ─────────────────────────── Ctor ───────────────────────────────────
    public FloorPlanConfiguratorPage()
    {
        InitializeComponent();

        ZoomSlider.ValueChanged += (_, _) => TxtZoomPct.Text = $"{ZoomSlider.Value * 100:0}%";

        Loaded += (_, _) =>
        {
            InitFloorDecor();
            LoadFromDb();
            RefreshLevelMeta();
            SyncLevelUi();
            RebuildCanvas();
            RefreshStatusCounts();
            BuildColorPalette();
            TxtZoomPct.Text = $"{ZoomSlider.Value * 100:0}%";
            UpdateInspectorHeader();
            Focus();
        };
    }

    // ───────────────────── Canvas decoration ────────────────────────────
    private void InitFloorDecor()
    {
        const double tile = 20;
        var carpetTile = new DrawingGroup();
        carpetTile.Children.Add(new GeometryDrawing(
            new SolidColorBrush(Color.FromRgb(0xF1, 0xEF, 0xE8)), null,
            new RectangleGeometry(new Rect(0, 0, tile, tile))));
        var dotBrush = new SolidColorBrush(Color.FromArgb(20, 0x27, 0x32, 0x3A));
        carpetTile.Children.Add(new GeometryDrawing(dotBrush, null, new EllipseGeometry(new Point(5, 5), 1.1, 1.1)));
        carpetTile.Children.Add(new GeometryDrawing(dotBrush, null, new EllipseGeometry(new Point(15, 15), 1.1, 1.1)));

        var floor = new Rectangle
        {
            Width = CanvasW, Height = CanvasH,
            IsHitTestVisible = false,
            Fill = new DrawingBrush(carpetTile)
            {
                TileMode = TileMode.Tile,
                Viewport = new Rect(0, 0, tile, tile),
                ViewportUnits = BrushMappingMode.Absolute,
                Stretch = Stretch.Fill
            }
        };
        Canvas.SetLeft(floor, 0); Canvas.SetTop(floor, 0);
        PlanCanvas.Children.Add(floor);

        var ambient = new Rectangle
        {
            Width = CanvasW, Height = CanvasH,
            IsHitTestVisible = false,
            Opacity = 0.55,
            Fill = new LinearGradientBrush
            {
                StartPoint = new Point(0, 0), EndPoint = new Point(1, 1),
                GradientStops =
                {
                    new GradientStop(Color.FromArgb(55, 0xB8, 0xD8, 0xA8), 0),
                    new GradientStop(Color.FromArgb(0,  0x27, 0x32, 0x3A), 0.5),
                    new GradientStop(Color.FromArgb(26, 0x27, 0x32, 0x3A), 1)
                }
            }
        };
        Canvas.SetLeft(ambient, 0); Canvas.SetTop(ambient, 0);
        PlanCanvas.Children.Add(ambient);

        var pen = new Pen(new SolidColorBrush(Color.FromArgb(26, 0x27, 0x32, 0x3A)), 0.5);
        var gridBrush = new DrawingBrush
        {
            TileMode = TileMode.Tile,
            Viewport = new Rect(0, 0, SnapPx, SnapPx),
            ViewportUnits = BrushMappingMode.Absolute,
            Drawing = new GeometryDrawing(null, pen, new RectangleGeometry(new Rect(0, 0, SnapPx, SnapPx)))
        };
        var gridLayer = new Rectangle
        {
            Width = CanvasW, Height = CanvasH,
            Fill = gridBrush, Opacity = 0.30,
            IsHitTestVisible = false
        };
        Canvas.SetLeft(gridLayer, 0); Canvas.SetTop(gridLayer, 0);
        PlanCanvas.Children.Add(gridLayer);
    }

    // ─────────────────────── DB Load / Save ─────────────────────────────
    private void LoadFromDb()
    {
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            FloorPlanSchema.EnsureSchema(conn);
            var (lv, sp, tb) = _repo.Load(conn);
            _levels.Clear(); _levels.AddRange(lv);
            _spaces.Clear(); _spaces.AddRange(sp);
            _tables.Clear(); _tables.AddRange(tb);

            if (_levels.Count == 0)
                _levels.Add(new FloorLevelModel { Name = "Sală", SortOrder = 0 });

            _currentLevelId = _levels[0].Id;
            foreach (var s in _spaces.Where(z => string.IsNullOrWhiteSpace(z.LevelId))) s.LevelId = _currentLevelId;
            foreach (var t in _tables.Where(z => string.IsNullOrWhiteSpace(z.LevelId))) t.LevelId = _currentLevelId;
        }
        catch (Exception ex)
        {
            MessageBox.Show("Nu am putut incarca harta din baza de date.\n" + ex.Message,
                "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Warning);
            if (_levels.Count == 0)
            {
                var n = new FloorLevelModel { Name = "Sala", SortOrder = 0 };
                _levels.Add(n); _currentLevelId = n.Id;
            }
        }
        SetDirty(false);
    }

    private void SaveToDb()
    {
        using var conn = SmartPubDb.OpenEmbedded();
        FloorPlanSchema.EnsureSchema(conn);
        _repo.SaveAll(conn, _levels, _spaces, _tables);
        SetDirty(false);
    }

    private void SetDirty(bool dirty)
    {
        _dirty = dirty;
        DirtyDot.Visibility = dirty ? Visibility.Visible : Visibility.Collapsed;
    }

    private void BtnReload_Click(object sender, RoutedEventArgs e)
    {
        if (_dirty)
        {
            var r = MessageBox.Show("Ai modificari nesalvate. Reincarci, pierzand modificarile?",
                "Reincarcare", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (r != MessageBoxResult.Yes) return;
        }
        ClearSelection();
        LoadFromDb();
        RefreshLevelMeta();
        SyncLevelUi();
        RebuildCanvas();
        RefreshStatusCounts();
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            SaveToDb();
            MessageBox.Show("Harta a fost salvata in SMARTPUB.FDB.", "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Salvare esuata:\n" + ex.Message, "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    // ─────────────────────── Levels list ────────────────────────────────
    private void RefreshLevelMeta()
    {
        foreach (var lv in _levels)
        {
            var tables = _tables.Count(t => NormId(t.LevelId).Equals(NormId(lv.Id), StringComparison.OrdinalIgnoreCase));
            var zones  = _spaces.Count(s => NormId(s.LevelId).Equals(NormId(lv.Id), StringComparison.OrdinalIgnoreCase));
            lv.TableCount = tables;
            lv.LevelMetaText = $"{tables} mese · {zones} zone";
        }
        TxtLevelsHint.Text = _levels.Count == 1 ? "1 sala configurata" : $"{_levels.Count} sali configurate";
    }

    private void SyncLevelUi()
    {
        _suspendLevelTab = true;
        LevelTabs.ItemsSource = null;
        LevelTabs.ItemsSource = _levels.OrderBy(l => l.SortOrder).ToList();
        var sel = _levels.FirstOrDefault(l => l.Id == _currentLevelId) ?? _levels.FirstOrDefault();
        if (sel != null)
        {
            _currentLevelId = sel.Id;
            LevelTabs.SelectedItem = sel;
        }
        _suspendLevelTab = false;

        _suspendLevelName = true;
        TxtLevelName.Text = sel?.Name ?? "";
        _suspendLevelName = false;
    }

    private void LevelTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suspendLevelTab) return;
        if (LevelTabs.SelectedItem is not FloorLevelModel lv) return;
        if (_currentLevelId == lv.Id) return;
        _currentLevelId = lv.Id;
        _suspendLevelName = true;
        TxtLevelName.Text = lv.Name;
        _suspendLevelName = false;
        ClearSelection();
        RebuildCanvas();
        RefreshStatusCounts();
        FlashPlan();
    }

    private void FlashPlan()
    {
        ZoomHost.Opacity = 0.82;
        var anim = new DoubleAnimation(1, TimeSpan.FromMilliseconds(220))
        {
            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
        };
        anim.Completed += (_, _) => ZoomHost.Opacity = 1;
        ZoomHost.BeginAnimation(UIElement.OpacityProperty, anim);
    }

    private void TxtLevelName_LostFocus(object sender, RoutedEventArgs e) => ApplyLevelNameFromTextBox();
    private void TxtLevelName_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) ApplyLevelNameFromTextBox(); }

    private void ApplyLevelNameFromTextBox()
    {
        if (_suspendLevelName) return;
        var lv = CurrentLevel(); if (lv == null) return;
        var n = TxtLevelName.Text.Trim();
        if (string.IsNullOrEmpty(n)) n = "Sala";
        if (lv.Name == n) return;
        lv.Name = n;
        SetDirty(true);
        SyncLevelUi();
    }

    private FloorLevelModel? CurrentLevel() => _levels.FirstOrDefault(l => l.Id == _currentLevelId);

    private void BtnAddLevel_Click(object sender, RoutedEventArgs e)
    {
        var next = _levels.Count == 0 ? 0 : _levels.Max(l => l.SortOrder) + 1;
        var nl = new FloorLevelModel { Name = "Sala " + (_levels.Count + 1), SortOrder = next };
        _levels.Add(nl);
        _currentLevelId = nl.Id;
        SetDirty(true);
        RefreshLevelMeta();
        SyncLevelUi();
        ClearSelection();
        RebuildCanvas();
        RefreshStatusCounts();
        FlashPlan();
    }

    private void BtnDeleteLevel_Click(object sender, RoutedEventArgs e)
    {
        var lv = CurrentLevel();
        if (lv == null || _levels.Count <= 1)
        {
            MessageBox.Show("Trebuie sa ramana cel putin un nivel (sala).", "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var n = _spaces.Count(s => s.LevelId == lv.Id) + _tables.Count(t => t.LevelId == lv.Id);
        var msg = n > 0
            ? $"Stergi nivelul '{lv.Name}' si cele {n} elemente de pe plan?"
            : $"Stergi nivelul '{lv.Name}'?";
        if (MessageBox.Show(msg, "Confirmare", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;

        _spaces.RemoveAll(s => s.LevelId == lv.Id);
        _tables.RemoveAll(t => t.LevelId == lv.Id);
        _levels.RemoveAll(l => l.Id == lv.Id);
        _currentLevelId = _levels[0].Id;
        SetDirty(true);
        RefreshLevelMeta();
        SyncLevelUi();
        ClearSelection();
        RebuildCanvas();
        RefreshStatusCounts();
    }

    private void BtnLevelUp_Click(object sender, RoutedEventArgs e) => ReorderLevel(-1);
    private void BtnLevelDown_Click(object sender, RoutedEventArgs e) => ReorderLevel(+1);

    private void ReorderLevel(int delta)
    {
        var lv = CurrentLevel(); if (lv == null) return;
        var ordered = _levels.OrderBy(l => l.SortOrder).ToList();
        var idx = ordered.IndexOf(lv);
        var target = idx + delta;
        if (target < 0 || target >= ordered.Count) return;
        ordered.RemoveAt(idx);
        ordered.Insert(target, lv);
        for (var i = 0; i < ordered.Count; i++) ordered[i].SortOrder = i;
        SetDirty(true);
        SyncLevelUi();
    }

    // ───────────────────── Canvas rebuild ──────────────────────────────
    private IEnumerable<FloorSpaceModel> SpacesOnCanvas =>
        _spaces.Where(s => NormId(s.LevelId).Equals(NormId(_currentLevelId), StringComparison.OrdinalIgnoreCase))
               .OrderBy(z => z.ZOrder);

    private IEnumerable<FloorTableModel> TablesOnCanvas =>
        _tables.Where(t => NormId(t.LevelId).Equals(NormId(_currentLevelId), StringComparison.OrdinalIgnoreCase));

    private void SyncCurrentLevelFromTabs()
    {
        if (LevelTabs.SelectedItem is FloorLevelModel lv) { _currentLevelId = lv.Id.Trim(); return; }
        if (_levels.Count == 0) return;
        var sel = _levels.FirstOrDefault(l => NormId(l.Id).Equals(NormId(_currentLevelId), StringComparison.OrdinalIgnoreCase))
                  ?? _levels[0];
        _currentLevelId = sel.Id.Trim();
        _suspendLevelTab = true; LevelTabs.SelectedItem = sel; _suspendLevelTab = false;
    }

    private void RebuildCanvas()
    {
        SyncCurrentLevelFromTabs();
        // Decor layers are first 3 children (floor, ambient, grid). Remove everything else.
        while (PlanCanvas.Children.Count > 3) PlanCanvas.Children.RemoveAt(PlanCanvas.Children.Count - 1);

        foreach (var s in SpacesOnCanvas) PlanCanvas.Children.Add(CreateSpaceVisual(s));
        foreach (var t in TablesOnCanvas) PlanCanvas.Children.Add(CreateTableVisual(t));

        ApplySelectionHighlight();
        ApplyResizeHandles();
    }

    private Border CreateSpaceVisual(FloorSpaceModel s)
    {
        var b = new Border
        {
            Width = s.Width, Height = s.Height,
            CornerRadius = new CornerRadius(16),
            BorderThickness = new Thickness(2),
            BorderBrush = ZoneIdleBorder,
            Background = new SolidColorBrush(ToColor(s.TintArgb)),
            Cursor = Cursors.Hand,
            Tag = s,
            SnapsToDevicePixels = true,
            Effect = new DropShadowEffect
            {
                BlurRadius = 12, ShadowDepth = 2, Opacity = 0.18,
                Color = Color.FromRgb(0x27, 0x32, 0x3A)
            }
        };
        b.Child = new TextBlock
        {
            Text = s.Name,
            FontSize = 14, FontWeight = FontWeights.SemiBold,
            Foreground = new SolidColorBrush(Color.FromRgb(0x27, 0x32, 0x3A)),
            Margin = new Thickness(12, 10, 12, 0),
            Effect = new DropShadowEffect { BlurRadius = 3, ShadowDepth = 0, Opacity = 0.3, Color = Colors.White }
        };
        Canvas.SetLeft(b, s.X); Canvas.SetTop(b, s.Y);
        b.MouseLeftButtonDown += Element_MouseLeftButtonDown;
        return b;
    }

    private static Color ToColor(int argb)
    {
        unchecked
        {
            var u = (uint)argb;
            return Color.FromArgb((byte)((u >> 24) & 0xFF), (byte)((u >> 16) & 0xFF),
                (byte)((u >> 8) & 0xFF), (byte)(u & 0xFF));
        }
    }

    private UIElement CreateTableVisual(FloorTableModel t)
    {
        var shadow = new DropShadowEffect
        {
            BlurRadius = 22, ShadowDepth = 8, Opacity = 0.28,
            Color = Color.FromRgb(0x27, 0x32, 0x3A)
        };
        var woodRect = new LinearGradientBrush
        {
            StartPoint = new Point(0, 0), EndPoint = new Point(1, 1),
            GradientStops =
            {
                new GradientStop(Color.FromRgb(0xFF,0xFF,0xFF), 0),
                new GradientStop(Color.FromRgb(0xF4,0xF7,0xF1), 0.5),
                new GradientStop(Color.FromRgb(0xE2,0xE8,0xDE), 1)
            }
        };
        var roundFill = new RadialGradientBrush
        {
            GradientOrigin = new Point(0.38, 0.32), Center = new Point(0.5, 0.36),
            RadiusX = 0.62, RadiusY = 0.62,
            GradientStops =
            {
                new GradientStop(Color.FromRgb(0xFF,0xFF,0xFF), 0),
                new GradientStop(Color.FromRgb(0xF1,0xF5,0xEE), 0.55),
                new GradientStop(Color.FromRgb(0xD5,0xDD,0xD2), 1)
            }
        };

        if (t.IsRound)
        {
            var d = Math.Max(t.Width, t.Height);
            var grid = new Grid { Width = d, Height = d, Tag = t };

            grid.Children.Add(new Ellipse { Width = d, Height = d, Fill = roundFill, Stroke = TableRim, StrokeThickness = 2.5, Effect = shadow });
            AddChairHints(grid, t, d, d, true);

            grid.Children.Add(new TextBlock
            {
                Text = t.Name,
                TextAlignment = TextAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                FontSize = 12.5, FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(0x27, 0x32, 0x3A)),
                Margin = new Thickness(4, 0, 4, 18)
            });
            grid.Children.Add(new TextBlock
            {
                Text = $"{t.Seats} locuri",
                FontSize = 10,
                Foreground = new SolidColorBrush(Color.FromArgb(220, 0x27, 0x32, 0x3A)),
                TextAlignment = TextAlignment.Center,
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(4, 0, 4, 10)
            });
            grid.Cursor = Cursors.Hand;
            Canvas.SetLeft(grid, t.X); Canvas.SetTop(grid, t.Y);
            grid.MouseLeftButtonDown += Element_MouseLeftButtonDown;
            return grid;
        }

        var bd = new Border
        {
            Width = t.Width, Height = t.Height,
            CornerRadius = new CornerRadius(10),
            Background = woodRect,
            BorderBrush = TableRim,
            BorderThickness = new Thickness(2.5),
            Effect = shadow,
            Cursor = Cursors.Hand,
            Tag = t
        };
        var inner = new Grid { Tag = t };
        AddChairHints(inner, t, t.Width, t.Height, false);

        var stack = new StackPanel
        {
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(6)
        };
        stack.Children.Add(new TextBlock
        {
            Text = t.Name, TextAlignment = TextAlignment.Center,
            FontSize = 12.5, FontWeight = FontWeights.SemiBold,
            Foreground = new SolidColorBrush(Color.FromRgb(0x27, 0x32, 0x3A))
        });
        stack.Children.Add(new TextBlock
        {
            Text = $"{t.Seats} locuri",
            FontSize = 10, TextAlignment = TextAlignment.Center,
            Foreground = new SolidColorBrush(Color.FromArgb(220, 0x27, 0x32, 0x3A)),
            Margin = new Thickness(0, 2, 0, 0)
        });
        inner.Children.Add(stack);
        bd.Child = inner;
        Canvas.SetLeft(bd, t.X); Canvas.SetTop(bd, t.Y);
        bd.MouseLeftButtonDown += Element_MouseLeftButtonDown;
        return bd;
    }

    private static void AddChairHints(Panel host, FloorTableModel t, double w, double h, bool round)
    {
        var n = Math.Clamp(t.Seats, 1, 24);
        var fill = new SolidColorBrush(Color.FromArgb(200, 0x4A, 0x55, 0x62));
        const double chairR = 5.5;

        if (round)
        {
            var cx = w / 2; var cy = h / 2;
            var rad = Math.Min(w, h) / 2 + 10;
            var cvs = new Canvas { Width = w, Height = h, IsHitTestVisible = false };
            for (var i = 0; i < n; i++)
            {
                var ang = -Math.PI / 2 + i * 2 * Math.PI / n;
                var ell = new Ellipse { Width = chairR * 2, Height = chairR * 2, Fill = fill, Opacity = 0.85 };
                Canvas.SetLeft(ell, cx + rad * Math.Cos(ang) - chairR);
                Canvas.SetTop(ell, cy + rad * Math.Sin(ang) - chairR);
                cvs.Children.Add(ell);
            }
            host.Children.Insert(0, cvs);
        }
        else
        {
            var pad = 8.0;
            var per = new List<Point>();
            var top = (int)Math.Ceiling(n / 2.0);
            var bottom = n - top;
            for (var i = 0; i < top; i++)
                per.Add(new Point(pad + (w - 2 * pad) * (top == 1 ? 0.5 : i / (double)(top - 1)), -chairR - 2));
            for (var i = 0; i < bottom; i++)
                per.Add(new Point(pad + (w - 2 * pad) * (bottom <= 1 ? 0.5 : i / (double)(bottom - 1)), h + chairR + 2));

            var cvs = new Canvas { Width = w, Height = h, IsHitTestVisible = false };
            foreach (var p in per.Take(n))
            {
                var ell = new Ellipse { Width = chairR * 2, Height = chairR * 2, Fill = fill, Opacity = 0.85 };
                Canvas.SetLeft(ell, p.X - chairR);
                Canvas.SetTop(ell, p.Y - chairR);
                cvs.Children.Add(ell);
            }
            host.Children.Insert(0, cvs);
        }
    }

    // ─────────────────── Drag/Resize/Selection ─────────────────────────
    private void Element_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is not FrameworkElement fe) return;
        object? model = fe.Tag is FloorSpaceModel sp ? sp : fe.Tag as FloorTableModel;
        if (model == null && fe is Grid g && g.Tag is FloorTableModel tm) model = tm;
        if (model == null) return;

        Select(model, fe);
        _dragEl = fe;
        _dragOffset = e.GetPosition(_dragEl);
        _dragging = true;
        _dragEl.CaptureMouse();
        e.Handled = true;
    }

    private void PlanCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.OriginalSource is FrameworkElement fe && fe.Tag is ResizeHandleTag) return;
        if (e.OriginalSource is not FrameworkElement src || src.Tag == null) ClearSelection();
    }

    private void Page_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (_resizing)
        {
            var pos = e.GetPosition(PlanCanvas);
            if (ChkSnapGrid.IsChecked == true) pos = new Point(Snap(pos.X), Snap(pos.Y));

            if (_resizeModel is FloorSpaceModel fs)
            {
                ApplyRectResize(_resizeCorner, pos, _resizeSx, _resizeSy, _resizeSw, _resizeSh,
                    out var nx, out var ny, out var nw, out var nh);
                fs.X = nx; fs.Y = ny; fs.Width = nw; fs.Height = nh;
            }
            else if (_resizeModel is FloorTableModel ft)
            {
                if (_resizeIsRound)
                {
                    var half = Math.Max(Math.Abs(pos.X - _resizeCx), Math.Abs(pos.Y - _resizeCy));
                    var dNew = Math.Clamp(2 * half, MinTblPx, Math.Min(CanvasW, CanvasH));
                    ft.Width = dNew; ft.Height = dNew;
                    ft.X = Math.Clamp(_resizeCx - dNew / 2, 0, CanvasW - dNew);
                    ft.Y = Math.Clamp(_resizeCy - dNew / 2, 0, CanvasH - dNew);
                }
                else
                {
                    ApplyRectResize(_resizeCorner, pos, _resizeSx, _resizeSy, _resizeSw, _resizeSh,
                        out var nx, out var ny, out var nw, out var nh);
                    ft.X = nx; ft.Y = ny;
                    ft.Width = Math.Clamp(nw, MinTblPx, MaxTblPx);
                    ft.Height = Math.Clamp(nh, MinTblPx, MaxTblPx);
                }
            }
            SetDirty(true);
            RebuildCanvas();
            RestoreSelectionAfterRebuild();
            SyncInspectorFromSelection();
            return;
        }

        if (!_dragging || _dragEl == null) return;

        GetDragElementSize(_dragEl, out var ew, out var eh);
        var pos2 = e.GetPosition(PlanCanvas);
        var nx2 = pos2.X - _dragOffset.X;
        var ny2 = pos2.Y - _dragOffset.Y;
        if (ChkSnapGrid.IsChecked == true) { nx2 = Snap(nx2); ny2 = Snap(ny2); }
        nx2 = Math.Clamp(nx2, 0, CanvasW - ew);
        ny2 = Math.Clamp(ny2, 0, CanvasH - eh);
        Canvas.SetLeft(_dragEl, nx2);
        Canvas.SetTop(_dragEl, ny2);

        UpdateStatusBar(nx2, ny2, ew, eh);
    }

    private static double Snap(double v) => Math.Round(v / SnapPx) * SnapPx;

    private void ApplyRectResize(ResizeCorner corner, Point mouse,
        double sx, double sy, double sw, double sh,
        out double x, out double y, out double w, out double h)
    {
        const double minW = 64; const double minH = 64;
        var dx = mouse.X - _resizeStartMouse.X;
        var dy = mouse.Y - _resizeStartMouse.Y;
        x = sx; y = sy; w = sw; h = sh;
        switch (corner)
        {
            case ResizeCorner.SE: w = sw + dx; h = sh + dy; break;
            case ResizeCorner.S:  h = sh + dy; break;
            case ResizeCorner.E:  w = sw + dx; break;
            case ResizeCorner.NE: w = sw + dx; h = sh - dy; y = sy + dy; break;
            case ResizeCorner.N:  h = sh - dy; y = sy + dy; break;
            case ResizeCorner.NW: w = sw - dx; h = sh - dy; x = sx + dx; y = sy + dy; break;
            case ResizeCorner.W:  w = sw - dx; x = sx + dx; break;
            case ResizeCorner.SW: w = sw - dx; h = sh + dy; x = sx + dx; break;
        }
        if (w < minW) { if (corner is ResizeCorner.NW or ResizeCorner.W or ResizeCorner.SW) x = sx + sw - minW; w = minW; }
        if (h < minH) { if (corner is ResizeCorner.NW or ResizeCorner.N or ResizeCorner.NE) y = sy + sh - minH; h = minH; }
        w = Math.Clamp(w, minW, CanvasW);
        h = Math.Clamp(h, minH, CanvasH);
        x = Math.Clamp(x, 0, CanvasW - w);
        y = Math.Clamp(y, 0, CanvasH - h);
    }

    private void ResizeHandle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is not FrameworkElement fe || fe.Tag is not ResizeHandleTag tag) return;
        e.Handled = true;
        _resizing = true;
        _resizeCorner = tag.Corner;
        _resizeModel = tag.Model;
        _resizeStartMouse = e.GetPosition(PlanCanvas);
        if (ChkSnapGrid.IsChecked == true)
            _resizeStartMouse = new Point(Snap(_resizeStartMouse.X), Snap(_resizeStartMouse.Y));

        if (tag.Model is FloorSpaceModel fs)
        {
            _resizeSx = fs.X; _resizeSy = fs.Y; _resizeSw = fs.Width; _resizeSh = fs.Height;
            _resizeIsRound = false;
        }
        else if (tag.Model is FloorTableModel ft)
        {
            _resizeIsRound = ft.IsRound;
            if (ft.IsRound)
            {
                var d = Math.Max(ft.Width, ft.Height);
                _resizeCx = ft.X + d / 2; _resizeCy = ft.Y + d / 2;
                _resizeSx = ft.X; _resizeSy = ft.Y; _resizeSw = d; _resizeSh = d;
            }
            else { _resizeSx = ft.X; _resizeSy = ft.Y; _resizeSw = ft.Width; _resizeSh = ft.Height; }
        }
        PlanCanvas.CaptureMouse();
    }

    private static void GetDragElementSize(FrameworkElement el, out double w, out double h)
    {
        if (el.Tag is FloorSpaceModel s) { w = s.Width; h = s.Height; return; }
        if (el.Tag is FloorTableModel t)
        {
            if (t.IsRound) { var d = Math.Max(t.Width, t.Height); w = h = d; return; }
            w = t.Width; h = t.Height; return;
        }
        w = el.ActualWidth > 1 ? el.ActualWidth : 80;
        h = el.ActualHeight > 1 ? el.ActualHeight : 80;
    }

    private void Page_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (_resizing)
        {
            _resizing = false;
            PlanCanvas.ReleaseMouseCapture();
            _resizeModel = null;
            if (_selectedModel is FloorTableModel tt) AssignTableToSpace(tt);
            SetDirty(true);
            RebuildCanvas();
            RestoreSelectionAfterRebuild();
            SyncInspectorFromSelection();
            return;
        }

        if (!_dragging || _dragEl == null) return;
        _dragging = false;
        _dragEl.ReleaseMouseCapture();

        var left = Canvas.GetLeft(_dragEl);
        var top = Canvas.GetTop(_dragEl);

        if (_dragEl.Tag is FloorSpaceModel sp) { sp.X = left; sp.Y = top; }
        else if (_dragEl.Tag is FloorTableModel tb) { tb.X = left; tb.Y = top; AssignTableToSpace(tb); }
        else if (_dragEl is Grid gr && gr.Tag is FloorTableModel t2) { t2.X = left; t2.Y = top; AssignTableToSpace(t2); }
        _dragEl = null;
        SetDirty(true);
        SyncInspectorFromSelection();
    }

    private void AssignTableToSpace(FloorTableModel t)
    {
        var cx = t.X + t.Width / 2;
        var cy = t.Y + t.Height / 2;
        if (t.IsRound) { var d = Math.Max(t.Width, t.Height); cx = t.X + d / 2; cy = t.Y + d / 2; }
        t.SpaceId = null;
        foreach (var s in _spaces.Where(z => z.LevelId == t.LevelId).OrderByDescending(z => z.ZOrder))
        {
            if (cx >= s.X && cx <= s.X + s.Width && cy >= s.Y && cy <= s.Y + s.Height)
            { t.SpaceId = s.Id; return; }
        }
    }

    // ───────────────────── Selection / Inspector ────────────────────────
    private void Select(object model, FrameworkElement el)
    {
        _selectedModel = model;
        _selectedEl = el;
        PropsEditor.Visibility = Visibility.Visible;
        TxtSelectionHint.Visibility = Visibility.Collapsed;
        SyncInspectorFromSelection();
        UpdateInspectorHeader();
        ApplySelectionHighlight();
        ApplyResizeHandles();
    }

    private void SyncInspectorFromSelection()
    {
        if (_selectedModel == null) return;
        _suspendProps = true;

        if (_selectedModel is FloorSpaceModel fs)
        {
            CardShape.Visibility = Visibility.Collapsed;
            CardZone.Visibility = Visibility.Collapsed;
            CardColor.Visibility = Visibility.Visible;

            TxtPropName.Text = fs.Name;
            TxtPropX.Text = fs.X.ToString("0", CultureInfo.InvariantCulture);
            TxtPropY.Text = fs.Y.ToString("0", CultureInfo.InvariantCulture);
            TxtPropW.Text = fs.Width.ToString("0", CultureInfo.InvariantCulture);
            TxtPropH.Text = fs.Height.ToString("0", CultureInfo.InvariantCulture);

            UpdateColorSwatches(fs.TintArgb);
            UpdateStatusBar(fs.X, fs.Y, fs.Width, fs.Height);

            var lv = _levels.FirstOrDefault(l => l.Id == fs.LevelId)?.Name ?? "";
            TxtPropMeta.Text = $"Sub-zona in nivelul '{lv}'. Trage colturile aurii pentru redimensionare.";
        }
        else if (_selectedModel is FloorTableModel ft)
        {
            CardShape.Visibility = Visibility.Visible;
            CardZone.Visibility = Visibility.Visible;
            CardColor.Visibility = Visibility.Collapsed;

            _suspendShapeToggle = true;
            TbShapeRect.IsChecked  = !ft.IsRound;
            TbShapeRound.IsChecked =  ft.IsRound;
            _suspendShapeToggle = false;

            TxtPropName.Text = ft.Name;
            TxtPropSeats.Text = ft.Seats.ToString(CultureInfo.InvariantCulture);
            TxtPropX.Text = ft.X.ToString("0", CultureInfo.InvariantCulture);
            TxtPropY.Text = ft.Y.ToString("0", CultureInfo.InvariantCulture);
            TxtPropW.Text = ft.Width.ToString("0", CultureInfo.InvariantCulture);
            TxtPropH.Text = ft.Height.ToString("0", CultureInfo.InvariantCulture);

            // Combo of zones in this level + (Auto)
            var zones = new List<FloorSpaceModel> { new() { Id = "", Name = "(Auto — dupa pozitie)" } };
            zones.AddRange(_spaces.Where(s => s.LevelId == ft.LevelId).OrderBy(s => s.Name));
            CmbSpace.ItemsSource = zones;
            var match = zones.FirstOrDefault(z => z.Id == (ft.SpaceId ?? "")) ?? zones[0];
            CmbSpace.SelectedItem = match;

            UpdateStatusBar(ft.X, ft.Y, ft.Width, ft.Height);

            var zoneText = string.IsNullOrWhiteSpace(ft.SpaceId)
                ? "in afara sub-zonelor"
                : _spaces.FirstOrDefault(z => z.Id == ft.SpaceId)?.Name ?? "sub-zona";
            var lv = _levels.FirstOrDefault(l => l.Id == ft.LevelId)?.Name ?? "";
            TxtPropMeta.Text = $"Nivel: {lv}. Tip: {(ft.IsRound ? "rotunda" : "dreptunghi")}. Sub-zona: {zoneText}.";
        }

        _suspendProps = false;
    }

    private void UpdateInspectorHeader()
    {
        if (_selectedModel == null)
        {
            TxtInspectorTitle.Text = "Nicio selectie";
            TxtInspectorSubtitle.Text = "Selecteaza un element pe plan.";
            return;
        }
        if (_selectedModel is FloorSpaceModel fs)
        {
            TxtInspectorTitle.Text = string.IsNullOrWhiteSpace(fs.Name) ? "Sub-zona" : fs.Name;
            TxtInspectorSubtitle.Text = "Sub-zona · grupare in sala";
        }
        else if (_selectedModel is FloorTableModel ft)
        {
            TxtInspectorTitle.Text = string.IsNullOrWhiteSpace(ft.Name) ? "Masa" : ft.Name;
            TxtInspectorSubtitle.Text = ft.IsRound
                ? $"Masa rotunda · {ft.Seats} locuri"
                : $"Masa dreptunghi · {ft.Seats} locuri";
        }
    }

    private void ClearSelection()
    {
        _selectedModel = null;
        _selectedEl = null;
        PropsEditor.Visibility = Visibility.Collapsed;
        TxtSelectionHint.Visibility = Visibility.Visible;
        UpdateInspectorHeader();
        UpdateStatusBar(double.NaN, double.NaN, double.NaN, double.NaN);
        ApplySelectionHighlight();
        ApplyResizeHandles();
    }

    private void ApplySelectionHighlight()
    {
        foreach (UIElement child in PlanCanvas.Children)
        {
            if (child is not FrameworkElement fe) continue;
            if (fe.Tag is FloorSpaceModel)
            {
                var isSel = ReferenceEquals(fe, _selectedEl);
                if (fe is Border b)
                {
                    b.BorderBrush = isSel ? SelGoldBrush : ZoneIdleBorder;
                    b.BorderThickness = new Thickness(isSel ? 3 : 2);
                }
            }
            else if (fe.Tag is FloorTableModel)
            {
                var isSel = ReferenceEquals(fe, _selectedEl);
                if (fe is Border b)
                {
                    b.BorderBrush = isSel ? SelGoldBrush : TableRim;
                    b.BorderThickness = new Thickness(isSel ? 3 : 2);
                }
                else if (fe is Grid g)
                {
                    foreach (var c in g.Children.OfType<Ellipse>())
                    {
                        c.Stroke = isSel ? SelGoldBrush : TableRim;
                        c.StrokeThickness = isSel ? 3 : 2;
                    }
                }
            }
        }
    }

    private void ApplyResizeHandles()
    {
        for (var i = PlanCanvas.Children.Count - 1; i >= 0; i--)
            if (PlanCanvas.Children[i] is FrameworkElement fe && fe.Tag is ResizeHandleTag)
                PlanCanvas.Children.RemoveAt(i);

        if (_selectedModel == null) return;

        if (_selectedModel is FloorSpaceModel s)
            AddRectHandles(s, s.X, s.Y, s.Width, s.Height);
        else if (_selectedModel is FloorTableModel t)
        {
            if (t.IsRound) { var d = Math.Max(t.Width, t.Height); AddRoundHandles(t, t.X, t.Y, d); }
            else AddRectHandles(t, t.X, t.Y, t.Width, t.Height);
        }
    }

    private void AddRectHandles(object model, double x, double y, double w, double h)
    {
        void Add(ResizeCorner c, double hx, double hy)
        {
            var b = new Border
            {
                Width = HandleSz, Height = HandleSz,
                CornerRadius = new CornerRadius(HandleSz / 2),
                Background = Brushes.White,
                BorderBrush = SelGoldBrush,
                BorderThickness = new Thickness(2),
                Cursor = CursorForCorner(c),
                Tag = new ResizeHandleTag { Model = model, Corner = c },
                SnapsToDevicePixels = true
            };
            Canvas.SetLeft(b, hx - HandleSz / 2);
            Canvas.SetTop(b, hy - HandleSz / 2);
            Canvas.SetZIndex(b, 2000);
            b.MouseLeftButtonDown += ResizeHandle_MouseLeftButtonDown;
            PlanCanvas.Children.Add(b);
        }
        Add(ResizeCorner.NW, x, y);
        Add(ResizeCorner.N,  x + w / 2, y);
        Add(ResizeCorner.NE, x + w, y);
        Add(ResizeCorner.W,  x, y + h / 2);
        Add(ResizeCorner.E,  x + w, y + h / 2);
        Add(ResizeCorner.SW, x, y + h);
        Add(ResizeCorner.S,  x + w / 2, y + h);
        Add(ResizeCorner.SE, x + w, y + h);
    }

    private void AddRoundHandles(FloorTableModel t, double x, double y, double d)
    {
        void Add(ResizeCorner c, double hx, double hy)
        {
            var b = new Border
            {
                Width = HandleSz, Height = HandleSz,
                CornerRadius = new CornerRadius(HandleSz / 2),
                Background = Brushes.White,
                BorderBrush = SelGoldBrush,
                BorderThickness = new Thickness(2),
                Cursor = Cursors.SizeNWSE,
                Tag = new ResizeHandleTag { Model = t, Corner = c },
                SnapsToDevicePixels = true
            };
            Canvas.SetLeft(b, hx - HandleSz / 2);
            Canvas.SetTop(b, hy - HandleSz / 2);
            Canvas.SetZIndex(b, 2000);
            b.MouseLeftButtonDown += ResizeHandle_MouseLeftButtonDown;
            PlanCanvas.Children.Add(b);
        }
        Add(ResizeCorner.NW, x, y);
        Add(ResizeCorner.NE, x + d, y);
        Add(ResizeCorner.SW, x, y + d);
        Add(ResizeCorner.SE, x + d, y + d);
    }

    private static Cursor CursorForCorner(ResizeCorner c) => c switch
    {
        ResizeCorner.NW or ResizeCorner.SE => Cursors.SizeNWSE,
        ResizeCorner.NE or ResizeCorner.SW => Cursors.SizeNESW,
        ResizeCorner.N  or ResizeCorner.S  => Cursors.SizeNS,
        ResizeCorner.E  or ResizeCorner.W  => Cursors.SizeWE,
        _ => Cursors.Arrow
    };

    // ─────────────────── Inspector inputs handlers ─────────────────────
    private void TxtPropName_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_suspendProps || _selectedModel == null) return;
        if (_selectedModel is FloorSpaceModel fs) fs.Name = TxtPropName.Text.Trim();
        else if (_selectedModel is FloorTableModel ft) ft.Name = TxtPropName.Text.Trim();
        SetDirty(true);
        RefreshLevelMeta(); SyncLevelUi();
        RebuildCanvas(); RestoreSelectionAfterRebuild();
        UpdateInspectorHeader();
    }

    private void TxtPropSeats_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_suspendProps || _selectedModel is not FloorTableModel ft) return;
        if (int.TryParse(TxtPropSeats.Text.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var n))
            ft.Seats = Math.Clamp(n, 1, 99);
        SetDirty(true);
        RebuildCanvas(); RestoreSelectionAfterRebuild();
        UpdateInspectorHeader();
    }

    private void TxtPropPos_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_suspendProps || _selectedModel == null) return;
        double.TryParse(TxtPropX.Text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var x);
        double.TryParse(TxtPropY.Text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var y);

        if (_selectedModel is FloorSpaceModel fs)
        {
            fs.X = Math.Clamp(x, 0, CanvasW - fs.Width);
            fs.Y = Math.Clamp(y, 0, CanvasH - fs.Height);
        }
        else if (_selectedModel is FloorTableModel ft)
        {
            var w = ft.Width; var h = ft.Height;
            if (ft.IsRound) { var d = Math.Max(w, h); w = h = d; }
            ft.X = Math.Clamp(x, 0, CanvasW - w);
            ft.Y = Math.Clamp(y, 0, CanvasH - h);
        }
        SetDirty(true);
        RebuildCanvas(); RestoreSelectionAfterRebuild();
        if (_selectedModel is FloorSpaceModel s2) UpdateStatusBar(s2.X, s2.Y, s2.Width, s2.Height);
        else if (_selectedModel is FloorTableModel t2) UpdateStatusBar(t2.X, t2.Y, t2.Width, t2.Height);
    }

    private void TxtPropSize_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_suspendProps || _selectedModel == null) return;
        if (_selectedModel is FloorSpaceModel fs)
        {
            if (double.TryParse(TxtPropW.Text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var w))
                fs.Width = Math.Clamp(w, MinZonePx, CanvasW);
            if (double.TryParse(TxtPropH.Text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var h))
                fs.Height = Math.Clamp(h, MinZonePx, CanvasH);
            fs.X = Math.Clamp(fs.X, 0, CanvasW - fs.Width);
            fs.Y = Math.Clamp(fs.Y, 0, CanvasH - fs.Height);
        }
        else if (_selectedModel is FloorTableModel ft)
        {
            if (double.TryParse(TxtPropW.Text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var w))
                ft.Width = Math.Clamp(w, MinTblPx, MaxTblPx);
            if (double.TryParse(TxtPropH.Text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var h))
                ft.Height = Math.Clamp(h, MinTblPx, MaxTblPx);
            if (ft.IsRound) { var d = Math.Max(ft.Width, ft.Height); ft.Width = ft.Height = d; }
        }
        SetDirty(true);
        RebuildCanvas(); RestoreSelectionAfterRebuild();
        if (_selectedModel is FloorSpaceModel s2) UpdateStatusBar(s2.X, s2.Y, s2.Width, s2.Height);
        else if (_selectedModel is FloorTableModel t2) UpdateStatusBar(t2.X, t2.Y, t2.Width, t2.Height);
    }

    private void TbShape_Click(object sender, RoutedEventArgs e)
    {
        if (_suspendShapeToggle) return;
        if (_selectedModel is not FloorTableModel ft) return;

        var wantRound = ReferenceEquals(sender, TbShapeRound);
        if (ft.IsRound == wantRound)
        {
            _suspendShapeToggle = true;
            TbShapeRect.IsChecked = !ft.IsRound;
            TbShapeRound.IsChecked = ft.IsRound;
            _suspendShapeToggle = false;
            return;
        }

        ft.IsRound = wantRound;
        if (wantRound) { var d = Math.Max(ft.Width, ft.Height); ft.Width = ft.Height = d; }
        SetDirty(true);
        RebuildCanvas(); RestoreSelectionAfterRebuild();
        SyncInspectorFromSelection();
        UpdateInspectorHeader();
    }

    private void CmbSpace_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suspendProps || _selectedModel is not FloorTableModel ft) return;
        if (CmbSpace.SelectedItem is not FloorSpaceModel sp) return;
        ft.SpaceId = string.IsNullOrEmpty(sp.Id) ? null : sp.Id;
        SetDirty(true);
        UpdateInspectorHeader();
        SyncInspectorFromSelection();
    }

    // ─────────────────── Color palette (zones) ─────────────────────────
    private void BuildColorPalette()
    {
        WrapColors.Children.Clear();
        foreach (var argb in TintPalette)
        {
            var color = ToColor(argb);
            // boost alpha to ~100% for the swatch UI so it reads clearly
            var swatchColor = Color.FromRgb(color.R, color.G, color.B);

            var b = new Border
            {
                Width = 34, Height = 34,
                CornerRadius = new CornerRadius(17),
                Background = new SolidColorBrush(swatchColor),
                BorderBrush = new SolidColorBrush(Color.FromRgb(0xD4, 0xD8, 0xD1)),
                BorderThickness = new Thickness(1.5),
                Cursor = Cursors.Hand,
                Margin = new Thickness(0, 0, 8, 8),
                Tag = argb
            };
            b.MouseLeftButtonDown += ColorSwatch_MouseDown;
            WrapColors.Children.Add(b);
        }
    }

    private void ColorSwatch_MouseDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is not Border b || b.Tag is not int argb) return;
        if (_selectedModel is not FloorSpaceModel fs) return;
        fs.TintArgb = argb;
        SetDirty(true);
        UpdateColorSwatches(argb);
        RebuildCanvas(); RestoreSelectionAfterRebuild();
    }

    private void UpdateColorSwatches(int activeArgb)
    {
        foreach (var ch in WrapColors.Children)
        {
            if (ch is Border b && b.Tag is int argb)
            {
                var active = argb == activeArgb;
                b.BorderBrush = active ? SelGoldBrush : new SolidColorBrush(Color.FromRgb(0xD4, 0xD8, 0xD1));
                b.BorderThickness = new Thickness(active ? 3 : 1.5);
            }
        }
    }

    // ─────────────────── Status bar ────────────────────────────────────
    private void UpdateStatusBar(double x, double y, double w, double h)
    {
        if (double.IsNaN(x))
        {
            TxtStatusX.Text = "—"; TxtStatusY.Text = "—"; TxtStatusSize.Text = "—";
            return;
        }
        TxtStatusX.Text = $"{x:0} px";
        TxtStatusY.Text = $"{y:0} px";
        TxtStatusSize.Text = $"{w:0} × {h:0} px";
    }

    private void RefreshStatusCounts()
    {
        var spaces = SpacesOnCanvas.Count();
        var tables = TablesOnCanvas.Count();
        TxtStatusCounts.Text = $"{spaces} {(spaces == 1 ? "zona" : "zone")} · {tables} {(tables == 1 ? "masa" : "mese")}";
    }

    // ─────────────────── Restore selection after rebuild ───────────────
    private void RestoreSelectionAfterRebuild()
    {
        if (_selectedModel is FloorSpaceModel fs)
        {
            foreach (UIElement child in PlanCanvas.Children)
                if (child is FrameworkElement fe && fe.Tag is FloorSpaceModel z && z.Id == fs.Id)
                { _selectedEl = fe; ApplySelectionHighlight(); ApplyResizeHandles(); return; }
        }
        else if (_selectedModel is FloorTableModel ft)
        {
            foreach (UIElement child in PlanCanvas.Children)
                if (child is FrameworkElement fe && fe.Tag is FloorTableModel t && t.Id == ft.Id)
                { _selectedEl = fe; ApplySelectionHighlight(); ApplyResizeHandles(); return; }
        }
    }

    // ─────────────────── Add / Delete / Duplicate / Z-Order ────────────
    private void BtnAddSpace_Click(object sender, RoutedEventArgs e)
    {
        SyncCurrentLevelFromTabs();
        if (string.IsNullOrEmpty(NormId(_currentLevelId))) return;
        var same = _spaces.Count(z => NormId(z.LevelId).Equals(NormId(_currentLevelId), StringComparison.OrdinalIgnoreCase));
        var s = new FloorSpaceModel
        {
            LevelId = NormId(_currentLevelId),
            Name = "Zona " + (same + 1),
            X = 80 + same * 28, Y = 80 + same * 18,
            Width = 400, Height = 280,
            ZOrder = same
        };
        _spaces.Add(s);
        SetDirty(true);
        RefreshLevelMeta(); SyncLevelUi();
        RebuildCanvas();
        SelectModel(s);
        RefreshStatusCounts();
    }

    private void BtnAddTableRect_Click(object sender, RoutedEventArgs e)
    {
        SyncCurrentLevelFromTabs();
        if (string.IsNullOrEmpty(NormId(_currentLevelId))) return;
        var n = _tables.Count(t => NormId(t.LevelId).Equals(NormId(_currentLevelId), StringComparison.OrdinalIgnoreCase));
        var t = new FloorTableModel
        {
            LevelId = NormId(_currentLevelId),
            Name = "Masa " + (n + 1),
            X = 420 + n * 36, Y = 380 + n * 28,
            Width = 104, Height = 72,
            IsRound = false, Seats = 4
        };
        _tables.Add(t);
        SetDirty(true);
        RefreshLevelMeta(); SyncLevelUi();
        RebuildCanvas();
        SelectModel(t);
        RefreshStatusCounts();
    }

    private void BtnAddTableRound_Click(object sender, RoutedEventArgs e)
    {
        SyncCurrentLevelFromTabs();
        if (string.IsNullOrEmpty(NormId(_currentLevelId))) return;
        var n = _tables.Count(t => NormId(t.LevelId).Equals(NormId(_currentLevelId), StringComparison.OrdinalIgnoreCase));
        var t = new FloorTableModel
        {
            LevelId = NormId(_currentLevelId),
            Name = "Masa " + (n + 1),
            X = 460 + n * 36, Y = 400 + n * 28,
            Width = 88, Height = 88,
            IsRound = true, Seats = 4
        };
        _tables.Add(t);
        SetDirty(true);
        RefreshLevelMeta(); SyncLevelUi();
        RebuildCanvas();
        SelectModel(t);
        RefreshStatusCounts();
    }

    private void SelectModel(object model)
    {
        foreach (UIElement c in PlanCanvas.Children)
        {
            if (c is FrameworkElement fe)
            {
                if (fe.Tag is FloorSpaceModel sp && model is FloorSpaceModel sm && sp.Id == sm.Id)
                { Select(model, fe); fe.BringIntoView(); return; }
                if (fe.Tag is FloorTableModel tb && model is FloorTableModel tm && tb.Id == tm.Id)
                { Select(model, fe); fe.BringIntoView(); return; }
            }
        }
    }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        if (_selectedModel is FloorSpaceModel fs)
        {
            _spaces.RemoveAll(x => x.Id == fs.Id);
            foreach (var t in _tables.Where(x => x.SpaceId == fs.Id)) t.SpaceId = null;
        }
        else if (_selectedModel is FloorTableModel ft)
        {
            _tables.RemoveAll(x => x.Id == ft.Id);
        }
        else return;

        SetDirty(true);
        RefreshLevelMeta(); SyncLevelUi();
        ClearSelection();
        RebuildCanvas();
        RefreshStatusCounts();
    }

    private void BtnDuplicate_Click(object sender, RoutedEventArgs e) => DuplicateSelection();

    private void DuplicateSelection()
    {
        if (_selectedModel is FloorSpaceModel fs)
        {
            var clone = new FloorSpaceModel
            {
                LevelId = fs.LevelId,
                Name = fs.Name + " (copie)",
                X = Math.Min(fs.X + 30, CanvasW - fs.Width),
                Y = Math.Min(fs.Y + 30, CanvasH - fs.Height),
                Width = fs.Width, Height = fs.Height,
                TintArgb = fs.TintArgb,
                ZOrder = (_spaces.Count > 0 ? _spaces.Max(z => z.ZOrder) : 0) + 1
            };
            _spaces.Add(clone);
            SetDirty(true);
            RefreshLevelMeta(); SyncLevelUi();
            RebuildCanvas(); SelectModel(clone);
            RefreshStatusCounts();
        }
        else if (_selectedModel is FloorTableModel ft)
        {
            var clone = new FloorTableModel
            {
                LevelId = ft.LevelId,
                Name = NextTableName(ft.Name),
                X = Math.Min(ft.X + 30, CanvasW - ft.Width),
                Y = Math.Min(ft.Y + 30, CanvasH - ft.Height),
                Width = ft.Width, Height = ft.Height,
                IsRound = ft.IsRound, Seats = ft.Seats,
                SpaceId = ft.SpaceId
            };
            _tables.Add(clone);
            SetDirty(true);
            RefreshLevelMeta(); SyncLevelUi();
            RebuildCanvas(); SelectModel(clone);
            RefreshStatusCounts();
        }
    }

    private string NextTableName(string baseName)
    {
        var n = _tables.Count(t => NormId(t.LevelId).Equals(NormId(_currentLevelId), StringComparison.OrdinalIgnoreCase));
        return baseName + " #" + (n + 1);
    }

    private void BtnBringFront_Click(object sender, RoutedEventArgs e)
    {
        if (_selectedModel is FloorSpaceModel fs)
        {
            var maxZ = _spaces.Where(s => s.LevelId == fs.LevelId).Max(s => s.ZOrder);
            fs.ZOrder = maxZ + 1;
        }
        else if (_selectedModel is FloorTableModel ft)
        {
            _tables.Remove(ft); _tables.Add(ft);
        }
        else return;
        SetDirty(true);
        RebuildCanvas(); RestoreSelectionAfterRebuild();
    }

    private void BtnSendBack_Click(object sender, RoutedEventArgs e)
    {
        if (_selectedModel is FloorSpaceModel fs)
        {
            var minZ = _spaces.Where(s => s.LevelId == fs.LevelId).Min(s => s.ZOrder);
            fs.ZOrder = minZ - 1;
        }
        else if (_selectedModel is FloorTableModel ft)
        {
            _tables.Remove(ft); _tables.Insert(0, ft);
        }
        else return;
        SetDirty(true);
        RebuildCanvas(); RestoreSelectionAfterRebuild();
    }

    // ─────────────────── Zoom controls ────────────────────────────────
    private void BtnZoomReset_Click(object sender, RoutedEventArgs e) => ZoomSlider.Value = 1.0;
    private void BtnZoomIn_Click(object sender, RoutedEventArgs e)    => ZoomSlider.Value = Math.Min(ZoomSlider.Maximum, ZoomSlider.Value + 0.10);
    private void BtnZoomOut_Click(object sender, RoutedEventArgs e)   => ZoomSlider.Value = Math.Max(ZoomSlider.Minimum, ZoomSlider.Value - 0.10);

    // ─────────────────── Keyboard ─────────────────────────────────────
    private void Page_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        var ctrl = (Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control;
        var shift = (Keyboard.Modifiers & ModifierKeys.Shift) == ModifierKeys.Shift;

        if (ctrl && e.Key == Key.S) { BtnSave_Click(sender, e); e.Handled = true; return; }
        if (ctrl && e.Key == Key.D && _selectedModel != null) { DuplicateSelection(); e.Handled = true; return; }

        if (e.Key == Key.Delete && _selectedModel != null && !IsTextInputFocused())
        { BtnDelete_Click(sender, e); e.Handled = true; return; }

        if (_selectedModel != null && !IsTextInputFocused() &&
            e.Key is Key.Left or Key.Right or Key.Up or Key.Down)
        {
            var step = shift ? 10 : 1;
            var dx = e.Key == Key.Left ? -step : e.Key == Key.Right ? step : 0;
            var dy = e.Key == Key.Up   ? -step : e.Key == Key.Down  ? step : 0;
            NudgeSelection(dx, dy);
            e.Handled = true;
        }
    }

    private static bool IsTextInputFocused()
    {
        var f = Keyboard.FocusedElement;
        return f is TextBox or PasswordBox;
    }

    private void NudgeSelection(double dx, double dy)
    {
        if (_selectedModel is FloorSpaceModel fs)
        {
            fs.X = Math.Clamp(fs.X + dx, 0, CanvasW - fs.Width);
            fs.Y = Math.Clamp(fs.Y + dy, 0, CanvasH - fs.Height);
        }
        else if (_selectedModel is FloorTableModel ft)
        {
            var w = ft.IsRound ? Math.Max(ft.Width, ft.Height) : ft.Width;
            var h = ft.IsRound ? w : ft.Height;
            ft.X = Math.Clamp(ft.X + dx, 0, CanvasW - w);
            ft.Y = Math.Clamp(ft.Y + dy, 0, CanvasH - h);
            AssignTableToSpace(ft);
        }
        else return;

        SetDirty(true);
        RebuildCanvas(); RestoreSelectionAfterRebuild();
        SyncInspectorFromSelection();
    }

    // ─────────────────── Types ─────────────────────────────────────────
    private enum ResizeCorner { NW, N, NE, W, E, SW, S, SE }

    private sealed class ResizeHandleTag
    {
        public object Model { get; init; } = null!;
        public ResizeCorner Corner { get; init; }
    }
}

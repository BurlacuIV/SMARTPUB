using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Views;

public partial class SalesModulePage : Page
{
    private readonly ObservableCollection<PosSaleHeaderRow> _sales = new();
    private readonly ObservableCollection<PosSaleLineRow> _lines = new();
    private readonly ObservableCollection<TransferDocumentPick> _transfer = new();
    private readonly ObservableCollection<PosSaleLineRow> _transferLines = new();
    private readonly ObservableCollection<PosSaleTransferPick> _sent = new();

    public SalesModulePage()
    {
        InitializeComponent();
        GridSales.ItemsSource = _sales;
        GridLines.ItemsSource = _lines;
        GridTransfer.ItemsSource = _transfer;
        GridTransferLines.ItemsSource = _transferLines;
        GridSent.ItemsSource = _sent;
        DpFrom.SelectedDate = DateTime.Today.AddDays(-7);
        DpTo.SelectedDate = DateTime.Today;
        Loaded += (_, _) =>
        {
            RefreshSalesList();
            RefreshTransferList();
            RefreshSentList();
        };
    }

    private void BtnRefreshList_Click(object sender, RoutedEventArgs e) => RefreshSalesList();

    private void BtnRefreshTransfer_Click(object sender, RoutedEventArgs e) => RefreshTransferList();

    private void BtnRefreshSent_Click(object sender, RoutedEventArgs e) => RefreshSentList();

    private void RefreshSalesList()
    {
        _sales.Clear();
        _lines.Clear();
        try
        {
            var from = DpFrom.SelectedDate ?? DateTime.Today.AddDays(-30);
            var to = DpTo.SelectedDate ?? DateTime.Today;
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchema(conn);
            foreach (var h in PosSaleRepository.ListHeaders(conn, from, to, null))
                _sales.Add(h);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void RefreshTransferList()
    {
        _transfer.Clear();
        _transferLines.Clear();
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchema(conn);
            var from = DateTime.Today.AddYears(-1);
            var to = DateTime.Today.AddDays(1);
            var headers = PosSaleRepository.ListHeaders(conn, from, to, PosSaleRepository.SagaReady);
            var transferCfg = new ProgramExtendedConfigRepository().LoadTransfer(conn);
            var client = ResolveTransferClient(conn, transferCfg);
            foreach (var doc in BuildTransferDocuments(conn, headers, client))
                _transfer.Add(doc);

            if (_transfer.Count > 0)
                GridTransfer.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void RefreshSentList()
    {
        _sent.Clear();
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchema(conn);
            var from = DateTime.Today.AddYears(-2);
            var to = DateTime.Today.AddDays(1);
            foreach (var h in PosSaleRepository.ListHeaders(conn, from, to, PosSaleRepository.SagaSent))
                _sent.Add(ToTransferPick(h));
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void GridSales_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        _lines.Clear();
        if (GridSales.SelectedItem is not PosSaleHeaderRow h || string.IsNullOrWhiteSpace(h.Id))
            return;
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            PosOperationalSchema.EnsureSchema(conn);
            foreach (var ln in PosSaleRepository.ListLines(conn, h.Id))
                _lines.Add(ln);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void GridTransfer_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        _transferLines.Clear();
        if (GridTransfer.SelectedItem is not TransferDocumentPick doc)
            return;

        foreach (var line in doc.Lines)
            _transferLines.Add(line);
    }

    private void BtnTransfer_Click(object sender, RoutedEventArgs e)
    {
        var picks = _transfer.Where(x => x.Selected).ToList();
        if (picks.Count == 0)
        {
            MessageBox.Show("Bifați cel puțin un document de transfer.", "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var saleIds = picks.SelectMany(x => x.SaleIds).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var ok = SagaVanzariTransferService.TryTransferSales(saleIds, out var msg);
        var summary = msg;
        MessageBox.Show(summary, "SAGA", MessageBoxButton.OK,
            ok ? MessageBoxImage.Information : MessageBoxImage.Warning);

        RefreshTransferList();
        RefreshSentList();
        RefreshSalesList();
    }

    private void BtnCancelTransfer_Click(object sender, RoutedEventArgs e)
    {
        var selected = _sent.Where(x => x.Selected).ToList();
        if (selected.Count == 0)
        {
            MessageBox.Show("Bifați cel puțin un document transferat pentru anulare.", "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var selectedIds = selected
            .Select(x => x.Id)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var selectedSagaIds = selected
            .Where(x => x.SagaIdIesire.HasValue)
            .Select(x => x.SagaIdIesire!.Value)
            .ToHashSet();
        var selectedSagaNumbers = selected
            .Select(x => (x.SagaNrIesire ?? "").Trim())
            .Where(x => x.Length > 0)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var picks = _sent
            .Where(x =>
                selectedIds.Contains(x.Id) ||
                (x.SagaIdIesire.HasValue && selectedSagaIds.Contains(x.SagaIdIesire.Value)) ||
                selectedSagaNumbers.Contains((x.SagaNrIesire ?? "").Trim()))
            .ToList();

        var docs = picks
            .Select(x => (x.SagaNrIesire ?? "").Trim())
            .Where(x => x.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        var docText = docs.Count == 0 ? "" : Environment.NewLine + "Documente SAGA: " + string.Join(", ", docs);
        var confirm = MessageBox.Show(
            $"Anulați marcarea ca transferate pentru {picks.Count} bonuri?{docText}{Environment.NewLine}{Environment.NewLine}" +
            "Bonurile vor reveni în tabul „Transfer date în SAGA”. Documentele deja create în SAGA trebuie verificate/stornate manual dacă este cazul.",
            "Anulare transfer SAGA",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);
        if (confirm != MessageBoxResult.Yes)
            return;

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchema(conn);
            var updated = PosSaleRepository.ResetSagaTransferToReady(conn, picks.Select(x => x.Id));
            MessageBox.Show(
                updated == 0
                    ? "Nu s-a modificat niciun bon. Reîncărcați lista și verificați starea transferului."
                    : $"Transfer anulat pentru {updated} bonuri. Acestea reapar în „Transfer date în SAGA”.",
                "SMARTPUB",
                MessageBoxButton.OK,
                updated == 0 ? MessageBoxImage.Information : MessageBoxImage.Information);

            RefreshTransferList();
            RefreshSentList();
            RefreshSalesList();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private static List<TransferDocumentPick> BuildTransferDocuments(
        FbConnection conn,
        List<PosSaleHeaderRow> headers,
        TransferClientInfo client)
    {
        var result = new List<TransferDocumentPick>();
        foreach (var day in headers.GroupBy(h => h.PaidAt.Date).OrderBy(g => g.Key))
        {
            var dayHeaders = day.OrderBy(h => h.OrderNo).ToList();
            var rawLines = new List<PosSaleLineRow>();
            foreach (var h in dayHeaders)
                rawLines.AddRange(PosSaleRepository.ListLines(conn, h.Id));

            var lines = AggregateTransferLines(rawLines);
            ApplyArticleTypes(conn, lines);
            if (lines.Count == 0)
                continue;

            result.Add(new TransferDocumentPick
            {
                DocumentDate = day.Key,
                DocumentNo = int.Parse(day.Key.ToString("yyyyMMdd")),
                ClientCode = client.Code,
                ClientName = client.Name,
                Valoare = Math.Round(lines.Sum(x => x.Valoare), 2, MidpointRounding.AwayFromZero),
                ValoareTva = Math.Round(lines.Sum(x => x.ValoareTva), 2, MidpointRounding.AwayFromZero),
                Total = Math.Round(lines.Sum(x => x.Total), 2, MidpointRounding.AwayFromZero),
                BonCount = dayHeaders.Count,
                SalesSummary = $"{dayHeaders.Min(x => x.OrderNo)} - {dayHeaders.Max(x => x.OrderNo)}",
                SaleIds = dayHeaders.Select(x => x.Id).ToList(),
                Lines = lines
            });
        }

        return result;
    }

    private static List<PosSaleLineRow> AggregateTransferLines(List<PosSaleLineRow> lines)
    {
        return lines
            .GroupBy(x => new
            {
                Code = Norm(x.ProductCode),
                Gest = Norm(x.CodGestiune),
                Tva = Math.Round(x.TvaPct, 2),
                Price = Math.Round(x.UnitPrice, 4),
                Um = Norm(x.Um)
            })
            .Select(g =>
            {
                var first = g.First();
                return new PosSaleLineRow
                {
                    ProductCode = first.ProductCode,
                    ProductName = first.ProductName,
                    CodGestiune = first.CodGestiune,
                    DenGest = first.DenGest,
                    Um = first.Um,
                    TvaPct = first.TvaPct,
                    UnitPrice = first.UnitPrice,
                    Qty = g.Sum(x => x.Qty),
                    Valoare = Math.Round(g.Sum(x => x.Valoare), 2, MidpointRounding.AwayFromZero),
                    ValoareTva = Math.Round(g.Sum(x => x.ValoareTva), 2, MidpointRounding.AwayFromZero),
                    Total = Math.Round(g.Sum(x => x.Total), 2, MidpointRounding.AwayFromZero)
                };
            })
            .OrderBy(x => x.CodGestiune)
            .ThenBy(x => x.ProductName)
            .ToList();
    }

    private static TransferClientInfo ResolveTransferClient(
        FbConnection conn,
        ProgramTransferDocConfig cfg)
    {
        var code = string.IsNullOrWhiteSpace(cfg.ImplicitClient)
            ? SagaVanzariTransferService.DefaultClientCode
            : cfg.ImplicitClient.Trim();
        var name = "";
        try
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
SELECT TRIM(COALESCE(NAME, ''))
FROM SP_SAGA_CLIENTI
WHERE TRIM(CODE) = TRIM(@C)
ROWS 1";
            cmd.Parameters.AddWithValue("@C", code);
            name = cmd.ExecuteScalar()?.ToString()?.Trim() ?? "";
        }
        catch
        {
            name = "";
        }

        return new TransferClientInfo(code, string.IsNullOrWhiteSpace(name) ? code : name);
    }

    private static string Norm(string? value) => (value ?? "").Trim().ToUpperInvariant();

    private static PosSaleTransferPick ToTransferPick(PosSaleHeaderRow h) => new()
    {
        Id = h.Id,
        OrderNo = h.OrderNo,
        OperatorName = h.OperatorName,
        PaidAt = h.PaidAt,
        CreatedAt = h.CreatedAt,
        Valoare = h.Valoare,
        ValoareTva = h.ValoareTva,
        Total = h.Total,
        TableDisplayName = h.TableDisplayName,
        Status = h.Status,
        ModPlata = h.ModPlata,
        SagaTransferStatus = h.SagaTransferStatus,
        SagaIdIesire = h.SagaIdIesire,
        SagaNrIesire = h.SagaNrIesire,
        SagaError = h.SagaError
    };

    private static void ApplyArticleTypes(FbConnection conn, List<PosSaleLineRow> lines)
    {
        if (lines.Count == 0)
            return;

        var codes = lines
            .Select(x => (x.ProductCode ?? "").Trim())
            .Where(x => x.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        if (codes.Count == 0)
            return;

        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        const int batch = 80;
        for (var i = 0; i < codes.Count; i += batch)
        {
            var chunk = codes.Skip(i).Take(batch).ToList();
            var placeholders = string.Join(",", chunk.Select((_, idx) => "@C" + idx));
            using var cmd = conn.CreateCommand();
            cmd.CommandText = $@"
SELECT TRIM(CODE), TRIM(COALESCE(DEN_TIP, ''))
FROM SP_SAGA_ARTICOLE
WHERE TRIM(CODE) IN ({placeholders})";
            for (var j = 0; j < chunk.Count; j++)
                cmd.Parameters.AddWithValue("@C" + j, chunk[j]);

            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var code = (rd[0]?.ToString() ?? "").Trim();
                if (code.Length > 0)
                    map[code] = (rd[1]?.ToString() ?? "").Trim();
            }
        }

        foreach (var line in lines)
            if (map.TryGetValue(line.ProductCode, out var denTip))
                line.DenTip = denTip;
    }

    private sealed record TransferClientInfo(string Code, string Name);

    private sealed class TransferDocumentPick : INotifyPropertyChanged
    {
        private bool _selected;

        public bool Selected
        {
            get => _selected;
            set
            {
                if (_selected == value)
                    return;
                _selected = value;
                OnPropertyChanged();
            }
        }

        public string Tip { get; init; } = "B";
        public int DocumentNo { get; init; }
        public string ClientCode { get; init; } = "";
        public string ClientName { get; init; } = "";
        public DateTime DocumentDate { get; init; }
        public decimal Valoare { get; init; }
        public decimal ValoareTva { get; init; }
        public decimal Total { get; init; }
        public int BonCount { get; init; }
        public string SalesSummary { get; init; } = "";
        public List<string> SaleIds { get; init; } = new();
        public List<PosSaleLineRow> Lines { get; init; } = new();

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string? n = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    }
}

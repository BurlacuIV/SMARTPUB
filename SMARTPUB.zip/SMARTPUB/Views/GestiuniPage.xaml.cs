using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Printing;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Services;

namespace SMARTPUB.Views;

public partial class GestiuniPage : Page
{
    private readonly PosGestiunePrinterRepository _printerRepo = new();
    private readonly ObservableCollection<GestiuneListRow> _allRows = new();
    private List<string> _printerNames = new();
    private bool _loaded;

    public ObservableCollection<PrinterOption> PrinterOptions { get; } = new();

    public GestiuniPage()
    {
        InitializeComponent();
        GridGestiuni.ItemsSource = _allRows;
        Loaded += async (_, _) => await LoadGestiuniAsync();
    }

    private void BtnReload_Click(object sender, RoutedEventArgs e) =>
        _ = LoadGestiuniAsync();

    private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (!_loaded)
            return;
        ApplyFilter();
    }

    private void GridGestiuni_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    {
        if (e.EditAction == DataGridEditAction.Cancel)
            return;
        GridGestiuni.Dispatcher.BeginInvoke(() =>
        {
            GridGestiuni.CommitEdit(DataGridEditingUnit.Row, true);
            GridGestiuni.CommitEdit();
        });
    }

    private async Task LoadGestiuniAsync()
    {
        TxtFooter.Text = "Se încarcă gestiunile...";
        try
        {
            var data = await Task.Run(() =>
            {
                var printers = CollectPrinterNames();
                using var conn = SmartPubDb.OpenEmbedded();
                SmartPubBootstrap.ApplySchemaForce(conn);
                var printerMap = _printerRepo.LoadMap(conn);
                var rows = LoadGestiuniFromDb(conn, printerMap);
                return (printers, rows);
            }).ConfigureAwait(true);

            _printerNames = data.printers;
            InitPrinterColumn();

            _allRows.Clear();
            foreach (var row in data.rows)
                _allRows.Add(row);

            _loaded = true;
            ApplyFilter();
        }
        catch (Exception ex)
        {
            TxtFooter.Text = "Eroare la încărcare gestiuni";
            MessageBox.Show("Nu am putut încărca gestiunile.\n" + ex.Message,
                "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void InitPrinterColumn()
    {
        PrinterOptions.Clear();
        PrinterOptions.Add(new PrinterOption("", "Fără imprimantă"));
        foreach (var printer in _printerNames)
            PrinterOptions.Add(new PrinterOption(printer, printer));
    }

    private static List<GestiuneListRow> LoadGestiuniFromDb(
        FbConnection conn,
        IReadOnlyDictionary<string, string> printerMap)
    {
        var list = new List<GestiuneListRow>();
        if (!TableExists(conn, "SP_SAGA_GESTIUNI"))
            return list;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT TRIM(CODE) AS CODE, TRIM(COALESCE(NAME, '')) AS NAME
FROM SP_SAGA_GESTIUNI
ORDER BY CODE";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var code = (rd["CODE"]?.ToString() ?? "").Trim();
            if (code.Length == 0)
                continue;

            printerMap.TryGetValue(code, out var printer);
            list.Add(new GestiuneListRow
            {
                Code = code,
                Name = (rd["NAME"]?.ToString() ?? "").Trim(),
                PrinterName = printer ?? ""
            });
        }

        return list;
    }

    private void ApplyFilter()
    {
        var term = (TxtSearch.Text ?? "").Trim();
        if (term.Length == 0)
        {
            GridGestiuni.ItemsSource = _allRows;
            TxtFooter.Text = $"{_allRows.Count} gestiuni · {_allRows.Count(r => !string.IsNullOrWhiteSpace(r.PrinterName))} cu imprimantă";
            return;
        }

        var filtered = _allRows
            .Where(x =>
                x.Code.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                x.Name.Contains(term, StringComparison.OrdinalIgnoreCase))
            .ToList();
        GridGestiuni.ItemsSource = filtered;
        TxtFooter.Text = $"{filtered.Count} din {_allRows.Count} gestiuni afișate";
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            GridGestiuni.CommitEdit(DataGridEditingUnit.Row, true);
            GridGestiuni.CommitEdit();

            using var conn = SmartPubDb.OpenEmbedded();
            _printerRepo.EnsureSchema(conn);
            foreach (var row in _allRows)
                _printerRepo.SavePrinter(conn, row.Code, row.PrinterName);

            var withPrinter = _allRows.Count(r => !string.IsNullOrWhiteSpace(r.PrinterName));
            TxtFooter.Text = $"{_allRows.Count} gestiuni · {withPrinter} cu imprimantă (salvat)";
            MessageBox.Show("Setările de imprimantă pe gestiuni au fost salvate.",
                "Gestiuni", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Salvarea a eșuat.\n" + ex.Message,
                "Gestiuni", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private static List<string> CollectPrinterNames()
    {
        var names = new List<string>();
        try
        {
            using var server = new LocalPrintServer();
            foreach (var q in server.GetPrintQueues(new[]
                     {
                         EnumeratedPrintQueueTypes.Local,
                         EnumeratedPrintQueueTypes.Connections
                     }))
            {
                try { names.Add(q.Name); }
                catch { /* ignore broken queue */ }
            }
        }
        catch
        {
            names.Add("Microsoft Print to PDF");
        }

        names.Sort(StringComparer.OrdinalIgnoreCase);
        return names.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private sealed class GestiuneListRow : INotifyPropertyChanged
    {
        private string _printerName = "";

        public string Code { get; set; } = "";
        public string Name { get; set; } = "";

        public string PrinterName
        {
            get => _printerName;
            set
            {
                if (_printerName == value)
                    return;
                _printerName = value ?? "";
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string? name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public sealed record PrinterOption(string Value, string Display);
}

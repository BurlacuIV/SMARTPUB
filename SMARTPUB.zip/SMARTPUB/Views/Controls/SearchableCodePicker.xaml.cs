using System.Collections;
using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using SMARTPUB.Models;

namespace SMARTPUB.Views.Controls;

public partial class SearchableCodePicker : UserControl
{
    public static readonly DependencyProperty SelectedCodeProperty =
        DependencyProperty.Register(
            nameof(SelectedCode),
            typeof(string),
            typeof(SearchableCodePicker),
            new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnSelectedCodeChanged));

    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register(
            nameof(ItemsSource),
            typeof(IEnumerable),
            typeof(SearchableCodePicker),
            new PropertyMetadata(null, OnItemsSourceChanged));

    private List<BomCatalogItem> _all = new();
    private bool _suspendTextChanged;
    private INotifyCollectionChanged? _watched;

    public string SelectedCode
    {
        get => (string)GetValue(SelectedCodeProperty);
        set => SetValue(SelectedCodeProperty, value);
    }

    public IEnumerable? ItemsSource
    {
        get => (IEnumerable?)GetValue(ItemsSourceProperty);
        set => SetValue(ItemsSourceProperty, value);
    }

    public SearchableCodePicker()
    {
        InitializeComponent();
        Loaded += (_, _) => SyncTextFromSelectedCode();
        Unloaded += (_, _) =>
        {
            if (_watched != null)
            {
                _watched.CollectionChanged -= OnCatalogCollectionChanged;
                _watched = null;
            }
        };
    }

    private static void OnSelectedCodeChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is SearchableCodePicker p)
            p.SyncTextFromSelectedCode();
    }

    private static void OnItemsSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is not SearchableCodePicker p)
            return;

        if (p._watched != null)
        {
            p._watched.CollectionChanged -= p.OnCatalogCollectionChanged;
            p._watched = null;
        }

        if (e.NewValue is INotifyCollectionChanged ncc)
        {
            p._watched = ncc;
            ncc.CollectionChanged += p.OnCatalogCollectionChanged;
        }

        p.RebuildAll();
    }

    private void OnCatalogCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        RebuildAll();
    }

    private void RebuildAll()
    {
        _all = new List<BomCatalogItem>();
        if (ItemsSource != null)
        {
            foreach (var o in ItemsSource)
            {
                if (o is BomCatalogItem b)
                    _all.Add(b);
            }
        }

        ApplyFilter(Txt.Text);
    }

    private void SyncTextFromSelectedCode()
    {
        _suspendTextChanged = true;
        try
        {
            Txt.Text = SelectedCode ?? "";
        }
        finally
        {
            _suspendTextChanged = false;
        }
    }

    private void Txt_OnTextChanged(object sender, TextChangedEventArgs e)
    {
        if (_suspendTextChanged)
            return;

        SelectedCode = Txt.Text?.Trim() ?? "";
        ApplyFilter(Txt.Text);
        if (Lst.Items.Count > 0)
            Popup.IsOpen = true;
    }

    private void ApplyFilter(string? raw)
    {
        var term = (raw ?? "").Trim();
        if (_all.Count == 0)
        {
            Lst.ItemsSource = null;
            return;
        }

        if (term.Length == 0)
        {
            Lst.ItemsSource = _all.Take(2000).ToList();
            return;
        }

        var t = term;
        var filtered = _all
            .Where(x =>
                x.Code.Contains(t, StringComparison.OrdinalIgnoreCase) ||
                x.Name.Contains(t, StringComparison.OrdinalIgnoreCase) ||
                x.Categorie.Contains(t, StringComparison.OrdinalIgnoreCase))
            .Take(500)
            .ToList();

        Lst.ItemsSource = filtered;
    }

    private void Txt_OnGotFocus(object sender, RoutedEventArgs e)
    {
        ApplyFilter(Txt.Text);
        if (Lst.Items.Count > 0)
            Popup.IsOpen = true;
    }

    private void Txt_OnLostFocus(object sender, RoutedEventArgs e)
    {
        Dispatcher.BeginInvoke(new Action(() =>
        {
            if (!Popup.IsKeyboardFocusWithin && !Txt.IsKeyboardFocused)
                Popup.IsOpen = false;
        }), DispatcherPriority.ApplicationIdle);
    }

    private void Txt_OnPreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Down && Lst.Items.Count > 0)
        {
            Lst.Focus();
            Lst.SelectedIndex = 0;
            e.Handled = true;
        }
    }

    private void Lst_OnMouseUp(object sender, MouseButtonEventArgs e)
    {
        if (Lst.SelectedItem is BomCatalogItem item)
        {
            _suspendTextChanged = true;
            try
            {
                Txt.Text = item.Code;
                SelectedCode = item.Code;
            }
            finally
            {
                _suspendTextChanged = false;
            }

            Popup.IsOpen = false;
        }
    }

    private void Lst_OnKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && Lst.SelectedItem is BomCatalogItem item)
        {
            _suspendTextChanged = true;
            try
            {
                Txt.Text = item.Code;
                SelectedCode = item.Code;
            }
            finally
            {
                _suspendTextChanged = false;
            }

            Popup.IsOpen = false;
            Txt.Focus();
            e.Handled = true;
        }

        if (e.Key == Key.Escape)
        {
            Popup.IsOpen = false;
            Txt.Focus();
            e.Handled = true;
        }
    }
}

using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SMARTPUB.Views.Controls;

public partial class CircularProgressRing : UserControl
{
    public static readonly DependencyProperty PercentProperty =
        DependencyProperty.Register(
            nameof(Percent),
            typeof(double),
            typeof(CircularProgressRing),
            new PropertyMetadata(0d, OnPercentChanged));

    public double Percent
    {
        get => (double)GetValue(PercentProperty);
        set => SetValue(PercentProperty, value);
    }

    public CircularProgressRing()
    {
        InitializeComponent();
        Loaded += (_, _) => UpdateArc();
    }

    private static void OnPercentChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is CircularProgressRing ring)
            ring.UpdateArc();
    }

    private void UpdateArc()
    {
        const double cx = 60;
        const double cy = 60;
        const double r = 48;
        var sweep = Math.Max(0, Math.Min(100, Percent)) / 100.0 * 360.0;
        if (sweep <= 0.01)
        {
            ArcPath.Data = Geometry.Empty;
            return;
        }

        var startDeg = -90d;
        var endDeg = startDeg + sweep;
        var startRad = startDeg * Math.PI / 180;
        var endRad = endDeg * Math.PI / 180;

        var x1 = cx + r * Math.Cos(startRad);
        var y1 = cy + r * Math.Sin(startRad);
        var x2 = cx + r * Math.Cos(endRad);
        var y2 = cy + r * Math.Sin(endRad);

        var fig = new PathFigure { StartPoint = new Point(x1, y1), IsClosed = false };
        fig.Segments.Add(new ArcSegment
        {
            Point = new Point(x2, y2),
            Size = new Size(r, r),
            IsLargeArc = sweep > 180,
            SweepDirection = SweepDirection.Clockwise,
            RotationAngle = 0
        });

        ArcPath.Data = new PathGeometry { Figures = { fig } };
    }
}

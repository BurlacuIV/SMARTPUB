using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace SMARTPUB.Views.Converters;

public sealed class LineKindMatchToVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        short kind;
        try
        {
            kind = System.Convert.ToInt16(value, culture);
        }
        catch
        {
            return Visibility.Collapsed;
        }

        var want = parameter?.ToString() == "1" ? (short)1 : (short)0;
        return kind == want ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}

using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Views;

public partial class SyncedProductsPage : Page
{
    private readonly SyncedProductsRepository _repo = new();
    private readonly SagaSyncSettingsRepository _sagaSettings = new();
    private readonly SagaWorkerClient _sagaWorker = new();
    private readonly SagaSyncImportService _sagaImporter = new();
    private List<SyncedProductRow> _allRows = new();
    private bool _suspendDestSave;

    public SyncedProductsPage()
    {
        InitializeComponent();
        Loaded += async (_, _) => await LoadProductsAsync();
    }

    private void BtnReload_Click(object sender, RoutedEventArgs e)
    {
        LoadProducts();
    }

    private void BtnAddArticle_Click(object sender, RoutedEventArgs e)
    {
        var owner = Window.GetWindow(this);
        var dlg = new AddArticleDialog { Owner = owner };
        if (dlg.ShowDialog() == true)
            LoadProducts();
    }

    private async void BtnSyncArticles_Click(object sender, RoutedEventArgs e)
    {
        SagaSyncSettingsData settings;
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            settings = _sagaSettings.LoadData(conn);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Nu am putut citi setările SAGA.\n" + ex.Message, "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var company = settings.Company;
        if (company == null || string.IsNullOrWhiteSpace(company.DatabasePath))
        {
            MessageBox.Show(
                "Nu este salvată firma SAGA. Configurează/scanează firma SAGA înainte de sincronizare.",
                "SMARTPUB",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
            return;
        }

        // Păstrăm sincronizarea veche: local/embedded, fără IP/port SERVER.
        var sagaRoot = ResolveLocalSagaRoot(settings);
        if (string.IsNullOrWhiteSpace(sagaRoot) || !Directory.Exists(sagaRoot))
        {
            MessageBox.Show("Calea SAGA locală nu este validă. Selectați/scanați folderul local SAGA.",
                "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var listRes = await Task.Run(() => _sagaWorker.ListArticles(
            company.DatabasePath,
            sagaRoot,
            SagaConnectionMode.Embedded));

        if (!listRes.Success)
        {
            MessageBox.Show("Nu am putut citi articolele din SAGA.\n" + (listRes.Error ?? "Eroare necunoscută."),
                "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var typesDlg = new SagaSyncTypesDialog(listRes.Articles) { Owner = Window.GetWindow(this) };
        if (typesDlg.ShowDialog() != true)
            return;

        var includeDenTip = typesDlg.SelectedDenTip;

        SetSyncBusy(true);
        ShowSyncOverlay(true);
        try
        {
            await SetSyncProgressAsync(2, "Pornire sincronizare...");
            var exportProgress = new Progress<SagaWorkerProgress>(p =>
            {
                var mapped = 5 + (int)Math.Round(Math.Clamp(p.Percent, 0, 100) * 0.73, MidpointRounding.AwayFromZero);
                SetSyncProgress(mapped, p.Message);
            });

            var export = await Task.Run(() => _sagaWorker.Export(
                company.DatabasePath,
                sagaRoot,
                SagaConnectionMode.Embedded,
                includeDenTip: includeDenTip,
                progress: exportProgress));

            if (!export.Success || export.Sync == null)
            {
                MessageBox.Show("Export SAGA eșuat.\n" + (export.Error ?? "Eroare necunoscută."),
                    "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            await SetSyncProgressAsync(80, "Import în SMARTPUB.FDB...");
            (int Gestiuni, int Articole, int Retete, int ReteteDet, int RecipeLines, int Clienti) counts = default;
            await Task.Run(() =>
            {
                using var conn = SmartPubDb.OpenEmbedded();
                SagaSettingsSchema.EnsureSchema(conn);
                _sagaImporter.EnsureSchema(conn);
                counts = _sagaImporter.UpsertAll(conn, export.Sync);
            });

            WaiterProductCatalogCache.Instance.Invalidate();
            WaiterProductCatalogCache.Instance.PreloadAsync();

            await SetSyncProgressAsync(92, "Reîncarcă lista de articole...");
            await LoadProductsAsync();
            await SetSyncProgressAsync(100, "Sincronizare completă.");
            await Task.Delay(300);

            TxtFooter.Text =
                $"Sincronizare finalizată: {counts.Articole:N0} articole, {counts.Gestiuni:N0} gestiuni, {counts.Clienti:N0} clienți.";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Sincronizare articole eșuată.\n" + ex.Message, "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            ShowSyncOverlay(false);
            SetSyncBusy(false);
        }
    }

    private async Task LoadProductsAsync()
    {
        TxtFooter.Text = "Se încarcă articolele...";
        try
        {
            var rows = await Task.Run(() =>
            {
                using var conn = SmartPubDb.OpenEmbedded();
                return _repo.GetAll(conn);
            }).ConfigureAwait(true);

            _allRows = rows;
            UpdateSummaryCards();
            ApplyProductFilter();

            if (_allRows.Count > 0)
                GridProducts.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            TxtFooter.Text = "Eroare la încărcare articole sincronizate";
            MessageBox.Show(
                "Nu am putut încărca articolele sincronizate.\n" + ex.Message,
                "SMARTPUB",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private void LoadProducts() => _ = LoadProductsAsync();

    private static string ResolveLocalSagaRoot(SagaSyncSettingsData settings)
    {
        var candidates = new[]
        {
            (settings.SagaRootPath ?? "").Trim(),
            (settings.ServerSagaRoot ?? "").Trim(),
            @"C:\SAGA C.3.0"
        };

        foreach (var path in candidates)
        {
            if (string.IsNullOrWhiteSpace(path))
                continue;

            var root = path.EndsWith("CONFIG.FDB", StringComparison.OrdinalIgnoreCase)
                ? Path.GetDirectoryName(path) ?? ""
                : path;
            if (Directory.Exists(root) && File.Exists(Path.Combine(root, "CONFIG.FDB")))
                return root;
        }

        return candidates.FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "";
    }

    private void SetSyncBusy(bool busy)
    {
        BtnSyncArticles.IsEnabled = !busy;
        BtnReload.IsEnabled = !busy;
        TxtSearch.IsEnabled = !busy;
    }

    private void ShowSyncOverlay(bool visible)
    {
        SyncOverlay.Visibility = visible ? Visibility.Visible : Visibility.Collapsed;
        if (!visible)
        {
            SyncProgressRing.Percent = 0;
            TxtSyncPercent.Text = "0%";
            TxtSyncStep.Text = "";
        }
    }

    private async Task SetSyncProgressAsync(int percent, string step)
    {
        percent = Math.Clamp(percent, 0, 100);
        await Dispatcher.InvokeAsync(() =>
        {
            SetSyncProgress(percent, step);
        });
        await Task.Delay(30);
    }

    private void SetSyncProgress(int percent, string step)
    {
        percent = Math.Clamp(percent, 0, 100);
        if (percent < SyncProgressRing.Percent)
            percent = (int)SyncProgressRing.Percent;
        SyncProgressRing.Percent = percent;
        TxtSyncPercent.Text = $"{percent}%";
        TxtSyncStep.Text = step;
    }

    private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
        ApplyProductFilter();
    }

    private void ApplyProductFilter()
    {
        var term = (TxtSearch.Text ?? string.Empty).Trim();
        IEnumerable<SyncedProductRow> rows = _allRows;

        if (!string.IsNullOrWhiteSpace(term))
        {
            rows = rows.Where(x =>
                x.Code.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                x.Name.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                x.DenTip.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                x.GrupaAfisat.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                x.GestiuneAfisat.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                x.CodBare.Contains(term, StringComparison.OrdinalIgnoreCase));
        }

        var filtered = rows.ToList();
        _suspendDestSave = true;
        GridProducts.ItemsSource = filtered;
        Dispatcher.BeginInvoke(new Action(() => _suspendDestSave = false),
            System.Windows.Threading.DispatcherPriority.Background);
        TxtFooter.Text = $"{filtered.Count} din {_allRows.Count} articole afișate";
    }

    private void DestCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suspendDestSave)
            return;
        if (sender is not ComboBox cb || cb.DataContext is not SyncedProductRow row)
            return;

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            _repo.SetDestinationOverride(conn, row.Code, row.Destinatie);
            var map = new OrderRoutingRepository().LoadGroupMap(conn);
            row.DestinatieEfectiva = OrderRoutingRepository.Resolve(map, row.Destinatie, row.Grupa);
            WaiterProductCatalogCache.Instance.Invalidate();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Nu am putut salva destinația.\n" + ex.Message, "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void UpdateSummaryCards()
    {
        TxtTotalArticole.Text = _allRows.Count.ToString("N0");
        TxtTotalCategorii.Text = _allRows
            .Select(x => string.IsNullOrWhiteSpace(x.GrupaAfisat) ? x.Categorie : x.GrupaAfisat)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Count()
            .ToString("N0");
        TxtTotalGestiuni.Text = _allRows
            .Select(x => string.IsNullOrWhiteSpace(x.GestiuneAfisat) ? x.Gestiune : x.GestiuneAfisat)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Count()
            .ToString("N0");
        TxtTotalTva11.Text = CountByTva(11m).ToString("N0");
        TxtTotalTva21.Text = CountByTva(21m).ToString("N0");
    }

    private int CountByTva(decimal tva) =>
        _allRows.Count(x => Math.Abs(x.Tva - tva) < 0.01m);

    private void BtnRecipeRow_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button btn || btn.DataContext is not SyncedProductRow row)
            return;

        e.Handled = true;
        GridProducts.SelectedItem = row;
        OpenRecipe(row);
    }

    private void GridProducts_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (GridProducts.SelectedItem is not SyncedProductRow selected)
            return;

        OpenRecipe(selected);
    }

    private void OpenRecipe(SyncedProductRow selected)
    {
        var owner = Window.GetWindow(this);
        if (owner == null)
            return;

        owner.Dispatcher.BeginInvoke(DispatcherPriority.Input, () =>
        {
            try
            {
                try
                {
                    GridProducts.CommitEdit(DataGridEditingUnit.Cell, true);
                }
                catch
                {
                    /* */
                }

                try
                {
                    GridProducts.CommitEdit(DataGridEditingUnit.Row, true);
                }
                catch
                {
                    /* */
                }

                var dlg = new RecipeWindow(selected) { Owner = owner };
                dlg.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    owner,
                    "Nu am putut deschide fereastra cu rețeta.\n" + ex.Message,
                    "SMARTPUB",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        });
    }
}

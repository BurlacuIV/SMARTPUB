using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Views;

public partial class WaiterOperatorsConfigPage : Page
{
    private readonly ObservableCollection<PosOperatorRow> _rows = new();
    private readonly Dictionary<string, CheckBox> _rightsCheckBoxes = new(StringComparer.OrdinalIgnoreCase);
    private PosOperatorDetail? _loadedDetail;
    private string? _selectedId;
    private string? _pinWhenLoaded;
    private readonly Style? _checkListCheckBoxStyle;
    private readonly Style? _rightsExpanderStyle;
    private RadioButton? _rbStartupN;
    private RadioButton? _rbStartupR;
    private RadioButton? _rbStartupD;
    private CheckBox? _chkCloseApp;
    private CheckBox? _chkRightsAllTables;
    private bool _syncingAccessAllTables;

    private sealed record RoleItem(string Label, string Code);

    public WaiterOperatorsConfigPage()
    {
        InitializeComponent();
        _checkListCheckBoxStyle = TryFindResource("OperatorCheckListCheckBox") as Style;
        _rightsExpanderStyle = TryFindResource("RightsExpanderStyle") as Style;
        GridOps.ItemsSource = _rows;
        CbRole.ItemsSource = new[]
        {
            new RoleItem("Administrator", "Administrator"),
            new RoleItem("Șef de tură", "ShiftLead"),
            new RoleItem("Ospătar", "Waiter"),
            new RoleItem("Personalizat", "Custom")
        };
        CbRole.DisplayMemberPath = "Label";
        CbRole.SelectedValuePath = "Code";
        CbRole.SelectionChanged += CbRole_OnSelectionChanged;
        ChkAllTables.Checked += OnGeneralAccessAllTablesChanged;
        ChkAllTables.Unchecked += OnGeneralAccessAllTablesChanged;
        Loaded += (_, _) => ReloadGrid();
    }

    private void CbRole_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        var role = CbRole.SelectedValue?.ToString() ?? "";
        if (role is "Administrator" or "ShiftLead")
            ChkAllTables.IsChecked = true;
    }

    private void OnGeneralAccessAllTablesChanged(object sender, RoutedEventArgs e)
    {
        if (_syncingAccessAllTables || _chkRightsAllTables == null)
            return;
        _syncingAccessAllTables = true;
        try
        {
            _chkRightsAllTables.IsChecked = ChkAllTables.IsChecked;
        }
        finally
        {
            _syncingAccessAllTables = false;
        }
    }

    private void OnRightsAccessAllTablesChanged(object sender, RoutedEventArgs e)
    {
        if (_syncingAccessAllTables)
            return;
        _syncingAccessAllTables = true;
        try
        {
            ChkAllTables.IsChecked = _chkRightsAllTables?.IsChecked == true;
        }
        finally
        {
            _syncingAccessAllTables = false;
        }
    }

    private void ReloadGrid()
    {
        _rows.Clear();
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchema(conn);
            foreach (var r in PosOperatorRepository.ListAll(conn))
                _rows.Add(r);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        ClearDetailPanel();
    }

    private void ClearDetailPanel()
    {
        _selectedId = null;
        _loadedDetail = null;
        _pinWhenLoaded = null;
        TxtUser.Text = "";
        TxtName.Text = "";
        CbRole.SelectedValue = null;
        ChkActive.IsChecked = true;
        ChkAllTables.IsChecked = true;
        TxtBuletin.Text = "";
        PwdNew.Password = "";
        PwdRepeat.Password = "";
        TxtCard.Text = "";
        TxtPinHint.Text = "PIN obligatoriu pentru conturi active. Lăsați gol doar dacă nu schimbați PIN-ul existent.";
        _rightsCheckBoxes.Clear();
        _rbStartupN = _rbStartupR = _rbStartupD = null;
        _chkCloseApp = _chkRightsAllTables = null;
        PanelRights.Children.Clear();
        PanelTables.Children.Clear();
        PanelGest.Children.Clear();
        PanelGrup.Children.Clear();
    }

    private void GridOps_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (GridOps.SelectedItem is not PosOperatorRow row || string.IsNullOrWhiteSpace(row.Id))
        {
            ClearDetailPanel();
            return;
        }

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            PosOperationalSchema.EnsureSchema(conn);
            var d = PosOperatorRepository.LoadDetail(conn, row.Id);
            _loadedDetail = d;
            _selectedId = row.Id;
            _pinWhenLoaded = d.Operator.PasswordPin;
            PushDetailToUi(d);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void PushDetailToUi(PosOperatorDetail d)
    {
        var o = d.Operator;
        TxtUser.Text = o.Username;
        TxtName.Text = o.DisplayName;
        CbRole.SelectedValue = o.Role;
        ChkActive.IsChecked = o.Active;
        ChkAllTables.IsChecked = o.AccessAllTables;
        TxtBuletin.Text = o.Buletin ?? "";
        PwdNew.Password = "";
        PwdRepeat.Password = "";
        TxtPinHint.Text = string.IsNullOrWhiteSpace(o.PasswordPin)
            ? "Acest cont nu are PIN. Setați PIN unic înainte de folosirea login-ului."
            : "PIN setat. Completați câmpurile doar dacă doriți să îl schimbați.";
        TxtCard.Text = o.CardBarcode ?? "";

        BuildRightsPanel(d);

        PanelTables.Children.Clear();
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            var (levels, _, tables) = new FloorPlanRepository().Load(conn);
            foreach (var t in tables.OrderBy(x => x.Name))
            {
                var lvl = levels.FirstOrDefault(l => l.Id == t.LevelId)?.Name ?? "";
                var cb = new CheckBox
                {
                    Content = string.IsNullOrWhiteSpace(lvl) ? t.Name : $"{t.Name}  ({lvl})",
                    Tag = t.Id,
                    IsChecked = d.AllowedTableIds.Contains(t.Id),
                    Style = _checkListCheckBoxStyle
                };
                PanelTables.Children.Add(cb);
            }
        }
        catch
        {
            PanelTables.Children.Add(new TextBlock { Text = "Nu s-a putut încărca planul meselor." });
        }

        PanelGest.Children.Clear();
        PanelGrup.Children.Clear();
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            foreach (var g in PosOperatorRepository.ListDistinctGestiuni(conn))
            {
                var cb = new CheckBox
                {
                    Content = g,
                    Tag = g,
                    IsChecked = d.BlockedGestiuni.Contains(g),
                    Style = _checkListCheckBoxStyle
                };
                PanelGest.Children.Add(cb);
            }

            foreach (var g in PosOperatorRepository.ListDistinctGrupe(conn))
            {
                var cb = new CheckBox
                {
                    Content = g,
                    Tag = g,
                    IsChecked = d.BlockedGrupe.Contains(g),
                    Style = _checkListCheckBoxStyle
                };
                PanelGrup.Children.Add(cb);
            }
        }
        catch
        {
            /* ignore */
        }
    }

    private void BuildRightsPanel(PosOperatorDetail d)
    {
        PanelRights.Children.Clear();
        _rightsCheckBoxes.Clear();
        _rbStartupN = _rbStartupR = _rbStartupD = null;
        _chkCloseApp = _chkRightsAllTables = null;

        var root = new StackPanel();
        var dangerBrush = TryFindResource("DangerBrush") as Brush
                          ?? new SolidColorBrush(Color.FromRgb(0xC9, 0x4A, 0x4A));
        var normalBrush = TryFindResource("TextPrimaryBrush") as Brush ?? Brushes.Black;

        root.Children.Add(new TextBlock
        {
            Text = "Drepturi SMARTPUB",
            FontSize = 18,
            FontWeight = FontWeights.SemiBold,
            Foreground = normalBrush,
            Margin = new Thickness(0, 0, 0, 14)
        });

        root.Children.Add(new TextBlock
        {
            Text = "La pornire programului",
            FontSize = 12,
            Foreground = TryFindResource("TextSecondaryBrush") as Brush ?? Brushes.Gray,
            Margin = new Thickness(0, 0, 0, 8)
        });

        var startup = PosOperatorRightsCatalog.ResolveStartupMode(d.GrantedRights);
        foreach (var (code, label) in PosOperatorRightsCatalog.StartupOptions)
        {
            var rb = new RadioButton
            {
                Content = label,
                Tag = code,
                GroupName = "SmartPubStartup",
                Margin = new Thickness(4, 0, 0, 8),
                FontSize = 13,
                Cursor = System.Windows.Input.Cursors.Hand
            };
            rb.IsChecked = string.Equals(code, startup, StringComparison.OrdinalIgnoreCase);
            if (string.Equals(code, PosOperatorRightsCatalog.StartupNormal, StringComparison.OrdinalIgnoreCase))
                _rbStartupN = rb;
            else if (string.Equals(code, PosOperatorRightsCatalog.StartupRestaurant, StringComparison.OrdinalIgnoreCase))
                _rbStartupR = rb;
            else if (string.Equals(code, PosOperatorRightsCatalog.StartupDelivery, StringComparison.OrdinalIgnoreCase))
                _rbStartupD = rb;
            root.Children.Add(rb);
        }

        _chkCloseApp = new CheckBox
        {
            Content = "Poate închide aplicația",
            IsChecked = d.GrantedRights.Contains(PosOperatorRightsCatalog.InchideAplicatie),
            Margin = new Thickness(0, 6, 0, 16),
            FontSize = 13,
            Style = _checkListCheckBoxStyle,
            Cursor = System.Windows.Input.Cursors.Hand
        };
        root.Children.Add(_chkCloseApp);

        foreach (var section in PosOperatorRightsCatalog.Sections)
        {
            var inner = new StackPanel { Margin = new Thickness(4, 4, 0, 0) };
            inner.SetValue(TextElement.FontWeightProperty, FontWeights.Normal);
            inner.SetValue(TextElement.FontSizeProperty, 13.0);

            foreach (var item in section.Items)
            {
                var cb = CreateRightItemCheckBox(item, d, dangerBrush, normalBrush);
                inner.Children.Add(cb);
            }

            var exp = new Expander
            {
                Header = section.Title,
                Content = inner,
                IsExpanded = section.StartsExpanded,
                Style = _rightsExpanderStyle
            };
            root.Children.Add(exp);
        }

        PanelRights.Children.Add(root);
    }

    private CheckBox CreateRightItemCheckBox(
        PosOperatorRightsCatalog.RightItem item,
        PosOperatorDetail d,
        Brush dangerBrush,
        Brush normalBrush)
    {
        var label = new TextBlock
        {
            Text = item.Label,
            TextWrapping = TextWrapping.Wrap,
            Foreground = item.Emphasize ? dangerBrush : normalBrush,
            FontWeight = item.Emphasize ? FontWeights.SemiBold : FontWeights.Normal
        };

        var cb = new CheckBox
        {
            Content = label,
            Style = _checkListCheckBoxStyle,
            Cursor = System.Windows.Input.Cursors.Hand
        };

        if (item.MirrorsAccessAllTables)
        {
            cb.IsChecked = d.Operator.AccessAllTables;
            _chkRightsAllTables = cb;
            cb.Checked += OnRightsAccessAllTablesChanged;
            cb.Unchecked += OnRightsAccessAllTablesChanged;
        }
        else
        {
            cb.IsChecked = d.GrantedRights.Contains(item.Code);
            _rightsCheckBoxes[item.Code] = cb;
        }

        return cb;
    }

    private PosOperatorDetail? ReadDetailFromUi()
    {
        if (string.IsNullOrWhiteSpace(_selectedId) || _loadedDetail == null)
            return null;

        var o = _loadedDetail.Operator;
        o.Username = TxtUser.Text.Trim();
        o.DisplayName = TxtName.Text.Trim();
        o.Role = CbRole.SelectedValue?.ToString() ?? "Waiter";
        o.Active = ChkActive.IsChecked == true;
        o.AccessAllTables = ChkAllTables.IsChecked == true;
        o.Buletin = string.IsNullOrWhiteSpace(TxtBuletin.Text) ? null : TxtBuletin.Text.Trim();
        o.CardBarcode = string.IsNullOrWhiteSpace(TxtCard.Text) ? null : TxtCard.Text.Trim();

        var pn = PwdNew.Password;
        var pr = PwdRepeat.Password;
        if (!string.IsNullOrEmpty(pn) || !string.IsNullOrEmpty(pr))
        {
            if (!string.Equals(pn, pr, StringComparison.Ordinal))
            {
                MessageBox.Show("PIN-ul și repetarea nu coincid.", "SMARTPUB",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return null;
            }

            if (!IsValidPin(pn))
            {
                MessageBox.Show("PIN-ul trebuie să conțină doar cifre și să aibă între 4 și 12 caractere.", "SMARTPUB",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return null;
            }

            o.PasswordPin = string.IsNullOrEmpty(pn) ? null : pn;
        }
        else
            o.PasswordPin = _pinWhenLoaded;

        var rights = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var kv in _rightsCheckBoxes)
        {
            if (kv.Value.IsChecked == true)
                rights.Add(kv.Key);
        }

        if (_chkCloseApp?.IsChecked == true)
            rights.Add(PosOperatorRightsCatalog.InchideAplicatie);

        var startup = PosOperatorRightsCatalog.StartupNormal;
        if (_rbStartupD?.IsChecked == true)
            startup = PosOperatorRightsCatalog.StartupDelivery;
        else if (_rbStartupR?.IsChecked == true)
            startup = PosOperatorRightsCatalog.StartupRestaurant;
        PosOperatorRightsCatalog.SetStartupMode(rights, startup);

        var tables = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var child in PanelTables.Children)
        {
            if (child is CheckBox { IsChecked: true, Tag: string tid })
                tables.Add(tid);
        }

        var blockedG = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var child in PanelGest.Children)
        {
            if (child is CheckBox { IsChecked: true, Tag: string gc })
                blockedG.Add(gc);
        }

        var blockedR = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var child in PanelGrup.Children)
        {
            if (child is CheckBox { IsChecked: true, Tag: string gr })
                blockedR.Add(gr);
        }

        return new PosOperatorDetail
        {
            Operator = o,
            GrantedRights = rights,
            AllowedTableIds = tables,
            BlockedGestiuni = blockedG,
            BlockedGrupe = blockedR
        };
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        var d = ReadDetailFromUi();
        if (d == null)
        {
            if (string.IsNullOrWhiteSpace(_selectedId))
                MessageBox.Show("Selectați un operator sau adăugați unul nou.", "SMARTPUB",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (string.IsNullOrWhiteSpace(d.Operator.Username) || string.IsNullOrWhiteSpace(d.Operator.DisplayName))
        {
            MessageBox.Show("Completați utilizator și nume.", "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchema(conn);
            if (d.Operator.Active && string.IsNullOrWhiteSpace(d.Operator.PasswordPin))
            {
                MessageBox.Show("Setați un PIN unic pentru operatorul activ. Login-ul SMARTPUB se face doar pe PIN.",
                    "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Warning);
                TabsDetail.SelectedIndex = 0;
                PwdNew.Focus();
                return;
            }

            if (PosOperatorRepository.IsPinUsedByOther(conn, d.Operator.PasswordPin, d.Operator.Id))
            {
                MessageBox.Show("PIN-ul este deja folosit de alt operator. Fiecare cont trebuie să aibă PIN unic.",
                    "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Warning);
                TabsDetail.SelectedIndex = 0;
                PwdNew.Focus();
                return;
            }

            if ((!d.Operator.Active || !PosOperatorRepository.IsAdministratorRole(d.Operator.Role)) &&
                PosOperatorRepository.CountActiveAdministrators(conn, d.Operator.Id) == 0)
            {
                MessageBox.Show("Nu puteți dezactiva sau schimba ultimul administrator activ.",
                    "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            PosOperatorRepository.SaveDetail(conn, d);
            _pinWhenLoaded = d.Operator.PasswordPin;
            PwdNew.Password = "";
            PwdRepeat.Password = "";
            ReloadGrid();
            var sel = _rows.FirstOrDefault(x => x.Id == d.Operator.Id);
            if (sel != null)
                GridOps.SelectedItem = sel;
            MessageBox.Show("Salvat.", "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BtnRevert_Click(object sender, RoutedEventArgs e)
    {
        if (GridOps.SelectedItem is PosOperatorRow row && !string.IsNullOrWhiteSpace(row.Id))
        {
            try
            {
                using var conn = SmartPubDb.OpenEmbedded();
                var d = PosOperatorRepository.LoadDetail(conn, row.Id);
                _loadedDetail = d;
                _pinWhenLoaded = d.Operator.PasswordPin;
                PushDetailToUi(d);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        else
            ClearDetailPanel();
    }

    private void BtnAddWaiter_Click(object sender, RoutedEventArgs e) =>
        CreateOperatorDraft("Waiter", "Ospătar nou", accessAllTables: false);

    private void BtnAddShiftLead_Click(object sender, RoutedEventArgs e) =>
        CreateOperatorDraft("ShiftLead", "Șef sală nou", accessAllTables: true);

    private void BtnAddAdmin_Click(object sender, RoutedEventArgs e) =>
        CreateOperatorDraft("Administrator", "Administrator nou", accessAllTables: true);

    private void CreateOperatorDraft(string role, string displayName, bool accessAllTables)
    {
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchema(conn);
            var row = new PosOperatorRow
            {
                Username = GenerateUsername(role),
                DisplayName = displayName,
                Role = role,
                Active = true,
                AccessAllTables = accessAllTables
            };
            PosOperatorRepository.Insert(conn, row);
            ReloadGrid();
            var sel = _rows.FirstOrDefault(x => x.Id == row.Id);
            if (sel != null)
            {
                GridOps.SelectedItem = sel;
                TabsDetail.SelectedIndex = 0;
                PwdNew.Focus();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        if (GridOps.SelectedItem is not PosOperatorRow row || string.IsNullOrWhiteSpace(row.Id))
        {
            MessageBox.Show("Selectați un operator.", "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (MessageBox.Show($"Ștergeți operatorul „{row.DisplayName}”?", "Confirmare",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchema(conn);
            if (PosOperatorRepository.IsAdministratorRole(row.Role) &&
                PosOperatorRepository.CountActiveAdministrators(conn, row.Id) == 0)
            {
                MessageBox.Show("Nu puteți șterge ultimul administrator activ.", "SMARTPUB",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            PosOperatorRepository.DeleteOperator(conn, row.Id);
            ReloadGrid();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private static bool IsValidPin(string pin) =>
        pin.Length is >= 4 and <= 12 && pin.All(char.IsDigit);

    private static string GenerateUsername(string role)
    {
        var prefix = role switch
        {
            "Administrator" => "admin",
            "ShiftLead" => "sef",
            _ => "osp"
        };
        return $"{prefix}_{DateTime.Now:HHmmssfff}";
    }
}

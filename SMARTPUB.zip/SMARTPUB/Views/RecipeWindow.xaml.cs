using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.ComponentModel;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Views;

public partial class RecipeWindow : Window
{
    private readonly SyncedProductRow _product;
    private readonly SyncedProductsRepository _repo = new();
    private ObservableCollection<SyncedRecipeLineRow> _mainLines = new();
    /// <summary>
    /// Liniile ART_ANTE ascunse când există și ART_A_DET pentru același articol (model mixt).
    /// În SAGA C.3 rețeta poate fi doar în ART_ANTE — atunci liniile se afișează în grilă (fără păstrare separată).
    /// </summary>
    private List<SyncedRecipeLineRow> _preservedAnteLines = new();
    private ICollectionView? _mainView;
    private bool _dirty;
    private bool _suppressDirty = true;
    private decimal _cantRaport = 1m;

    public RecipeWindow(SyncedProductRow product)
    {
        InitializeComponent();
        _product = product;
        TxtProductName.Text = product.Name;
        TxtProductCode.Text = product.Code;
        Loaded += RecipeWindow_OnFirstLoaded;
    }

    private void RecipeWindow_OnFirstLoaded(object sender, RoutedEventArgs e)
    {
        Loaded -= RecipeWindow_OnFirstLoaded;
        try
        {
            LoadMainGrid();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this,
                "Nu am putut încărca liniile rețetei.\n" + ex.Message,
                "Rețetă de producție",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }
        finally
        {
            _suppressDirty = false;
        }
    }

    private void CommitRecipeGridEdits()
    {
        try
        {
            GridMain.CommitEdit(DataGridEditingUnit.Cell, true);
        }
        catch
        {
            /* nu e edit activ */
        }

        try
        {
            GridMain.CommitEdit(DataGridEditingUnit.Row, true);
        }
        catch
        {
            /* nu e rând nou */
        }
    }

    /// <summary>
    /// ICollectionView.Refresh / grilă: nu e permis în timpul tranzacției AddNew/EditItem a DataGrid-ului.
    /// </summary>
    private void RefreshRecipeFilterView()
    {
        if (_mainView == null)
            return;

        void DoRefresh(int attempt)
        {
            CommitRecipeGridEdits();
            try
            {
                _mainView?.Refresh();
            }
            catch (InvalidOperationException)
            {
                if (attempt < 1)
                    Dispatcher.BeginInvoke(DispatcherPriority.Loaded, () => DoRefresh(attempt + 1));
            }
        }

        DoRefresh(0);
    }

    private void LoadMainGrid()
    {
        using var conn = SmartPubDb.OpenEmbedded();
        var fromRecipe = _repo.GetRecipeLines(conn, _product.Code);
        var hasArtADet = fromRecipe.Exists(l =>
            string.Equals(l.SourceTable, "ART_A_DET", StringComparison.OrdinalIgnoreCase));

        List<SyncedRecipeLineRow> body;
        if (hasArtADet)
        {
            _preservedAnteLines = fromRecipe
                .Where(l => string.Equals(l.SourceTable, "ART_ANTE", StringComparison.OrdinalIgnoreCase))
                .ToList();
            body = fromRecipe
                .Where(l => !string.Equals(l.SourceTable, "ART_ANTE", StringComparison.OrdinalIgnoreCase))
                .ToList();
        }
        else
        {
            _preservedAnteLines = new List<SyncedRecipeLineRow>();
            body = fromRecipe.ToList();
            foreach (var row in body)
            {
                if (!string.Equals(row.SourceTable, "ART_ANTE", StringComparison.OrdinalIgnoreCase))
                    continue;
                if (!string.IsNullOrWhiteSpace(row.ComponentCode))
                    continue;
                var op = (row.Operatie ?? "").Trim();
                if (op.Length > 0 && !string.Equals(op, "-", StringComparison.OrdinalIgnoreCase))
                    row.ComponentCode = op;
            }
        }

        if (body.Count == 0)
            body = _repo.GetReteteDetLines(conn, _product.Code);

        _cantRaport = _repo.GetRecipeCantRaportare(conn, _product.Code);
        TxtCantitateRaportare.Text = _cantRaport.ToString("N3", CultureInfo.CurrentCulture);

        _mainLines = new ObservableCollection<SyncedRecipeLineRow>(body);
        _mainLines.CollectionChanged -= MainLines_CollectionChanged;
        _mainLines.CollectionChanged += MainLines_CollectionChanged;
        _mainView = CollectionViewSource.GetDefaultView(_mainLines);
        _mainView.Filter = FilterMainLines;
        GridMain.ItemsSource = _mainView;
    }

    private void MainLines_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        MarkDirty();
    }

    private void MarkDirty()
    {
        if (!_suppressDirty)
            _dirty = true;
    }

    private bool FilterMainLines(object obj)
    {
        if (obj is not SyncedRecipeLineRow r)
            return false;
        var term = (TxtSearch.Text ?? string.Empty).Trim();
        if (string.IsNullOrEmpty(term))
            return true;
        return r.Tip.Contains(term, StringComparison.OrdinalIgnoreCase)
               || r.Gestiune.Contains(term, StringComparison.OrdinalIgnoreCase)
               || r.ComponentName.Contains(term, StringComparison.OrdinalIgnoreCase)
               || r.ComponentCode.Contains(term, StringComparison.OrdinalIgnoreCase)
               || r.Um.Contains(term, StringComparison.OrdinalIgnoreCase);
    }

    private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
        RefreshRecipeFilterView();
    }

    private void BtnSearchIcon_Click(object sender, RoutedEventArgs e)
    {
        RefreshRecipeFilterView();
    }

    private void TxtCantitateRaportare_LostFocus(object sender, RoutedEventArgs e)
    {
        var prev = _cantRaport;
        var t = TxtCantitateRaportare.Text.Trim().Replace(',', '.');
        if (decimal.TryParse(t, NumberStyles.Any, CultureInfo.InvariantCulture, out var v)
            || decimal.TryParse(TxtCantitateRaportare.Text.Trim(), NumberStyles.Any, CultureInfo.CurrentCulture, out v))
        {
            _cantRaport = v <= 0 ? 1m : v;
            TxtCantitateRaportare.Text = _cantRaport.ToString("N3", CultureInfo.CurrentCulture);
        }
        else
        {
            TxtCantitateRaportare.Text = _cantRaport.ToString("N3", CultureInfo.CurrentCulture);
        }

        if (prev != _cantRaport)
            MarkDirty();
    }

    private void BtnAdd_Click(object sender, RoutedEventArgs e)
    {
        var line = new SyncedRecipeLineRow
        {
            LineKey = Guid.NewGuid().ToString("N"),
            SourceTable = "MANUAL",
            Operatie = "",
            Tip = "",
            Gestiune = "",
            ComponentName = "",
            ComponentCode = "",
            Um = "",
            Quantity = 0
        };
        _mainLines.Add(line);
        GridMain.SelectedItem = line;
        GridMain.ScrollIntoView(line);
        RefreshRecipeFilterView();
    }

    private void BtnEdit_Click(object sender, RoutedEventArgs e)
    {
        if (GridMain.SelectedItem is not SyncedRecipeLineRow line)
        {
            MessageBox.Show(this, "Selectează o linie de modificat.", "Rețetă de producție",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var dlg = new RecipeLineEditDialog(line) { Owner = this };
        if (dlg.ShowDialog() == true)
        {
            MarkDirty();
            RefreshRecipeFilterView();
        }
    }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        if (GridMain.SelectedItem is not SyncedRecipeLineRow line)
        {
            MessageBox.Show(this, "Selectează o linie de șters.", "Rețetă de producție",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (MessageBox.Show(this, "Ștergi linia selectată?", "Confirmare",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;

        _mainLines.Remove(line);
        RefreshRecipeFilterView();
    }

    private void GridMain_CellEditEnding(object? sender, DataGridCellEditEndingEventArgs e)
    {
        if (e.EditAction == DataGridEditAction.Commit)
            MarkDirty();
    }

    private void GridMain_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        BtnEdit_Click(sender, e);
    }

    private void BtnExport_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new SaveFileDialog
        {
            Filter = "CSV (*.csv)|*.csv",
            FileName = $"reteta_{_product.Code}.csv"
        };
        if (dlg.ShowDialog() != true)
            return;

        var sb = new StringBuilder();
        sb.AppendLine("Tip;Gestiune;Denumire;Cod;UM;Cantitate;Sursa");
        foreach (SyncedRecipeLineRow r in _mainLines)
        {
            sb.AppendLine(string.Join(';',
                Csv(r.Tip), Csv(r.Gestiune), Csv(r.ComponentName), Csv(r.ComponentCode),
                Csv(r.Um), r.Quantity.ToString(CultureInfo.InvariantCulture), Csv(r.SourceTable)));
        }

        File.WriteAllText(dlg.FileName, sb.ToString(), new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));
        MessageBox.Show(this, "Export finalizat.", "Rețetă de producție", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private static string Csv(string? s)
    {
        s ??= "";
        if (s.Contains(';') || s.Contains('"') || s.Contains('\n'))
            return "\"" + s.Replace("\"", "\"\"") + "\"";
        return s;
    }

    private void BtnImport_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog { Filter = "CSV (*.csv)|*.csv" };
        if (dlg.ShowDialog() != true)
            return;

        if (MessageBox.Show(this,
                "Înlocuiește liniile curente cu conținutul fișierului?",
                "Import CSV",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;

        try
        {
            var text = File.ReadAllText(dlg.FileName);
            var lines = ParseCsvImport(text);
            _mainLines.Clear();
            foreach (var line in lines)
                _mainLines.Add(line);
            RefreshRecipeFilterView();
            MarkDirty();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Import eșuat:\n" + ex.Message, "Rețetă de producție",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private static List<SyncedRecipeLineRow> ParseCsvImport(string text)
    {
        var list = new List<SyncedRecipeLineRow>();
        var rows = text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
        var start = 0;
        if (rows.Length > 0 && rows[0].Contains("Tip", StringComparison.OrdinalIgnoreCase)
                             && rows[0].Contains("Gestiune", StringComparison.OrdinalIgnoreCase))
            start = 1;

        for (var i = start; i < rows.Length; i++)
        {
            var row = rows[i].Trim();
            if (string.IsNullOrEmpty(row))
                continue;
            var parts = SplitCsvLine(row);
            if (parts.Count < 6)
                continue;

            if (!decimal.TryParse(parts[5].Trim().Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out var qty)
                && !decimal.TryParse(parts[5].Trim(), NumberStyles.Any, CultureInfo.CurrentCulture, out qty))
                qty = 0;

            list.Add(new SyncedRecipeLineRow
            {
                LineKey = Guid.NewGuid().ToString("N"),
                SourceTable = parts.Count > 6 ? parts[6].Trim() : "IMPORT",
                Operatie = "-",
                Tip = parts[0].Trim(),
                Gestiune = parts[1].Trim(),
                ComponentName = parts[2].Trim(),
                ComponentCode = parts[3].Trim(),
                Um = parts[4].Trim(),
                Quantity = qty
            });
        }

        return list;
    }

    private static List<string> SplitCsvLine(string line)
    {
        var result = new List<string>();
        var cur = new StringBuilder();
        var inQ = false;
        for (var i = 0; i < line.Length; i++)
        {
            var c = line[i];
            if (inQ)
            {
                if (c == '"')
                {
                    if (i + 1 < line.Length && line[i + 1] == '"')
                    {
                        cur.Append('"');
                        i++;
                    }
                    else inQ = false;
                }
                else cur.Append(c);
            }
            else
            {
                if (c == ';')
                {
                    result.Add(cur.ToString());
                    cur.Clear();
                }
                else if (c == '"') inQ = true;
                else cur.Append(c);
            }
        }

        result.Add(cur.ToString());
        return result;
    }

    private void BtnToolbarPrint_Click(object sender, RoutedEventArgs e)
    {
        var printDlg = new PrintDialog();
        if (printDlg.ShowDialog() != true)
            return;

        var doc = new FlowDocument
        {
            PagePadding = new Thickness(40),
            ColumnWidth = double.PositiveInfinity,
            FontFamily = new FontFamily("Segoe UI"),
            FontSize = 11
        };

        AppendRecipeBlock(doc, _product.Code, _product.Name, _product.Um, _mainLines.ToList(), _cantRaport);
        printDlg.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, "Rețetă SMARTPUB");
    }

    private static void AppendRecipeBlock(
        FlowDocument doc,
        string code,
        string name,
        string um,
        IReadOnlyList<SyncedRecipeLineRow> lines,
        decimal factor)
    {
        var header = new Paragraph(new Run($"Rețetă de producție — {name}"))
        {
            FontSize = 14,
            FontWeight = FontWeights.SemiBold,
            Margin = new Thickness(0, 0, 0, 4)
        };
        doc.Blocks.Add(header);
        doc.Blocks.Add(new Paragraph(new Run($"Cod: {code}  |  UM: {um}  |  Cantitate raportare: {factor:N3}"))
        {
            Foreground = Brushes.DimGray,
            Margin = new Thickness(0, 0, 0, 8)
        });

        var table = new Table { CellSpacing = 0 };
        table.Columns.Add(new TableColumn { Width = new GridLength(120) });
        table.Columns.Add(new TableColumn { Width = new GridLength(120) });
        table.Columns.Add(new TableColumn { Width = new GridLength(1, GridUnitType.Star) });
        table.Columns.Add(new TableColumn { Width = new GridLength(80) });
        table.Columns.Add(new TableColumn { Width = new GridLength(48) });
        table.Columns.Add(new TableColumn { Width = new GridLength(72) });

        var rg = new TableRowGroup();
        var hdr = new TableRow { Background = Brushes.AliceBlue };
        hdr.Cells.Add(Cell("Tip"));
        hdr.Cells.Add(Cell("Gestiune desc."));
        hdr.Cells.Add(Cell("Denumire articol"));
        hdr.Cells.Add(Cell("Cod"));
        hdr.Cells.Add(Cell("UM"));
        hdr.Cells.Add(Cell("Cantitate"));
        rg.Rows.Add(hdr);

        foreach (var line in lines)
        {
            var q = line.Quantity * factor;
            var row = new TableRow();
            row.Cells.Add(Cell(line.Tip));
            row.Cells.Add(Cell(line.Gestiune));
            row.Cells.Add(Cell(line.ComponentName));
            row.Cells.Add(Cell(line.ComponentCode));
            row.Cells.Add(Cell(line.Um));
            row.Cells.Add(Cell(q.ToString("N3", CultureInfo.CurrentCulture)));
            rg.Rows.Add(row);
        }

        table.RowGroups.Add(rg);
        doc.Blocks.Add(table);
        doc.Blocks.Add(new Paragraph(new Run(" ")) { Margin = new Thickness(0, 16, 0, 0) });
    }

    private static TableCell Cell(string text)
    {
        return new TableCell(new Paragraph(new Run(text ?? "")))
        {
            BorderBrush = Brushes.LightGray,
            BorderThickness = new Thickness(0.5),
            Padding = new Thickness(4)
        };
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            SyncCantRaportFromUi();
            if (!ConfirmSaveWhenRecipeEmpty())
                return;
            using var conn = SmartPubDb.OpenEmbedded();
            var combined = new List<SyncedRecipeLineRow>(_preservedAnteLines);
            combined.AddRange(_mainLines);
            _repo.SaveRecipeLines(conn, _product.Code, combined);
            _repo.SaveRecipeCantRaportare(conn, _product.Code, _cantRaport);
            _dirty = false;
            MessageBox.Show(this, "Rețeta a fost salvată.", "Rețetă de producție",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Salvare eșuată:\n" + ex.Message, "Rețetă de producție",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BtnClose_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }

    private void RecipeWindow_OnClosing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        if (!_dirty)
            return;

        var r = MessageBox.Show(this,
            "Există modificări nesalvate. Salvezi înainte de închidere?",
            "Rețetă de producție",
            MessageBoxButton.YesNoCancel,
            MessageBoxImage.Question);

        if (r == MessageBoxResult.Cancel)
        {
            e.Cancel = true;
            return;
        }

        if (r != MessageBoxResult.Yes)
            return;

        try
        {
            SyncCantRaportFromUi();
            if (!ConfirmSaveWhenRecipeEmpty())
            {
                e.Cancel = true;
                return;
            }

            using var conn = SmartPubDb.OpenEmbedded();
            var combined = new List<SyncedRecipeLineRow>(_preservedAnteLines);
            combined.AddRange(_mainLines);
            _repo.SaveRecipeLines(conn, _product.Code, combined);
            _repo.SaveRecipeCantRaportare(conn, _product.Code, _cantRaport);
            _dirty = false;
        }
        catch (Exception ex)
        {
            e.Cancel = true;
            MessageBox.Show(this, "Nu s-a putut salva:\n" + ex.Message, "Rețetă de producție",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    /// <summary>Evită salvarea accidentală a unei rețete goale care șterge liniile din SAGA.</summary>
    private bool ConfirmSaveWhenRecipeEmpty()
    {
        var combinedCount = _preservedAnteLines.Count + _mainLines.Count;
        if (combinedCount > 0)
            return true;
        using var conn = SmartPubDb.OpenEmbedded();
        var existing = _repo.CountAllRecipeLinesForArticle(conn, _product.Code);
        if (existing == 0)
            return true;
        return MessageBox.Show(this,
            "Rețeta este goală. Salvarea va șterge toate liniile existente pentru acest articol (inclusiv cele sincronizate din SAGA).\n\nContinui?",
            "Rețetă de producție",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning) == MessageBoxResult.Yes;
    }

    private void SyncCantRaportFromUi()
    {
        var t = TxtCantitateRaportare.Text.Trim().Replace(',', '.');
        if (decimal.TryParse(t, NumberStyles.Any, CultureInfo.InvariantCulture, out var v)
            || decimal.TryParse(TxtCantitateRaportare.Text.Trim(), NumberStyles.Any, CultureInfo.CurrentCulture, out v))
        {
            _cantRaport = v <= 0 ? 1m : v;
            TxtCantitateRaportare.Text = _cantRaport.ToString("N3", CultureInfo.CurrentCulture);
        }
    }
}

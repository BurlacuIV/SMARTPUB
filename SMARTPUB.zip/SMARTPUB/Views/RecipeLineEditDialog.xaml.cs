using System.Globalization;
using System.Linq;
using System.Windows;
using FirebirdSql.Data.FirebirdClient;
using System.Windows.Controls;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Views;

public partial class RecipeLineEditDialog : Window
{
    private readonly SyncedRecipeLineRow _line;
    private readonly SagaRecipeLookupService _lookup = new();
    private bool _suppressArticoleChange;
    private bool _loaded;

    public RecipeLineEditDialog(SyncedRecipeLineRow line)
    {
        InitializeComponent();
        _line = line;
        Loaded += (_, _) => LoadLookups();
    }

    private void LoadLookups()
    {
        if (_loaded)
            return;
        _loaded = true;

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            var tips = _lookup.ListDistinctTip(conn);
            CmbTip.ItemsSource = tips;
            CmbTip.Text = _line.Tip;

            var gest = _lookup.ListGestiuni(conn);
            CmbGestiune.ItemsSource = gest;
            var matchG = gest.FirstOrDefault(g =>
                string.Equals(g.Code, _line.Gestiune.Trim(), StringComparison.OrdinalIgnoreCase));
            if (matchG != null)
                CmbGestiune.SelectedItem = matchG;
            else
                CmbGestiune.Text = string.IsNullOrEmpty(_line.Gestiune) ? "" : _line.Gestiune;

            TxtDenumire.Text = _line.ComponentName;
            TxtCod.Text = _line.ComponentCode;
            TxtUm.Text = _line.Um;
            TxtCantitate.Text = _line.Quantity.ToString(CultureInfo.CurrentCulture);
            TxtSursa.Text = _line.SourceTable;

            ReloadArticolePickList(conn);
            TrySelectCurrentArticole();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this,
                "Nu am putut încărca listele SAGA: " + ex.Message,
                "Linie rețetă",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
            CmbTip.Text = _line.Tip;
            CmbGestiune.Text = _line.Gestiune;
            TxtDenumire.Text = _line.ComponentName;
            TxtCod.Text = _line.ComponentCode;
            TxtUm.Text = _line.Um;
            TxtCantitate.Text = _line.Quantity.ToString(CultureInfo.CurrentCulture);
            TxtSursa.Text = _line.SourceTable;
        }
    }

    private void ReloadArticolePickList(FbConnection conn)
    {
        var rows = _lookup.ListArticole(conn, grupaFilter: null);
        _suppressArticoleChange = true;
        CmbArticole.ItemsSource = rows;
        _suppressArticoleChange = false;
    }

    private void TrySelectCurrentArticole()
    {
        if (CmbArticole.ItemsSource is not System.Collections.IEnumerable en)
            return;
        foreach (RecipeArticolePickRow r in en)
        {
            if (string.Equals(r.Code, _line.ComponentCode.Trim(), StringComparison.OrdinalIgnoreCase))
            {
                _suppressArticoleChange = true;
                CmbArticole.SelectedItem = r;
                _suppressArticoleChange = false;
                return;
            }
        }
    }

    private void CmbArticole_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressArticoleChange || CmbArticole.SelectedItem is not RecipeArticolePickRow r)
            return;

        TxtCod.Text = r.Code;
        TxtDenumire.Text = r.Name;
        TxtUm.Text = r.Um;
    }

    private void BtnOk_Click(object sender, RoutedEventArgs e)
    {
        var raw = TxtCantitate.Text.Trim().Replace(',', '.');
        if (!decimal.TryParse(raw, NumberStyles.Any, CultureInfo.InvariantCulture, out var qty))
        {
            MessageBox.Show(this, "Cantitatea nu este numerică validă.", "Rețetă",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        _line.Tip = (CmbTip.Text ?? "").Trim();
        _line.Gestiune = ResolveGestiuneCode();
        _line.ComponentName = TxtDenumire.Text.Trim();
        _line.ComponentCode = TxtCod.Text.Trim();
        _line.Um = TxtUm.Text.Trim();
        _line.Quantity = qty;
        _line.SourceTable = TxtSursa.Text.Trim();
        DialogResult = true;
    }

    private string ResolveGestiuneCode()
    {
        if (CmbGestiune.SelectedItem is GestiuneComboOption g)
            return g.Code.Trim();
        return (CmbGestiune.Text ?? "").Trim();
    }
}

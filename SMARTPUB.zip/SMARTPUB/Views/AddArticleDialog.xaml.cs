using System.Globalization;
using System.Windows;
using SMARTPUB.Models;
using SMARTPUB.Services;

namespace SMARTPUB.Views;

public partial class AddArticleDialog : Window
{
    private readonly SyncedProductsRepository _repo = new();
    private readonly SagaRecipeLookupService _lookup = new();
    private bool _loaded;

    public AddArticleDialog()
    {
        InitializeComponent();
        Loaded += (_, _) => LoadLookups();
    }

    private void LoadLookups()
    {
        if (_loaded)
            return;
        _loaded = true;

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            CmbDenTip.ItemsSource = _lookup.ListDistinctTip(conn);
            CmbGrupa.ItemsSource = _lookup.ListGrupaComboOptions(conn);
            CmbGestiune.ItemsSource = _lookup.ListGestiuni(conn);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this,
                "Nu am putut încărca listele: " + ex.Message,
                "Adaugă articol",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }

        TxtTva.Text = "21";
        TxtUm.Text = "BUC";
        TxtPret.Text = "0";
    }

    private void BtnSalveaza_Click(object sender, RoutedEventArgs e)
    {
        var code = (TxtCod.Text ?? "").Trim();
        var name = (TxtDenumire.Text ?? "").Trim();
        if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(name))
        {
            MessageBox.Show(this, "Completați codul și denumirea.", "Adaugă articol", MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return;
        }

        if (!decimal.TryParse((TxtTva.Text ?? "").Trim().Replace(',', '.'),
                NumberStyles.Number, CultureInfo.InvariantCulture, out var tva))
        {
            MessageBox.Show(this, "TVA invalid.", "Adaugă articol", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        if (!decimal.TryParse((TxtPret.Text ?? "").Trim().Replace(',', '.'),
                NumberStyles.Number, CultureInfo.InvariantCulture, out var pret))
        {
            MessageBox.Show(this, "Preț invalid.", "Adaugă articol", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var denTip = (CmbDenTip.Text ?? "").Trim();
        var tipSaga = (TxtTipSaga.Text ?? "").Trim();
        var categorie = (TxtCategorie.Text ?? "").Trim();
        var grupa = ResolveGrupaCode();
        var gestiune = ResolveGestiuneCode();
        var um = (TxtUm.Text ?? "").Trim();

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            if (_repo.ArticolCodeExists(conn, code))
            {
                var r = MessageBox.Show(this,
                    $"Există deja un articol cu codul „{code}”. Suprascrieți datele?",
                    "Adaugă articol",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);
                if (r != MessageBoxResult.Yes)
                    return;
            }

            var row = new SagaSyncArticol
            {
                Code = code,
                Name = name,
                Um = um,
                Tva = tva,
                Categorie = categorie,
                Grupa = grupa,
                Gestiune = gestiune,
                PretVanz = pret,
                IsBlocked = ChkBlocat.IsChecked == true,
                DenTip = denTip,
                TipSaga = tipSaga
            };

            _repo.UpsertArticole(conn, row);
            DialogResult = true;
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Adaugă articol", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private string ResolveGestiuneCode()
    {
        if (CmbGestiune.SelectedItem is GestiuneComboOption g)
            return g.Code.Trim();
        return (CmbGestiune.Text ?? "").Trim();
    }

    private string ResolveGrupaCode()
    {
        if (CmbGrupa.SelectedItem is GrupaComboOption go)
            return go.Code;
        return GrupaComboOption.ExtractCodeFromEditorText(CmbGrupa.Text);
    }
}

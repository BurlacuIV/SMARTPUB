using System.Globalization;
using System.Text;
using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.SagaWorker;

/// <summary>Limite și utilitare insert IESIRI/IES_DET — schema SAGA C.3 (verificată pe CONT_BAZA).</summary>
internal static class SagaIesiriInsertHelpers
{
    internal static readonly Encoding DbEncoding = Encoding.GetEncoding(1252);

    private static readonly Dictionary<string, int> IesiriCols = new(StringComparer.OrdinalIgnoreCase)
    {
        ["NR_IESIRE"] = 16,
        ["COD"] = 8,
        ["DENUMIRE"] = 64,
        ["CONT_CLI"] = 20,
        ["CONT_D_A"] = 20,
        ["CONT_C_A"] = 20,
        ["COMANDA"] = 16,
        ["INF_SUPLM"] = 250,
        ["TIP"] = 1
    };

    private static readonly Dictionary<string, int> DetCols = new(StringComparer.OrdinalIgnoreCase)
    {
        ["GESTIUNE"] = 4,
        ["DEN_GEST"] = 24,
        ["COD"] = 16,
        ["DENUMIRE"] = 60,
        ["DEN_TIP"] = 36,
        ["UM"] = 5,
        ["CONT"] = 20,
        ["TEXT_SUPL"] = 240,
        ["NR_STORNO"] = 10
    };

    internal static int IesiriCol(string name) => IesiriCols.TryGetValue(name, out var n) ? n : 32;
    internal static int DetCol(string name) => DetCols.TryGetValue(name, out var n) ? n : 32;
    internal static decimal RoundMoney(decimal v) => Math.Round(v, 2, MidpointRounding.AwayFromZero);
    internal static decimal RoundQty(decimal v) => Math.Round(v, 3, MidpointRounding.AwayFromZero);
    internal static decimal RoundPrice(decimal v) => Math.Round(v, 4, MidpointRounding.AwayFromZero);

    internal static void AddVarChar(FbCommand cmd, string name, string? value, int size)
    {
        var p = cmd.Parameters.Add(name, FbDbType.VarChar);
        p.Size = size;
        p.Value = Truncate(value, size);
    }

    internal static void AddSmallInt(FbCommand cmd, string name, int value)
    {
        var p = cmd.Parameters.Add(name, FbDbType.SmallInt);
        p.Value = (short)value;
    }

    internal static void AddInteger(FbCommand cmd, string name, int value)
    {
        var p = cmd.Parameters.Add(name, FbDbType.Integer);
        p.Value = value;
    }

    internal static void AddDate(FbCommand cmd, string name, DateTime value)
    {
        var p = cmd.Parameters.Add(name, FbDbType.Date);
        p.Value = value.Date;
    }

    internal static void AddNumeric(FbCommand cmd, string name, decimal value, byte precision, byte scale)
    {
        var p = cmd.Parameters.Add(name, FbDbType.Decimal);
        p.Precision = precision;
        p.Scale = scale;
        p.Value = Math.Round(value, scale, MidpointRounding.AwayFromZero);
    }

    internal static string Truncate(string? s, int maxChars)
    {
        if (maxChars <= 0)
            return "";
        if (string.IsNullOrEmpty(s))
            return "";
        var t = s.Trim();
        if (t.Length <= maxChars && DbEncoding.GetByteCount(t) <= maxChars)
            return t;

        var cut = t.Length <= maxChars ? t : t[..maxChars];
        while (cut.Length > 0 && DbEncoding.GetByteCount(cut) > maxChars)
            cut = cut[..^1];
        return cut;
    }

    internal static string LookupContVenit(FbConnection saga, FbTransaction tx, string code)
    {
        var c = (code ?? "").Trim();
        if (c.Length == 0)
            return "";

        using var cmd = saga.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = @"
SELECT FIRST 1 TRIM(CONT)
FROM IES_DET
WHERE TRIM(COD) = TRIM(@C) AND TRIM(COALESCE(CONT, '')) <> ''
ORDER BY PK DESC";
        cmd.Parameters.AddWithValue("@C", c);
        var o = cmd.ExecuteScalar();
        return (o?.ToString() ?? "").Trim();
    }

    internal static bool IsStringTruncation(Exception ex)
    {
        for (var e = ex; e != null; e = e.InnerException)
        {
            var msg = e.Message ?? "";
            if (msg.Contains("string truncation", StringComparison.OrdinalIgnoreCase)
                || msg.Contains("string right truncation", StringComparison.OrdinalIgnoreCase))
                return true;
        }

        return false;
    }
}

using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using FirebirdSql.Data.FirebirdClient;
using SMARTPUB;
using SMARTPUB.SagaWorker;

Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

if (args.Length == 0)
{
    Write(new WorkerResponse { Success = false, Error = "Missing command. Use: scan|scansrv|test|export|accounts|applybom|iesiri" });
    return;
}

var command = args[0].Trim().ToLowerInvariant();
try
{
    switch (command)
    {
        case "scan":
            if (args.Length < 2)
            {
                Write(new WorkerResponse { Success = false, Error = "Usage: scan <sagaRoot>" });
                return;
            }
            Write(ScanSagaCompanies(args[1]));
            return;

        case "scansrv":
            if (args.Length < 4)
            {
                Write(new WorkerResponse { Success = false, Error = "Usage: scansrv <host> <port> <sagaRootOnServer>" });
                return;
            }
            Write(ScanSagaCompaniesServer(args[1], args[2], args[3]));
            return;

        case "test":
            if (args.Length == 3)
            {
                Write(TestSagaConnection(args[1], args[2], false, "", 0));
                return;
            }
            if (args.Length == 6 && string.Equals(args[3], "SERVER", StringComparison.OrdinalIgnoreCase))
            {
                var pTest = int.TryParse(args[5], out var pvTest) ? pvTest : SagaConnectionDefaults.FirebirdServerPort;
                Write(TestSagaConnection(args[1], args[2], true, args[4], pTest));
                return;
            }
            Write(new WorkerResponse
            {
                Success = false,
                Error = "Usage: test <dbPath> <sagaRoot> | test <dbPath> <sagaRoot> SERVER <host> <port>"
            });
            return;

        case "export":
            if (args.Length == 3)
            {
                Write(ExportSyncPayload(args[1], args[2], false, null, 0));
                return;
            }
            if (args.Length == 6 && string.Equals(args[3], "SERVER", StringComparison.OrdinalIgnoreCase))
            {
                var pEx = int.TryParse(args[5], out var pvEx) ? pvEx : SagaConnectionDefaults.FirebirdServerPort;
                Write(ExportSyncPayload(args[1], args[2], true, args[4], pEx));
                return;
            }
            Write(new WorkerResponse
            {
                Success = false,
                Error = "Usage: export <dbPath> <sagaRoot> | export <dbPath> <sagaRoot> SERVER <host> <port>"
            });
            return;

        case "applybom":
            if (args.Length == 4)
            {
                Write(ApplyBomToSaga(args[1], args[2], args[3], false, null, 0));
                return;
            }
            if (args.Length == 7 && string.Equals(args[4], "SERVER", StringComparison.OrdinalIgnoreCase))
            {
                var pAb = int.TryParse(args[6], out var pvAb) ? pvAb : SagaConnectionDefaults.FirebirdServerPort;
                Write(ApplyBomToSaga(args[1], args[2], args[3], true, args[5], pAb));
                return;
            }
            Write(new WorkerResponse
            {
                Success = false,
                Error = "Usage: applybom <dbPath> <sagaRoot> <jsonPath> | applybom <dbPath> <sagaRoot> <jsonPath> SERVER <host> <port>"
            });
            return;

        case "artlist":
            if (args.Length == 3)
            {
                Write(ListArticleBriefs(args[1], args[2], false, null, 0));
                return;
            }
            if (args.Length == 6 && string.Equals(args[3], "SERVER", StringComparison.OrdinalIgnoreCase))
            {
                var pAl = int.TryParse(args[5], out var pvAl) ? pvAl : SagaConnectionDefaults.FirebirdServerPort;
                Write(ListArticleBriefs(args[1], args[2], true, args[4], pAl));
                return;
            }
            Write(new WorkerResponse
            {
                Success = false,
                Error = "Usage: artlist <dbPath> <sagaRoot> | artlist <dbPath> <sagaRoot> SERVER <host> <port>"
            });
            return;

        case "accounts":
            if (args.Length == 3)
            {
                Write(ListAccounts(args[1], args[2], false, null, 0));
                return;
            }
            if (args.Length == 6 && string.Equals(args[3], "SERVER", StringComparison.OrdinalIgnoreCase))
            {
                var pAcc = int.TryParse(args[5], out var pvAcc) ? pvAcc : SagaConnectionDefaults.FirebirdServerPort;
                Write(ListAccounts(args[1], args[2], true, args[4], pAcc));
                return;
            }
            Write(new WorkerResponse
            {
                Success = false,
                Error = "Usage: accounts <dbPath> <sagaRoot> | accounts <dbPath> <sagaRoot> SERVER <host> <port>"
            });
            return;

        case "iesiri":
            if (args.Length < 2)
            {
                Write(new WorkerResponse { Success = false, Error = "Usage: iesiri <transferJsonPath>" });
                return;
            }
            Write(IesiriTransferFromJsonFile(args[1]));
            return;

        default:
            Write(new WorkerResponse { Success = false, Error = $"Unknown command: {command}" });
            return;
    }
}
catch (Exception ex)
{
    Write(new WorkerResponse { Success = false, Error = ex.Message });
}

static WorkerResponse ScanSagaCompanies(string sagaRootPath)
{
    if (string.IsNullOrWhiteSpace(sagaRootPath) || !Directory.Exists(sagaRootPath))
        return new WorkerResponse { Success = false, Error = "Calea SAGA este invalidă." };

    var configDb = Path.Combine(sagaRootPath, "CONFIG.FDB");
    if (!File.Exists(configDb))
        return new WorkerResponse { Success = false, Error = $"CONFIG.FDB nu a fost găsit în {sagaRootPath}" };

    var fbClient = ResolveWorkingClient(configDb, sagaRootPath, out var resolveError);
    if (string.IsNullOrWhiteSpace(fbClient))
        return new WorkerResponse { Success = false, Error = resolveError };

    var companies = new List<WorkerCompany>();
    using var conn = OpenEmbedded(configDb, fbClient);
    using var cmd = conn.CreateCommand();
    cmd.CommandText = @"
SELECT TRIM(COD)  AS COD,
       TRIM(NUME) AS NUME,
       TRIM(CALE) AS CALE,
       BLOCAT     AS BLOCAT,
       TRIM(DBD)  AS DBD
FROM FIRME
ORDER BY COD";

    using var rd = cmd.ExecuteReader();
    while (rd.Read())
    {
        var code = (rd["COD"]?.ToString() ?? "").Trim();
        var name = (rd["NUME"]?.ToString() ?? "").Trim();
        var cale = (rd["CALE"]?.ToString() ?? "").Trim();
        var dbd = (rd["DBD"]?.ToString() ?? "").Trim();
        if (string.IsNullOrWhiteSpace(code))
            continue;

        var blocked = false;
        try { blocked = Convert.ToInt32(rd["BLOCAT"]) != 0; } catch { }
        var folder = string.IsNullOrWhiteSpace(cale) ? code : cale;
        var dbPath = ResolveCompanyDbPath(sagaRootPath, folder, dbd);
        if (string.IsNullOrWhiteSpace(dbPath))
            continue;

        companies.Add(new WorkerCompany
        {
            Code = code,
            Name = string.IsNullOrWhiteSpace(name) ? code : name,
            DatabasePath = dbPath,
            IsBlocked = blocked
        });
    }

    return new WorkerResponse { Success = true, FbClientPath = fbClient, Companies = companies };
}

/// <summary>Scanare CONFIG.FDB pe server Firebird (calea rădăcină SAGA este pe mașina serverului).</summary>
static WorkerResponse ScanSagaCompaniesServer(string host, string portStr, string sagaRootOnServer)
{
    if (string.IsNullOrWhiteSpace(host) || string.IsNullOrWhiteSpace(sagaRootOnServer))
        return new WorkerResponse { Success = false, Error = "Host sau rădăcină SAGA pe server lipsă." };

    var root = NormalizeSagaRootFolder(sagaRootOnServer);
    // Pe mașina serverului: CONFIG.FDB local (ca isql), nu TCP — ADO pe 127.0.0.1/3060 dă adesea WireCrypt/28000.
    if (IsLocalSagaServerHost(host) && File.Exists(Path.Combine(root, "CONFIG.FDB")))
        return ScanSagaCompanies(root);

    var port = int.TryParse(portStr, out var p) ? p : SagaConnectionDefaults.FirebirdServerPort;
    var configDb = CombineServerPath(root, "CONFIG.FDB");

    var fbClient = ResolveFbClientForTcp(null);
    if (string.IsNullOrWhiteSpace(fbClient))
        return new WorkerResponse { Success = false, Error = "Nu am găsit fbclient.dll pentru mod client Firebird." };

    var companies = new List<WorkerCompany>();
    try
    {
        using var conn = OpenTcp(host.Trim(), port, configDb, fbClient);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT TRIM(COD)  AS COD,
       TRIM(NUME) AS NUME,
       TRIM(CALE) AS CALE,
       BLOCAT     AS BLOCAT,
       TRIM(DBD)  AS DBD
FROM FIRME
ORDER BY COD";

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var code = (rd["COD"]?.ToString() ?? "").Trim();
            var name = (rd["NUME"]?.ToString() ?? "").Trim();
            var cale = (rd["CALE"]?.ToString() ?? "").Trim();
            var dbd = (rd["DBD"]?.ToString() ?? "").Trim();
            if (string.IsNullOrWhiteSpace(code))
                continue;

            var blocked = false;
            try { blocked = Convert.ToInt32(rd["BLOCAT"]) != 0; } catch { }
            var folder = string.IsNullOrWhiteSpace(cale) ? code : cale;
            var dbPath = ResolveCompanyDbPathForServer(root, folder, dbd);
            if (string.IsNullOrWhiteSpace(dbPath))
                continue;

            companies.Add(new WorkerCompany
            {
                Code = code,
                Name = string.IsNullOrWhiteSpace(name) ? code : name,
                DatabasePath = dbPath,
                IsBlocked = blocked
            });
        }
    }
    catch (Exception ex)
    {
        return new WorkerResponse { Success = false, Error = ex.Message, FbClientPath = fbClient };
    }

    return new WorkerResponse { Success = true, FbClientPath = fbClient, Companies = companies };
}

static WorkerResponse TestSagaConnection(string dbPath, string sagaRootPath, bool serverMode, string serverHost, int serverPort)
{
    if (serverMode)
    {
        if (string.IsNullOrWhiteSpace(serverHost))
            return new WorkerResponse { Success = false, Error = "Host server lipsă." };
        if (string.IsNullOrWhiteSpace(dbPath))
            return new WorkerResponse { Success = false, Error = "Calea bazei firmei pe server lipsește." };

        if (CanOpenSagaDatabaseLocally(serverHost, sagaRootPath, dbPath))
        {
            var fbLocal = ResolveWorkingClient(dbPath, sagaRootPath, out var localErr);
            if (string.IsNullOrWhiteSpace(fbLocal))
                return new WorkerResponse { Success = false, Error = localErr };

            using var connLocal = OpenEmbedded(dbPath, fbLocal);
            using var cmdLocal = connLocal.CreateCommand();
            cmdLocal.CommandText = "SELECT rdb$get_context('SYSTEM', 'ENGINE_VERSION') FROM rdb$database";
            var verLocal = cmdLocal.ExecuteScalar()?.ToString()?.Trim();
            return new WorkerResponse { Success = true, FbClientPath = fbLocal, EngineVersion = verLocal };
        }

        var fbClient = ResolveFbClientForTcp(null);
        if (string.IsNullOrWhiteSpace(fbClient))
            return new WorkerResponse { Success = false, Error = "Nu am găsit fbclient.dll pentru mod client." };

        try
        {
            using var conn = OpenTcp(serverHost.Trim(), serverPort <= 0 ? SagaConnectionDefaults.FirebirdServerPort : serverPort, dbPath, fbClient);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT rdb$get_context('SYSTEM', 'ENGINE_VERSION') FROM rdb$database";
            var version = cmd.ExecuteScalar()?.ToString()?.Trim();
            return new WorkerResponse { Success = true, FbClientPath = fbClient, EngineVersion = version };
        }
        catch (Exception ex)
        {
            var p = serverPort <= 0 ? SagaConnectionDefaults.FirebirdServerPort : serverPort;
            var hint =
                $"\n[Firebird TCP: host={serverHost.Trim()}, port={p}, fișier pe server={dbPath}]";
            return new WorkerResponse { Success = false, Error = ex.Message + hint, FbClientPath = fbClient };
        }
    }

    if (string.IsNullOrWhiteSpace(dbPath) || !File.Exists(dbPath))
        return new WorkerResponse { Success = false, Error = "Baza firmei nu există pe acest PC (mod local)." };

    var fb = ResolveWorkingClient(dbPath, sagaRootPath, out var resolveError);
    if (string.IsNullOrWhiteSpace(fb))
        return new WorkerResponse { Success = false, Error = resolveError };

    using var c = OpenEmbedded(dbPath, fb);
    using var cmd2 = c.CreateCommand();
    cmd2.CommandText = "SELECT rdb$get_context('SYSTEM', 'ENGINE_VERSION') FROM rdb$database";
    var ver = cmd2.ExecuteScalar()?.ToString()?.Trim();
    return new WorkerResponse { Success = true, FbClientPath = fb, EngineVersion = ver };
}

/// <summary>Lista articolelor (compactă) pentru popup-ul de sincronizare: cod, denumire, UM, preț, tip.</summary>
static WorkerResponse ListArticleBriefs(string dbPath, string sagaRootPath, bool serverMode, string? serverHost, int serverPort)
{
    if (!serverMode && (string.IsNullOrWhiteSpace(dbPath) || !File.Exists(dbPath)))
        return new WorkerResponse { Success = false, Error = "Baza firmei nu există pe acest PC (mod local)." };
    if (serverMode && string.IsNullOrWhiteSpace(serverHost))
        return new WorkerResponse { Success = false, Error = "Host server lipsă." };
    if (serverMode && string.IsNullOrWhiteSpace(dbPath))
        return new WorkerResponse { Success = false, Error = "Calea bazei firmei pe server lipsește." };

    try
    {
        using var conn = OpenCompanyConnection(dbPath, sagaRootPath, serverMode, serverHost, serverPort, out var fbClient);

        var hasDenTip = ColumnExists(conn, "ARTICOLE", "DEN_TIP");
        var hasTip = ColumnExists(conn, "ARTICOLE", "TIP");
        var hasPretVTva = ColumnExists(conn, "ARTICOLE", "PRET_V_TVA");
        var denTipExpr = hasDenTip ? "TRIM(COALESCE(DEN_TIP, ''))" : "CAST('' AS VARCHAR(48))";
        var tipExpr = hasTip ? "TRIM(COALESCE(TIP, ''))" : "CAST('' AS VARCHAR(4))";
        var pretVTvaExpr = hasPretVTva ? "COALESCE(PRET_V_TVA, 0)" : "CAST(0 AS NUMERIC(18,4))";

        var resp = new WorkerResponse { Success = true, FbClientPath = fbClient };
        using var cmd = conn.CreateCommand();
        cmd.CommandText =
            "SELECT TRIM(COD) AS COD, TRIM(DENUMIRE) AS DENUMIRE, TRIM(COALESCE(UM,'')) AS UM, " +
            "COALESCE(TVA,0) AS TVA, COALESCE(PRET_VANZ,0) AS PRET_VANZ, " + pretVTvaExpr + " AS PRET_V_TVA, COALESCE(BLOCAT,0) AS BLOCAT, " +
            denTipExpr + " AS DEN_TIP, " + tipExpr + " AS TIP_SAGA FROM ARTICOLE ORDER BY DENUMIRE";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var code = (rd["COD"]?.ToString() ?? "").Trim();
            if (string.IsNullOrWhiteSpace(code))
                continue;
            resp.ArticleList.Add(new WorkerArticleBrief
            {
                Code = code,
                Name = (rd["DENUMIRE"]?.ToString() ?? "").Trim(),
                Um = (rd["UM"]?.ToString() ?? "").Trim(),
                Tva = ToDecimal(rd["TVA"]),
                PretVanz = ResolveGrossSalePrice(ToDecimal(rd["PRET_VANZ"]), ToDecimal(rd["PRET_V_TVA"]), ToDecimal(rd["TVA"])),
                IsBlocked = ToInt(rd["BLOCAT"]) != 0,
                DenTip = (rd["DEN_TIP"]?.ToString() ?? "").Trim(),
                TipSaga = (rd["TIP_SAGA"]?.ToString() ?? "").Trim()
            });
        }

        return resp;
    }
    catch (Exception ex)
    {
        return new WorkerResponse { Success = false, Error = ex.Message };
    }
}

static WorkerResponse ListAccounts(string dbPath, string sagaRootPath, bool serverMode, string? serverHost, int serverPort)
{
    if (!serverMode && !File.Exists(dbPath))
        return new WorkerResponse { Success = false, Error = "Baza firmei nu există pe acest PC (mod local)." };
    if (serverMode && string.IsNullOrWhiteSpace(serverHost))
        return new WorkerResponse { Success = false, Error = "Host server lipsă." };
    if (serverMode && string.IsNullOrWhiteSpace(dbPath))
        return new WorkerResponse { Success = false, Error = "Calea bazei firmei pe server lipsește." };

    try
    {
        var fbClient = "";
        using var conn = OpenCompanyConnection(dbPath, sagaRootPath, serverMode, serverHost, serverPort, out fbClient);
        var resp = new WorkerResponse { Success = true, FbClientPath = fbClient };
        if (!TableExists(conn, "CONTURI"))
            return resp;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT TRIM(CONT) AS CONT, TRIM(COALESCE(DENUMIRE, '')) AS DENUMIRE
FROM CONTURI
WHERE TRIM(COALESCE(CONT, '')) <> ''
ORDER BY CONT";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            resp.AccountList.Add(new WorkerAccountBrief
            {
                Code = (rd["CONT"]?.ToString() ?? "").Trim(),
                Name = (rd["DENUMIRE"]?.ToString() ?? "").Trim()
            });
        }

        return resp;
    }
    catch (Exception ex)
    {
        return new WorkerResponse { Success = false, Error = ex.Message };
    }
}

/// <summary>Deschide conexiunea la baza firmei: TCP în mod SERVER (chiar pe mașina SAGA), embedded doar local.</summary>
static FbConnection OpenCompanyConnection(
    string dbPath, string sagaRootPath, bool serverMode, string? serverHost, int serverPort, out string fbClient)
{
    if (serverMode)
    {
        if (string.IsNullOrWhiteSpace(serverHost))
            throw new InvalidOperationException("Host server lipsă.");
        fbClient = ResolveFbClientForTcp(null) ?? "";
        if (string.IsNullOrWhiteSpace(fbClient))
            throw new InvalidOperationException("Nu am găsit fbclient.dll pentru mod client Firebird (x64).");
        return OpenTcp(
            serverHost.Trim(),
            serverPort <= 0 ? SagaConnectionDefaults.FirebirdServerPort : serverPort,
            dbPath,
            fbClient);
    }

    fbClient = ResolveWorkingClient(dbPath, sagaRootPath, out var err) ?? "";
    if (string.IsNullOrWhiteSpace(fbClient))
        throw new InvalidOperationException(err);
    return OpenEmbedded(dbPath, fbClient);
}

/// <summary>
/// Tipurile (DEN_TIP) selectate în popup. Sursă preferată: fișierul indicat de SAGA_INCLUDE_DENTIP_FILE
/// (un tip pe linie). Fallback: env SAGA_INCLUDE_DENTIP (separate prin linie nouă).
/// </summary>
static List<string> ReadIncludeDenTipFilter()
{
    string? raw = null;

    var file = Environment.GetEnvironmentVariable("SAGA_INCLUDE_DENTIP_FILE");
    if (!string.IsNullOrWhiteSpace(file) && File.Exists(file))
    {
        try { raw = File.ReadAllText(file); }
        catch { raw = null; }
    }

    if (string.IsNullOrWhiteSpace(raw))
        raw = Environment.GetEnvironmentVariable("SAGA_INCLUDE_DENTIP");

    if (string.IsNullOrWhiteSpace(raw))
        return new List<string>();

    return raw
        .Replace("\r", "")
        .Split('\n')
        .Select(x => x.Trim().ToUpperInvariant())
        .Where(x => x.Length > 0)
        .Distinct()
        .ToList();
}

static WorkerResponse ExportSyncPayload(string dbPath, string sagaRootPath, bool serverMode, string? serverHost, int serverPort)
{
    ReportProgress(1, "Pregătire conexiune SAGA...");
    if (!serverMode && (string.IsNullOrWhiteSpace(dbPath) || !File.Exists(dbPath)))
        return new WorkerResponse { Success = false, Error = "Baza firmei nu există pe acest PC (mod local)." };

    if (serverMode && string.IsNullOrWhiteSpace(serverHost))
        return new WorkerResponse { Success = false, Error = "Host server lipsă pentru export." };

    if (serverMode && string.IsNullOrWhiteSpace(dbPath))
        return new WorkerResponse { Success = false, Error = "Calea bazei firmei pe server lipsește." };

    string fbClient;
    FbConnection conn;
    try
    {
        conn = OpenCompanyConnection(dbPath, sagaRootPath, serverMode, serverHost, serverPort, out fbClient);
        ReportProgress(4, "Conexiune SAGA deschisă.");
    }
    catch (Exception ex)
    {
        return new WorkerResponse { Success = false, Error = ex.Message };
    }

    var payload = new WorkerSyncPayload();

    using (conn)
    {
    // Gestiuni
    ReportProgress(6, "Export gestiuni...");
    using (var cmd = conn.CreateCommand())
    {
        cmd.CommandText = @"
SELECT TRIM(COD) AS COD,
       TRIM(DENUMIRE) AS DENUMIRE,
       TRIM(GESTIONAR) AS GESTIONAR,
       COALESCE(TIP_EVAL, 0) AS TIP_EVAL,
       TRIM(CATEGORIE) AS CATEGORIE,
       COALESCE(PROCTVA, 0) AS PROCTVA
FROM GESTIUNI";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            payload.Gestiuni.Add(new WorkerSyncGestiune
            {
                Code = (rd["COD"]?.ToString() ?? "").Trim(),
                Name = (rd["DENUMIRE"]?.ToString() ?? "").Trim(),
                Gestionar = (rd["GESTIONAR"]?.ToString() ?? "").Trim(),
                TipEval = ToInt(rd["TIP_EVAL"]),
                Categorie = (rd["CATEGORIE"]?.ToString() ?? "").Trim(),
                ProcTva = ToDecimal(rd["PROCTVA"])
            });
        }
    }

    ReportProgress(10, $"Gestiuni exportate: {payload.Gestiuni.Count}.");
    TryExportCodDenumireTable(conn, "GRUPARI", payload.Grupari);
    // SAGA C: „Grupe articole” în GRUPE (TIP='A'); GRUPARI poate fi gol sau paralel.
    MergeArticleGroupsFromGrupe(conn, payload.Grupari);
    TryExportCodDenumireTable(conn, "CATEGORII", payload.Categorii);
    foreach (var c in payload.Categorii)
    {
        if (payload.Grupari.All(g => !string.Equals(g.Code, c.Code, StringComparison.OrdinalIgnoreCase)))
            payload.Grupari.Add(new WorkerSyncCodDenumire { Code = c.Code, Name = c.Name });
    }

    // SAGA C.3: „Grupe articole” = ART_GR (COD + DENUMIRE); prioritar față de GRUPARI/GRUPE goale.
    MergeArtGrIntoGrupari(conn, payload.Grupari);

    // Articole (GRUPA / GESTIUNE / DEN_TIP / TIP dacă există în ARTICOLE)
    {
        ReportProgress(14, "Pregătire export articole...");
        var hasGrupa = ColumnExists(conn, "ARTICOLE", "GRUPA");
        var hasGestiuneArt = ColumnExists(conn, "ARTICOLE", "GESTIUNE");
        var hasDenTip = ColumnExists(conn, "ARTICOLE", "DEN_TIP");
        var hasTipArt = ColumnExists(conn, "ARTICOLE", "TIP");
        var hasPretVTva = ColumnExists(conn, "ARTICOLE", "PRET_V_TVA");
        var sql = @"
SELECT TRIM(COD) AS COD,
       TRIM(DENUMIRE) AS DENUMIRE,
       TRIM(UM) AS UM,
       COALESCE(TVA, 0) AS TVA,
       TRIM(CATEGORIE) AS CATEGORIE,
       COALESCE(PRET_VANZ, 0) AS PRET_VANZ,
       COALESCE(BLOCAT, 0) AS BLOCAT";
        sql += hasPretVTva
            ? ", COALESCE(PRET_V_TVA, 0) AS PRET_V_TVA"
            : ", CAST(0 AS NUMERIC(18,4)) AS PRET_V_TVA";
        sql += hasGrupa
            ? ", TRIM(COALESCE(GRUPA, '')) AS GRUPA"
            : ", CAST('' AS VARCHAR(16)) AS GRUPA";
        sql += hasGestiuneArt
            ? ", TRIM(COALESCE(GESTIUNE, '')) AS GESTIUNE_ART"
            : ", CAST('' AS VARCHAR(16)) AS GESTIUNE_ART";
        sql += hasDenTip
            ? ", TRIM(COALESCE(DEN_TIP, '')) AS DEN_TIP"
            : ", CAST('' AS VARCHAR(48)) AS DEN_TIP";
        sql += hasTipArt
            ? ", TRIM(COALESCE(TIP, '')) AS TIP_SAGA"
            : ", CAST('' AS VARCHAR(4)) AS TIP_SAGA";
        sql += " FROM ARTICOLE";

        // Filtru tipuri (DEN_TIP) ales de utilizator în popup-ul de sincronizare (env SAGA_INCLUDE_DENTIP).
        // Gol => aducem toate tipurile.
        var includeDenTip = ReadIncludeDenTipFilter();
        if (hasDenTip && includeDenTip.Count > 0)
        {
            var ph = string.Join(",", includeDenTip.Select((_, i) => "@dt" + i.ToString(CultureInfo.InvariantCulture)));
            sql += " WHERE UPPER(TRIM(COALESCE(DEN_TIP, ''))) IN (" + ph + ")";
        }

        var totalArticole = EstimateArticoleCount(conn, hasDenTip, includeDenTip);
        var readArticole = 0;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        if (hasDenTip && includeDenTip.Count > 0)
        {
            for (var i = 0; i < includeDenTip.Count; i++)
                cmd.Parameters.AddWithValue("@dt" + i.ToString(CultureInfo.InvariantCulture), includeDenTip[i]);
        }
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            readArticole++;
            payload.Articole.Add(new WorkerSyncArticol
            {
                Code = (rd["COD"]?.ToString() ?? "").Trim(),
                Name = (rd["DENUMIRE"]?.ToString() ?? "").Trim(),
                Um = (rd["UM"]?.ToString() ?? "").Trim(),
                Tva = ToDecimal(rd["TVA"]),
                Categorie = (rd["CATEGORIE"]?.ToString() ?? "").Trim(),
                Grupa = (rd["GRUPA"]?.ToString() ?? "").Trim(),
                Gestiune = (rd["GESTIUNE_ART"]?.ToString() ?? "").Trim(),
                PretVanz = ResolveGrossSalePrice(ToDecimal(rd["PRET_VANZ"]), ToDecimal(rd["PRET_V_TVA"]), ToDecimal(rd["TVA"])),
                IsBlocked = ToInt(rd["BLOCAT"]) != 0,
                DenTip = (rd["DEN_TIP"]?.ToString() ?? "").Trim(),
                TipSaga = (rd["TIP_SAGA"]?.ToString() ?? "").Trim()
            });
            if (readArticole == 1 || readArticole % 100 == 0)
                ReportWeightedProgress(15, 55, readArticole, totalArticole, $"Export articole: {readArticole:N0}/{totalArticole:N0}...");
        }
        ReportProgress(70, $"Articole exportate: {payload.Articole.Count:N0}.");
    }

    // Clienti
    ReportProgress(72, "Export clienți...");
    using (var cmd = conn.CreateCommand())
    {
        cmd.CommandText = @"
SELECT TRIM(COD) AS COD,
       TRIM(DENUMIRE) AS DENUMIRE,
       TRIM(COD_FISCAL) AS COD_FISCAL,
       TRIM(REG_COM) AS REG_COM,
       TRIM(TEL) AS TEL,
       TRIM(EMAIL) AS EMAIL,
       TRIM(ADRESA) AS ADRESA,
       COALESCE(BLOCAT, 0) AS BLOCAT
FROM CLIENTI";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            payload.Clienti.Add(new WorkerSyncClient
            {
                Code = (rd["COD"]?.ToString() ?? "").Trim(),
                Name = (rd["DENUMIRE"]?.ToString() ?? "").Trim(),
                FiscalCode = (rd["COD_FISCAL"]?.ToString() ?? "").Trim(),
                RegCom = (rd["REG_COM"]?.ToString() ?? "").Trim(),
                Phone = (rd["TEL"]?.ToString() ?? "").Trim(),
                Email = (rd["EMAIL"]?.ToString() ?? "").Trim(),
                Address = (rd["ADRESA"]?.ToString() ?? "").Trim(),
                IsBlocked = ToInt(rd["BLOCAT"]) != 0
            });
        }
    }
    ReportProgress(80, $"Clienți exportați: {payload.Clienti.Count:N0}.");

    // Retete antet (ART_ANTE)
    ReportProgress(82, "Export rețete...");
    using (var cmd = conn.CreateCommand())
    {
        cmd.CommandText = @"
SELECT PK,
       TRIM(COD_ART) AS COD_ART,
       TRIM(OPERATIE) AS OPERATIE,
       TRIM(DEN_TIP) AS DEN_TIP,
       TRIM(DENUMIRE) AS DENUMIRE,
       TRIM(UM) AS UM,
       COALESCE(CANTITATE, 0) AS CANTITATE,
       TRIM(GESTIUNE) AS GESTIUNE
FROM ART_ANTE
WHERE TRIM(COD_ART) <> ''";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var op = (rd["OPERATIE"]?.ToString() ?? "").Trim();
            // În SAGA C.3, liniile de consum sunt adesea doar în ART_ANTE: OPERATIE = cod articol componentă.
            var compFromOp = op.Length > 0 && !string.Equals(op, "-", StringComparison.OrdinalIgnoreCase) ? op : "";

            var item = new WorkerSyncReteta
            {
                ArticolCode = (rd["COD_ART"]?.ToString() ?? "").Trim(),
                Operatie = op,
                Tip = (rd["DEN_TIP"]?.ToString() ?? "").Trim(),
                Name = (rd["DENUMIRE"]?.ToString() ?? "").Trim(),
                Um = (rd["UM"]?.ToString() ?? "").Trim(),
                Quantity = ToDecimal(rd["CANTITATE"]),
                Gestiune = (rd["GESTIUNE"]?.ToString() ?? "").Trim()
            };
            payload.Retete.Add(item);

            payload.RecipeLines.Add(new WorkerSyncRecipeLine
            {
                LineKey = $"ART_ANTE:{ToInt(rd["PK"])}",
                ArticolCode = item.ArticolCode,
                SourceTable = "ART_ANTE",
                Tip = item.Tip,
                Gestiune = item.Gestiune,
                Operatie = item.Operatie,
                ComponentCode = compFromOp,
                ComponentName = item.Name,
                Um = item.Um,
                Quantity = item.Quantity
            });
        }
    }

    ReportProgress(90, $"Rețete exportate: {payload.Retete.Count:N0}.");
    TryExportArtADet(conn, payload);
    ReportProgress(96, $"Linii rețetă exportate: {payload.RecipeLines.Count:N0}.");

    return new WorkerResponse
    {
        Success = true,
        FbClientPath = fbClient,
        Sync = payload
    };
    }
}

static WorkerResponse ApplyBomToSaga(string dbPath, string sagaRoot, string jsonPath, bool serverMode, string? serverHost, int serverPort)
{
    if (!serverMode && (string.IsNullOrWhiteSpace(dbPath) || !File.Exists(dbPath)))
        return new WorkerResponse { Success = false, Error = "Baza firmei nu există pe acest PC (mod local)." };

    if (serverMode && string.IsNullOrWhiteSpace(serverHost))
        return new WorkerResponse { Success = false, Error = "Host server lipsă." };

    if (serverMode && string.IsNullOrWhiteSpace(dbPath))
        return new WorkerResponse { Success = false, Error = "Calea bazei pe server lipsește." };

    if (!File.Exists(jsonPath))
        return new WorkerResponse { Success = false, Error = $"Fișier JSON inexistent: {jsonPath}" };

    BomApplyJsonDto? req;
    try
    {
        var json = File.ReadAllText(jsonPath);
        req = JsonSerializer.Deserialize<BomApplyJsonDto>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
    }
    catch (Exception ex)
    {
        return new WorkerResponse { Success = false, Error = $"JSON invalid: {ex.Message}" };
    }

    if (req?.Article == null || req.Lines == null || req.Lines.Count == 0)
        return new WorkerResponse { Success = false, Error = "JSON applybom: lipsește articolul sau liniile." };

    var useLocalOnServer = serverMode && CanOpenSagaDatabaseLocally(serverHost, sagaRoot, dbPath);
    string fbClient;
    if (serverMode && !useLocalOnServer)
    {
        fbClient = ResolveFbClientForTcp(null) ?? "";
        if (string.IsNullOrWhiteSpace(fbClient))
            return new WorkerResponse { Success = false, Error = "Nu am găsit fbclient.dll pentru mod client." };
    }
    else
    {
        fbClient = ResolveWorkingClient(dbPath, sagaRoot, out var resolveError) ?? "";
        if (string.IsNullOrWhiteSpace(fbClient))
            return new WorkerResponse { Success = false, Error = resolveError };
    }

    var a = req.Article;
    var codArt = (a.Code ?? "").Trim();
    if (string.IsNullOrEmpty(codArt))
        return new WorkerResponse { Success = false, Error = "Cod articol lipsă." };

    using var conn = serverMode && !useLocalOnServer
        ? OpenTcp(serverHost!.Trim(), serverPort <= 0 ? SagaConnectionDefaults.FirebirdServerPort : serverPort, dbPath, fbClient)
        : OpenEmbedded(dbPath, fbClient);
    using var tx = conn.BeginTransaction();

    try
    {
        using (var cmd = conn.CreateCommand())
        {
            cmd.Transaction = tx;
            cmd.CommandText = @"
UPDATE OR INSERT INTO ARTICOLE (COD, DENUMIRE, UM, TVA, CATEGORIE, PRET_VANZ, BLOCAT)
VALUES (@COD, @DEN, @UM, @TVA, @CAT, @PRET, 0)
MATCHING (COD)";
            cmd.Parameters.AddWithValue("@COD", codArt);
            cmd.Parameters.AddWithValue("@DEN", (a.Name ?? "").Trim());
            cmd.Parameters.AddWithValue("@UM", DbOrEmpty(a.Um));
            cmd.Parameters.AddWithValue("@TVA", a.Tva);
            cmd.Parameters.AddWithValue("@CAT", DbOrEmpty(a.Categorie));
            cmd.Parameters.AddWithValue("@PRET", a.PretVanz);
            cmd.ExecuteNonQuery();
        }

        var anteOk = false;
        try
        {
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = "DELETE FROM ART_ANTE WHERE COD_ART = @C";
                cmd.Parameters.AddWithValue("@C", codArt);
                cmd.ExecuteNonQuery();
            }

            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
INSERT INTO ART_ANTE (COD_ART, OPERATIE, DENUMIRE, UM, CANTITATE, GESTIUNE, DEN_TIP)
VALUES (@COD, '-', @DEN, @UM, 1, @GEST, @TIP)";
                cmd.Parameters.AddWithValue("@COD", codArt);
                cmd.Parameters.AddWithValue("@DEN", (a.Name ?? "").Trim());
                cmd.Parameters.AddWithValue("@UM", DbOrEmpty(a.Um));
                cmd.Parameters.AddWithValue("@GEST", DbOrEmpty(a.GestiuneAntet));
                var tipAnt = string.IsNullOrWhiteSpace(a.DenTipAntet) ? "PRODUSE NESTOCATE" : a.DenTipAntet.Trim();
                cmd.Parameters.AddWithValue("@TIP", tipAnt);
                cmd.ExecuteNonQuery();
            }

            anteOk = true;
        }
        catch
        {
            // Unele instalări SAGA au structură diferită pe ART_ANTE; continuăm cu rețeta detaliată.
        }

        using (var cmd = conn.CreateCommand())
        {
            cmd.Transaction = tx;
            cmd.CommandText = "DELETE FROM ART_A_DET WHERE COD_ART = @C";
            cmd.Parameters.AddWithValue("@C", codArt);
            cmd.ExecuteNonQuery();
        }

        foreach (var ln in req.Lines)
        {
            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = @"
INSERT INTO ART_A_DET (COD_ART, COD, DENUMIRE, CANTITATE, UM, GESTIUNE, DEN_TIP)
VALUES (@COD_ART, @COD, @DEN, @CANT, @UM, @GEST, @TIP)";
            cmd.Parameters.AddWithValue("@COD_ART", codArt);
            cmd.Parameters.AddWithValue("@COD", (ln.Cod ?? "").Trim());
            cmd.Parameters.AddWithValue("@DEN", (ln.Denumire ?? "").Trim());
            cmd.Parameters.AddWithValue("@CANT", ln.Cantitate);
            cmd.Parameters.AddWithValue("@UM", DbOrEmpty(ln.Um));
            cmd.Parameters.AddWithValue("@GEST", DbOrEmpty(ln.Gestiune));
            cmd.Parameters.AddWithValue("@TIP", DbOrEmpty(ln.DenTip));
            cmd.ExecuteNonQuery();
        }

        tx.Commit();
        var msg = $"ARTICOLE + {req.Lines.Count} linii ART_A_DET.";
        if (!anteOk)
            msg += " (ART_ANTE: omis — structură necunoscută sau eroare la inserare.)";
        return new WorkerResponse { Success = true, FbClientPath = fbClient, Detail = msg };
    }
    catch (Exception ex)
    {
        try { tx.Rollback(); } catch { /* ignore */ }
        return new WorkerResponse { Success = false, Error = ex.Message };
    }
}

static object DbOrEmpty(string? s)
    => string.IsNullOrWhiteSpace(s) ? DBNull.Value : s.Trim();

static int ToInt(object? value)
{
    if (value == null || value == DBNull.Value) return 0;
    return Convert.ToInt32(value, CultureInfo.InvariantCulture);
}

static decimal ToDecimal(object? value)
{
    if (value == null || value == DBNull.Value) return 0m;
    return Convert.ToDecimal(value, CultureInfo.InvariantCulture);
}

static decimal ResolveGrossSalePrice(decimal pretVanz, decimal pretVTva, decimal tva)
{
    if (pretVTva > 0)
        return Math.Round(pretVTva, 4, MidpointRounding.AwayFromZero);
    if (pretVanz <= 0)
        return 0m;

    return Math.Round(pretVanz * (1 + tva / 100m), 4, MidpointRounding.AwayFromZero);
}

static int EstimateArticoleCount(FbConnection conn, bool hasDenTip, List<string> includeDenTip)
{
    try
    {
        using var cmd = conn.CreateCommand();
        var sql = "SELECT COUNT(*) FROM ARTICOLE";
        if (hasDenTip && includeDenTip.Count > 0)
        {
            var ph = string.Join(",", includeDenTip.Select((_, i) => "@dt" + i.ToString(CultureInfo.InvariantCulture)));
            sql += " WHERE UPPER(TRIM(COALESCE(DEN_TIP, ''))) IN (" + ph + ")";
            for (var i = 0; i < includeDenTip.Count; i++)
                cmd.Parameters.AddWithValue("@dt" + i.ToString(CultureInfo.InvariantCulture), includeDenTip[i]);
        }

        cmd.CommandText = sql;
        return Math.Max(1, Convert.ToInt32(cmd.ExecuteScalar() ?? 1, CultureInfo.InvariantCulture));
    }
    catch
    {
        return 1;
    }
}

static void ReportWeightedProgress(int startPercent, int spanPercent, int current, int total, string message)
{
    total = Math.Max(1, total);
    current = Math.Max(0, Math.Min(current, total));
    var pct = startPercent + (int)Math.Round(spanPercent * (current / (double)total), MidpointRounding.AwayFromZero);
    ReportProgress(pct, message);
}

static void ReportProgress(int percent, string message)
{
    percent = Math.Max(0, Math.Min(100, percent));
    Console.Error.WriteLine($"__SMARTPUB_PROGRESS__{percent.ToString(CultureInfo.InvariantCulture)}|{message}");
    Console.Error.Flush();
}

static bool TableExists(FbConnection conn, string tableName, FbTransaction? tx = null)
{
    using var cmd = conn.CreateCommand();
    cmd.Transaction = tx;
    cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
    cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
    var x = cmd.ExecuteScalar();
    return x != null && x != DBNull.Value;
}

/// <summary>Export ART_A_DET: coloane părinte/cantitate/PK variabile între versiuni SAGA; fallback RDB$DB_KEY.</summary>
static void TryExportArtADet(FbConnection conn, WorkerSyncPayload payload)
{
    if (!TableExists(conn, "ART_A_DET"))
        return;

    var parentCol = ResolveArtADetParentCodColumn(conn);
    if (parentCol == null)
    {
        Console.Error.WriteLine("[SagaWorker] ART_A_DET: lipsește coloana articolului părinte (ex. COD_ART).");
        return;
    }

    var codCompExpr = "CAST('' AS VARCHAR(24))";
    if (ColumnExists(conn, "ART_A_DET", "COD"))
        codCompExpr = "TRIM(COALESCE(AD.COD, ''))";
    else if (ColumnExists(conn, "ART_A_DET", "COD_MAT"))
        codCompExpr = "TRIM(COALESCE(AD.COD_MAT, ''))";
    else if (ColumnExists(conn, "ART_A_DET", "COD_ARTICOL"))
        codCompExpr = "TRIM(COALESCE(AD.COD_ARTICOL, ''))";

    var denCompExpr = ColumnExists(conn, "ART_A_DET", "DENUMIRE")
        ? "TRIM(COALESCE(AD.DENUMIRE, ''))"
        : ColumnExists(conn, "ART_A_DET", "NUME")
            ? "TRIM(COALESCE(AD.NUME, ''))"
            : "CAST('' AS VARCHAR(120))";

    var denTipDetExpr = ColumnExists(conn, "ART_A_DET", "DEN_TIP")
        ? "TRIM(COALESCE(AD.DEN_TIP, ''))"
        : "CAST('' AS VARCHAR(80))";

    var qtyExpr = ResolveArtADetQtyExpr(conn);
    var umExpr = ResolveArtADetUmExpr(conn);
    var gestExpr = ResolveArtADetGestiuneExpr(conn);

    foreach (var rowIdExpr in BuildArtADetRowIdCandidates(conn))
    {
        var sql = $@"
SELECT TRIM(AD.{parentCol}) AS COD_ART,
       {rowIdExpr},
       {denTipDetExpr} AS DEN_TIP,
       {codCompExpr} AS COD_COMPONENTA,
       {denCompExpr} AS DEN_COMPONENTA,
       {qtyExpr} AS CANTITATE,
       {umExpr} AS UM,
       {gestExpr} AS GESTIUNE
FROM ART_A_DET AD
WHERE TRIM(AD.{parentCol}) <> ''";

        try
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            using var rd = cmd.ExecuteReader();
            var seq = 0;
            while (rd.Read())
            {
                seq++;
                var codArt = (rd["COD_ART"]?.ToString() ?? "").Trim();
                if (string.IsNullOrEmpty(codArt))
                    continue;

                var compCode = (rd["COD_COMPONENTA"]?.ToString() ?? "").Trim();
                var compName = (rd["DEN_COMPONENTA"]?.ToString() ?? "").Trim();
                var rowId = rd["ROW_ID"];

                var item = new WorkerSyncRetetaDet
                {
                    ArticolCode = codArt,
                    ComponentCode = compCode,
                    ComponentName = compName,
                    Quantity = ToDecimal(rd["CANTITATE"]),
                    Um = (rd["UM"]?.ToString() ?? "").Trim(),
                    Gestiune = (rd["GESTIUNE"]?.ToString() ?? "").Trim(),
                    Tip = (rd["DEN_TIP"]?.ToString() ?? "").Trim()
                };
                payload.ReteteDet.Add(item);

                payload.RecipeLines.Add(new WorkerSyncRecipeLine
                {
                    LineKey = BuildArtADetLineKey(rowId, seq, codArt, compCode),
                    ArticolCode = item.ArticolCode,
                    SourceTable = "ART_A_DET",
                    Tip = item.Tip,
                    Gestiune = item.Gestiune,
                    Operatie = "",
                    ComponentCode = item.ComponentCode,
                    ComponentName = item.ComponentName,
                    Um = item.Um,
                    Quantity = item.Quantity
                });
            }

            return;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[SagaWorker] ART_A_DET ({rowIdExpr}): {ex.Message}");
        }
    }
}

static string? ResolveArtADetParentCodColumn(FbConnection conn)
{
    foreach (var c in new[] { "COD_ART", "CODART" })
    {
        if (ColumnExists(conn, "ART_A_DET", c))
            return c;
    }

    return null;
}

static string ResolveArtADetQtyExpr(FbConnection conn)
{
    if (ColumnExists(conn, "ART_A_DET", "CANTITATE"))
        return "COALESCE(AD.CANTITATE, 0)";
    if (ColumnExists(conn, "ART_A_DET", "CANT"))
        return "COALESCE(AD.CANT, 0)";
    if (ColumnExists(conn, "ART_A_DET", "QTY"))
        return "COALESCE(AD.QTY, 0)";
    return "CAST(0 AS NUMERIC(18,6))";
}

static string ResolveArtADetUmExpr(FbConnection conn)
    => ColumnExists(conn, "ART_A_DET", "UM")
        ? "TRIM(COALESCE(AD.UM, ''))"
        : "CAST('' AS VARCHAR(16))";

static string ResolveArtADetGestiuneExpr(FbConnection conn)
    => ColumnExists(conn, "ART_A_DET", "GESTIUNE")
        ? "TRIM(COALESCE(AD.GESTIUNE, ''))"
        : "CAST('' AS VARCHAR(16))";

static IEnumerable<string> BuildArtADetRowIdCandidates(FbConnection conn)
{
    if (ColumnExists(conn, "ART_A_DET", "PK"))
        yield return "AD.PK AS ROW_ID";
    if (ColumnExists(conn, "ART_A_DET", "ID"))
        yield return "AD.ID AS ROW_ID";
    if (ColumnExists(conn, "ART_A_DET", "NR"))
        yield return "AD.NR AS ROW_ID";
    yield return "AD.RDB$DB_KEY AS ROW_ID";
    yield return "RDB$DB_KEY AS ROW_ID";
}

static string BuildArtADetLineKey(object? rowId, int seq, string codArt, string compCode)
{
    if (rowId != null && rowId != DBNull.Value)
    {
        if (rowId is byte[] bytes && bytes.Length > 0)
        {
            var hex = Convert.ToHexString(bytes).ToLowerInvariant();
            if (hex.Length > 48)
                hex = hex[..48];
            return $"ART_A_DET:{hex}";
        }

        try
        {
            var n = Convert.ToInt64(rowId, CultureInfo.InvariantCulture);
            if (n != 0)
                return $"ART_A_DET:{n}";
        }
        catch
        {
            // fall through
        }
    }

    var mix = $"{codArt}|{compCode}|{seq}".GetHashCode();
    return $"ART_A_DET:s{seq:x6}:{(uint)mix:x8}";
}

static void TryExportCodDenumireTable(FbConnection conn, string table, List<WorkerSyncCodDenumire> target)
{
    if (!TableExists(conn, table))
        return;

    var queries = new[]
    {
        $"SELECT TRIM(COD) AS C, TRIM(DENUMIRE) AS D FROM {table}",
        $"SELECT TRIM(COD) AS C, TRIM(COALESCE(DENUMIRE, NUME, '')) AS D FROM {table}"
    };

    foreach (var sql in queries)
    {
        try
        {
            var before = target.Count;
            using var cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var code = (rd["C"]?.ToString() ?? "").Trim();
                if (string.IsNullOrEmpty(code))
                    continue;
                var name = (rd["D"]?.ToString() ?? "").Trim();
                if (target.Any(x => string.Equals(x.Code, code, StringComparison.OrdinalIgnoreCase)))
                    continue;
                target.Add(new WorkerSyncCodDenumire { Code = code, Name = name });
            }

            if (target.Count > before)
                return;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[SagaWorker] Export {table}: {ex.Message}");
        }
    }
}

/// <summary>
/// Îmbogățește lista de grupuri cu <c>GRUPE</c>. Prioritate: rânduri al căror COD e folosit în <c>ARTICOLE.GRUPA</c> (merge și când <c>TIP</c> nu e 'A').
/// Apoi catalog <c>TIP='A'</c>. Variante coloane denumire: DENUMIRE, NUME; cod: COD sau CODE.
/// </summary>
static void MergeArticleGroupsFromGrupe(FbConnection conn, List<WorkerSyncCodDenumire> target)
{
    if (!TableExists(conn, "GRUPE"))
        return;

    var codCol = ColumnExists(conn, "GRUPE", "COD") ? "COD" : ColumnExists(conn, "GRUPE", "CODE") ? "CODE" : null;
    if (codCol == null)
        return;

    var hasNume = ColumnExists(conn, "GRUPE", "NUME");
    var hasDen = ColumnExists(conn, "GRUPE", "DENUMIRE");
    string DenPlain()
    {
        if (hasDen && hasNume)
            return "TRIM(COALESCE(DENUMIRE, NUME, ''))";
        if (hasDen)
            return "TRIM(COALESCE(DENUMIRE, ''))";
        if (hasNume)
            return "TRIM(COALESCE(NUME, ''))";
        return "CAST('' AS VARCHAR(120))";
    }

    string DenAlias(string alias)
    {
        var p = alias + ".";
        if (hasDen && hasNume)
            return $"TRIM(COALESCE({p}DENUMIRE, {p}NUME, ''))";
        if (hasDen)
            return $"TRIM(COALESCE({p}DENUMIRE, ''))";
        if (hasNume)
            return $"TRIM(COALESCE({p}NUME, ''))";
        return "CAST('' AS VARCHAR(120))";
    }

    void Upsert(string code, string name)
    {
        if (string.IsNullOrWhiteSpace(code))
            return;
        var existing = target.FirstOrDefault(x =>
            string.Equals(x.Code, code, StringComparison.OrdinalIgnoreCase));
        if (existing == null)
            target.Add(new WorkerSyncCodDenumire { Code = code, Name = name });
        else if (!string.IsNullOrWhiteSpace(name))
            existing.Name = name;
    }

    void RunQuery(string sql)
    {
        try
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var code = (rd["C"]?.ToString() ?? "").Trim();
                var name = (rd["D"]?.ToString() ?? "").Trim();
                Upsert(code, name);
            }
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[SagaWorker] Merge GRUPE: {ex.Message}");
        }
    }

    var dPlain = DenPlain();
    var dG = DenAlias("G");

    // 1) Orice grupă din GRUPE folosită pe articole — nu depinde de TIP (multe baze au TIP diferit de 'A').
    if (TableExists(conn, "ARTICOLE") && ColumnExists(conn, "ARTICOLE", "GRUPA"))
    {
        RunQuery($@"
SELECT TRIM(G.{codCol}) AS C, {dG} AS D
FROM GRUPE G
WHERE EXISTS (
  SELECT 1 FROM ARTICOLE A
  WHERE TRIM(COALESCE(A.GRUPA, '')) = TRIM(G.{codCol}))");
    }

    // 2) Catalog „Grupe articole” când TIP marchează articolele (completează grupe fără articole încă)
    if (ColumnExists(conn, "GRUPE", "TIP"))
    {
        RunQuery($@"
SELECT TRIM({codCol}) AS C, {dPlain} AS D
FROM GRUPE
WHERE UPPER(TRIM(COALESCE(TIP, ''))) = 'A'");
    }
}

/// <summary>
/// SAGA C.3: tabelul <c>ART_GR</c> (aceeași sursă ca în isql: COD, DENUMIRE). Actualizează sau adaugă în lista de grupuri.
/// </summary>
static void MergeArtGrIntoGrupari(FbConnection conn, List<WorkerSyncCodDenumire> target)
{
    if (!TableExists(conn, "ART_GR"))
        return;

    var hasNume = ColumnExists(conn, "ART_GR", "NUME");
    var denExpr = hasNume
        ? "TRIM(COALESCE(DENUMIRE, NUME, ''))"
        : "TRIM(COALESCE(DENUMIRE, ''))";

    try
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = $@"
SELECT TRIM(COD) AS C, {denExpr} AS D
FROM ART_GR
WHERE TRIM(COALESCE(COD, '')) <> ''";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var code = (rd["C"]?.ToString() ?? "").Trim();
            var name = (rd["D"]?.ToString() ?? "").Trim();
            if (string.IsNullOrEmpty(code))
                continue;
            var existing = target.FirstOrDefault(x =>
                string.Equals(x.Code, code, StringComparison.OrdinalIgnoreCase));
            if (existing == null)
                target.Add(new WorkerSyncCodDenumire { Code = code, Name = name });
            else if (!string.IsNullOrWhiteSpace(name))
                existing.Name = name;
        }
    }
    catch (Exception ex)
    {
        Console.Error.WriteLine($"[SagaWorker] Merge ART_GR: {ex.Message}");
    }
}

static bool ColumnExists(FbConnection conn, string table, string column, FbTransaction? tx = null)
{
    using var cmd = conn.CreateCommand();
    cmd.Transaction = tx;
    cmd.CommandText = @"
SELECT 1 FROM RDB$RELATION_FIELDS
WHERE TRIM(RDB$RELATION_NAME) = @T AND TRIM(RDB$FIELD_NAME) = @C ROWS 1";
    cmd.Parameters.AddWithValue("@T", table.Trim().ToUpperInvariant());
    cmd.Parameters.AddWithValue("@C", column.Trim().ToUpperInvariant());
    var x = cmd.ExecuteScalar();
    return x != null && x != DBNull.Value;
}

static string CombineServerPath(string root, string fileName)
{
    var r = root.Trim().TrimEnd('\\', '/');
    var f = fileName.TrimStart('\\', '/');
    return r + "\\" + f;
}

/// <summary>Dacă utilizatorul pune calea la CONFIG.FDB în loc de folderul SAGA, folosim folderul părinte.</summary>
static string NormalizeSagaRootFolder(string sagaRootOnServer)
{
    var t = (sagaRootOnServer ?? "").Trim().TrimEnd('\\', '/');
    if (t.Length == 0)
        return t;
    var fn = Path.GetFileName(t);
    if (fn.Equals("CONFIG.FDB", StringComparison.OrdinalIgnoreCase))
    {
        var parent = Path.GetDirectoryName(t);
        return string.IsNullOrEmpty(parent) ? t : parent;
    }

    return t;
}

/// <summary>True dacă host-ul e mașina curentă (127.0.0.1, localhost, IP LAN, nume PC).</summary>
static bool IsLocalSagaServerHost(string host)
{
    if (string.IsNullOrWhiteSpace(host))
        return false;

    var h = host.Trim();
    if (h.Equals("127.0.0.1", StringComparison.OrdinalIgnoreCase)) return true;
    if (h.Equals("localhost", StringComparison.OrdinalIgnoreCase)) return true;
    if (h.Equals("::1", StringComparison.OrdinalIgnoreCase)) return true;

    try
    {
        if (h.Equals(Dns.GetHostName(), StringComparison.OrdinalIgnoreCase))
            return true;
    }
    catch
    {
        /* ignore */
    }

    try
    {
        foreach (var addr in Dns.GetHostAddresses(Dns.GetHostName()))
        {
            if (addr.AddressFamily == AddressFamily.InterNetwork &&
                h.Equals(addr.ToString(), StringComparison.OrdinalIgnoreCase))
                return true;
        }
    }
    catch
    {
        /* ignore */
    }

    return false;
}

/// <summary>Pe serverul SAGA, fișierele .fdb sunt locale — deschidere directă, ca isql fără host/port.</summary>
static bool CanOpenSagaDatabaseLocally(string? serverHost, string sagaRootPath, string databaseOnServer)
{
    if (!IsLocalSagaServerHost(serverHost ?? ""))
        return false;

    var root = NormalizeSagaRootFolder(sagaRootPath);
    if (!File.Exists(Path.Combine(root, "CONFIG.FDB")))
        return false;

    var path = databaseOnServer.Trim().Replace('/', Path.DirectorySeparatorChar);
    return path.Length >= 3 && path.Contains(':', StringComparison.Ordinal) && File.Exists(path);
}

static string? ResolveCompanyDbPathForServer(string sagaRootOnServer, string folder, string dbd)
{
    var root = NormalizeSagaRootFolder(sagaRootOnServer);
    if (!string.IsNullOrWhiteSpace(dbd))
    {
        var d = dbd.Trim().Replace('/', '\\');
        if (d.Contains(":\\", StringComparison.Ordinal) || d.StartsWith("\\\\", StringComparison.Ordinal))
            return d;
        if (string.IsNullOrWhiteSpace(root))
            return d;
        return CombineServerPath(root, d);
    }

    if (string.IsNullOrWhiteSpace(root) || string.IsNullOrWhiteSpace(folder))
        return null;

    var f = folder.Trim();
    return CombineServerPath(CombineServerPath(root, f), "CONT_BAZA.FDB");
}

static string? ResolveFbClientForTcp(string? preferredPath) =>
    SagaFbClientLocator.GetTcpProbeOrder(preferredPath).FirstOrDefault();

static string QuoteAdoConnectionValue(string v) =>
    "\"" + (v ?? "").Replace("\"", "\"\"", StringComparison.Ordinal) + "\"";

// TCP: Database = host/port:'C:/cale/cu spații'. Nu setăm FIREBIRD — firebird.conf din folderul clientului poate forța WireCrypt
// și intră în conflict cu stringul de conexiune (335544721 / negociere stricată).
// Încercăm mai întâi fbclient din aceeași instalare ca serverul (Firebird30_Saga), apoi PubLine — același build ca serverul reduce erori WireCrypt.
static FbConnection OpenTcp(string host, int port, string databaseOnServer, string? fbClientPath)
{
    var h = (host ?? "").Trim();
    if (string.IsNullOrWhiteSpace(h))
        throw new InvalidOperationException("Host Firebird lipsește.");

    var dbRaw = (databaseOnServer ?? "").Trim();
    if (string.IsNullOrWhiteSpace(dbRaw))
        throw new InvalidOperationException("Calea bazei pe server lipsește.");

    var p = port <= 0 ? SagaConnectionDefaults.FirebirdServerPort : port;

    var allErrors = new List<string>();

    foreach (var fb in EnumerateTcpFbClientPaths(fbClientPath))
    {
        var fbLabel = Path.GetFileName(Path.GetDirectoryName(fb)) ?? fb;
        var errors = new List<string>();
        if (TryOpenTcpSingleClient(h, p, dbRaw, fb, errors, out var conn) && conn != null)
            return conn;
        foreach (var e in errors)
            allErrors.Add($"[{fbLabel}] {e}");
    }

    if (allErrors.Count == 0)
        throw new InvalidOperationException("Nu am găsit niciun fbclient.dll pentru mod client.");
    throw new InvalidOperationException(string.Join(" | ", allErrors));
}

static IEnumerable<string> EnumerateTcpFbClientPaths(string? preferredFromCaller) =>
    SagaFbClientLocator.GetTcpProbeOrder(preferredFromCaller);

static bool TryOpenTcpSingleClient(
    string h, int p, string databaseOnServer, string fb, List<string> errors, out FbConnection? conn)
{
    conn = null;
    var pathSlash = databaseOnServer.Replace('\\', '/');
    var filePart = pathSlash.Contains(' ', StringComparison.Ordinal) || pathSlash.Contains('\'', StringComparison.Ordinal)
        ? "'" + pathSlash.Replace("'", "''", StringComparison.Ordinal) + "'"
        : pathSlash;
    var dbSpec = h + "/" + p.ToString(CultureInfo.InvariantCulture) + ":" + filePart;
    var dbQ = QuoteAdoConnectionValue(dbSpec);
    var fbQ = QuoteAdoConnectionValue(fb);

    // PubLine pe Windows folosește des Win_Sspi (fără user/parolă Firebird). isql: același lucru cu -trust.
    // ISC_* în mediu blochează trusted — le golim înainte.
    Environment.SetEnvironmentVariable("ISC_USER", null);
    Environment.SetEnvironmentVariable("ISC_PASSWORD", null);

    // Prima încercare: același model ca isql care a fost validat manual.
    // 127.0.0.1/3060:C:\...\CONT_BAZA.FDB + SYSDBA/masterkey, cu home-ul clientului Firebird 3 explicit.
    var previousFirebirdHome = Environment.GetEnvironmentVariable("FIREBIRD");
    var firebirdHome = Path.GetDirectoryName(fb);
    if (!string.IsNullOrWhiteSpace(firebirdHome))
        Environment.SetEnvironmentVariable("FIREBIRD", firebirdHome);

    try
    {
        var csb = new FbConnectionStringBuilder
        {
            UserID = "SYSDBA",
            Password = "masterkey",
            DataSource = h,
            Port = p,
            Database = databaseOnServer,
            Charset = "WIN1252",
            Dialect = 3,
            Pooling = false,
            ServerType = FbServerType.Default,
            ClientLibrary = fb,
            WireCrypt = FbWireCrypt.Disabled
        };
        var c = new FbConnection(csb.ConnectionString);
        c.Open();
        conn = c;
        return true;
    }
    catch (Exception ex)
    {
        errors.Add($"[isql equivalent Disabled] {ex.Message}");
    }
    finally
    {
        Environment.SetEnvironmentVariable("FIREBIRD", previousFirebirdHome);
    }

    foreach (var (wireSuffix, wireLabel) in new (string suffix, string label)[]
             {
                 (";WireCrypt=Enabled", "Enabled"),
                 (";WireCrypt=Required", "Required"),
                 ("", "implicit")
             })
    {
        try
        {
            var cs =
                "Database=" + dbQ + ";" +
                "Charset=WIN1252;Dialect=3;Pooling=False;ServerType=0" +
                wireSuffix + ";" +
                "ClientLibrary=" + fbQ;
            var c = new FbConnection(cs);
            c.Open();
            conn = c;
            return true;
        }
        catch (Exception ex)
        {
            errors.Add($"[trusted Win_Sspi composite {wireLabel}] {ex.Message}");
        }
    }

    try
    {
        var csb = new FbConnectionStringBuilder
        {
            DataSource = h,
            Port = p,
            Database = pathSlash,
            Charset = "WIN1252",
            Dialect = 3,
            Pooling = false,
            ServerType = FbServerType.Default,
            ClientLibrary = fb,
            WireCrypt = FbWireCrypt.Enabled
        };
        csb.Remove("User ID");
        csb.Remove("Password");
        var c = new FbConnection(csb.ConnectionString);
        c.Open();
        conn = c;
        return true;
    }
    catch (Exception ex)
    {
        errors.Add($"[trusted builder Enabled] {ex.Message}");
    }

    foreach (var (wireSuffix, wireLabel) in new (string suffix, string label)[]
             {
                 (";WireCrypt=Required", "Required"),
                 (";WireCrypt=Enabled", "Enabled"),
                 ("", "implicit"),
                 (";WireCrypt=Disabled", "Disabled")
             })
    {
        var cs =
            "User=SYSDBA;Password=masterkey;" +
            "Database=" + dbQ + ";" +
            "Charset=WIN1252;Dialect=3;Pooling=False;ServerType=0" +
            wireSuffix + ";" +
            "ClientLibrary=" + fbQ;
        try
        {
            var c = new FbConnection(cs);
            c.Open();
            conn = c;
            return true;
        }
        catch (Exception ex)
        {
            errors.Add($"[composite {wireLabel}] {ex.Message}");
        }
    }

    foreach (var wc in new[] { FbWireCrypt.Required, FbWireCrypt.Enabled, FbWireCrypt.Disabled })
    {
        try
        {
            var csb = new FbConnectionStringBuilder
            {
                UserID = "SYSDBA",
                Password = "masterkey",
                DataSource = h,
                Port = p,
                Database = databaseOnServer,
                Charset = "WIN1252",
                Dialect = 3,
                Pooling = false,
                ServerType = FbServerType.Default,
                ClientLibrary = fb,
                WireCrypt = wc
            };
            var c = new FbConnection(csb.ConnectionString);
            c.Open();
            conn = c;
            return true;
        }
        catch (Exception ex)
        {
            errors.Add($"[DataSource+Port {wc}] {ex.Message}");
        }
    }

    return false;
}

static FbConnection OpenEmbedded(string dbPath, string fbClientPath)
{
    var cs = new FbConnectionStringBuilder
    {
        Database = dbPath,
        UserID = "SYSDBA",
        Password = "masterkey",
        ServerType = FbServerType.Embedded,
        ClientLibrary = fbClientPath,
        Pooling = false,
        Dialect = 3,
        Charset = "WIN1252"
    };

    var conn = new FbConnection(cs.ToString());
    conn.Open();
    return conn;
}

static WorkerResponse IesiriTransferFromJsonFile(string jsonPath)
{
    if (string.IsNullOrWhiteSpace(jsonPath) || !File.Exists(jsonPath))
        return new WorkerResponse { Success = false, Error = "Lipsește fișierul JSON pentru transfer IESIRI." };

    IesiriTransferJsonDto? dto;
    try
    {
        var json = File.ReadAllText(jsonPath);
        dto = JsonSerializer.Deserialize<IesiriTransferJsonDto>(json,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
    }
    catch (Exception ex)
    {
        return new WorkerResponse { Success = false, Error = "JSON invalid: " + ex.Message };
    }

    if (dto == null || string.IsNullOrWhiteSpace(dto.SagaDbPath))
        return new WorkerResponse { Success = false, Error = "SagaDbPath lipsește." };

    var serverMode = string.Equals(dto.ConnectionMode, "SERVER", StringComparison.OrdinalIgnoreCase);
    if (!serverMode && !File.Exists(dto.SagaDbPath))
        return new WorkerResponse { Success = false, Error = "SagaDbPath invalid sau fișier lipsă (mod local)." };

    if (dto.Header == null || dto.Lines == null || dto.Lines.Count == 0)
        return new WorkerResponse { Success = false, Error = "Antet sau linii lipsă în JSON." };

    var root = string.IsNullOrWhiteSpace(dto.SagaRootPath)
        ? GuessSagaRoot(dto.SagaDbPath)
        : dto.SagaRootPath.Trim();

    var host = (dto.ServerHost ?? "").Trim();
    var port = dto.ServerPort is > 0 and var sp ? sp : SagaConnectionDefaults.FirebirdServerPort;
    var sagaDb = dto.SagaDbPath.Trim();

    if (serverMode && string.IsNullOrWhiteSpace(host))
        return new WorkerResponse { Success = false, Error = "Pentru mod SERVER lipsește serverHost." };

    var fb = "";
    try
    {
        using var saga = OpenCompanyConnection(sagaDb, root, serverMode, host, port, out fb);
        var clientCode = string.IsNullOrWhiteSpace(dto.DefaultClientCode) ? "00001" : dto.DefaultClientCode.Trim();
        RunIesiriInsert(saga, dto.Header, dto.Lines, clientCode, out var idIes, out var nrIes);
        return new WorkerResponse
        {
            Success = true,
            FbClientPath = fb,
            IdIesire = idIes,
            NrIesire = nrIes,
            Detail = "Transfer IESIRI/IES_DET reușit."
        };
    }
    catch (Exception ex)
    {
        return new WorkerResponse { Success = false, Error = ex.Message, FbClientPath = fb };
    }
}

static string GuessSagaRoot(string dbPath)
{
    try
    {
        var dir = Path.GetDirectoryName(dbPath);
        if (string.IsNullOrWhiteSpace(dir))
            return @"C:\";
        var parent = Directory.GetParent(dir)?.FullName;
        return string.IsNullOrWhiteSpace(parent) ? dir : parent;
    }
    catch
    {
        return @"C:\";
    }
}

static void RunIesiriInsert(
    FbConnection saga,
    IesiriHeaderJsonDto header,
    List<IesiriLineJsonDto> lines,
    string defaultClientCode,
    out decimal idIesireOut,
    out string nrIesireOut)
{
    var (clientCod, clientDen) = LoadClientIesiri(saga, defaultClientCode);
    if (string.IsNullOrWhiteSpace(clientCod))
        clientCod = defaultClientCode;
    if (string.IsNullOrWhiteSpace(clientDen))
        clientDen = "VANZARI POS";

    var tip = NormalizeIesiriTip(header.DocumentTip);
    var isBonFiscal = tip == "B";
    var docDate = header.PaidAt.Date;
    var sumNet = header.Valoare;
    var sumVat = header.ValoareTva;
    var sumTot = header.Total;
    var tvai = sumVat > 0 ? 1 : 0;
    var transferAccount = (header.TransferAccount ?? "").Trim();
    if (isBonFiscal && string.IsNullOrWhiteSpace(transferAccount))
        throw new InvalidOperationException("Cont încasare lipsă pentru bon fiscal SAGA (IESIRI.CONT_CLI). Verificați maparea modului de încasare.");
    // PubLine-style: bon fiscal (B) are contul de încasare completat, dar rămâne nevalidat în SAGA.
    var neachitat = 0m;
    var contClient = isBonFiscal ? transferAccount : "";
    var contDebit = isBonFiscal ? "" : transferAccount;
    var validat = "";
    var nrBonuri = header.BonCount > 0 ? header.BonCount : 0;

    decimal nextId;
    using (var mx = saga.CreateCommand())
    {
        mx.CommandText = "SELECT COALESCE(MAX(ID_IESIRE), 0) + 1 FROM IESIRI";
        nextId = Convert.ToDecimal(mx.ExecuteScalar() ?? 1m);
    }

    using var tx = saga.BeginTransaction();
    try
    {
        var nrIesire = isBonFiscal
            ? AllocateBonFiscalNumber(saga, tx, header.SerieBonuri)
            : SagaIesiriInsertHelpers.Truncate($"SP{header.OrderNo:000000}", SagaIesiriInsertHelpers.IesiriCol("NR_IESIRE"));
        var comanda = isBonFiscal
            ? SagaIesiriInsertHelpers.Truncate(docDate.ToString("yyyyMMdd"), SagaIesiriInsertHelpers.IesiriCol("COMANDA"))
            : SagaIesiriInsertHelpers.Truncate("SP-" + header.OrderNo, SagaIesiriInsertHelpers.IesiriCol("COMANDA"));

        using (var ins = saga.CreateCommand())
        {
            ins.Transaction = tx;
            ins.CommandText = @"
INSERT INTO IESIRI (
  NR_IESIRE, ID_IESIRE, COD, DENUMIRE, TVAI, DATA, SCADENT,
  BAZA_TVA, TVA, VALIDAT, TOTAL, NEACHITAT, ADAOS,
  CONT_CLI, AGENT, DEN_AGENT, TIP, ACCIZE,
  CONT_D_A, CONT_C_A, COMANDA, TIPARIT, CURS_REF, DATA_DOC,
  INF_SUPLM, NR_BONURI, ID_ADRLIV, RECIPISA, IS_EF, ID_SOLICIT, TIP_O
) VALUES (
  @NR, @ID, @CC, @CD, @TVAI, @DT, @DT,
  @BAZA, @TVA, @VALIDAT, @TOT, @NEACH, 0,
  @CONT_CLI, '', '', @TIP, 0,
  @CONT_D_A, '', @COM, 0, 0, NULL,
  @INF, @NRB, 0, '', 0, '', ''
)";
            SagaIesiriInsertHelpers.AddVarChar(ins, "@NR", nrIesire, SagaIesiriInsertHelpers.IesiriCol("NR_IESIRE"));
            SagaIesiriInsertHelpers.AddNumeric(ins, "@ID", nextId, 10, 0);
            SagaIesiriInsertHelpers.AddVarChar(ins, "@CC", clientCod, SagaIesiriInsertHelpers.IesiriCol("COD"));
            SagaIesiriInsertHelpers.AddVarChar(ins, "@CD", clientDen, SagaIesiriInsertHelpers.IesiriCol("DENUMIRE"));
            SagaIesiriInsertHelpers.AddSmallInt(ins, "@TVAI", tvai);
            SagaIesiriInsertHelpers.AddDate(ins, "@DT", docDate);
            SagaIesiriInsertHelpers.AddNumeric(ins, "@BAZA", sumNet, 15, 2);
            SagaIesiriInsertHelpers.AddNumeric(ins, "@TVA", sumVat, 15, 2);
            SagaIesiriInsertHelpers.AddVarChar(ins, "@VALIDAT", validat, 1);
            SagaIesiriInsertHelpers.AddNumeric(ins, "@TOT", sumTot, 15, 2);
            SagaIesiriInsertHelpers.AddNumeric(ins, "@NEACH", neachitat, 15, 2);
            SagaIesiriInsertHelpers.AddVarChar(ins, "@CONT_CLI", contClient, SagaIesiriInsertHelpers.IesiriCol("CONT_CLI"));
            SagaIesiriInsertHelpers.AddVarChar(ins, "@TIP", tip, SagaIesiriInsertHelpers.IesiriCol("TIP"));
            SagaIesiriInsertHelpers.AddVarChar(ins, "@CONT_D_A", contDebit, SagaIesiriInsertHelpers.IesiriCol("CONT_D_A"));
            SagaIesiriInsertHelpers.AddVarChar(ins, "@COM", comanda, SagaIesiriInsertHelpers.IesiriCol("COMANDA"));
            SagaIesiriInsertHelpers.AddVarChar(ins, "@INF", BuildIesiriInfo(header), SagaIesiriInsertHelpers.IesiriCol("INF_SUPLM"));
            SagaIesiriInsertHelpers.AddNumeric(ins, "@NRB", nrBonuri, 5, 0);
            try
            {
                ins.ExecuteNonQuery();
            }
            catch (Exception ex) when (SagaIesiriInsertHelpers.IsStringTruncation(ex))
            {
                throw new InvalidOperationException(
                    $"Antet IESIRI (client {SagaIesiriInsertHelpers.Truncate(clientCod, 8)} / {SagaIesiriInsertHelpers.Truncate(clientDen, 40)}): {ex.Message}",
                    ex);
            }
        }

        foreach (var ln in lines)
        {
            var code = (ln.ProductCode ?? "").Trim();
            var (denTip, denArt, umArt, gestArt, denGestArt) = LookupSagaArticol(saga, tx, code);
            if (string.IsNullOrWhiteSpace(denArt))
                denArt = ln.ProductName ?? "";
            if (string.IsNullOrWhiteSpace(denTip))
                denTip = "Nedefinit";
            if (string.IsNullOrWhiteSpace(umArt))
                umArt = ln.Um ?? "";
            var gestiune = string.IsNullOrWhiteSpace(ln.CodGestiune) ? gestArt : ln.CodGestiune;
            var denGest = string.IsNullOrWhiteSpace(ln.DenGest) ? denGestArt : ln.DenGest;
            gestiune = NormalizeGestiuneCode(gestiune, SagaIesiriInsertHelpers.DetCol("GESTIUNE"));
            if (string.IsNullOrWhiteSpace(gestiune))
                throw new InvalidOperationException(
                    $"Gestiune lipsă pentru articolul {code} - {denArt}. Verificați în SAGA ARTICOLE/ART_ANTE sau resincornizați nomenclatorul.");

            try
            {
                using var insD = saga.CreateCommand();
                insD.Transaction = tx;
                insD.CommandText = @"
INSERT INTO IES_DET (
  ID_IESIRE, GESTIUNE, DEN_GEST, COD, DENUMIRE, DEN_TIP, UM, TVA_ART,
  CANTITATE, PRET_UNITAR, PU_TVA, VALOARE, TVA_DED, TOTAL, ADAOS, CONT,
  TEXT_SUPL, DISCOUNT, NR_STORNO, ID_U
) VALUES (
  @IDI, @G, @DG, @COD, @DEN, @DT, @UM, @TVA,
  @CANT, @PU, 0, @VAL, @VTVA, @TOT, 0, @CONT,
  '', 0, '', 0
)";
                var contVenit = SagaIesiriInsertHelpers.LookupContVenit(saga, tx, code);
                SagaIesiriInsertHelpers.AddNumeric(insD, "@IDI", nextId, 10, 0);
                SagaIesiriInsertHelpers.AddVarChar(insD, "@G", gestiune, SagaIesiriInsertHelpers.DetCol("GESTIUNE"));
                SagaIesiriInsertHelpers.AddVarChar(insD, "@DG", denGest, SagaIesiriInsertHelpers.DetCol("DEN_GEST"));
                SagaIesiriInsertHelpers.AddVarChar(insD, "@COD", code, SagaIesiriInsertHelpers.DetCol("COD"));
                SagaIesiriInsertHelpers.AddVarChar(insD, "@DEN", denArt, SagaIesiriInsertHelpers.DetCol("DENUMIRE"));
                SagaIesiriInsertHelpers.AddVarChar(insD, "@DT", denTip, SagaIesiriInsertHelpers.DetCol("DEN_TIP"));
                SagaIesiriInsertHelpers.AddVarChar(insD, "@UM", umArt, SagaIesiriInsertHelpers.DetCol("UM"));
                SagaIesiriInsertHelpers.AddSmallInt(insD, "@TVA", (int)Math.Round(ln.TvaPct, 0, MidpointRounding.AwayFromZero));
                SagaIesiriInsertHelpers.AddNumeric(insD, "@CANT", ln.Qty, 14, 3);
                SagaIesiriInsertHelpers.AddNumeric(insD, "@PU", ln.UnitPrice, 16, 4);
                SagaIesiriInsertHelpers.AddNumeric(insD, "@VAL", ln.Valoare, 15, 2);
                SagaIesiriInsertHelpers.AddNumeric(insD, "@VTVA", ln.ValoareTva, 15, 2);
                SagaIesiriInsertHelpers.AddNumeric(insD, "@TOT", ln.Total, 15, 2);
                SagaIesiriInsertHelpers.AddVarChar(insD, "@CONT", contVenit, SagaIesiriInsertHelpers.DetCol("CONT"));
                insD.ExecuteNonQuery();
            }
            catch (Exception ex) when (SagaIesiriInsertHelpers.IsStringTruncation(ex))
            {
                throw new InvalidOperationException(
                    $"Articol {SagaIesiriInsertHelpers.Truncate(code, 16)} ({SagaIesiriInsertHelpers.Truncate(denArt, 40)}): text prea lung pentru IES_DET în SAGA. {ex.Message}",
                    ex);
            }
        }

        tx.Commit();
        idIesireOut = nextId;
        nrIesireOut = nrIesire.Trim();
    }
    catch
    {
        tx.Rollback();
        throw;
    }
}

static (string Cod, string Den) LoadClientIesiri(FbConnection saga, string cod)
{
    using var cmd = saga.CreateCommand();
    cmd.CommandText = @"
SELECT TRIM(COD), TRIM(DENUMIRE) FROM CLIENTI WHERE TRIM(COD) = TRIM(@C) ROWS 1";
    cmd.Parameters.AddWithValue("@C", cod.Trim());
    using var rd = cmd.ExecuteReader();
    if (!rd.Read())
        return ("", "");
    return ((rd[0]?.ToString() ?? "").Trim(), (rd[1]?.ToString() ?? "").Trim());
}

static string NormalizeIesiriTip(string? tip)
{
    var t = (tip ?? "B").Trim().ToUpperInvariant();
    return t.Length == 0 ? "B" : t[..1];
}

/// <summary>PubLine: bon fiscal tip B cu număr secvențial (ex. 479), opțional prefix din seria de bonuri.</summary>
static string AllocateBonFiscalNumber(FbConnection saga, FbTransaction tx, string? serieBon)
{
    var serie = (serieBon ?? "").Trim().ToUpperInvariant();
    var maxNum = 0;
    using var cmd = saga.CreateCommand();
    cmd.Transaction = tx;
    cmd.CommandText = @"SELECT TRIM(NR_IESIRE) FROM IESIRI WHERE TRIM(TIP) = 'B'";
    using var rd = cmd.ExecuteReader();
    while (rd.Read())
    {
        var nr = (rd[0]?.ToString() ?? "").Trim();
        if (nr.Length == 0)
            continue;

        if (serie.Length > 0)
        {
            if (!nr.StartsWith(serie, StringComparison.OrdinalIgnoreCase))
                continue;
            var suffix = nr[serie.Length..];
            if (int.TryParse(suffix, NumberStyles.Integer, CultureInfo.InvariantCulture, out var n) && n > maxNum)
                maxNum = n;
        }
        else if (int.TryParse(nr, NumberStyles.Integer, CultureInfo.InvariantCulture, out var n2) && n2 > maxNum)
        {
            maxNum = n2;
        }
    }

    var next = maxNum + 1;
    var numPart = next.ToString(CultureInfo.InvariantCulture);
    if (serie.Length == 0)
        return TruncateIesiri(numPart, 16);

    var maxPrefix = Math.Max(0, 16 - numPart.Length);
    if (serie.Length > maxPrefix)
        serie = serie[..maxPrefix];
    return TruncateIesiri(serie + numPart, 16);
}

static string BuildIesiriInfo(IesiriHeaderJsonDto header)
{
    if (string.Equals(NormalizeIesiriTip(header.DocumentTip), "B", StringComparison.Ordinal))
    {
        // PubLine lasă observațiile goale pe bonul fiscal agregat; detaliile sunt în IES_DET.
        if (!string.IsNullOrWhiteSpace(header.ExtraInfo))
            return header.ExtraInfo.Trim();
        return "";
    }

    var parts = new List<string> { "SMARTPUB POS #" + header.OrderNo };
    if (!string.IsNullOrWhiteSpace(header.PaymentSummary))
        parts.Add(header.PaymentSummary.Trim());
    if (!string.IsNullOrWhiteSpace(header.ExtraInfo))
        parts.Add(header.ExtraInfo.Trim());
    return string.Join(" | ", parts);
}

static (string DenTip, string DenArt, string Um, string Gestiune, string DenGest) LookupSagaArticol(FbConnection saga, FbTransaction tx, string code)
{
    var c = (code ?? "").Trim();
    if (c.Length == 0)
        return ("", "", "", "", "");

    using var cmd = saga.CreateCommand();
    cmd.Transaction = tx;
    var hasArticleGestiune = ColumnExists(saga, "ARTICOLE", "GESTIUNE", tx);
    var hasGestiuni = TableExists(saga, "GESTIUNI", tx);
    cmd.CommandText = hasArticleGestiune && hasGestiuni
        ? @"
SELECT TRIM(A.DENUMIRE), TRIM(COALESCE(A.UM,'')), TRIM(COALESCE(A.DEN_TIP,'')),
       TRIM(COALESCE(A.GESTIUNE,'')), TRIM(COALESCE(G.DENUMIRE,''))
FROM ARTICOLE A
LEFT JOIN GESTIUNI G ON TRIM(A.GESTIUNE) = TRIM(G.COD)
WHERE TRIM(A.COD) = TRIM(@C) ROWS 1"
        : hasArticleGestiune
            ? @"
SELECT TRIM(DENUMIRE), TRIM(COALESCE(UM,'')), TRIM(COALESCE(DEN_TIP,'')),
       TRIM(COALESCE(GESTIUNE,'')), CAST('' AS VARCHAR(64))
FROM ARTICOLE WHERE TRIM(COD) = TRIM(@C) ROWS 1"
            : @"
SELECT TRIM(DENUMIRE), TRIM(COALESCE(UM,'')), TRIM(COALESCE(DEN_TIP,'')),
       CAST('' AS VARCHAR(16)), CAST('' AS VARCHAR(64))
FROM ARTICOLE WHERE TRIM(COD) = TRIM(@C) ROWS 1";
    cmd.Parameters.AddWithValue("@C", c);
    using var rd = cmd.ExecuteReader();
    if (!rd.Read())
        return ("", "", "", "", "");
    (string DenTip, string DenArt, string Um, string Gestiune, string DenGest) result = (
        (rd[2]?.ToString() ?? "").Trim(),
        (rd[0]?.ToString() ?? "").Trim(),
        (rd[1]?.ToString() ?? "").Trim(),
        (rd[3]?.ToString() ?? "").Trim(),
        (rd[4]?.ToString() ?? "").Trim());
    if (string.IsNullOrWhiteSpace(result.Gestiune))
        result = ApplyArtAnteGestiuneFallback(saga, tx, c, result);
    return result;
}

static (string DenTip, string DenArt, string Um, string Gestiune, string DenGest) ApplyArtAnteGestiuneFallback(
    FbConnection saga,
    FbTransaction tx,
    string code,
    (string DenTip, string DenArt, string Um, string Gestiune, string DenGest) current)
{
    if (!TableExists(saga, "ART_ANTE", tx))
        return current;

    using var cmd = saga.CreateCommand();
    cmd.Transaction = tx;
    var hasGestiuni = TableExists(saga, "GESTIUNI", tx);
    cmd.CommandText = hasGestiuni
        ? @"
SELECT FIRST 1
  TRIM(COALESCE(A.GESTIUNE, '')) AS GESTIUNE,
  TRIM(COALESCE(G.DENUMIRE, '')) AS DEN_GEST,
  TRIM(COALESCE(A.DEN_TIP, '')) AS DEN_TIP,
  TRIM(COALESCE(A.UM, '')) AS UM
FROM ART_ANTE A
LEFT JOIN GESTIUNI G ON TRIM(A.GESTIUNE) = TRIM(G.COD)
WHERE TRIM(A.COD_ART) = TRIM(@C)
  AND TRIM(COALESCE(A.GESTIUNE, '')) <> ''
ORDER BY A.PK"
        : @"
SELECT FIRST 1
  TRIM(COALESCE(GESTIUNE, '')) AS GESTIUNE,
  CAST('' AS VARCHAR(64)) AS DEN_GEST,
  TRIM(COALESCE(DEN_TIP, '')) AS DEN_TIP,
  TRIM(COALESCE(UM, '')) AS UM
FROM ART_ANTE
WHERE TRIM(COD_ART) = TRIM(@C)
  AND TRIM(COALESCE(GESTIUNE, '')) <> ''
ORDER BY PK";
    cmd.Parameters.AddWithValue("@C", code);
    using var rd = cmd.ExecuteReader();
    if (!rd.Read())
        return current;

    var gest = (rd["GESTIUNE"]?.ToString() ?? "").Trim();
    if (gest.Length == 0)
        return current;

    var denGest = (rd["DEN_GEST"]?.ToString() ?? "").Trim();
    var denTip = (rd["DEN_TIP"]?.ToString() ?? "").Trim();
    var um = (rd["UM"]?.ToString() ?? "").Trim();
    return (
        ShouldUseFallbackDenTip(current.DenTip, denTip) ? denTip : current.DenTip,
        current.DenArt,
        string.IsNullOrWhiteSpace(current.Um) ? um : current.Um,
        gest,
        string.IsNullOrWhiteSpace(current.DenGest) ? denGest : current.DenGest);
}

static bool ShouldUseFallbackDenTip(string current, string fallback)
{
    if (string.IsNullOrWhiteSpace(fallback))
        return false;
    if (string.IsNullOrWhiteSpace(current))
        return true;
    var c = current.Trim();
    var f = fallback.Trim();
    if (string.Equals(c, f, StringComparison.OrdinalIgnoreCase))
        return false;
    return string.Equals(c, "PRODUSE NESTOCATE", StringComparison.OrdinalIgnoreCase)
           || string.Equals(c, "Nedefinit", StringComparison.OrdinalIgnoreCase);
}

static string TruncateIesiri(string? s, int max) => SagaIesiriInsertHelpers.Truncate(s, max);

static string NormalizeGestiuneCode(string? gestiune, int maxLen)
{
    var t = (gestiune ?? "").Trim();
    if (t.Length == 0 || maxLen <= 0)
        return "";
    if (t.Length <= maxLen)
        return t;
    if (t.All(char.IsDigit))
        return t[^maxLen..];
    return t.Substring(0, maxLen);
}

static string? ResolveWorkingClient(string dbPath, string sagaRootPath, out string error)
{
    var existing = SagaFbClientLocator.GetEmbeddedProbeOrder(sagaRootPath).ToList();
    if (existing.Count == 0)
    {
        error = "Nu am găsit fbclient.dll x64 pentru SAGA (Firebird 3). Instalați Firebird30_Saga sau setați calea în sincronizare.";
        return null;
    }

    var errors = new List<string>();
    foreach (var fb in existing)
    {
        try
        {
            using var probe = OpenEmbedded(dbPath, fb);
            error = string.Empty;
            return fb;
        }
        catch (Exception ex)
        {
            errors.Add($"{fb} -> {ex.Message}");
        }
    }

    error = "Niciun fbclient SAGA nu a putut deschide baza.\n" + string.Join("\n", errors);
    return null;
}

static string? ResolveCompanyDbPath(string sagaRoot, string folder, string dbd)
{
    if (!string.IsNullOrWhiteSpace(dbd))
    {
        if (File.Exists(dbd)) return dbd;
        var rel = Path.Combine(sagaRoot, dbd);
        if (File.Exists(rel)) return rel;
    }

    var folderPath = Path.Combine(sagaRoot, folder);
    if (!Directory.Exists(folderPath)) return null;
    return Directory.EnumerateFiles(folderPath, "*.fdb", SearchOption.TopDirectoryOnly).FirstOrDefault();
}

static void Write(WorkerResponse response)
{
    Console.OutputEncoding = System.Text.Encoding.UTF8;
    var json = JsonSerializer.Serialize(response, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
    Console.WriteLine(json);
}

internal sealed class WorkerResponse
{
    public bool Success { get; set; }
    public string? Error { get; set; }
    public string? Detail { get; set; }
    public string? FbClientPath { get; set; }
    public string? EngineVersion { get; set; }
    public decimal? IdIesire { get; set; }
    public string? NrIesire { get; set; }
    public List<WorkerCompany> Companies { get; set; } = new();
    public WorkerSyncPayload? Sync { get; set; }
    public List<WorkerArticleBrief> ArticleList { get; set; } = new();
    public List<WorkerAccountBrief> AccountList { get; set; } = new();
}

internal sealed class WorkerArticleBrief
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Um { get; set; } = "";
    public decimal Tva { get; set; }
    public decimal PretVanz { get; set; }
    public string DenTip { get; set; } = "";
    public string TipSaga { get; set; } = "";
    public bool IsBlocked { get; set; }
}

internal sealed class WorkerAccountBrief
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
}

internal sealed class IesiriTransferJsonDto
{
    public string? SagaDbPath { get; set; }
    public string? SagaRootPath { get; set; }
    public string? FbClientPath { get; set; }
    public string? DefaultClientCode { get; set; }
    /// <summary>EMBEDDED (implicit) sau SERVER — client Firebird către serviciu, ca PubLine.</summary>
    public string? ConnectionMode { get; set; }
    public string? ServerHost { get; set; }
    public int? ServerPort { get; set; }
    public IesiriHeaderJsonDto? Header { get; set; }
    public List<IesiriLineJsonDto>? Lines { get; set; }
}

internal sealed class IesiriHeaderJsonDto
{
    public int OrderNo { get; set; }
    public DateTime PaidAt { get; set; }
    public decimal Valoare { get; set; }
    public decimal ValoareTva { get; set; }
    public decimal Total { get; set; }
    /// <summary>Tip document SAGA: B = bon fiscal (PubLine), V = vânzare.</summary>
    public string? DocumentTip { get; set; }
    public string? SerieBonuri { get; set; }
    public int BonCount { get; set; }
    public string? PaymentMethod { get; set; }
    public string? PaymentSummary { get; set; }
    public string? TransferAccount { get; set; }
    public string? ExtraInfo { get; set; }
}

internal sealed class IesiriLineJsonDto
{
    public string? ProductCode { get; set; }
    public string? ProductName { get; set; }
    public string? CodGestiune { get; set; }
    public string? DenGest { get; set; }
    public string? Um { get; set; }
    public decimal TvaPct { get; set; }
    public decimal Qty { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal Valoare { get; set; }
    public decimal ValoareTva { get; set; }
    public decimal Total { get; set; }
}

internal sealed class BomApplyJsonDto
{
    public BomApplyArticleJson? Article { get; set; }
    public List<BomApplyFlatLineJson>? Lines { get; set; }
}

internal sealed class BomApplyArticleJson
{
    public string? Code { get; set; }
    public string? Name { get; set; }
    public string? Um { get; set; }
    public decimal Tva { get; set; }
    public string? Categorie { get; set; }
    public decimal PretVanz { get; set; }
    public string? DenTipAntet { get; set; }
    public string? GestiuneAntet { get; set; }
}

internal sealed class BomApplyFlatLineJson
{
    public string? Cod { get; set; }
    public string? Denumire { get; set; }
    public decimal Cantitate { get; set; }
    public string? Um { get; set; }
    public string? Gestiune { get; set; }
    public string? DenTip { get; set; }
}

internal sealed class WorkerCompany
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string DatabasePath { get; set; } = "";
    public bool IsBlocked { get; set; }
}

internal sealed class WorkerSyncPayload
{
    public List<WorkerSyncGestiune> Gestiuni { get; set; } = new();
    public List<WorkerSyncCodDenumire> Grupari { get; set; } = new();
    public List<WorkerSyncCodDenumire> Categorii { get; set; } = new();
    public List<WorkerSyncArticol> Articole { get; set; } = new();
    public List<WorkerSyncClient> Clienti { get; set; } = new();
    public List<WorkerSyncReteta> Retete { get; set; } = new();
    public List<WorkerSyncRetetaDet> ReteteDet { get; set; } = new();
    public List<WorkerSyncRecipeLine> RecipeLines { get; set; } = new();
}

internal sealed class WorkerSyncCodDenumire
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
}

internal sealed class WorkerSyncGestiune
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Gestionar { get; set; } = "";
    public int TipEval { get; set; }
    public string Categorie { get; set; } = "";
    public decimal ProcTva { get; set; }
}

internal sealed class WorkerSyncArticol
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Um { get; set; } = "";
    public decimal Tva { get; set; }
    public string Categorie { get; set; } = "";
    public string Grupa { get; set; } = "";
    public string Gestiune { get; set; } = "";
    public decimal PretVanz { get; set; }
    public bool IsBlocked { get; set; }
    public string DenTip { get; set; } = "";
    public string TipSaga { get; set; } = "";
}

internal sealed class WorkerSyncClient
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string FiscalCode { get; set; } = "";
    public string RegCom { get; set; } = "";
    public string Phone { get; set; } = "";
    public string Email { get; set; } = "";
    public string Address { get; set; } = "";
    public bool IsBlocked { get; set; }
}

internal sealed class WorkerSyncReteta
{
    public string ArticolCode { get; set; } = "";
    public string Operatie { get; set; } = "";
    public string Tip { get; set; } = "";
    public string Name { get; set; } = "";
    public string Um { get; set; } = "";
    public decimal Quantity { get; set; }
    public string Gestiune { get; set; } = "";
}

internal sealed class WorkerSyncRetetaDet
{
    public string ArticolCode { get; set; } = "";
    public string ComponentCode { get; set; } = "";
    public string ComponentName { get; set; } = "";
    public decimal Quantity { get; set; }
    public string Um { get; set; } = "";
    public string Gestiune { get; set; } = "";
    public string Tip { get; set; } = "";
}

internal sealed class WorkerSyncRecipeLine
{
    public string LineKey { get; set; } = "";
    public string ArticolCode { get; set; } = "";
    public string SourceTable { get; set; } = "";
    public string Tip { get; set; } = "";
    public string Gestiune { get; set; } = "";
    public string Operatie { get; set; } = "";
    public string ComponentCode { get; set; } = "";
    public string ComponentName { get; set; } = "";
    public string Um { get; set; } = "";
    public decimal Quantity { get; set; }
}

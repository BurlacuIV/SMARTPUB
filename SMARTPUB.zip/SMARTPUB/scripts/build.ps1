param(
    [string]$SolutionPath = "D:\SMARTPUB\SMARTPUB.sln",
    [int]$MaxAttempts = 10
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Is-TransientWpfError {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) { return $false }

    return ($Text -match "error BG1002") -or
           ($Text -match "CS2001: Source file .*\.g\.cs") -or
           ($Text -match "_wpftmp\.csproj") -or
           ($Text -match "cannot be found\.\s*\[.*WinFX\.targets") -or
           ($Text -match "error NETSDK1004") -or
           ($Text -match "error CS5001") -or
           ($Text -match "CS0103: The name 'InitializeComponent'") -or
           ($Text -match "CS0103: The name 'MainFrame'")
}

function Is-FileLockError {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) { return $false }

    return ($Text -match "error MSB3021") -or
           ($Text -match "error MSB3027") -or
           ($Text -match "warning MSB3026") -or
           ($Text -match "could not copy .* because it is being used by another process") -or
           ($Text -match "The file is locked by:")
}

function Get-LockingPids {
    param([string]$Text)

    $pids = New-Object System.Collections.Generic.HashSet[int]
    if ([string]::IsNullOrWhiteSpace($Text)) { return @() }

    $matches = [regex]::Matches($Text, "\((\d+)\)")
    foreach ($m in $matches) {
        $procId = 0
        if ([int]::TryParse($m.Groups[1].Value, [ref]$procId) -and $procId -gt 0 -and $procId -ne $PID) {
            [void]$pids.Add($procId)
        }
    }

    $result = @()
    foreach ($x in $pids) { $result += $x }
    return $result
}

function Stop-LockingProcesses {
    param([int[]]$Pids)

    # Debugger used by Cursor/VS Code locks the built DLL in bin\Debug
    Get-Process -Name "netcoredbg" -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            Write-Host "Stopping netcoredbg (PID $($_.Id)) - unlocks SMARTPUB.dll for copy." -ForegroundColor Yellow
            Stop-Process -Id $_.Id -Force -ErrorAction Stop
        } catch { }
    }

    foreach ($p in $Pids) {
        try {
            $proc = Get-Process -Id $p -ErrorAction Stop
            Write-Host "Stopping locking process: $($proc.ProcessName) ($p)" -ForegroundColor Yellow
            Stop-Process -Id $p -Force -ErrorAction Stop
        } catch {
            # Already gone or inaccessible; continue.
        }
    }

    if ($Pids.Count -eq 0) {
        Get-Process -Name "SMARTPUB" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    }
}

function Remove-BuildArtifacts {
    param([string]$Root)

    Remove-Item -Recurse -Force (Join-Path $Root "obj") -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force (Join-Path $Root "bin") -ErrorAction SilentlyContinue
    $sw = Join-Path $Root "SMARTPUB.SagaWorker"
    Remove-Item -Recurse -Force (Join-Path $sw "obj") -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force (Join-Path $sw "bin") -ErrorAction SilentlyContinue
}

$projectDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
    Write-Host "== Build attempt $attempt/$MaxAttempts ==" -ForegroundColor Cyan

    & dotnet restore $SolutionPath "/property:GenerateFullPaths=true" 2>&1 | ForEach-Object { $_.ToString() } | Write-Host
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Restore failed." -ForegroundColor Red
        exit $LASTEXITCODE
    }

    # Single MSBuild node; nodereuse:false avoids stale MSBuild nodes racing WPF MarkupCompile vs MainResourcesGeneration (BG1002).
    $output = & dotnet build $SolutionPath --no-restore "/maxcpucount:1" "/nodereuse:false" "/property:GenerateFullPaths=true" "/consoleloggerparameters:NoSummary;ForceNoAlign" 2>&1
    $output | ForEach-Object { $_.ToString() } | Write-Host
    $exitCode = $LASTEXITCODE

    if ($exitCode -eq 0) {
        Write-Host "Build succeeded." -ForegroundColor Green
        exit 0
    }

    $joined = ($output | Out-String)
    if ($attempt -lt $MaxAttempts -and (Is-FileLockError -Text $joined)) {
        Write-Host "DLL locked (usually debugger netcoredbg). Stopping debuggers and retrying..." -ForegroundColor Yellow
        $lockingPids = Get-LockingPids -Text $joined
        Stop-LockingProcesses -Pids $lockingPids
        Start-Sleep -Seconds 2
        continue
    }

    if ($attempt -lt $MaxAttempts -and (Is-TransientWpfError -Text $joined)) {
        Write-Host "WPF incremental glitch. dotnet clean + remove obj/bin (app + SagaWorker), then retry..." -ForegroundColor Yellow
        & dotnet clean $SolutionPath | Out-Host
        Remove-BuildArtifacts -Root $projectDir
        Start-Sleep -Seconds 3
        continue
    }

    Write-Host "Build failed (non-transient or max retries reached)." -ForegroundColor Red
    exit $exitCode
}

exit 1

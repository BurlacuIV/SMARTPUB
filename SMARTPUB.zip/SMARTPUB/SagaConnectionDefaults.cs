using System.IO;

namespace SMARTPUB;

/// <summary>Valori implicite pentru conexiunea SAGA la Firebird Server (TCP), aliniate cu instalarea SAGA / PubLine.</summary>
public static class SagaConnectionDefaults
{
    /// <summary>Port TCP din firebird.conf (RemoteServicePort) pentru instanța Firebird SAGA.</summary>
    public const int FirebirdServerPort = 3060;

    /// <summary>Același fbclient ca PubLine — acolo unde există folderul.</summary>
    public const string PubLineFbClientPath = @"C:\PubLine\FbClient\fbclient.dll";

    /// <summary>Client din aceeași instalare ca serviciul Firebird SAGA (recomandat pentru TCP / WireCrypt).</summary>
    public const string Firebird30SagaFbClientPath = @"C:\Program Files\Firebird\Firebird30_Saga\fbclient.dll";

    public const string Firebird30SagaFbClientPathX86 = @"C:\Program Files (x86)\Firebird\Firebird30_Saga\fbclient.dll";

    /// <summary>Primul fbclient compatibil cu procesul curent (x64 → Firebird30_Saga, nu PubLine 32-bit).</summary>
    public static string? TryGetPreferredTcpFbClientPath() =>
        SagaFbClientLocator.GetTcpProbeOrder().FirstOrDefault();
}

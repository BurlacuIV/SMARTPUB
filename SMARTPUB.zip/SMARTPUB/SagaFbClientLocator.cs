using System.IO;

namespace SMARTPUB;

/// <summary>
/// Alege fbclient.dll compatibil cu arhitectura procesului (SMARTPUB / SagaWorker sunt x64).
/// Evită PubLine 32-bit și alte biblioteci care provoacă BadImageFormatException.
/// </summary>
public static class SagaFbClientLocator
{
    public static IEnumerable<string> GetTcpProbeOrder(string? preferredPath = null)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var path in BuildOrderedCandidates(preferredPath))
        {
            if (seen.Add(path))
                yield return path;
        }
    }

    public static IEnumerable<string> GetEmbeddedProbeOrder(string sagaRootPath, string? preferredPath = null)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var path in BuildOrderedCandidates(preferredPath))
        {
            if (seen.Add(path))
                yield return path;
        }

        if (!string.IsNullOrWhiteSpace(sagaRootPath) && Directory.Exists(sagaRootPath))
        {
            List<string> fromRoot;
            try
            {
                fromRoot = Directory
                    .EnumerateFiles(sagaRootPath, "fbclient.dll", SearchOption.AllDirectories)
                    .Where(p => IsCompatibleNativeLibrary(p))
                    .ToList();
            }
            catch
            {
                fromRoot = new List<string>();
            }

            foreach (var path in fromRoot)
            {
                if (seen.Add(path))
                    yield return path;
            }
        }
    }

    public static bool IsCompatibleNativeLibrary(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            return false;

        try
        {
            var pe64 = IsPe64Bit(path);
            return Environment.Is64BitProcess ? pe64 : !pe64;
        }
        catch
        {
            return false;
        }
    }

    private static IEnumerable<string> BuildOrderedCandidates(string? preferredPath)
    {
        if (!string.IsNullOrWhiteSpace(preferredPath))
        {
            var p = preferredPath.Trim();
            if (IsCompatibleNativeLibrary(p))
                yield return p;
        }

        if (Environment.Is64BitProcess)
        {
            if (File.Exists(SagaConnectionDefaults.Firebird30SagaFbClientPath) &&
                IsCompatibleNativeLibrary(SagaConnectionDefaults.Firebird30SagaFbClientPath))
                yield return SagaConnectionDefaults.Firebird30SagaFbClientPath;

            foreach (var path in DiscoverProgramFilesFirebird3Clients())
                yield return path;
        }
        else
        {
            if (File.Exists(SagaConnectionDefaults.Firebird30SagaFbClientPathX86) &&
                IsCompatibleNativeLibrary(SagaConnectionDefaults.Firebird30SagaFbClientPathX86))
                yield return SagaConnectionDefaults.Firebird30SagaFbClientPathX86;

            if (File.Exists(SagaConnectionDefaults.PubLineFbClientPath) &&
                IsCompatibleNativeLibrary(SagaConnectionDefaults.PubLineFbClientPath))
                yield return SagaConnectionDefaults.PubLineFbClientPath;
        }
    }

    private static IEnumerable<string> DiscoverProgramFilesFirebird3Clients()
    {
        const string root = @"C:\Program Files\Firebird";
        if (!Directory.Exists(root))
            yield break;

        IEnumerable<string> paths;
        try
        {
            paths = Directory.EnumerateFiles(root, "fbclient.dll", SearchOption.AllDirectories);
        }
        catch
        {
            yield break;
        }

        foreach (var path in paths.Where(IsFirebird3ClientPath).OrderBy(ScoreClientPath))
        {
            if (IsCompatibleNativeLibrary(path))
                yield return path;
        }
    }

    private static bool IsFirebird3ClientPath(string path)
    {
        var p = path.ToUpperInvariant();
        return p.Contains("FIREBIRD30_SAGA", StringComparison.Ordinal)
               || p.Contains("FIREBIRD_3", StringComparison.Ordinal);
    }

    private static int ScoreClientPath(string path)
    {
        var p = path.ToUpperInvariant();
        if (p.Contains("FIREBIRD30_SAGA", StringComparison.Ordinal)) return 0;
        if (p.Contains("FIREBIRD_3", StringComparison.Ordinal)) return 1;
        return 5;
    }

    /// <summary>PE Machine: 0x8664 = AMD64, 0x014C = I386.</summary>
    private static bool IsPe64Bit(string path)
    {
        using var fs = File.OpenRead(path);
        using var br = new BinaryReader(fs);
        if (fs.Length < 64)
            return false;

        fs.Position = 0x3C;
        var peOffset = br.ReadInt32();
        if (peOffset <= 0 || peOffset + 6 > fs.Length)
            return false;

        fs.Position = peOffset + 4;
        var machine = br.ReadUInt16();
        return machine == 0x8664;
    }
}

using System.Windows;
using System.Windows.Controls;
using SMARTPUB.Core.Session;
using SMARTPUB.Modules.Kitchen.Views;
using SMARTPUB.Modules.Waiter.Views;
using SMARTPUB.Services;
using SMARTPUB.Shell;
using SMARTPUB.Views;

namespace SMARTPUB;

public partial class MainWindow : Window
{
    private readonly Dictionary<string, Page> _pageCache = new();

    public MainWindow()
    {
        InitializeComponent();
        Loaded += MainWindow_Loaded;
    }

    private void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        ApplyModuleChrome();
        TryApplyStartFullscreenFromSettings();
    }

    private void TryApplyStartFullscreenFromSettings()
    {
        if (AppSession.Current.Module != AppModuleKind.Admin)
            return;
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchema(conn);
            var s = new ProgramSettingsRepository().Load(conn);
            if (s.StartFullscreen)
                WindowState = WindowState.Maximized;
        }
        catch
        {
            /* ignore */
        }
    }

    private void ApplyModuleChrome()
    {
        var m = AppSession.Current.Module;
        AdminMenu.Visibility = m == AppModuleKind.Admin ? Visibility.Visible : Visibility.Collapsed;
        WaiterMenu.Visibility = m == AppModuleKind.Waiter ? Visibility.Visible : Visibility.Collapsed;
        KitchenMenu.Visibility = m == AppModuleKind.Kitchen ? Visibility.Visible : Visibility.Collapsed;
        TxtSessionOperator.Text = BuildSessionLabel(m);

        Title = m switch
        {
            AppModuleKind.Admin => "SMARTPUB — Administrare",
            AppModuleKind.Waiter => "SMARTPUB — Ospătar",
            AppModuleKind.Kitchen => "SMARTPUB — Bucătărie (KDS)",
            _ => Title
        };

        switch (m)
        {
            case AppModuleKind.Admin:
                MainFrame.Content = null;
                break;
            case AppModuleKind.Waiter:
                NavigateDirect(new WaiterFloorPage());
                break;
            case AppModuleKind.Kitchen:
                NavigateDirect(new KitchenDisplayPage());
                break;
            default:
                break;
        }
    }

    private static string BuildSessionLabel(AppModuleKind module)
    {
        var name = string.IsNullOrWhiteSpace(AppSession.Current.OperatorName)
            ? "Operator"
            : AppSession.Current.OperatorName!.Trim();
        var role = module switch
        {
            AppModuleKind.Admin => "Admin",
            AppModuleKind.Waiter => "Ospătar",
            AppModuleKind.Kitchen => "KDS",
            _ => "SMARTPUB"
        };
        return $"{name} · {role}";
    }

    private void NavigateDirect(Page page)
    {
        MainFrame.Navigate(page);
    }

    private void WaiterSales_Click(object sender, RoutedEventArgs e) =>
        NavigateDirect(new WaiterFloorPage());

    private void WaiterCatalog_Click(object sender, RoutedEventArgs e) =>
        NavigateDirect(new SyncedProductsPage());

    private void KitchenKds_Click(object sender, RoutedEventArgs e) =>
        NavigateDirect(new KitchenDisplayPage());

    private void BtnLogoff_Click(object sender, RoutedEventArgs e)
    {
        var login = new WaiterLoginWindow { Owner = this };
        var ok = login.ShowDialog() == true;
        if (!ok)
            return;

        WaiterOperatorContext.Clear();
        _pageCache.Clear();
        ApplyModuleChrome();
        TryApplyStartFullscreenFromSettings();
    }

    private void LeafMenuItem_Click(object sender, RoutedEventArgs e)
    {
        if (AppSession.Current.Module != AppModuleKind.Admin)
            return;

        if (sender is not MenuItem clickedItem)
            return;

        var section = clickedItem.Header?.ToString() ?? "Necunoscut";
        var module = (clickedItem.Parent as MenuItem)?.Header?.ToString() ?? "Modul";

        NavigateToSection(module, section);
    }

    private void NavigateToSection(string module, string section)
    {
        var key = $"{module}|{section}";

        if (!_pageCache.TryGetValue(key, out var page))
        {
            page = CreatePageForSection(module, section);
            if (page != null)
                _pageCache[key] = page;
        }

        if (page != null)
            MainFrame.Navigate(page);
    }

    private static Page? CreatePageForSection(string module, string section)
    {
        if (module == "Administrare" && section == "Configurare program")
            return new ProgramConfigurationPage();
        if (module == "Catalog" && section == "ARTICOLE")
            return new SyncedProductsPage();
        if (module == "POS Restaurant" && section == "Hartă mese")
            return new FloorPlanConfiguratorPage();
        if (module == "POS Restaurant" && section == "Vânzări")
            return new SalesModulePage();
        if (module == "POS Restaurant" && section == "Gestiuni")
            return new GestiuniPage();
        if (module == "Administrare" && section == "Configurare ospătari")
            return new WaiterOperatorsConfigPage();
        if (module == "Bucătărie / Bar" && section == "Monitor bucătărie")
            return new KitchenDisplayPage();

        return null;
    }
}

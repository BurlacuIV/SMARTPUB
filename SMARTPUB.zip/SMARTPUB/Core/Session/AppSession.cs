namespace SMARTPUB.Core.Session;

/// <summary>
/// Context de sesiune pentru modulul activ (în memorie, extensibil ulterior cu autentificare).
/// </summary>
public sealed class AppSession
{
    public static AppSession Current { get; } = new();

    public AppModuleKind Module { get; set; } = AppModuleKind.Admin;

    /// <summary>ID operator din SP_POS_OPERATOR (după autentificare ospătar).</summary>
    public string? OperatorId { get; set; }

    /// <summary>Numele afișat al operatorului (ospătar / bucătar); opțional.</summary>
    public string? OperatorName { get; set; }
}

namespace SMARTPUB.Core.Session;

/// <summary>
/// Rolul stației la deschiderea aplicației: administrare completă, vânzare la sală sau ecran bucătărie.
/// </summary>
public enum AppModuleKind
{
    Admin,
    Waiter,
    Kitchen
}

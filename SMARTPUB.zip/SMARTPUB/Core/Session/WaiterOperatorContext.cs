using SMARTPUB.Services;

namespace SMARTPUB.Core.Session;

/// <summary>Drepturi și restricții operator încărcate o dată la login (evită DB la fiecare click).</summary>
public sealed class WaiterOperatorContext
{
    public string? OperatorId { get; init; }
    public bool IsAdministrator { get; init; }
    public HashSet<string> Rights { get; init; } = new(StringComparer.OrdinalIgnoreCase);
    public HashSet<string>? AllowedTableIds { get; init; }
    public HashSet<string> BlockedGestiuni { get; init; } = new(StringComparer.OrdinalIgnoreCase);
    public HashSet<string> BlockedGrupe { get; init; } = new(StringComparer.OrdinalIgnoreCase);

    public static WaiterOperatorContext? Current { get; private set; }

    public static void Clear() => Current = null;

    public static void LoadFromDatabase(string operatorId)
    {
        if (string.IsNullOrWhiteSpace(operatorId))
        {
            Current = null;
            return;
        }

        using var conn = SmartPubDb.OpenEmbedded();
        var isAdmin = PosOperatorRepository.IsAdministratorRole(conn, operatorId);
        var rights = PosOperatorRepository.LoadRights(conn, operatorId);
        var allowedTables = PosOperatorRepository.GetAllowedTableIds(conn, operatorId);
        var blockedGest = PosOperatorRepository.LoadBlockedGestiuni(conn, operatorId);
        var blockedGrup = PosOperatorRepository.LoadBlockedGrupe(conn, operatorId);

        Current = new WaiterOperatorContext
        {
            OperatorId = operatorId.Trim(),
            IsAdministrator = isAdmin,
            Rights = rights,
            AllowedTableIds = allowedTables,
            BlockedGestiuni = blockedGest,
            BlockedGrupe = blockedGrup
        };
    }

    public bool HasRight(string rightCode) =>
        IsAdministrator || Rights.Contains(rightCode);

    public bool CanAccessTable(string tableId)
    {
        if (AllowedTableIds == null)
            return true;
        if (AllowedTableIds.Count == 0)
            return false;
        return AllowedTableIds.Contains(tableId);
    }
}

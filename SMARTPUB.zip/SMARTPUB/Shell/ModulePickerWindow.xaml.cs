using System.Windows;
using SMARTPUB.Core.Session;

namespace SMARTPUB.Shell;

public partial class ModulePickerWindow : Window
{
    public ModulePickerWindow()
    {
        InitializeComponent();
    }

    private void BtnAdmin_Click(object sender, RoutedEventArgs e)
    {
        AppSession.Current.Module = AppModuleKind.Admin;
        DialogResult = true;
        Close();
    }

    private void BtnWaiter_Click(object sender, RoutedEventArgs e)
    {
        AppSession.Current.Module = AppModuleKind.Waiter;
        DialogResult = true;
        Close();
    }

    private void BtnKitchen_Click(object sender, RoutedEventArgs e)
    {
        AppSession.Current.Module = AppModuleKind.Kitchen;
        DialogResult = true;
        Close();
    }
}

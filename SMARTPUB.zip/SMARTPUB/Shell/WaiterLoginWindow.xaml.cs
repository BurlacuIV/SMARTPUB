using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using SMARTPUB.Core.Session;
using SMARTPUB.Services;

namespace SMARTPUB.Shell;

public partial class WaiterLoginWindow : Window
{
    public WaiterLoginWindow()
    {
        InitializeComponent();
        Loaded += (_, _) =>
        {
            TxtPin.Focus();
            CheckPinSetup();
        };
    }

    private void CheckPinSetup()
    {
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            PosOperatorRepository.EnsureAdministratorBootstrapPin(conn);
            if (!PosOperatorRepository.AnyAdministratorHasConfiguredPin(conn))
            {
                TxtStatus.Text =
                    "Administrator fără PIN propriu. Intrați cu 0000, apoi setați PIN-uri unice în Administrare → Operatori.";
            }
            else if (!PosOperatorRepository.HasAnyActivePin(conn))
            {
                TxtStatus.Text =
                    "Nu există niciun PIN configurat. Intrați temporar cu 0000 și setați PIN-uri unice în Administrare → Operatori.";
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Nu s-a putut pregăti autentificarea: " + ex.Message, "SMARTPUB",
                MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void Digit_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button b && b.Content is string digit && TxtPin.Password.Length < TxtPin.MaxLength)
        {
            TxtStatus.Text = "";
            TxtPin.Password += digit;
        }
    }

    private void Backspace_Click(object sender, RoutedEventArgs e)
    {
        if (TxtPin.Password.Length > 0)
            TxtPin.Password = TxtPin.Password[..^1];
    }

    private void Clear_Click(object sender, RoutedEventArgs e)
    {
        TxtPin.Clear();
        TxtStatus.Text = "";
    }

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key >= Key.D0 && e.Key <= Key.D9)
        {
            AppendDigit((char)('0' + (e.Key - Key.D0)));
            e.Handled = true;
            return;
        }

        if (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
        {
            AppendDigit((char)('0' + (e.Key - Key.NumPad0)));
            e.Handled = true;
            return;
        }

        if (e.Key == Key.Back)
        {
            Backspace_Click(sender, e);
            e.Handled = true;
            return;
        }

        if (e.Key == Key.Escape)
        {
            Clear_Click(sender, e);
            e.Handled = true;
        }
    }

    private void AppendDigit(char digit)
    {
        if (TxtPin.Password.Length >= TxtPin.MaxLength)
            return;
        TxtStatus.Text = "";
        TxtPin.Password += digit;
    }

    private void BtnOk_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            PosOperatorRepository.EnsureAdministratorBootstrapPin(conn);

            var op = PosOperatorRepository.FindActiveByPin(conn, TxtPin.Password, out var error);
            if (op == null)
                op = PosOperatorRepository.TryBootstrapAdministratorLogin(conn, TxtPin.Password);
            if (op != null)
                error = "";

            if (op == null)
            {
                TxtStatus.Text = error;
                TxtPin.Clear();
                TxtPin.Focus();
                return;
            }

            AppSession.Current.OperatorId = op.Id;
            AppSession.Current.OperatorName = op.DisplayName;
            AppSession.Current.Module = PosOperatorRepository.IsAdministratorRole(op.Role)
                ? AppModuleKind.Admin
                : AppModuleKind.Waiter;

            WaiterOperatorContext.LoadFromDatabase(op.Id);
            if (AppSession.Current.Module == AppModuleKind.Waiter)
                WaiterProductCatalogCache.Instance.PreloadAsync();

            DialogResult = true;
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "SMARTPUB", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}

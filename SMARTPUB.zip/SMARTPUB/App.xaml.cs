using System.IO;
using System.Text;
using System.Threading;
using System.Windows;
using SMARTPUB.Core.Session;
using SMARTPUB.Services;
using SMARTPUB.Shell;

namespace SMARTPUB;

public partial class App : Application
{
    private static Mutex? _singleInstanceMutex;

    public App()
    {
        // SAGA / Firebird folosesc des WIN1250; .NET Core+ nu încarcă implicit codepage-urile (PubLine pe .NET Framework le are).
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

        // Dialogul de autentificare se închide înainte de MainWindow; fără asta WPF ar închide aplicația.
        ShutdownMode = ShutdownMode.OnExplicitShutdown;
    }

    private void Application_Startup(object sender, StartupEventArgs e)
    {
        try
        {
            SmartPubBootstrap.EnsureDatabase();
        }
        catch (FileNotFoundException ex)
        {
            MessageBox.Show(ex.Message, "SMARTPUB — lipsă bază de date", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown();
            return;
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Inițializarea bazei SMARTPUB a eșuat:\n" + ex.Message,
                "SMARTPUB",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            Shutdown();
            return;
        }

        if (!TryAcquireSingleInstanceOrShutdown())
            return;

        var login = new WaiterLoginWindow();
        login.ShowDialog();
        if (login.DialogResult != true)
        {
            Shutdown();
            return;
        }

        var main = new MainWindow();
        MainWindow = main;
        main.Closed += (_, _) =>
        {
            _singleInstanceMutex?.ReleaseMutex();
            _singleInstanceMutex?.Dispose();
            _singleInstanceMutex = null;
            Shutdown();
        };
        main.Show();
    }

    private static bool TryAcquireSingleInstanceOrShutdown()
    {
        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            SmartPubBootstrap.ApplySchema(conn);
            var s = new ProgramSettingsRepository().Load(conn);
            if (!s.SingleInstance)
                return true;

            _singleInstanceMutex = new Mutex(true, @"Local\SMARTPUB_POS_SINGLE_INSTANCE_v1", out var createdNew);
            if (createdNew)
                return true;

            MessageBox.Show(
                "SMARTPUB rulează deja. Nu este permisă deschiderea simultană a mai multor instanțe.",
                "SMARTPUB",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
            Current.Shutdown();
            return false;
        }
        catch
        {
            return true;
        }
    }
}

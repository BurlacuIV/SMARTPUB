namespace SMARTPUB.Models;

/// <summary>Operator + drepturi și restricții pentru ecranul de configurare.</summary>
public sealed class PosOperatorDetail
{
    public PosOperatorRow Operator { get; set; } = new();

    /// <summary>Drepturi acordate (cod din <see cref="PosOperatorRightsCatalog"/>).</summary>
    public HashSet<string> GrantedRights { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>Mese permise când <see cref="PosOperatorRow.AccessAllTables"/> e false.</summary>
    public HashSet<string> AllowedTableIds { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>Gestiuni blocate (articolele din aceste gestiuni nu apar la ospătar).</summary>
    public HashSet<string> BlockedGestiuni { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>Grupe de articole blocate.</summary>
    public HashSet<string> BlockedGrupe { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

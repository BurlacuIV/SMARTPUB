namespace SMARTPUB.Models;

/// <summary>Articol compact pentru popup-ul de sincronizare SAGA (preview + selecție tip).</summary>
public sealed class SagaArticleBrief
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Um { get; set; } = "";
    public decimal Tva { get; set; }
    public decimal PretVanz { get; set; }
    public string DenTip { get; set; } = "";
    public string TipSaga { get; set; } = "";
    public bool IsBlocked { get; set; }
}

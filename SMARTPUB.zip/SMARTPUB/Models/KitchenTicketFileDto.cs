using System.Text.Json.Serialization;

namespace SMARTPUB.Models;

public sealed class KitchenTicketFileDto
{
    [JsonPropertyName("tickets")]
    public List<KitchenTicket> Tickets { get; set; } = new();
}

namespace SMARTPUB.Models;

/// <summary>
/// Linie după expandare completă la materii prime (gata de SAGA ART_A_DET).
/// </summary>
public sealed class FlattenedBomLine
{
    public string ComponentCode { get; set; } = "";
    public string ComponentName { get; set; } = "";
    public decimal Quantity { get; set; }
    public string Um { get; set; } = "";
    public string Gestiune { get; set; } = "";
    public string DenTip { get; set; } = "";
}

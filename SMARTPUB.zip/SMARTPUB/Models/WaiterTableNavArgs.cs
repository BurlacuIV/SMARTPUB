namespace SMARTPUB.Models;

/// <summary>Parametri pentru ecranul de comandă pe o masă.</summary>
public sealed class WaiterTableNavArgs
{
    public string TableId { get; init; } = "";
    public string TableName { get; init; } = "";
    public string LevelName { get; init; } = "";
    public string? SpaceName { get; init; }

    public string DisplayTitle =>
        SpaceName is { Length: > 0 } s
            ? $"{TableName} · {s} · {LevelName}"
            : $"{TableName} · {LevelName}";
}

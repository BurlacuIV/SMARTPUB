namespace SMARTPUB.Models;

public sealed class ClientRow
{
    public string COD { get; set; } = "";
    public string DENUMIRE { get; set; } = "";
    public string? COD_FISCAL { get; set; }
    public string? REG_COM { get; set; }
    public string? ANALITIC { get; set; }
    public short ZS { get; set; }
    public decimal DISCOUNT { get; set; }
    public string? ADRESA { get; set; }
    public string? JUDET { get; set; }
    public string? BANCA { get; set; }
    public string? CONT_BANCA { get; set; }
    public string? FILIALA { get; set; }
    public string? DELEGAT { get; set; }
    public string? BI_SERIE { get; set; }
    public string? BI_NUMAR { get; set; }
    public string? BI_POL { get; set; }
    public string? MASINA { get; set; }
    public string? INF_SUPL { get; set; }
    public string? AGENT { get; set; }
    public string? DEN_AGENT { get; set; }
    public string? GRUPA { get; set; }
    public string? TIP_TERT { get; set; }
    public string? TARA { get; set; }
    public string? TEL { get; set; }
    public string? EMAIL { get; set; }
    public short IS_TVA { get; set; }
    public short BLOCAT { get; set; }
    public DateTime? DATA_V_TVA { get; set; }
    public decimal CB_CARD { get; set; }
    public DateTime? DATA_S_TVA { get; set; }
    public decimal C_LIMIT { get; set; }
    public string? LOCALITATE { get; set; }
    public string? COD_POST { get; set; }
    public short IS_EFACT { get; set; }
    public string? ID_EFACT { get; set; }
    public string? C_SAFT { get; set; }
}

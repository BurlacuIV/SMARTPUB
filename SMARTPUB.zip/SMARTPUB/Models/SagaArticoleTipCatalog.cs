namespace SMARTPUB.Models;

/// <summary>
/// În SAGA, „Tip” articol = <c>ARTICOLE.DEN_TIP</c> (text afișat, ex. „Materii prime 301B”)
/// și opțional <c>ARTICOLE.TIP</c> (cod 1 caracter, contabilitate).
/// Lista de bază reflectă nomenclatorul din ecranul Articole SAGA C.
/// </summary>
public static class SagaArticoleTipCatalog
{
    /// <summary>Denumiri din lista derulantă SAGA (fără sufix cont).</summary>
    public static readonly string[] DenumiriDeBaza =
    [
        "Marfuri",
        "Materii prime",
        "Materiale auxiliare",
        "Combustibili",
        "Piese de schimb",
        "Alte mat. consumabile",
        "Produse finite",
        "Ambalaje",
        "Obiecte de inventar",
        "Produse reziduale",
        "Semifabricate",
        "Amenajari provizorii"
    ];

    /// <summary>Sufixe cont sintetic frecvente în DEN_TIP (ex. 301A, 301C).</summary>
    public static readonly string[] SufixContFrecvente =
    [
        "301A", "301B", "301C", "302", "303", "371", "378", "381"
    ];

    /// <summary>Valori speciale des întâlnite în practică.</summary>
    public static readonly string[] PreseturiSuplimentare =
    [
        "PRODUSE NESTOCATE",
        "Marfuri 301C",
        "Materii prime 301A",
        "Materii prime 301B",
        "Materiale auxiliare 302",
        "Semifabricate 341",
        "Produse finite 345"
    ];

    /// <summary>Toate presetările pentru combobox (fără duplicate).</summary>
    public static List<string> ToPresetList()
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var p in PreseturiSuplimentare)
            set.Add(p);
        foreach (var b in DenumiriDeBaza)
            set.Add(b);
        foreach (var b in DenumiriDeBaza)
        {
            foreach (var s in SufixContFrecvente)
                set.Add($"{b} {s}");
        }

        return set.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
    }
}

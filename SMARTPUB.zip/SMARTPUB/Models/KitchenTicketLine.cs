namespace SMARTPUB.Models;

public sealed class KitchenTicketLine
{
    public string ProductCode { get; set; } = "";
    public string ProductName { get; set; } = "";
    public decimal Qty { get; set; } = 1;
    public decimal UnitPrice { get; set; }
    public string? Notes { get; set; }
    public string GestiuneCode { get; set; } = "";
    public string GestiuneName { get; set; } = "";
}

namespace SMARTPUB.Models;

public sealed class BomCatalogItem
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Um { get; set; } = "";
    public string Categorie { get; set; } = "";

    public string Display
    {
        get
        {
            if (string.IsNullOrWhiteSpace(Name))
                return Code;
            if (string.IsNullOrWhiteSpace(Um))
                return $"{Code} — {Name}";
            return $"{Code} — {Name} ({Um})";
        }
    }
}

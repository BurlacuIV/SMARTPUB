namespace SMARTPUB.Models;

public sealed class FloorTableModel
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    /// <summary>ID nivel (tab sală).</summary>
    public string LevelId { get; set; } = "";
    public string Name { get; set; } = "Masa";
    public double X { get; set; }
    public double Y { get; set; }
    public double Width { get; set; } = 72;
    public double Height { get; set; } = 72;
    public bool IsRound { get; set; }
    public int Seats { get; set; } = 4;
    public string? SpaceId { get; set; }
}

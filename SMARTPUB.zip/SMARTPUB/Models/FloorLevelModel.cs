namespace SMARTPUB.Models;

/// <summary>
/// Nivel de sală (tab în plan: Terasă, Interior etc.) — fiecare are propriul canvas.
/// </summary>
public sealed class FloorLevelModel
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Sală";
    public int SortOrder { get; set; }

    /// <summary>Etichetă tab (evită nume gol în UI).</summary>
    public string DisplayName => string.IsNullOrWhiteSpace(Name) ? "Sală" : Name;

    /// <summary>UI display only — set de configurator, nepersistat.</summary>
    public int TableCount { get; set; }
    /// <summary>UI display only — set de configurator, nepersistat.</summary>
    public string LevelMetaText { get; set; } = "";
}

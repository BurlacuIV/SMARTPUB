namespace SMARTPUB.Models;

/// <summary>Rotunjiri consistente pentru split note (evită 0,01 fantomă și 1,01 din floating point).</summary>
public static class SplitQtyMath
{
    public const decimal MinQty = 0.01m;

    public static decimal Round(decimal qty) =>
        Math.Round(qty, 2, MidpointRounding.AwayFromZero);

    public static bool IsEffectivelyZero(decimal qty) =>
        Round(qty) < MinQty;

    public static decimal Available(decimal totalQty, decimal allocatedQty) =>
        Math.Max(0, Round(totalQty - allocatedQty));
}

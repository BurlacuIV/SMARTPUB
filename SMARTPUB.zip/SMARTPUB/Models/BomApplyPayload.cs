namespace SMARTPUB.Models;

/// <summary>JSON trimis workerului applybom (scris și pe disc temporar).</summary>
public sealed class BomApplyPayload
{
    public BomApplyArticle Article { get; set; } = new();
    public List<BomApplyFlatLine> Lines { get; set; } = new();
}

public sealed class BomApplyArticle
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Um { get; set; } = "";
    public decimal Tva { get; set; }
    public string Categorie { get; set; } = "";
    public decimal PretVanz { get; set; }
    /// <summary>Ex. tip antet rețetă / produs nestocat (etichetă SAGA).</summary>
    public string DenTipAntet { get; set; } = "PRODUSE NESTOCATE";
    public string GestiuneAntet { get; set; } = "";
}

public sealed class BomApplyFlatLine
{
    public string Cod { get; set; } = "";
    public string Denumire { get; set; } = "";
    public decimal Cantitate { get; set; }
    public string Um { get; set; } = "";
    public string Gestiune { get; set; } = "";
    public string DenTip { get; set; } = "";
}

using System.Text.Json.Serialization;

namespace SMARTPUB.Models;

public sealed class KitchenTicket
{
    public string Id { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

    [JsonIgnore]
    public DateTime CreatedLocalDisplay =>
        DateTime.SpecifyKind(CreatedAtUtc, DateTimeKind.Utc).ToLocalTime();
    public string TableId { get; set; } = "";
    public string TableDisplayName { get; set; } = "";
    public string LevelName { get; set; } = "";
    public string? SpaceName { get; set; }
    public KitchenTicketStatus Status { get; set; } = KitchenTicketStatus.New;
    public List<KitchenTicketLine> Lines { get; set; } = new();
    public string? SourceOperator { get; set; }
}

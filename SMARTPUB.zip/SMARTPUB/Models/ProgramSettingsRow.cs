namespace SMARTPUB.Models;

/// <summary>Setări aplicație (echivalent orientativ cu PubLine „Configurare”).</summary>
public sealed class ProgramSettingsRow
{
    public string SagaConnMode { get; set; } = "Standard";
    public string SagaServerIp { get; set; } = "";
    public string SagaServerDbFolder { get; set; } = "";
    public string PrinterFirmOrder { get; set; } = "";
    public string PrinterBill { get; set; } = "";
    public string PrinterInvoice { get; set; } = "";

    /// <summary>Imprimanta pentru comenzile de BAR (rutare internă).</summary>
    public string PrinterBar { get; set; } = "";

    /// <summary>Imprimanta pentru comenzile de BUCĂTĂRIE (rutare internă).</summary>
    public string PrinterKitchen { get; set; } = "";
    public bool SingleInstance { get; set; } = true;
    public bool StartFullscreen { get; set; } = true;
    public bool CheckUpdatesOnStart { get; set; }
    public bool AutoSyncNomenclature { get; set; }
    public int AutoLogoutSec { get; set; } = -1;
    public bool HotelMode { get; set; }
}

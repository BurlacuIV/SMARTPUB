namespace SMARTPUB.Models;

public sealed class SyncedRecipeLineRow
{
    /// <summary>Cheie unică în SP_SAGA_RECIPE_LINES; generată la adăugare dacă lipsește.</summary>
    public string LineKey { get; set; } = "";

    public string SourceTable { get; set; } = "";
    public string Tip { get; set; } = "";
    public string Gestiune { get; set; } = "";
    public string Operatie { get; set; } = "";
    public string ComponentCode { get; set; } = "";
    public string ComponentName { get; set; } = "";
    public string Um { get; set; } = "";
    public decimal Quantity { get; set; }
}

namespace SMARTPUB.Models;

public sealed class FloorSpaceModel
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    /// <summary>ID nivel (tab sală).</summary>
    public string LevelId { get; set; } = "";
    public string Name { get; set; } = "Zonă";
    public double X { get; set; }
    public double Y { get; set; }
    public double Width { get; set; } = 320;
    public double Height { get; set; } = 220;
    public int ZOrder { get; set; }
    public int TintArgb { get; set; } = unchecked((int)0x40B8D8A8);
}

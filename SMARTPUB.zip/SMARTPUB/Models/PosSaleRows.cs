using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace SMARTPUB.Models;

public class PosSaleHeaderRow
{
    public string Id { get; set; } = "";
    public int OrderNo { get; set; }
    public string OperatorName { get; set; } = "";
    public DateTime PaidAt { get; set; }
    public DateTime CreatedAt { get; set; }
    public decimal Valoare { get; set; }
    public decimal ValoareTva { get; set; }
    public decimal Total { get; set; }
    public string TableDisplayName { get; set; } = "";
    public string Status { get; set; } = "";
    public string ModPlata { get; set; } = "";
    public string SagaTransferStatus { get; set; } = "";
    public decimal? SagaIdIesire { get; set; }
    public string? SagaNrIesire { get; set; }
    public string? SagaError { get; set; }

    public string StareDisplay => Status.Trim().ToUpperInvariant() switch
    {
        "PAID" => "Încasată",
        _ => Status
    };

    public string SagaDisplay => SagaTransferStatus.Trim().ToUpperInvariant() switch
    {
        "READY" => "Pregătit transfer SAGA",
        "SENT" => "Transferat în SAGA",
        "NONE" => "—",
        "ERROR" => "Eroare transfer",
        _ => SagaTransferStatus
    };
}

public sealed class PosSaleLineRow
{
    public string SaleId { get; set; } = "";
    public int LineNo { get; set; }
    public string CodGestiune { get; set; } = "";
    public string DenGest { get; set; } = "";
    public string ProductCode { get; set; } = "";
    public string ProductName { get; set; } = "";
    public string Um { get; set; } = "";
    public decimal TvaPct { get; set; }
    public decimal Qty { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal Valoare { get; set; }
    public decimal ValoareTva { get; set; }
    public decimal Total { get; set; }
    public string DenTip { get; set; } = "";
}

public sealed class PosSalePaymentInput
{
    public string MethodKey { get; set; } = "";
    public decimal Amount { get; set; }
}

public sealed class PosSalePaymentRow
{
    public string SaleId { get; set; } = "";
    public int LineNo { get; set; }
    public string MethodKey { get; set; } = "";
    public decimal Amount { get; set; }
}

/// <summary>Rând pentru tab-ul de transfer (bifare în masă).</summary>
public sealed class PosSaleTransferPick : PosSaleHeaderRow, INotifyPropertyChanged
{
    private bool _selected;

    public bool Selected
    {
        get => _selected;
        set
        {
            if (_selected == value)
                return;
            _selected = value;
            OnPropertyChanged();
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? n = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
}

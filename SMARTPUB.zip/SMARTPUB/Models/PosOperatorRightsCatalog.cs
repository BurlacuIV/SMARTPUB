namespace SMARTPUB.Models;

/// <summary>Drepturi POS — structură tip „Drepturi SMARTPUB” (secțiuni ca în PubLine).</summary>
public static class PosOperatorRightsCatalog
{
    public const string StartupNormal = "STARTUP_NORMAL";
    public const string StartupRestaurant = "STARTUP_RESTAURANT_MODULE";
    public const string StartupDelivery = "STARTUP_DELIVERY_MODULE";
    public const string InchideAplicatie = "INCHIDE_APLICATIE";
    /// <summary>Doar UI; valoarea reală e <see cref="PosOperatorRow.AccessAllTables"/>.</summary>
    public const string AccesToateMeseleUi = "ACCES_TOATE_MESELE_UI";

    public static IReadOnlyList<(string Code, string Label)> StartupOptions { get; } =
    [
        (StartupNormal, "Intră în program normal"),
        (StartupRestaurant, "Intră în program direct în modul Restaurant"),
        (StartupDelivery, "Intră în program direct în modul Livrări"),
    ];

    public sealed record RightItem(string Code, string Label, bool Emphasize = false, bool MirrorsAccessAllTables = false);

    public sealed record RightSection(string Title, IReadOnlyList<RightItem> Items, bool StartsExpanded = true);

    /// <summary>Secțiuni cu casete (fără modul pornire — acela e separat).</summary>
    public static IReadOnlyList<RightSection> Sections { get; } =
    [
        new RightSection("Modul Restaurant",
        [
            new RightItem("DELEGARE_AUTO_MASA", "Delegare automată la ieșirea de pe masă"),
            new RightItem("PARASESTE_MOD_RESTAURANT", "Poate părăsi modul Restaurant"),
            new RightItem(AccesToateMeseleUi, "Are acces la toate mesele", Emphasize: true, MirrorsAccessAllTables: true),
            new RightItem("ACCES_MESE_ALTI_OSPATARI", "Are acces la mesele deschise de alți ospătari"),
            new RightItem("ACCES_SALA", "Are acces la planul sălii / modul Restaurant"),
            new RightItem("VINDE_ARTICOL", "Poate vinde articole"),
            new RightItem("STORNO_ARTICOL", "Poate storna articole", Emphasize: true),
            new RightItem("ANULARE_ARTICOL", "Poate anula articole"),
            new RightItem("ANULARE_COMANDA", "Poate anula comanda"),
            new RightItem("ANULARE_INCASARE_STORNO", "Poate anula încasarea sau stornarea"),
            new RightItem("RETIPARIRE_COMANDA", "Poate RE-tipări comanda"),
            new RightItem("DISCOUNT_OPERATIE", "Are acces la operația de discount"),
            new RightItem("TRANSFER_PRODUSE", "Poate transfera produse"),
            new RightItem("TRANSFER_COMANDA", "Poate transfera comanda"),
            new RightItem("ISTORIC_COMENZI_PROPRII", "Are acces la istoricul comenzilor proprii"),
            new RightItem("ISTORIC_COMENZI_ALTII", "Are acces la istoricul comenzilor operate de alți ospătari"),
            new RightItem("MODIFICA_PRET_VANZARE", "Poate modifica prețul articolelor la vânzare"),
            new RightItem("NOTA_CLIENT_F7", "Poate tipări nota de plată"),
            new RightItem("TRIMITE_BUCATARIE", "Trimite comandă la bucătărie"),
            new RightItem("BON_PREVIZ", "Poate tipări / previzualizare bon comandă"),
            new RightItem("INCASARE", "Poate încasa comanda"),
            new RightItem("INCHIDE_PROTOCOOL", "Poate închide comanda pe protocol"),
            new RightItem("INCHIDE_ALTE_MODALITATI_INCASARE", "Poate închide comanda prin alte metode de încasare", Emphasize: true),
            new RightItem("BON_FISCAL_TIPARIRE", "Poate tipări bonul fiscal"),
            new RightItem("BON_FISCAL_RETIPARIRE", "Poate RE-tipări bonul fiscal"),
            new RightItem("DEPASESTE_PLAFON_VANZARE", "Poate depăși plafonul de vânzare"),
            new RightItem("FACTURA_SAGA", "Poate genera factura în SAGA"),
            new RightItem("RAPORT_INCASARI_TIPARIRE", "Poate tipări raportul încasărilor"),
            new RightItem("GOLESTE_COS", "Poate goli coșul comenzii"),
            new RightItem("EDIT_CANTITATE", "Poate modifica cantitatea articolelor în comandă"),
            new RightItem("STERGE_LINIE", "Poate șterge linii din comandă"),
            new RightItem("CATALOG_ARTICOLE", "Acces la catalog articole (meniu)"),
        ], StartsExpanded: true),

        new RightSection("Modul hotel",
        [
            new RightItem("HOTEL_ACCES_REZERVARI", "Acces la rezervări camere"),
            new RightItem("HOTEL_CHECKIN_CHECKOUT", "Operațiuni check-in / check-out"),
            new RightItem("HOTEL_RAPOARTE_CAZARE", "Rapoarte cazare"),
        ], StartsExpanded: false),

        new RightSection("Operații casă de marcat",
        [
            new RightItem("CASA_DESCHIDERE_TURA", "Deschidere tură casă"),
            new RightItem("CASA_INCHIDERE_TURA", "Închidere tură casă"),
            new RightItem("CASA_RAPORT_X", "Raport X"),
            new RightItem("CASA_RAPORT_Z", "Raport Z / închidere fiscală"),
        ], StartsExpanded: false),
    ];

    /// <summary>Coduri din secțiuni (persistate), fără mod pornire și fără oglindă „toate mesele”.</summary>
    public static IEnumerable<string> AllSectionCheckboxCodes()
    {
        foreach (var s in Sections)
        {
            foreach (var it in s.Items)
            {
                if (it.MirrorsAccessAllTables)
                    continue;
                yield return it.Code;
            }
        }
    }

    /// <summary>Toate valorile posibile în DB (inclusiv un singur mod de pornire odată).</summary>
    public static HashSet<string> AllCodes()
    {
        var h = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var c in AllSectionCheckboxCodes())
            h.Add(c);
        h.Add(InchideAplicatie);
        foreach (var (c, _) in StartupOptions)
            h.Add(c);
        return h;
    }

    public static string ResolveStartupMode(IReadOnlySet<string> granted)
    {
        if (granted.Contains(StartupDelivery))
            return StartupDelivery;
        if (granted.Contains(StartupRestaurant))
            return StartupRestaurant;
        return StartupNormal;
    }

    public static void SetStartupMode(HashSet<string> granted, string selectedCode)
    {
        granted.Remove(StartupNormal);
        granted.Remove(StartupRestaurant);
        granted.Remove(StartupDelivery);
        var c = string.IsNullOrWhiteSpace(selectedCode) ? StartupNormal : selectedCode.Trim();
        if (c.Equals(StartupDelivery, StringComparison.OrdinalIgnoreCase))
            granted.Add(StartupDelivery);
        else if (c.Equals(StartupRestaurant, StringComparison.OrdinalIgnoreCase))
            granted.Add(StartupRestaurant);
        else
            granted.Add(StartupNormal);
    }

    public static HashSet<string> DefaultWaiterRights()
    {
        var h = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var code in AllSectionCheckboxCodes())
            h.Add(code);
        h.Add(InchideAplicatie);
        SetStartupMode(h, StartupNormal);
        return h;
    }

    public static HashSet<string> DefaultShiftLeadRights()
    {
        var h = DefaultWaiterRights();
        h.Add("ACCES_MESE_ALTI_OSPATARI");
        h.Add("ISTORIC_COMENZI_ALTII");
        h.Add("ANULARE_COMANDA");
        h.Add("ANULARE_INCASARE_STORNO");
        h.Add("RAPORT_INCASARI_TIPARIRE");
        SetStartupMode(h, StartupRestaurant);
        return h;
    }

    public static HashSet<string> DefaultAdministratorRights() => DefaultWaiterRights();
}

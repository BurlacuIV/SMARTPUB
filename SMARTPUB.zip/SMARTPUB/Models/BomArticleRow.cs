namespace SMARTPUB.Models;

public sealed class BomArticleRow
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Um { get; set; } = "";
    public decimal Tva { get; set; }
    public string Categorie { get; set; } = "";
    public decimal PretVanz { get; set; }
}

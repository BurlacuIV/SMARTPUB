namespace SMARTPUB.Models;

public sealed class SagaCompany
{
    public string Code { get; init; } = "";
    public string Name { get; init; } = "";
    public string DatabasePath { get; init; } = "";
    public bool IsBlocked { get; init; }

    public override string ToString()
        => string.IsNullOrWhiteSpace(Code) ? Name : $"{Code} - {Name}";
}

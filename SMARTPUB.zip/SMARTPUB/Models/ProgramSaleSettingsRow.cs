namespace SMARTPUB.Models;

/// <summary>Setări fila „Vânzare” (model PubLine).</summary>
public sealed class ProgramSaleSettingsRow
{
    public bool ArticoleUltimaGestiune { get; set; } = true;
    public bool VindeLaSelectare { get; set; } = true;
    public bool CumuleazaLaVanzare { get; set; } = true;
    public bool CumuleazaPeNota { get; set; }
    public bool CumuleazaPeBonFiscal { get; set; }
    public bool AfiseazaStocNegativ { get; set; } = true;
    public bool PermiteVanzareStocNegativ { get; set; } = true;
    public bool IncasareFaraComandaFerma { get; set; }
    public bool AfiseazaButonComandaFerma { get; set; }
    public bool TiparireAutoComandaFermaLaValidare { get; set; } = true;
    public bool IesireAutoDupaValidare { get; set; } = true;
    public bool InchideBonAutoDupaVanzare { get; set; }
    public bool TiparireAutoNotaFaraPreview { get; set; } = true;
    public bool TiparireAutoBonLaIncasare { get; set; }
    public bool IesireAutoDupaTiparireBonFiscal { get; set; }
    public bool AfiseazaGestiuneModButoane { get; set; }
    public bool AfiseazaPretModButoane { get; set; }
    public bool SuneteMonitorComenzi { get; set; }
    public bool GestiuneImplicitaLaGrupa { get; set; } = true;
    public bool IncasareRapida { get; set; }
    public bool TastaturaVirtuala { get; set; } = true;

    /// <summary>Butoane | Lista</summary>
    public string ModVizualizareArticole { get; set; } = "Buttons";

    /// <summary>Alphabetical | SalesOrder</summary>
    public string ModSortareArticole { get; set; } = "SalesOrder";

    /// <summary>Printer | Gestiune</summary>
    public string TiparireComandaFerma { get; set; } = "Gestiune";

    public decimal PlafonVanzare { get; set; }
}

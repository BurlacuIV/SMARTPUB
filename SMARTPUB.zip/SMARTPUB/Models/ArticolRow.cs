namespace SMARTPUB.Models;

public sealed class ArticolRow
{
    public string COD { get; set; } = "";
    public string DENUMIRE { get; set; } = "";
    public string? UM { get; set; }
    public short TVA { get; set; }
    public string? DEN_TIP { get; set; }
    public string? TIP { get; set; }
    public decimal? STOC { get; set; }
    public decimal? PRET_VANZ { get; set; }
    public decimal? PRET_V_TVA { get; set; }
    public decimal? PRET_VANZ2 { get; set; }
    public decimal? PRET_V_TV2 { get; set; }
    public short IS_VALUTA { get; set; }
    public short BLOCAT { get; set; }
    public long PLU { get; set; }
    public long COD_BARE { get; set; }
    public decimal? BRUT { get; set; }
    public decimal? CANT_MIN { get; set; }
    public string? GRUPA { get; set; }
    public string? TEXT_SUPL { get; set; }
    public int GARANTIE { get; set; }
    public decimal? GREUTATE { get; set; }
    public short OK { get; set; }
    public short IS_LOT { get; set; }
    public string? COD_CER { get; set; }
    public string? CATEGORIE { get; set; }
    public string? COD_FE { get; set; }
    public string? COD_CPV { get; set; }
    public string? COD_SGR { get; set; }
    public decimal? VOLUM { get; set; }
    public string? TIP_A { get; set; }
    public string? TARA_ORIG { get; set; }
    public decimal? GREUTATE_B { get; set; }
}

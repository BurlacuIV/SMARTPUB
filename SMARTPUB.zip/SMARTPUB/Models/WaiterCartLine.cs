using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace SMARTPUB.Models;

public sealed class WaiterCartLine : INotifyPropertyChanged
{
    private decimal _qty = 1;
    private decimal _unitPrice;
    private string _notes = "";
    private string _gestiuneCode = "";
    private string _gestiuneName = "";

    public string ProductCode { get; set; } = "";
    public string ProductName { get; set; } = "";

    /// <summary>Gestiunea aleasă la vânzare. Are prioritate peste gestiunea implicită din articol.</summary>
    public string GestiuneCode
    {
        get => _gestiuneCode;
        set
        {
            var v = (value ?? "").Trim();
            if (_gestiuneCode == v)
                return;
            _gestiuneCode = v;
            OnPropertyChanged();
            OnPropertyChanged(nameof(GestiuneDisplay));
        }
    }

    public string GestiuneName
    {
        get => _gestiuneName;
        set
        {
            var v = (value ?? "").Trim();
            if (_gestiuneName == v)
                return;
            _gestiuneName = v;
            OnPropertyChanged();
            OnPropertyChanged(nameof(GestiuneDisplay));
        }
    }

    public decimal UnitPrice
    {
        get => _unitPrice;
        set
        {
            if (_unitPrice == value)
                return;
            _unitPrice = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(LineTotal));
        }
    }

    /// <summary>TVA % din catalog (informativ pe bon).</summary>
    public decimal TvaPct { get; set; }

    public string Notes
    {
        get => _notes;
        set
        {
            if (_notes == value)
                return;
            _notes = value ?? "";
            OnPropertyChanged();
        }
    }

    public decimal Qty
    {
        get => _qty;
        set
        {
            if (value < 0.01m)
                value = 0.01m;
            if (_qty == value)
                return;
            _qty = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(LineTotal));
        }
    }

    /// <summary>Valoare linie (cant. × preț unitar).</summary>
    public decimal LineTotal => Math.Round(Qty * UnitPrice, 2, MidpointRounding.AwayFromZero);

    public string GestiuneDisplay =>
        string.IsNullOrWhiteSpace(GestiuneName)
            ? GestiuneCode
            : $"{GestiuneName} ({GestiuneCode})";

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}

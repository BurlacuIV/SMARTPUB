namespace SMARTPUB.Models;

/// <summary>Operator POS / ospătar (înlocuitor OSPATARI din PubLine).</summary>
public sealed class PosOperatorRow
{
    public string Id { get; set; } = "";
    public string Username { get; set; } = "";
    public string DisplayName { get; set; } = "";
    /// <summary>PIN simplu; gol = autentificare fără verificare (doar selectare).</summary>
    public string? PasswordPin { get; set; }

    /// <summary>Administrator | ShiftLead | Waiter | Custom</summary>
    public string Role { get; set; } = "Waiter";

    public bool Active { get; set; } = true;
    /// <summary>Dacă true, ignoră restricțiile din SP_POS_OPERATOR_TABLE.</summary>
    public bool AccessAllTables { get; set; } = true;

    public string? Cnp { get; set; }
    public string? Buletin { get; set; }
    public string? Politie { get; set; }
    /// <summary>Cod card / cititor (RFID etc.).</summary>
    public string? CardBarcode { get; set; }

    public string RoleDisplay => Role.Trim() switch
    {
        "Administrator" => "Administrator",
        "ShiftLead" => "Șef de tură",
        "Waiter" => "Ospătar",
        "Custom" => "Personalizat",
        _ => Role
    };
}

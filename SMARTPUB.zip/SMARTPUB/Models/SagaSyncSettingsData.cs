using SMARTPUB;

namespace SMARTPUB.Models;

/// <summary>Snapshot setări sincronizare SAGA (local + opțional client/server).</summary>
public sealed class SagaSyncSettingsData
{
    public SagaConnectionMode ConnectionMode { get; set; } = SagaConnectionMode.Embedded;

    /// <summary>Calea locală la folderul SAGA (CONFIG.FDB local) — folosită la mod Embedded.</summary>
    public string SagaRootPath { get; set; } = "";

    /// <summary>Hostname sau IP Firebird Server (mod Server).</summary>
    public string? ServerHost { get; set; }

    public int ServerPort { get; set; } = SagaConnectionDefaults.FirebirdServerPort;

    /// <summary>Folderul SAGA pe server (părintele CONFIG.FDB), ex. D:\SAGA C.3.0 — folosit la scanare client.</summary>
    public string? ServerSagaRoot { get; set; }

    public string? FbClientPath { get; set; }
    public SagaCompany? Company { get; set; }
}

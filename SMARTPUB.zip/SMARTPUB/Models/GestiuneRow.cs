namespace SMARTPUB.Models;

public sealed class GestiuneRow
{
    public string COD { get; set; } = "";
    public string DENUMIRE { get; set; } = "";
    public string? GESTIONAR { get; set; }
    public short TIP_EVAL { get; set; }
    public string? GLOB_371 { get; set; }
    public string? GLOB_378 { get; set; }
    public string? GLOB_707 { get; set; }
    public string? GLOB_4428 { get; set; }
    public string? GLOB_607 { get; set; }
    public decimal PROCTVA { get; set; }
    public string? CATEGORIE { get; set; }
}

namespace SMARTPUB.Models;

/// <summary>Rând pentru lista de articole cu rețetă (zonă inferioară).</summary>
public sealed class RecipeMasterListRow
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Um { get; set; } = "";
    public string Categorie { get; set; } = "";
    public decimal Stoc { get; set; }
    public decimal PretVanz { get; set; }
    public decimal Tva { get; set; }

    public decimal PretCuTva => PretVanz;

    public bool Selected { get; set; }
}

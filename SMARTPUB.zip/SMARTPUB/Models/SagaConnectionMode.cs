namespace SMARTPUB.Models;

/// <summary>Mod conexiune la baza firmei SAGA (PubLine: Client–Server = TCP către Firebird Server).</summary>
public enum SagaConnectionMode
{
    /// <summary>Fișier .fdb local, Firebird embedded (blochează fișierul; incompatibil cu SAGA deschisă pe același fișier).</summary>
    Embedded,

    /// <summary>Client TCP la Firebird Server; calea bazei este cea de pe mașina serverului.</summary>
    Server
}

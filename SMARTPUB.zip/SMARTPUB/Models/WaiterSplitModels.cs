using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
namespace SMARTPUB.Models;

public enum WaiterSplitSourceKind
{
    Draft = 0,
    Sent = 1
}

/// <summary>Linia sursă pe masă (draft sau trimisă la bucătărie), cu cantitate disponibilă pentru alocare.</summary>
public sealed class WaiterSplitPoolLine : INotifyPropertyChanged
{
    private decimal _totalQty;
    private decimal _allocatedQty;

    public string LineKey { get; init; } = "";
    public WaiterSplitSourceKind Source { get; init; }
    public string ProductCode { get; init; } = "";
    public string ProductName { get; init; } = "";
    public decimal UnitPrice { get; init; }
    public decimal TvaPct { get; init; }
    public string Notes { get; init; } = "";

    public decimal TotalQty
    {
        get => _totalQty;
        set { if (_totalQty == value) return; _totalQty = value; Notify(); NotifyAvail(); }
    }

    public decimal AllocatedQty
    {
        get => _allocatedQty;
        set { if (_allocatedQty == value) return; _allocatedQty = value; Notify(); NotifyAvail(); }
    }

    public decimal AvailableQty => SplitQtyMath.Available(TotalQty, AllocatedQty);

    public decimal LineTotal => Math.Round(AvailableQty * UnitPrice, 2, MidpointRounding.AwayFromZero);

    public string DisplayQty =>
        AvailableQty == Math.Floor(AvailableQty)
            ? ((int)AvailableQty).ToString()
            : AvailableQty.ToString("0.##");

    public event PropertyChangedEventHandler? PropertyChanged;

    private void Notify([CallerMemberName] string? n = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));

    private void NotifyAvail()
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(AvailableQty)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LineTotal)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DisplayQty)));
    }

    public static string BuildKey(WaiterSplitSourceKind source, string productCode, decimal unitPrice, string? notes) =>
        $"{(int)source}|{productCode.Trim().ToUpperInvariant()}|{unitPrice:0.####}|{(notes ?? "").Trim()}";
}

/// <summary>Linie alocată pe o notă de plată.</summary>
public sealed class WaiterSplitAllocLine : INotifyPropertyChanged
{
    private decimal _qty;

    public string PoolLineKey { get; init; } = "";
    public WaiterSplitSourceKind Source { get; init; }
    public string ProductCode { get; init; } = "";
    public string ProductName { get; init; } = "";
    public decimal UnitPrice { get; init; }
    public decimal TvaPct { get; init; }
    public string Notes { get; init; } = "";

    public decimal Qty
    {
        get => _qty;
        set
        {
            value = SplitQtyMath.Round(value);
            if (_qty == value) return;
            _qty = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Qty)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LineTotal)));
        }
    }

    public decimal LineTotal => Math.Round(Qty * UnitPrice, 2, MidpointRounding.AwayFromZero);

    public event PropertyChangedEventHandler? PropertyChanged;

    public WaiterCartLine ToCartLine() => new()
    {
        ProductCode = ProductCode,
        ProductName = ProductName,
        UnitPrice = UnitPrice,
        TvaPct = TvaPct,
        Qty = Qty,
        Notes = Notes
    };
}

/// <summary>Notă de plată (persoană / grup) pe masă.</summary>
public sealed class WaiterSplitBill : INotifyPropertyChanged
{
    private bool _isPaid;

    public int BillIndex { get; init; }
    public string Label => $"Nota {BillIndex}";
    public ObservableCollection<WaiterSplitAllocLine> Lines { get; } = new();

    public bool IsPaid
    {
        get => _isPaid;
        set
        {
            if (_isPaid == value) return;
            _isPaid = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsPaid)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(StatusText)));
        }
    }

    public string? SaleId { get; set; }

    public decimal Total => Lines.Sum(l => l.LineTotal);

    public string StatusText => IsPaid ? "Încasată" : (Lines.Count == 0 ? "Golă" : "Deschisă");

    public event PropertyChangedEventHandler? PropertyChanged;

    public void RefreshTotal() =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Total)));
}

public sealed class WaiterSplitDragPayload
{
    public string PoolLineKey { get; init; } = "";
    public IReadOnlyList<string> PoolLineKeys { get; init; } = Array.Empty<string>();
    public int? FromBillIndex { get; init; }
    public decimal Qty { get; init; }

    public IReadOnlyList<string> EffectivePoolLineKeys =>
        PoolLineKeys.Count > 0 ? PoolLineKeys : new[] { PoolLineKey };
}

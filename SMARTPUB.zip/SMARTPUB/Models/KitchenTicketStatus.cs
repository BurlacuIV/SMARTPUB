namespace SMARTPUB.Models;

public enum KitchenTicketStatus
{
    New,
    InProgress,
    Ready,
    Served,
    Cancelled
}

using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace SMARTPUB.Models;

public sealed class ProgramDisplayConfig
{
    public int GrupPanelHeight { get; set; } = 120;
    public int ArticolPanelHeight { get; set; } = 80;
}

public sealed class TransferModMapRow
{
    public string MethodKey { get; set; } = "";
    public string ClientCode { get; set; } = "";
    public string ContTransfer { get; set; } = "";
}

public sealed class ProgramTransferDocConfig
{
    public string ImplicitClient { get; set; } = "";
    public string DefaultGestiuneCode { get; set; } = "";
    public string DefaultGestiuneName { get; set; } = "";
    public string ContDiscount { get; set; } = "";
    public string ContProtocol { get; set; } = "";
    public string ContBacsis { get; set; } = "";
    public string SerieFacturi { get; set; } = "";
    public string SerieBonuri { get; set; } = "";
    public bool AutoTransferAfterPayment { get; set; }
    public bool IncludeModIncasarePeFactura { get; set; }
    public string TextSuplimentarFactura { get; set; } = "";
    public bool CazareIncludeNoptii { get; set; }
    public bool CazareIncludePerioada { get; set; }
    public bool CazareIncludeCamera { get; set; }
    public List<TransferModMapRow> ModMap { get; set; } = new();
}

public sealed class ProgramFiscalConfig
{
    public string Model { get; set; } = "";
    public string Driver { get; set; } = "FiscalNet";
    public string MonitorFolder { get; set; } = "";
    public bool TrimiteSumaCardLaPos { get; set; }
    public bool AfiseazaOperatorPeBon { get; set; }
    public bool AfiseazaNrComandaPeBon { get; set; }
    public bool AfiseazaDenumireArticolPeBon { get; set; }
    public string TextPublicitar { get; set; } = "";
    public Dictionary<string, int> PlataIndices { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<decimal, int> TvaIndices { get; set; } = new();
}

public sealed class NetworkServerRow : INotifyPropertyChanged
{
    private string _name = "";
    private string _ip = "";

    public int Id { get; set; }

    public string Name
    {
        get => _name;
        set
        {
            if (_name == value)
                return;
            _name = value;
            OnPropertyChanged();
        }
    }

    public string Ip
    {
        get => _ip;
        set
        {
            if (_ip == value)
                return;
            _ip = value;
            OnPropertyChanged();
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? n = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
}

public sealed class ProgramNetworkConfig
{
    public string RootPath { get; set; } = "";
    public bool MobilePrintComenziNotaBon { get; set; }
    public List<NetworkServerRow> Servers { get; set; } = new();
}

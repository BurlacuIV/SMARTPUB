namespace SMARTPUB.Models;

public sealed class SyncedProductRow
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Um { get; set; } = "";
    public decimal Tva { get; set; }
    public string Categorie { get; set; } = "";

    /// <summary>Tip articol (SAGA <c>ARTICOLE.DEN_TIP</c>).</summary>
    public string DenTip { get; set; } = "";

    /// <summary>Cod tip SAGA pe 1 caracter (<c>ARTICOLE.TIP</c>).</summary>
    public string TipSaga { get; set; } = "";

    /// <summary>Grupa din SAGA (cod în ARTICOLE.GRUPA).</summary>
    public string Grupa { get; set; } = "";

    /// <summary>Denumire grupă (din lookup); dacă lipsește numele, se afișează codul grupă/categorie.</summary>
    public string GrupaAfisat { get; set; } = "";

    /// <summary>Denumire gestiune (din GESTIUNI, nu codul).</summary>
    public string GestiuneAfisat { get; set; } = "";
    public decimal PretVanz { get; set; }
    public bool IsBlocked { get; set; }
    public int RecipeLinesCount { get; set; }
    public DateTime? UpdatedAt { get; set; }

    /// <summary>Stoc sincronizat / editabil după migrare schema.</summary>
    public decimal Stoc { get; set; }

    public string CodBare { get; set; } = "";
    public int Plu { get; set; }
    public string Gestiune { get; set; } = "";
    public string ImagePath { get; set; } = "";

    /// <summary>Override destinație rutare comandă (BAR / BUCATARIE / gol = moștenește din grupă).</summary>
    public string Destinatie { get; set; } = "";

    /// <summary>Destinație efectivă rezolvată (override sau mapare grupă); doar pentru afișare.</summary>
    public string DestinatieEfectiva { get; set; } = "";

    /// <summary>Preț final de vânzare, cu TVA inclus, sincronizat din SAGA.</summary>
    public decimal PretCuTva => PretVanz;
}


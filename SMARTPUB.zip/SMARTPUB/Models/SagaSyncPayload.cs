namespace SMARTPUB.Models;

public sealed class SagaSyncPayload
{
    public List<SagaSyncGestiune> Gestiuni { get; set; } = new();
    /// <summary>GRUPARI din SAGA (cod → denumire pentru afișare).</summary>
    public List<SagaSyncCodDenumire> Grupari { get; set; } = new();
    /// <summary>CATEGORII din SAGA (cod → denumire categorie articol).</summary>
    public List<SagaSyncCodDenumire> Categorii { get; set; } = new();
    public List<SagaSyncArticol> Articole { get; set; } = new();
    public List<SagaSyncClient> Clienti { get; set; } = new();
    public List<SagaSyncReteta> Retete { get; set; } = new();
    public List<SagaSyncRetetaDet> ReteteDet { get; set; } = new();
    public List<SagaSyncRecipeLine> RecipeLines { get; set; } = new();
}

public sealed class SagaSyncCodDenumire
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
}

public sealed class SagaSyncGestiune
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Gestionar { get; set; } = "";
    public int TipEval { get; set; }
    public string Categorie { get; set; } = "";
    public decimal ProcTva { get; set; }
}

public sealed class SagaSyncArticol
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Um { get; set; } = "";
    public decimal Tva { get; set; }
    public string Categorie { get; set; } = "";
    /// <summary>GRUPA din ARTICOLE (SAGA).</summary>
    public string Grupa { get; set; } = "";
    /// <summary>Gestiune implicită articol (ARTICOLE.GESTIUNE), dacă există.</summary>
    public string Gestiune { get; set; } = "";
    public decimal PretVanz { get; set; }
    public bool IsBlocked { get; set; }

    /// <summary>Tip articol afișat în SAGA: <c>ARTICOLE.DEN_TIP</c> (ex. „Materii prime 301B”).</summary>
    public string DenTip { get; set; } = "";

    /// <summary>Cod tip 1 caracter: <c>ARTICOLE.TIP</c>.</summary>
    public string TipSaga { get; set; } = "";
}

public sealed class SagaSyncClient
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string FiscalCode { get; set; } = "";
    public string RegCom { get; set; } = "";
    public string Phone { get; set; } = "";
    public string Email { get; set; } = "";
    public string Address { get; set; } = "";
    public bool IsBlocked { get; set; }
}

public sealed class SagaSyncReteta
{
    public string ArticolCode { get; set; } = "";
    public string Operatie { get; set; } = "";
    public string Tip { get; set; } = "";
    public string Name { get; set; } = "";
    public string Um { get; set; } = "";
    public decimal Quantity { get; set; }
    public string Gestiune { get; set; } = "";
}

public sealed class SagaSyncRetetaDet
{
    public string ArticolCode { get; set; } = "";
    public string ComponentCode { get; set; } = "";
    public string ComponentName { get; set; } = "";
    public decimal Quantity { get; set; }
    public string Um { get; set; } = "";
    public string Gestiune { get; set; } = "";
    public string Tip { get; set; } = "";
}

public sealed class SagaSyncRecipeLine
{
    public string LineKey { get; set; } = "";
    public string ArticolCode { get; set; } = "";
    public string SourceTable { get; set; } = "";
    public string Tip { get; set; } = "";
    public string Gestiune { get; set; } = "";
    public string Operatie { get; set; } = "";
    public string ComponentCode { get; set; } = "";
    public string ComponentName { get; set; } = "";
    public string Um { get; set; } = "";
    public decimal Quantity { get; set; }
}


namespace SMARTPUB.Models;

/// <summary>
/// Linie BOM: materie primă (cod din SAGA) sau sub-produs (cod din SP_BOM_ARTICLE).
/// </summary>
public sealed class BomLineRow
{
    public string ParentCode { get; set; } = "";
    public int LineNo { get; set; }
    /// <summary>0 = materie primă (SAGA), 1 = sub-produs (rețetă locală)</summary>
    public short LineKind { get; set; }
    public string ComponentCode { get; set; } = "";
    public decimal Qty { get; set; }
    public string Um { get; set; } = "";
    public string Gestiune { get; set; } = "";
    public string DenTip { get; set; } = "";
}

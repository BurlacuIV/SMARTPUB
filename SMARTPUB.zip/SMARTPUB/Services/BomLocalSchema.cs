using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

public static class BomLocalSchema
{
    public static void EnsureSchema(FbConnection conn)
    {
        EnsureTable(conn, "SP_BOM_ARTICLE", @"
CREATE TABLE SP_BOM_ARTICLE (
  CODE VARCHAR(24) NOT NULL,
  NAME VARCHAR(120),
  UM VARCHAR(10),
  TVA NUMERIC(10,2),
  CATEGORIE VARCHAR(40),
  PRET_VANZ NUMERIC(18,4),
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (CODE)
)");

        EnsureTable(conn, "SP_BOM_LINE", @"
CREATE TABLE SP_BOM_LINE (
  PARENT_CODE VARCHAR(24) NOT NULL,
  LINE_NO INTEGER NOT NULL,
  LINE_KIND SMALLINT NOT NULL,
  COMPONENT_CODE VARCHAR(24) NOT NULL,
  QTY NUMERIC(18,6) NOT NULL,
  UM VARCHAR(10),
  GESTIUNE VARCHAR(16),
  DEN_TIP VARCHAR(80),
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (PARENT_CODE, LINE_NO)
)");
    }

    private static void EnsureTable(FbConnection conn, string tableName, string ddl)
    {
        if (TableExists(conn, tableName))
            return;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = ddl;
        cmd.ExecuteNonQuery();
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1
FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0
  AND TRIM(RDB$RELATION_NAME) = @T
ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

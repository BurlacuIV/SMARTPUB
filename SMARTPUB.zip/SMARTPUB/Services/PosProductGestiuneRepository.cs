using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

/// <summary>Memorează gestiunea aleasă manual la vânzare pentru articole fără gestiune în SAGA.</summary>
public sealed class PosProductGestiuneRepository
{
    public void EnsureSchema(FbConnection conn)
    {
        if (TableExists(conn, "SP_POS_ARTICLE_GESTIUNE"))
            return;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
CREATE TABLE SP_POS_ARTICLE_GESTIUNE (
    PRODUCT_CODE VARCHAR(24) NOT NULL,
    GESTIUNE_CODE VARCHAR(24) NOT NULL,
    GESTIUNE_NAME VARCHAR(100),
    UPDATED_AT TIMESTAMP,
    PRIMARY KEY (PRODUCT_CODE)
)";
        cmd.ExecuteNonQuery();
    }

    public ProductGestiuneChoice? Load(FbConnection conn, string productCode)
    {
        EnsureSchema(conn);
        var code = (productCode ?? "").Trim();
        if (code.Length == 0)
            return null;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT TRIM(GESTIUNE_CODE), TRIM(COALESCE(GESTIUNE_NAME, ''))
FROM SP_POS_ARTICLE_GESTIUNE
WHERE TRIM(PRODUCT_CODE) = TRIM(@C)
ROWS 1";
        cmd.Parameters.AddWithValue("@C", code);
        using var rd = cmd.ExecuteReader();
        if (!rd.Read())
            return null;

        var gestCode = (rd[0]?.ToString() ?? "").Trim();
        if (gestCode.Length == 0)
            return null;

        return new ProductGestiuneChoice(gestCode, (rd[1]?.ToString() ?? "").Trim());
    }

    public void Save(FbConnection conn, string productCode, string gestiuneCode, string? gestiuneName)
    {
        EnsureSchema(conn);
        var code = (productCode ?? "").Trim();
        var gest = (gestiuneCode ?? "").Trim();
        if (code.Length == 0 || gest.Length == 0)
            return;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
UPDATE OR INSERT INTO SP_POS_ARTICLE_GESTIUNE
  (PRODUCT_CODE, GESTIUNE_CODE, GESTIUNE_NAME, UPDATED_AT)
VALUES
  (@P, @G, @N, CURRENT_TIMESTAMP)
MATCHING (PRODUCT_CODE)";
        cmd.Parameters.AddWithValue("@P", code);
        cmd.Parameters.AddWithValue("@G", gest);
        cmd.Parameters.AddWithValue("@N", string.IsNullOrWhiteSpace(gestiuneName) ? DBNull.Value : gestiuneName.Trim());
        cmd.ExecuteNonQuery();
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

public sealed record ProductGestiuneChoice(string Code, string Name);

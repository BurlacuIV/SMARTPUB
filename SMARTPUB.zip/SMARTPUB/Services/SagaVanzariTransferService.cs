using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

/// <summary>
/// Transfer vânzări SMARTPUB → SAGA <c>IESIRI</c> / <c>IES_DET</c> (structură compatibilă cu ieșirile din contabilitate).
/// </summary>
public static class SagaVanzariTransferService
{
    /// <summary>Cod client implicit din SAGA (ex. „VANZARI TERASA” la cod 00001).</summary>
    public const string DefaultClientCode = "00001";

    public static bool TryTransferSale(string saleId, out string message, bool keepReadyOnFailure = false)
    {
        return TryTransferSales(new[] { saleId }, out message, keepReadyOnFailure);
    }

    /// <summary>
    /// Transferă vânzările grupat PubLine-like: un document SAGA pe zi, cu toate articolele în detalii.
    /// </summary>
    public static bool TryTransferSales(IReadOnlyList<string> saleIds, out string message, bool keepReadyOnFailure = false)
    {
        message = "";
        var ids = saleIds
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x => x.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (ids.Count == 0)
        {
            message = "Nu există vânzări selectate pentru transfer.";
            return false;
        }

        using var smart = SmartPubDb.OpenEmbedded();
        SmartPubBootstrap.ApplySchema(smart);

        var headers = new List<PosSaleHeaderRow>();
        foreach (var id in ids)
        {
            var h = PosSaleRepository.GetHeader(smart, id);
            if (h != null)
                headers.Add(h);
        }

        if (headers.Count == 0)
        {
            message = "Vânzările selectate nu există.";
            return false;
        }

        var invalid = headers
            .Where(h => !string.Equals(h.SagaTransferStatus, PosSaleRepository.SagaReady, StringComparison.OrdinalIgnoreCase))
            .ToList();
        if (invalid.Count > 0)
        {
            message = "Există vânzări care nu sunt pregătite pentru transfer SAGA: " +
                      string.Join(", ", invalid.Take(5).Select(x => $"#{x.OrderNo} ({x.SagaTransferStatus})"));
            return false;
        }

        var settings = new SagaSyncSettingsRepository().LoadData(smart);
        var company = settings.Company;
        var sagaPath = company?.DatabasePath?.Trim();
        if (string.IsNullOrWhiteSpace(sagaPath))
        {
            message = "Setați firma SAGA (calea către CONT_BAZA.FDB) în „Setări sincronizare SAGA”.";
            UpdateFailure(smart, ids, message, keepReadyOnFailure);
            return false;
        }

        var hasLocalSagaDb = File.Exists(sagaPath);
        var serverMode = settings.ConnectionMode == SagaConnectionMode.Server
                         && !(hasLocalSagaDb && IsLocalHost(settings.ServerHost));
        if (!serverMode && !File.Exists(sagaPath))
        {
            message = "Fișierul bazei SAGA nu există: " + sagaPath;
            UpdateFailure(smart, ids, message, keepReadyOnFailure);
            return false;
        }

        if (serverMode)
        {
            if (string.IsNullOrWhiteSpace(settings.ServerHost))
            {
                message = "Mod client Firebird: completați IP/hostname server în „Setări sincronizare SAGA”.";
                UpdateFailure(smart, ids, message, keepReadyOnFailure);
                return false;
            }

            if (string.IsNullOrWhiteSpace(settings.ServerSagaRoot))
            {
                message = "Mod client Firebird: completați rădăcina SAGA pe server în setări.";
                UpdateFailure(smart, ids, message, keepReadyOnFailure);
                return false;
            }
        }

        var sagaRootForWorker = serverMode
            ? (settings.ServerSagaRoot ?? "").Trim()
            : (settings.SagaRootPath ?? "").Trim();
        var transferCfg = new ProgramExtendedConfigRepository().LoadTransfer(smart);
        var groups = BuildTransferGroups(smart, headers, transferCfg);
        if (groups.Count == 0)
        {
            message = "Nu există linii de transferat.";
            return false;
        }

        var successCount = 0;
        var errors = new List<string>();
        foreach (var group in groups)
        {
            if (string.IsNullOrWhiteSpace(group.TransferOptions.TransferAccount))
            {
                var errMsg =
                    $"Cont încasare lipsă pentru {group.DocumentDate:dd.MM.yyyy} " +
                    $"(mod {group.TransferOptions.MethodKey}). Completați „Transfer încasare (cont)” în Configurare program → Transfer documente.";
                errors.Add(errMsg);
                UpdateFailure(smart, group.Headers.Select(x => x.Id), errMsg, keepReadyOnFailure);
                continue;
            }

            var jsonPath = Path.Combine(Path.GetTempPath(), $"smartpub_iesiri_{group.DocumentDate:yyyyMMdd}_{Guid.NewGuid():N}.json");
            try
            {
                var payload = new IesiriWorkerJsonDto
                {
                    SagaDbPath = sagaPath,
                    SagaRootPath = sagaRootForWorker,
                    FbClientPath = string.IsNullOrWhiteSpace(settings.FbClientPath) ? null : settings.FbClientPath.Trim(),
                    ConnectionMode = serverMode ? "SERVER" : null,
                    ServerHost = serverMode ? settings.ServerHost?.Trim() : null,
                    ServerPort = serverMode ? settings.ServerPort : null,
                    DefaultClientCode = group.TransferOptions.ClientCode,
                    Header = new IesiriWorkerHeaderJsonDto
                    {
                        OrderNo = group.DocumentNo,
                        PaidAt = group.DocumentDate,
                        Valoare = group.Lines.Sum(x => x.Valoare),
                        ValoareTva = group.Lines.Sum(x => x.ValoareTva),
                        Total = group.Lines.Sum(x => x.Total),
                        DocumentTip = "B",
                        SerieBonuri = transferCfg.SerieBonuri,
                        BonCount = group.Headers.Count,
                        PaymentMethod = group.TransferOptions.MethodKey,
                        PaymentSummary = group.TransferOptions.PaymentSummary,
                        TransferAccount = group.TransferOptions.TransferAccount,
                        ExtraInfo = BuildBonFiscalExtraInfo(transferCfg, group.TransferOptions)
                    },
                    Lines = group.Lines.Select(l => new IesiriWorkerLineJsonDto
                    {
                        ProductCode = l.ProductCode,
                        ProductName = l.ProductName,
                        CodGestiune = l.CodGestiune,
                        DenGest = l.DenGest,
                        Um = l.Um,
                        TvaPct = l.TvaPct,
                        Qty = l.Qty,
                        UnitPrice = l.UnitPrice,
                        Valoare = l.Valoare,
                        ValoareTva = l.ValoareTva,
                        Total = l.Total
                    }).ToList()
                };

                var jsonOpts = new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                    WriteIndented = false
                };
                File.WriteAllText(jsonPath, JsonSerializer.Serialize(payload, jsonOpts));

                var worker = new SagaWorkerClient();
                var (ok, err, _, idIesire, nrIesire) = worker.TransferIesiri(jsonPath);
                if (!ok)
                {
                    var errMsg = err ?? "Transfer SAGA eșuat.";
                    errors.Add($"{group.DocumentDate:dd.MM.yyyy}: {errMsg}");
                    UpdateFailure(smart, group.Headers.Select(x => x.Id), errMsg, keepReadyOnFailure);
                    continue;
                }

                foreach (var h in group.Headers)
                    PosSaleRepository.UpdateSagaTransferResult(smart, h.Id, PosSaleRepository.SagaSent, idIesire, nrIesire, null);
                successCount++;
            }
            catch (Exception ex)
            {
                errors.Add($"{group.DocumentDate:dd.MM.yyyy}: {ex.Message}");
                UpdateFailure(smart, group.Headers.Select(x => x.Id), ex.Message, keepReadyOnFailure);
            }
            finally
            {
                try
                {
                    if (File.Exists(jsonPath))
                        File.Delete(jsonPath);
                }
                catch
                {
                    /* ignore */
                }
            }
        }

        var transferredSales = groups
            .Where(g => g.Headers.All(h => string.Equals(
                PosSaleRepository.GetHeader(smart, h.Id)?.SagaTransferStatus,
                PosSaleRepository.SagaSent,
                StringComparison.OrdinalIgnoreCase)))
            .Sum(g => g.Headers.Count);
        message = $"Transfer grupat: {successCount} document(e) SAGA, {transferredSales} bon(uri) incluse.";
        if (errors.Count > 0)
            message += "\n" + string.Join("\n", errors.Take(8));
        return errors.Count == 0;
    }

    private static List<TransferGroup> BuildTransferGroups(
        FbConnection smart,
        List<PosSaleHeaderRow> headers,
        ProgramTransferDocConfig transferCfg)
    {
        var result = new List<TransferGroup>();
        foreach (var day in headers.GroupBy(h => h.PaidAt.Date).OrderBy(g => g.Key))
        {
            var headersByMethod = day
                .OrderBy(h => h.OrderNo)
                .GroupBy(h => ResolveHeaderPaymentMethod(smart, h), StringComparer.OrdinalIgnoreCase)
                .OrderBy(g => g.Key);

            foreach (var methodGroup in headersByMethod)
            {
                var groupHeaders = methodGroup.ToList();
                var allLines = new List<PosSaleLineRow>();
                var allPayments = new List<PosSalePaymentRow>();
                foreach (var h in groupHeaders)
                {
                    allLines.AddRange(PosSaleRepository.ListLines(smart, h.Id));
                    allPayments.AddRange(PosSaleRepository.ListPayments(smart, h.Id));
                }

                EnrichLinesWithCurrentGestiune(smart, allLines);
                var lines = AggregateLines(allLines);
                if (lines.Count == 0)
                    continue;

                var transferOptions = ResolveTransferOptions(methodGroup.Key, transferCfg, allPayments);
                result.Add(new TransferGroup(
                    day.Key,
                    int.Parse(day.Key.ToString("yyyyMMdd")),
                    groupHeaders,
                    lines,
                    transferOptions));
            }
        }

        return result;
    }

    private static string ResolveHeaderPaymentMethod(FbConnection smart, PosSaleHeaderRow header)
    {
        var byMethod = PosSaleRepository.ListPayments(smart, header.Id)
            .Where(p => p.Amount > 0)
            .GroupBy(p => PosSaleRepository.NormalizeMethodKey(p.MethodKey), StringComparer.OrdinalIgnoreCase)
            .Select(g => new { Key = g.Key, Sum = g.Sum(x => x.Amount) })
            .Where(x => !string.IsNullOrWhiteSpace(x.Key))
            .OrderByDescending(x => x.Sum)
            .ToList();

        if (byMethod.Count > 0)
            return byMethod[0].Key;

        var fallback = PosSaleRepository.NormalizeMethodKey(header.ModPlata);
        if (string.IsNullOrWhiteSpace(fallback) || string.Equals(fallback, "METODE_MODERNE", StringComparison.OrdinalIgnoreCase))
            return "NUMERAR";
        return fallback;
    }

    private static void EnrichLinesWithCurrentGestiune(FbConnection smart, List<PosSaleLineRow> lines)
    {
        if (lines.Count == 0 || !TableExists(smart, "SP_SAGA_ARTICOLE"))
            return;

        var meta = LoadCurrentArticleGestiuni(smart);
        foreach (var line in lines)
        {
            var code = Norm(line.ProductCode);
            if (code.Length == 0 || !meta.TryGetValue(code, out var m))
                continue;

            // Gestiunea aleasă la vânzare are prioritate; SAGA/mirror este fallback.
            if (string.IsNullOrWhiteSpace(line.CodGestiune) && !string.IsNullOrWhiteSpace(m.GestiuneCode))
                line.CodGestiune = m.GestiuneCode;
            if (string.IsNullOrWhiteSpace(line.DenGest) && !string.IsNullOrWhiteSpace(m.GestiuneName))
                line.DenGest = m.GestiuneName;
            if (!string.IsNullOrWhiteSpace(m.Um))
                line.Um = m.Um;
        }
    }

    private static Dictionary<string, ArticleTransferMeta> LoadCurrentArticleGestiuni(FbConnection smart)
    {
        var map = new Dictionary<string, ArticleTransferMeta>(StringComparer.OrdinalIgnoreCase);
        using var cmd = smart.CreateCommand();
        cmd.CommandText = @"
SELECT
  UPPER(TRIM(A.CODE)) AS CODE,
  TRIM(COALESCE(A.GESTIUNE, '')) AS GESTIUNE,
  TRIM(COALESCE(G.NAME, '')) AS DEN_GEST,
  TRIM(COALESCE(A.UM, '')) AS UM
FROM SP_SAGA_ARTICOLE A
LEFT JOIN SP_SAGA_GESTIUNI G ON TRIM(A.GESTIUNE) = TRIM(G.CODE)";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var code = (rd["CODE"]?.ToString() ?? "").Trim();
            if (code.Length == 0)
                continue;
            map[code] = new ArticleTransferMeta(
                (rd["GESTIUNE"]?.ToString() ?? "").Trim(),
                (rd["DEN_GEST"]?.ToString() ?? "").Trim(),
                (rd["UM"]?.ToString() ?? "").Trim());
        }

        MergeReteteGestiuni(smart, map);
        MergeRecipeLineGestiuni(smart, map);
        return map;
    }

    private static void MergeReteteGestiuni(FbConnection smart, Dictionary<string, ArticleTransferMeta> map)
    {
        if (!TableExists(smart, "SP_SAGA_RETETE"))
            return;

        using var cmd = smart.CreateCommand();
        cmd.CommandText = @"
SELECT
  UPPER(TRIM(R.ARTICOL_CODE)) AS CODE,
  TRIM(COALESCE(R.GESTIUNE, '')) AS GESTIUNE,
  TRIM(COALESCE(G.NAME, '')) AS DEN_GEST,
  TRIM(COALESCE(R.UM, '')) AS UM
FROM SP_SAGA_RETETE R
LEFT JOIN SP_SAGA_GESTIUNI G ON TRIM(R.GESTIUNE) = TRIM(G.CODE)
WHERE TRIM(COALESCE(R.GESTIUNE, '')) <> ''";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var code = (rd["CODE"]?.ToString() ?? "").Trim();
            var gest = (rd["GESTIUNE"]?.ToString() ?? "").Trim();
            if (code.Length == 0 || gest.Length == 0)
                continue;
            ApplyMetaFallback(map, code, gest, rd["DEN_GEST"]?.ToString(), rd["UM"]?.ToString());
        }
    }

    private static void MergeRecipeLineGestiuni(FbConnection smart, Dictionary<string, ArticleTransferMeta> map)
    {
        if (!TableExists(smart, "SP_SAGA_RECIPE_LINES"))
            return;

        using var cmd = smart.CreateCommand();
        cmd.CommandText = @"
SELECT
  UPPER(TRIM(R.ARTICOL_CODE)) AS CODE,
  TRIM(COALESCE(R.GESTIUNE, '')) AS GESTIUNE,
  TRIM(COALESCE(G.NAME, '')) AS DEN_GEST,
  TRIM(COALESCE(R.UM, '')) AS UM
FROM SP_SAGA_RECIPE_LINES R
LEFT JOIN SP_SAGA_GESTIUNI G ON TRIM(R.GESTIUNE) = TRIM(G.CODE)
WHERE TRIM(COALESCE(R.GESTIUNE, '')) <> ''
  AND UPPER(TRIM(COALESCE(R.SOURCE_TABLE, ''))) = 'ART_ANTE'";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var code = (rd["CODE"]?.ToString() ?? "").Trim();
            var gest = (rd["GESTIUNE"]?.ToString() ?? "").Trim();
            if (code.Length == 0 || gest.Length == 0)
                continue;
            ApplyMetaFallback(map, code, gest, rd["DEN_GEST"]?.ToString(), rd["UM"]?.ToString());
        }
    }

    private static void ApplyMetaFallback(
        Dictionary<string, ArticleTransferMeta> map,
        string code,
        string gestiune,
        string? denGest,
        string? um)
    {
        if (!map.TryGetValue(code, out var existing))
        {
            map[code] = new ArticleTransferMeta(gestiune.Trim(), (denGest ?? "").Trim(), (um ?? "").Trim());
            return;
        }

        if (!string.IsNullOrWhiteSpace(existing.GestiuneCode))
            return;

        map[code] = existing with
        {
            GestiuneCode = gestiune.Trim(),
            GestiuneName = string.IsNullOrWhiteSpace(existing.GestiuneName) ? (denGest ?? "").Trim() : existing.GestiuneName,
            Um = string.IsNullOrWhiteSpace(existing.Um) ? (um ?? "").Trim() : existing.Um
        };
    }

    private static List<PosSaleLineRow> AggregateLines(List<PosSaleLineRow> lines)
    {
        var result = new List<PosSaleLineRow>();
        foreach (var g in lines.GroupBy(x => new
                 {
                     Code = Norm(x.ProductCode),
                     Gest = Norm(x.CodGestiune),
                     Tva = Math.Round(x.TvaPct, 2),
                     Price = Math.Round(x.UnitPrice, 4),
                     Um = Norm(x.Um)
                 }))
        {
            var first = g.First();
            result.Add(new PosSaleLineRow
            {
                ProductCode = first.ProductCode,
                ProductName = first.ProductName,
                CodGestiune = first.CodGestiune,
                DenGest = first.DenGest,
                Um = first.Um,
                TvaPct = first.TvaPct,
                UnitPrice = first.UnitPrice,
                Qty = g.Sum(x => x.Qty),
                Valoare = Math.Round(g.Sum(x => x.Valoare), 2, MidpointRounding.AwayFromZero),
                ValoareTva = Math.Round(g.Sum(x => x.ValoareTva), 2, MidpointRounding.AwayFromZero),
                Total = Math.Round(g.Sum(x => x.Total), 2, MidpointRounding.AwayFromZero)
            });
        }

        return result
            .OrderBy(x => x.CodGestiune)
            .ThenBy(x => x.ProductName)
            .ToList();
    }

    private static string Norm(string? value) => (value ?? "").Trim().ToUpperInvariant();

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    public static string ExplainAutoTransferPolicy()
    {
        return ShouldAutoTransferAfterPayment()
            ? "Transferul automat imediat după plată este oprit pentru modul PubLine-like: bonurile rămân pregătite și se transferă grupat pe zi din Administrare → POS Restaurant → Vânzări."
            : "";
    }

    private static void UpdateFailure(FbConnection conn, IEnumerable<string> saleIds, string message, bool keepReadyOnFailure)
    {
        foreach (var saleId in saleIds.Where(x => !string.IsNullOrWhiteSpace(x)))
            UpdateFailure(conn, saleId, message, keepReadyOnFailure);
    }

    public static bool ShouldAutoTransferAfterPayment()
    {
        using var smart = SmartPubDb.OpenEmbedded();
        SmartPubBootstrap.ApplySchema(smart);
        return new ProgramExtendedConfigRepository().LoadTransfer(smart).AutoTransferAfterPayment;
    }

    private static void UpdateFailure(FbConnection conn, string saleId, string message, bool keepReadyOnFailure)
    {
        PosSaleRepository.UpdateSagaTransferResult(
            conn,
            saleId,
            keepReadyOnFailure ? PosSaleRepository.SagaReady : PosSaleRepository.SagaError,
            null,
            null,
            message);
    }

    private static TransferOptions ResolveTransferOptions(
        string saleMethod,
        ProgramTransferDocConfig cfg,
        IReadOnlyList<PosSalePaymentRow> payments)
    {
        var active = payments
            .Where(p => p.Amount > 0)
            .Select(p => new PosSalePaymentRow
            {
                MethodKey = PosSaleRepository.NormalizeMethodKey(p.MethodKey),
                Amount = Math.Round(p.Amount, 2, MidpointRounding.AwayFromZero)
            })
            .ToList();

        var grouped = active
            .GroupBy(p => p.MethodKey, StringComparer.OrdinalIgnoreCase)
            .Select(g => new { Key = g.Key, Sum = g.Sum(x => x.Amount) })
            .OrderByDescending(x => x.Sum)
            .ToList();

        var methodKey = grouped.Count > 0
            ? grouped[0].Key
            : PosSaleRepository.NormalizeMethodKey(saleMethod);
        if (string.IsNullOrWhiteSpace(methodKey) || string.Equals(methodKey, "METODE_MODERNE", StringComparison.OrdinalIgnoreCase))
            methodKey = grouped.Count > 0 ? grouped[0].Key : "NUMERAR";

        // PubLine-like: toate vânzările merg pe clientul unic ales la Transfer date.
        var client = !string.IsNullOrWhiteSpace(cfg.ImplicitClient)
            ? cfg.ImplicitClient.Trim()
            : DefaultClientCode;

        var summary = active.Count == 0
            ? methodKey
            : string.Join("; ", active.Select(p => $"{p.MethodKey} {p.Amount:N2}"));

        var account = ResolveTransferAccount(cfg, methodKey, active);

        return new TransferOptions(methodKey, client, account, summary);
    }

    private static string ResolveTransferAccount(
        ProgramTransferDocConfig cfg,
        string methodKey,
        IReadOnlyList<PosSalePaymentRow> activePayments)
    {
        foreach (var key in EnumerateMethodKeysForAccount(methodKey, activePayments))
        {
            var mapped = LookupMappedTransferAccount(cfg, key);
            if (!string.IsNullOrWhiteSpace(mapped))
                return mapped;

            var fallback = DefaultTransferAccountForMethod(key);
            if (!string.IsNullOrWhiteSpace(fallback))
                return fallback;
        }

        return cfg.ModMap
            .Select(x => (x.ContTransfer ?? "").Trim())
            .FirstOrDefault(x => x.Length > 0) ?? "";
    }

    private static IEnumerable<string> EnumerateMethodKeysForAccount(
        string methodKey,
        IReadOnlyList<PosSalePaymentRow> activePayments)
    {
        yield return methodKey;
        foreach (var p in activePayments
                     .GroupBy(x => x.MethodKey, StringComparer.OrdinalIgnoreCase)
                     .OrderByDescending(g => g.Sum(x => x.Amount))
                     .Select(g => g.Key))
        {
            if (!string.Equals(p, methodKey, StringComparison.OrdinalIgnoreCase))
                yield return p;
        }

        yield return "NUMERAR";
        yield return "CARD";
    }

    private static string? LookupMappedTransferAccount(ProgramTransferDocConfig cfg, string methodKey)
    {
        var key = PosSaleRepository.NormalizeMethodKey(methodKey);
        return cfg.ModMap
            .FirstOrDefault(x => string.Equals(x.MethodKey, key, StringComparison.OrdinalIgnoreCase))
            ?.ContTransfer?
            .Trim();
    }

    private static string? DefaultTransferAccountForMethod(string methodKey) =>
        PosSaleRepository.NormalizeMethodKey(methodKey) switch
        {
            "NUMERAR" => "5311",
            "CARD" => "5121.1",
            _ => null
        };

    private static string BuildExtraInfo(ProgramTransferDocConfig cfg, TransferOptions options)
    {
        var parts = new List<string>();
        if (cfg.IncludeModIncasarePeFactura)
            parts.Add("Incasare: " + options.PaymentSummary);
        if (!string.IsNullOrWhiteSpace(cfg.TextSuplimentarFactura))
            parts.Add(cfg.TextSuplimentarFactura.Trim());
        return string.Join(" | ", parts);
    }

    /// <summary>Observații bon fiscal (tip B) — PubLine lasă de regulă câmpul gol; opțional text suplimentar / mod încasare.</summary>
    private static string BuildBonFiscalExtraInfo(ProgramTransferDocConfig cfg, TransferOptions options)
    {
        var parts = new List<string>();
        if (!string.IsNullOrWhiteSpace(cfg.TextSuplimentarFactura))
            parts.Add(cfg.TextSuplimentarFactura.Trim());
        if (cfg.IncludeModIncasarePeFactura && !string.IsNullOrWhiteSpace(options.PaymentSummary))
            parts.Add("Incasare: " + options.PaymentSummary.Trim());
        var text = string.Join(" | ", parts);
        return text.Length <= 120 ? text : text[..120];
    }

    private static bool IsLocalHost(string? host)
    {
        if (string.IsNullOrWhiteSpace(host))
            return false;

        var h = host.Trim();
        if (h.Equals("localhost", StringComparison.OrdinalIgnoreCase)
            || h.Equals("127.0.0.1", StringComparison.OrdinalIgnoreCase)
            || h.Equals("::1", StringComparison.OrdinalIgnoreCase))
            return true;

        try
        {
            if (h.Equals(Dns.GetHostName(), StringComparison.OrdinalIgnoreCase))
                return true;

            if (!IPAddress.TryParse(h, out var target))
                return false;

            return Dns.GetHostAddresses(Dns.GetHostName())
                .Where(x => x.AddressFamily is AddressFamily.InterNetwork or AddressFamily.InterNetworkV6)
                .Any(x => x.Equals(target));
        }
        catch
        {
            return false;
        }
    }

    private sealed record TransferOptions(string MethodKey, string ClientCode, string TransferAccount, string PaymentSummary);

    private sealed record TransferGroup(
        DateTime DocumentDate,
        int DocumentNo,
        List<PosSaleHeaderRow> Headers,
        List<PosSaleLineRow> Lines,
        TransferOptions TransferOptions);

    private sealed record ArticleTransferMeta(string GestiuneCode, string GestiuneName, string Um);

    private sealed class IesiriWorkerJsonDto
    {
        public string? SagaDbPath { get; set; }
        public string? SagaRootPath { get; set; }
        public string? FbClientPath { get; set; }
        public string? ConnectionMode { get; set; }
        public string? ServerHost { get; set; }
        public int? ServerPort { get; set; }
        public string? DefaultClientCode { get; set; }
        public IesiriWorkerHeaderJsonDto? Header { get; set; }
        public List<IesiriWorkerLineJsonDto>? Lines { get; set; }
    }

    private sealed class IesiriWorkerHeaderJsonDto
    {
        public int OrderNo { get; set; }
        public DateTime PaidAt { get; set; }
        public decimal Valoare { get; set; }
        public decimal ValoareTva { get; set; }
        public decimal Total { get; set; }
        public string? DocumentTip { get; set; }
        public string? SerieBonuri { get; set; }
        public int BonCount { get; set; }
        public string? PaymentMethod { get; set; }
        public string? PaymentSummary { get; set; }
        public string? TransferAccount { get; set; }
        public string? ExtraInfo { get; set; }
    }

    private sealed class IesiriWorkerLineJsonDto
    {
        public string? ProductCode { get; set; }
        public string? ProductName { get; set; }
        public string? CodGestiune { get; set; }
        public string? DenGest { get; set; }
        public string? Um { get; set; }
        public decimal TvaPct { get; set; }
        public decimal Qty { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Valoare { get; set; }
        public decimal ValoareTva { get; set; }
        public decimal Total { get; set; }
    }

}

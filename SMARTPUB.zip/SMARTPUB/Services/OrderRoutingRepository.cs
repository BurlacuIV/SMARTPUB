using System.Collections.Generic;
using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

/// <summary>Destinații interne de rutare a comenzii.</summary>
public static class OrderDestination
{
    public const string Bar = "BAR";
    public const string Kitchen = "BUCATARIE";

    /// <summary>Implicit pentru produsele neclasificate: bucătărie (apar pe KDS).</summary>
    public const string Default = Kitchen;

    public static string Normalize(string? value)
    {
        var t = (value ?? "").Trim().ToUpperInvariant();
        return t == Bar ? Bar : t == Kitchen ? Kitchen : "";
    }

    public static string DisplayName(string? value) =>
        Normalize(value) == Bar ? "Bar" : "Bucătărie";
}

/// <summary>
/// Maparea grupă → destinație (bar/bucătărie) + rezolvarea destinației unui produs
/// (override per articol &gt; mapare grupă &gt; implicit bucătărie).
/// </summary>
public sealed class OrderRoutingRepository
{
    public void EnsureSchema(FbConnection conn)
    {
        if (TableExists(conn, "SP_POS_GROUP_DEST"))
            return;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
CREATE TABLE SP_POS_GROUP_DEST (
    GRUPA_CODE VARCHAR(24) NOT NULL,
    DESTINATIE VARCHAR(16),
    UPDATED_AT TIMESTAMP,
    PRIMARY KEY (GRUPA_CODE)
)";
        cmd.ExecuteNonQuery();
    }

    /// <summary>Cod grupă (UPPER) → destinație (BAR / BUCATARIE).</summary>
    public Dictionary<string, string> LoadGroupMap(FbConnection conn)
    {
        EnsureSchema(conn);
        var map = new Dictionary<string, string>(System.StringComparer.OrdinalIgnoreCase);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT TRIM(GRUPA_CODE), TRIM(COALESCE(DESTINATIE,'')) FROM SP_POS_GROUP_DEST";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var code = (rd[0]?.ToString() ?? "").Trim();
            var dest = OrderDestination.Normalize(rd[1]?.ToString());
            if (code.Length > 0 && dest.Length > 0)
                map[code] = dest;
        }

        return map;
    }

    public void SaveGroupDestination(FbConnection conn, string groupCode, string? destination)
    {
        EnsureSchema(conn);
        var code = (groupCode ?? "").Trim();
        if (code.Length == 0)
            return;

        var dest = OrderDestination.Normalize(destination);
        using var cmd = conn.CreateCommand();
        if (dest.Length == 0)
        {
            // „Auto” → ștergem maparea (rămâne implicit).
            cmd.CommandText = "DELETE FROM SP_POS_GROUP_DEST WHERE TRIM(GRUPA_CODE) = @C";
            cmd.Parameters.AddWithValue("@C", code);
            cmd.ExecuteNonQuery();
            return;
        }

        cmd.CommandText = @"
UPDATE OR INSERT INTO SP_POS_GROUP_DEST (GRUPA_CODE, DESTINATIE, UPDATED_AT)
VALUES (@C, @D, CURRENT_TIMESTAMP)
MATCHING (GRUPA_CODE)";
        cmd.Parameters.AddWithValue("@C", code);
        cmd.Parameters.AddWithValue("@D", dest);
        cmd.ExecuteNonQuery();
    }

    /// <summary>Rezolvă destinația unui articol din DB (override articol + grupa lui), cu maparea dată.</summary>
    public string ResolveForArticle(FbConnection conn, IReadOnlyDictionary<string, string> groupMap, string code)
    {
        if (string.IsNullOrWhiteSpace(code))
            return OrderDestination.Default;

        var ovr = "";
        var grupa = "";
        try
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText =
                "SELECT TRIM(COALESCE(DESTINATIE,'')), TRIM(COALESCE(GRUPA,'')) " +
                "FROM SP_SAGA_ARTICOLE WHERE TRIM(CODE) = TRIM(@C) ROWS 1";
            cmd.Parameters.AddWithValue("@C", code.Trim());
            using var rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                ovr = rd[0]?.ToString() ?? "";
                grupa = rd[1]?.ToString() ?? "";
            }
        }
        catch
        {
            /* fallback implicit */
        }

        return Resolve(groupMap, ovr, grupa);
    }

    /// <summary>Override per articol &gt; mapare grupă &gt; implicit (bucătărie).</summary>
    public static string Resolve(IReadOnlyDictionary<string, string> groupMap, string? articleOverride, string? groupCode)
    {
        var ovr = OrderDestination.Normalize(articleOverride);
        if (ovr.Length > 0)
            return ovr;

        var g = (groupCode ?? "").Trim();
        if (g.Length > 0 && groupMap.TryGetValue(g, out var d) && d.Length > 0)
            return d;

        return OrderDestination.Default;
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

using FirebirdSql.Data.FirebirdClient;



namespace SMARTPUB.Services;



public static class FloorPlanSchema

{

    public static void EnsureSchema(FbConnection conn)

    {

        EnsureTable(conn, "SP_FLOOR_LEVEL", @"

CREATE TABLE SP_FLOOR_LEVEL (

  ID VARCHAR(36) NOT NULL,

  NAME VARCHAR(80),

  SORT_ORDER INTEGER,

  UPDATED_AT TIMESTAMP,

  PRIMARY KEY (ID)

)");



        EnsureTable(conn, "SP_FLOOR_SPACE", @"

CREATE TABLE SP_FLOOR_SPACE (

  ID VARCHAR(36) NOT NULL,

  LEVEL_ID VARCHAR(36),

  NAME VARCHAR(80),

  POS_X DOUBLE PRECISION,

  POS_Y DOUBLE PRECISION,

  WIDTH DOUBLE PRECISION,

  HEIGHT DOUBLE PRECISION,

  ZORDER INTEGER,

  TINT_ARGB INTEGER,

  UPDATED_AT TIMESTAMP,

  PRIMARY KEY (ID)

)");



        EnsureTable(conn, "SP_FLOOR_TABLE", @"

CREATE TABLE SP_FLOOR_TABLE (

  ID VARCHAR(36) NOT NULL,

  LEVEL_ID VARCHAR(36),

  NAME VARCHAR(40),

  POS_X DOUBLE PRECISION,

  POS_Y DOUBLE PRECISION,

  WIDTH DOUBLE PRECISION,

  HEIGHT DOUBLE PRECISION,

  IS_ROUND SMALLINT,

  SEATS INTEGER,

  SPACE_ID VARCHAR(36),

  UPDATED_AT TIMESTAMP,

  PRIMARY KEY (ID)

)");



        MigrateLegacyLevelColumns(conn);

    }



    private static void MigrateLegacyLevelColumns(FbConnection conn)

    {

        if (!ColumnExists(conn, "SP_FLOOR_SPACE", "LEVEL_ID"))

        {

            using var cmd = conn.CreateCommand();

            cmd.CommandText = "ALTER TABLE SP_FLOOR_SPACE ADD LEVEL_ID VARCHAR(36)";

            cmd.ExecuteNonQuery();

        }



        if (!ColumnExists(conn, "SP_FLOOR_TABLE", "LEVEL_ID"))

        {

            using var cmd = conn.CreateCommand();

            cmd.CommandText = "ALTER TABLE SP_FLOOR_TABLE ADD LEVEL_ID VARCHAR(36)";

            cmd.ExecuteNonQuery();

        }



        string? defaultLevelId = null;

        using (var cmd = conn.CreateCommand())

        {

            cmd.CommandText = "SELECT COUNT(*) FROM SP_FLOOR_LEVEL";

            var n = Convert.ToInt32(cmd.ExecuteScalar() ?? 0);

            if (n == 0)

            {

                defaultLevelId = Guid.NewGuid().ToString("N");

                using var ins = conn.CreateCommand();

                ins.CommandText = @"

INSERT INTO SP_FLOOR_LEVEL (ID, NAME, SORT_ORDER, UPDATED_AT)

VALUES (@ID, @N, 0, CURRENT_TIMESTAMP)";

                ins.Parameters.AddWithValue("@ID", defaultLevelId);

                ins.Parameters.AddWithValue("@N", "Sală");

                ins.ExecuteNonQuery();

            }

        }



        if (defaultLevelId == null)

        {

            using var cmd = conn.CreateCommand();

            cmd.CommandText = "SELECT FIRST 1 ID FROM SP_FLOOR_LEVEL ORDER BY SORT_ORDER, NAME";

            defaultLevelId = cmd.ExecuteScalar()?.ToString()?.Trim();

        }



        if (string.IsNullOrEmpty(defaultLevelId))

            return;



        using (var cmd = conn.CreateCommand())

        {

            cmd.CommandText = @"

UPDATE SP_FLOOR_SPACE SET LEVEL_ID = @L

WHERE LEVEL_ID IS NULL OR TRIM(LEVEL_ID) = ''";

            cmd.Parameters.AddWithValue("@L", defaultLevelId);

            cmd.ExecuteNonQuery();

        }



        using (var cmd = conn.CreateCommand())

        {

            cmd.CommandText = @"

UPDATE SP_FLOOR_TABLE SET LEVEL_ID = @L

WHERE LEVEL_ID IS NULL OR TRIM(LEVEL_ID) = ''";

            cmd.Parameters.AddWithValue("@L", defaultLevelId);

            cmd.ExecuteNonQuery();

        }

    }



    private static void EnsureTable(FbConnection conn, string tableName, string ddl)

    {

        if (TableExists(conn, tableName))

            return;

        using var cmd = conn.CreateCommand();

        cmd.CommandText = ddl;

        cmd.ExecuteNonQuery();

    }



    private static bool TableExists(FbConnection conn, string tableName)

    {

        using var cmd = conn.CreateCommand();

        cmd.CommandText = @"

SELECT 1 FROM RDB$RELATIONS

WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";

        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());

        var x = cmd.ExecuteScalar();

        return x != null && x != DBNull.Value;

    }



    private static bool ColumnExists(FbConnection conn, string tableName, string columnName)

    {

        using var cmd = conn.CreateCommand();

        cmd.CommandText = @"

SELECT 1 FROM RDB$RELATION_FIELDS RF

JOIN RDB$RELATIONS R ON R.RDB$RELATION_NAME = RF.RDB$RELATION_NAME

WHERE R.RDB$SYSTEM_FLAG = 0

  AND TRIM(R.RDB$RELATION_NAME) = @T

  AND TRIM(RF.RDB$FIELD_NAME) = @C

ROWS 1";

        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());

        cmd.Parameters.AddWithValue("@C", columnName.Trim().ToUpperInvariant());

        var x = cmd.ExecuteScalar();

        return x != null && x != DBNull.Value;

    }

}



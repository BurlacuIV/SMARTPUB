using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public sealed class SyncedProductsRepository
{
    /// <summary>Catalog complet pentru admin/nomenclator (include număr rețete).</summary>
    public List<SyncedProductRow> GetAll(FbConnection conn) =>
        LoadCatalog(conn, includeRecipeCounts: true);

    /// <summary>Catalog rapid pentru POS ospătar (fără N+1 pe rețete).</summary>
    public List<SyncedProductRow> GetAllForWaiter(FbConnection conn) =>
        LoadCatalog(conn, includeRecipeCounts: false);

    /// <summary>Grupe distincte pentru rutare în configurare (fără încărcare articole).</summary>
    public List<(string Code, string Display)> ListDistinctGroupsForRouting(FbConnection conn)
    {
        new SagaSyncImportService().EnsureGrupariCategoriiTables(conn);
        if (!TableExists(conn, "SP_SAGA_ARTICOLE"))
            return [];

        var list = new List<(string Code, string Display)>();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT DISTINCT
  TRIM(A.GRUPA) AS GCODE,
  CASE
    WHEN TRIM(COALESCE(A.GRUPA, '')) <> '' AND NULLIF(TRIM(GR_G.NAME), '') IS NOT NULL THEN TRIM(GR_G.NAME)
    WHEN TRIM(COALESCE(A.GRUPA, '')) <> '' THEN TRIM(A.GRUPA)
    ELSE ''
  END AS GDISPLAY
FROM SP_SAGA_ARTICOLE A
LEFT JOIN SP_SAGA_GRUPARI GR_G ON TRIM(COALESCE(A.GRUPA, '')) = TRIM(GR_G.CODE)
WHERE TRIM(COALESCE(A.GRUPA, '')) <> ''
ORDER BY 2";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var code = (rd["GCODE"]?.ToString() ?? "").Trim();
            if (code.Length == 0)
                continue;
            var display = (rd["GDISPLAY"]?.ToString() ?? "").Trim();
            if (display.Length == 0)
                display = code;
            list.Add((code, display));
        }

        return list;
    }

    private List<SyncedProductRow> LoadCatalog(FbConnection conn, bool includeRecipeCounts)
    {
        SagaArticoleSchemaExtensions.EnsureExtendedColumns(conn);
        new SagaSyncImportService().EnsureGrupariCategoriiTables(conn);
        var extended = SagaArticoleSchemaExtensions.HasExtendedArticoleColumns(conn);

        var list = new List<SyncedProductRow>();

        using var cmd = conn.CreateCommand();
        var hasDenTip = ColumnExists(conn, "SP_SAGA_ARTICOLE", "DEN_TIP");
        var denTipExpr = hasDenTip
            ? "TRIM(COALESCE(A.DEN_TIP, '')) AS DEN_TIP"
            : "CAST('' AS VARCHAR(48)) AS DEN_TIP";
        var tipSagaExpr = ColumnExists(conn, "SP_SAGA_ARTICOLE", "TIP_SAGA")
            ? "TRIM(COALESCE(A.TIP_SAGA, '')) AS TIP_SAGA"
            : "CAST('' AS VARCHAR(4)) AS TIP_SAGA";
        var destExpr = ColumnExists(conn, "SP_SAGA_ARTICOLE", "DESTINATIE")
            ? "TRIM(COALESCE(A.DESTINATIE, '')) AS DESTINATIE"
            : "CAST('' AS VARCHAR(16)) AS DESTINATIE";

        cmd.CommandText = extended
            ? $@"
SELECT
  TRIM(A.CODE) AS CODE,
  TRIM(A.NAME) AS NAME,
  TRIM(A.UM) AS UM,
  COALESCE(A.TVA, 0) AS TVA,
  TRIM(A.CATEGORIE) AS CATEGORIE,
  COALESCE(A.PRET_VANZ, 0) AS PRET_VANZ,
  COALESCE(A.IS_BLOCKED, 0) AS IS_BLOCKED,
  A.UPDATED_AT,
  COALESCE(A.STOC, 0) AS STOC,
  {destExpr},
  TRIM(COALESCE(A.COD_BARE, '')) AS COD_BARE,
  COALESCE(A.PLU, 0) AS PLU,
  TRIM(COALESCE(A.GESTIUNE, '')) AS GESTIUNE,
  TRIM(COALESCE(A.GRUPA, '')) AS GRUPA,
  TRIM(COALESCE(A.IMAGE_PATH, '')) AS IMAGE_PATH,
  {denTipExpr},
  {tipSagaExpr},
  COALESCE(NULLIF(TRIM(GG.NAME), ''), TRIM(COALESCE(A.GESTIUNE, ''))) AS GESTIUNE_AFIS,
  CASE
    WHEN TRIM(COALESCE(A.GRUPA, '')) <> '' AND NULLIF(TRIM(GR_G.NAME), '') IS NOT NULL THEN
      TRIM(GR_G.NAME)
    WHEN TRIM(COALESCE(A.GRUPA, '')) <> '' THEN
      TRIM(A.GRUPA)
    WHEN TRIM(COALESCE(A.CATEGORIE, '')) <> '' AND NULLIF(TRIM(GR_C.NAME), '') IS NOT NULL THEN
      TRIM(GR_C.NAME)
    WHEN TRIM(COALESCE(A.CATEGORIE, '')) <> '' THEN
      TRIM(A.CATEGORIE)
    ELSE ''
  END AS GRUPA_AFIS
FROM SP_SAGA_ARTICOLE A
LEFT JOIN SP_SAGA_GESTIUNI GG ON TRIM(A.GESTIUNE) = TRIM(GG.CODE)
LEFT JOIN SP_SAGA_GRUPARI GR_G ON TRIM(COALESCE(A.GRUPA, '')) = TRIM(GR_G.CODE)
LEFT JOIN SP_SAGA_GRUPARI GR_C ON TRIM(COALESCE(A.CATEGORIE, '')) = TRIM(GR_C.CODE)
ORDER BY A.NAME"
            : @"
SELECT
  TRIM(CODE) AS CODE,
  TRIM(NAME) AS NAME,
  TRIM(UM) AS UM,
  COALESCE(TVA, 0) AS TVA,
  TRIM(CATEGORIE) AS CATEGORIE,
  COALESCE(PRET_VANZ, 0) AS PRET_VANZ,
  COALESCE(IS_BLOCKED, 0) AS IS_BLOCKED,
  UPDATED_AT,
  TRIM(COALESCE(CATEGORIE, '')) AS GRUPA_AFIS,
  CAST('' AS VARCHAR(120)) AS GESTIUNE_AFIS
FROM SP_SAGA_ARTICOLE A
ORDER BY NAME";

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new SyncedProductRow
            {
                Code = (rd["CODE"]?.ToString() ?? "").Trim(),
                Name = (rd["NAME"]?.ToString() ?? "").Trim(),
                Um = (rd["UM"]?.ToString() ?? "").Trim(),
                Tva = ToDecimal(rd["TVA"]),
                Categorie = (rd["CATEGORIE"]?.ToString() ?? "").Trim(),
                PretVanz = ToDecimal(rd["PRET_VANZ"]),
                IsBlocked = ToInt(rd["IS_BLOCKED"]) != 0,
                UpdatedAt = rd["UPDATED_AT"] == DBNull.Value ? null : Convert.ToDateTime(rd["UPDATED_AT"]),
                Stoc = extended ? ToDecimal(rd["STOC"]) : 0,
                CodBare = extended ? (rd["COD_BARE"]?.ToString() ?? "").Trim() : "",
                Plu = extended ? ToInt(rd["PLU"]) : 0,
                Gestiune = extended ? (rd["GESTIUNE"]?.ToString() ?? "").Trim() : "",
                Grupa = extended ? (rd["GRUPA"]?.ToString() ?? "").Trim() : "",
                ImagePath = extended ? (rd["IMAGE_PATH"]?.ToString() ?? "").Trim() : "",
                DenTip = extended ? (rd["DEN_TIP"]?.ToString() ?? "").Trim() : "",
                TipSaga = extended ? (rd["TIP_SAGA"]?.ToString() ?? "").Trim() : "",
                Destinatie = extended ? OrderDestination.Normalize(rd["DESTINATIE"]?.ToString()) : "",
                GestiuneAfisat = (rd["GESTIUNE_AFIS"]?.ToString() ?? "").Trim(),
                GrupaAfisat = (rd["GRUPA_AFIS"]?.ToString() ?? "").Trim()
            });
        }

        var groupMap = new OrderRoutingRepository().LoadGroupMap(conn);
        foreach (var r in list)
            r.DestinatieEfectiva = OrderRoutingRepository.Resolve(groupMap, r.Destinatie, r.Grupa);

        if (includeRecipeCounts)
            ApplyRecipeLineCounts(conn, list);

        return list;
    }

    private static void ApplyRecipeLineCounts(FbConnection conn, List<SyncedProductRow> list)
    {
        if (list.Count == 0 || !TableExists(conn, "SP_SAGA_RECIPE_LINES"))
            return;

        var counts = LoadRecipeLineCountsBatch(conn);
        foreach (var r in list)
        {
            if (counts.TryGetValue(r.Code, out var n))
                r.RecipeLinesCount = n;
        }
    }

    /// <summary>Un singur query pentru toate numărările de linii rețetă (în loc de N COUNT-uri).</summary>
    private static Dictionary<string, int> LoadRecipeLineCountsBatch(FbConnection conn)
    {
        var map = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT UPPER(TRIM(ARTICOL_CODE)) AS AC, COUNT(*) AS CNT
FROM SP_SAGA_RECIPE_LINES R
WHERE (
  UPPER(TRIM(COALESCE(R.SOURCE_TABLE, ''))) <> 'ART_ANTE'
  OR NOT EXISTS (
    SELECT 1 FROM SP_SAGA_RECIPE_LINES R2
    WHERE UPPER(TRIM(R2.ARTICOL_CODE)) = UPPER(TRIM(R.ARTICOL_CODE))
      AND UPPER(TRIM(COALESCE(R2.SOURCE_TABLE, ''))) = 'ART_A_DET'
  )
)
GROUP BY UPPER(TRIM(ARTICOL_CODE))";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var code = (rd["AC"]?.ToString() ?? "").Trim();
            if (code.Length == 0)
                continue;
            map[code] = Convert.ToInt32(rd["CNT"] ?? 0);
        }

        return map;
    }

    /// <summary>
    /// Linii de consum: ART_A_DET, MANUAL, etc.; ART_ANTE doar dacă articolul nu are linii ART_A_DET
    /// (în SAGA C.3 rețeta poate fi numai în ART_ANTE).
    /// </summary>
    public static int CountSagaRecipeIngredientLines(FbConnection conn, string articleCode)
    {
        if (string.IsNullOrWhiteSpace(articleCode) || !TableExists(conn, "SP_SAGA_RECIPE_LINES"))
            return 0;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT COUNT(*)
FROM SP_SAGA_RECIPE_LINES
WHERE UPPER(TRIM(ARTICOL_CODE)) = UPPER(TRIM(@C))
  AND (
    UPPER(TRIM(COALESCE(SOURCE_TABLE, ''))) <> 'ART_ANTE'
    OR NOT EXISTS (
      SELECT 1 FROM SP_SAGA_RECIPE_LINES R2
      WHERE UPPER(TRIM(R2.ARTICOL_CODE)) = UPPER(TRIM(@C))
        AND UPPER(TRIM(COALESCE(R2.SOURCE_TABLE, ''))) = 'ART_A_DET'
    )
  )";
        cmd.Parameters.AddWithValue("@C", articleCode.Trim());
        var o = cmd.ExecuteScalar();
        return o == null || o == DBNull.Value ? 0 : Convert.ToInt32(o);
    }

    public decimal GetRecipeCantRaportare(FbConnection conn, string articleCode)
    {
        EnsureRecipeMetaTable(conn);
        if (string.IsNullOrWhiteSpace(articleCode))
            return 1m;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT COALESCE(CANT_RAPORTARE, 1) FROM SP_SAGA_RECIPE_META
WHERE UPPER(TRIM(ARTICOL_CODE)) = UPPER(TRIM(@C)) ROWS 1";
        cmd.Parameters.AddWithValue("@C", articleCode.Trim());
        var o = cmd.ExecuteScalar();
        if (o == null || o == DBNull.Value)
            return 1m;
        var v = Convert.ToDecimal(o);
        return v <= 0 ? 1m : v;
    }

    public void SaveRecipeCantRaportare(FbConnection conn, string articleCode, decimal cantRaportare)
    {
        EnsureRecipeMetaTable(conn);
        if (string.IsNullOrWhiteSpace(articleCode))
            return;
        var v = cantRaportare <= 0 ? 1m : cantRaportare;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
UPDATE OR INSERT INTO SP_SAGA_RECIPE_META (ARTICOL_CODE, CANT_RAPORTARE, UPDATED_AT)
VALUES (@C, @Q, CURRENT_TIMESTAMP)
MATCHING (ARTICOL_CODE)";
        cmd.Parameters.AddWithValue("@C", articleCode.Trim());
        cmd.Parameters.AddWithValue("@Q", v);
        cmd.ExecuteNonQuery();
    }

    private static void EnsureRecipeMetaTable(FbConnection conn)
    {
        if (TableExists(conn, "SP_SAGA_RECIPE_META"))
            return;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
CREATE TABLE SP_SAGA_RECIPE_META (
  ARTICOL_CODE VARCHAR(24) NOT NULL,
  CANT_RAPORTARE NUMERIC(18,6) DEFAULT 1,
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (ARTICOL_CODE)
)";
        try
        {
            cmd.ExecuteNonQuery();
        }
        catch
        {
            /* există deja sau versiune Firebird */
        }
    }

    /// <summary>Salvare articol în catalogul local (SP_SAGA_ARTICOLE); nu scrie în SAGA.</summary>
    public void UpsertArticole(FbConnection conn, SagaSyncArticol row)
    {
        if (string.IsNullOrWhiteSpace(row.Code))
            throw new ArgumentException("Codul articolului este obligatoriu.", nameof(row));

        SagaArticoleSchemaExtensions.EnsureExtendedColumns(conn);

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
UPDATE OR INSERT INTO SP_SAGA_ARTICOLE
(CODE, NAME, UM, TVA, CATEGORIE, GRUPA, PRET_VANZ, IS_BLOCKED, GESTIUNE, DEN_TIP, TIP_SAGA, UPDATED_AT)
VALUES
(@CODE, @NAME, @UM, @TVA, @CATEGORIE, @GRUPA, @PRET_VANZ, @IS_BLOCKED, @GESTIUNE, @DEN_TIP, @TIP_SAGA, CURRENT_TIMESTAMP)
MATCHING (CODE)";
        cmd.Parameters.AddWithValue("@CODE", row.Code.Trim());
        cmd.Parameters.AddWithValue("@NAME", DbOrTrim(row.Name));
        cmd.Parameters.AddWithValue("@UM", DbOrTrim(row.Um));
        cmd.Parameters.AddWithValue("@TVA", row.Tva);
        cmd.Parameters.AddWithValue("@CATEGORIE", DbOrTrim(row.Categorie));
        cmd.Parameters.AddWithValue("@GRUPA", DbOrTrim(row.Grupa));
        cmd.Parameters.AddWithValue("@PRET_VANZ", row.PretVanz);
        cmd.Parameters.AddWithValue("@IS_BLOCKED", row.IsBlocked ? 1 : 0);
        cmd.Parameters.AddWithValue("@GESTIUNE", DbOrTrim(row.Gestiune));
        cmd.Parameters.AddWithValue("@DEN_TIP", DbOrTrim(row.DenTip));
        cmd.Parameters.AddWithValue("@TIP_SAGA", DbOrTrim(NormalizeTipSagaLocal(row.TipSaga)));
        cmd.ExecuteNonQuery();
    }

    /// <summary>Setează override-ul de destinație (BAR / BUCATARIE / gol = auto) pentru un articol.</summary>
    public void SetDestinationOverride(FbConnection conn, string code, string? destination)
    {
        if (string.IsNullOrWhiteSpace(code))
            return;
        SagaArticoleSchemaExtensions.EnsureExtendedColumns(conn);

        using var cmd = conn.CreateCommand();
        cmd.CommandText = "UPDATE SP_SAGA_ARTICOLE SET DESTINATIE = @D WHERE TRIM(CODE) = TRIM(@C)";
        var dest = OrderDestination.Normalize(destination);
        cmd.Parameters.AddWithValue("@D", dest.Length == 0 ? DBNull.Value : dest);
        cmd.Parameters.AddWithValue("@C", code.Trim());
        cmd.ExecuteNonQuery();
    }

    public bool ArticolCodeExists(FbConnection conn, string code)
    {
        if (string.IsNullOrWhiteSpace(code))
            return false;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM SP_SAGA_ARTICOLE WHERE TRIM(CODE) = TRIM(@C) ROWS 1";
        cmd.Parameters.AddWithValue("@C", code.Trim());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    public List<SyncedRecipeLineRow> GetRecipeLines(FbConnection conn, string articleCode)
    {
        var list = new List<SyncedRecipeLineRow>();
        if (string.IsNullOrWhiteSpace(articleCode))
            return list;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT
  TRIM(COALESCE(LINE_KEY, '')) AS LINE_KEY,
  TRIM(COALESCE(SOURCE_TABLE, '')) AS SOURCE_TABLE,
  TRIM(COALESCE(TIP, '')) AS TIP,
  TRIM(COALESCE(GESTIUNE, '')) AS GESTIUNE,
  TRIM(COALESCE(OPERATIE, '')) AS OPERATIE,
  TRIM(COALESCE(COMPONENT_CODE, '')) AS COMPONENT_CODE,
  TRIM(COALESCE(COMPONENT_NAME, '')) AS COMPONENT_NAME,
  TRIM(COALESCE(UM, '')) AS UM,
  COALESCE(QTY, 0) AS QTY
FROM SP_SAGA_RECIPE_LINES
WHERE UPPER(TRIM(ARTICOL_CODE)) = UPPER(TRIM(@ARTICOL_CODE))
ORDER BY
  CASE UPPER(TRIM(COALESCE(SOURCE_TABLE, '')))
    WHEN 'ART_A_DET' THEN 1
    WHEN 'RETETE_DET' THEN 2
    WHEN 'MANUAL' THEN 3
    WHEN 'IMPORT' THEN 4
    WHEN 'ART_ANTE' THEN 0
    ELSE 5
  END,
  LINE_KEY";
        cmd.Parameters.AddWithValue("@ARTICOL_CODE", articleCode);

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new SyncedRecipeLineRow
            {
                LineKey = (rd["LINE_KEY"]?.ToString() ?? "").Trim(),
                SourceTable = (rd["SOURCE_TABLE"]?.ToString() ?? "").Trim(),
                Tip = (rd["TIP"]?.ToString() ?? "").Trim(),
                Gestiune = (rd["GESTIUNE"]?.ToString() ?? "").Trim(),
                Operatie = (rd["OPERATIE"]?.ToString() ?? "").Trim(),
                ComponentCode = (rd["COMPONENT_CODE"]?.ToString() ?? "").Trim(),
                ComponentName = (rd["COMPONENT_NAME"]?.ToString() ?? "").Trim(),
                Um = (rd["UM"]?.ToString() ?? "").Trim(),
                Quantity = ToDecimal(rd["QTY"])
            });
        }

        return list;
    }

    /// <summary>
    /// Linii din SP_SAGA_RETETE_DET (fallback dacă SP_SAGA_RECIPE_LINES e gol).
    /// </summary>
    public List<SyncedRecipeLineRow> GetReteteDetLines(FbConnection conn, string articolCode)
    {
        var list = new List<SyncedRecipeLineRow>();
        if (string.IsNullOrWhiteSpace(articolCode) || !TableExists(conn, "SP_SAGA_RETETE_DET"))
            return list;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT
  TRIM(COALESCE(COMPONENT_CODE, '')) AS COMPONENT_CODE,
  TRIM(COALESCE(COMPONENT_NAME, '')) AS COMPONENT_NAME,
  COALESCE(QTY, 0) AS QTY,
  TRIM(COALESCE(UM, '')) AS UM,
  TRIM(COALESCE(GESTIUNE, '')) AS GESTIUNE
FROM SP_SAGA_RETETE_DET
WHERE UPPER(TRIM(ARTICOL_CODE)) = UPPER(TRIM(@A))
ORDER BY COMPONENT_CODE";
        cmd.Parameters.AddWithValue("@A", articolCode.Trim());

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new SyncedRecipeLineRow
            {
                SourceTable = "RETETE_DET",
                Tip = "",
                Gestiune = (rd["GESTIUNE"]?.ToString() ?? "").Trim(),
                Operatie = "",
                ComponentCode = (rd["COMPONENT_CODE"]?.ToString() ?? "").Trim(),
                ComponentName = (rd["COMPONENT_NAME"]?.ToString() ?? "").Trim(),
                Um = (rd["UM"]?.ToString() ?? "").Trim(),
                Quantity = ToDecimal(rd["QTY"])
            });
        }

        return list;
    }

    /// <summary>Articole care au cel puțin o linie în SP_SAGA_RECIPE_LINES (listă inferioară).</summary>
    public List<RecipeMasterListRow> GetRecipeMasterList(FbConnection conn)
    {
        SagaArticoleSchemaExtensions.EnsureExtendedColumns(conn);
        var extended = SagaArticoleSchemaExtensions.HasExtendedArticoleColumns(conn);

        var list = new List<RecipeMasterListRow>();
        using var cmd = conn.CreateCommand();
        const string recipeExistsSql = @"
EXISTS (
  SELECT 1 FROM SP_SAGA_RECIPE_LINES R
  WHERE UPPER(TRIM(R.ARTICOL_CODE)) = UPPER(TRIM(A.CODE))
    AND (
      UPPER(TRIM(COALESCE(R.SOURCE_TABLE, ''))) <> 'ART_ANTE'
      OR NOT EXISTS (
        SELECT 1 FROM SP_SAGA_RECIPE_LINES R2
        WHERE UPPER(TRIM(R2.ARTICOL_CODE)) = UPPER(TRIM(A.CODE))
          AND UPPER(TRIM(COALESCE(R2.SOURCE_TABLE, ''))) = 'ART_A_DET'
      )
    )
)";
        cmd.CommandText = extended
            ? $@"
SELECT
  TRIM(A.CODE), TRIM(A.NAME), TRIM(A.UM), TRIM(A.CATEGORIE),
  COALESCE(A.STOC, 0), COALESCE(A.PRET_VANZ, 0), COALESCE(A.TVA, 0)
FROM SP_SAGA_ARTICOLE A
WHERE {recipeExistsSql}
ORDER BY A.NAME"
            : $@"
SELECT
  TRIM(A.CODE), TRIM(A.NAME), TRIM(A.UM), TRIM(A.CATEGORIE),
  0, COALESCE(A.PRET_VANZ, 0), COALESCE(A.TVA, 0)
FROM SP_SAGA_ARTICOLE A
WHERE {recipeExistsSql}
ORDER BY A.NAME";

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new RecipeMasterListRow
            {
                Code = (rd[0]?.ToString() ?? "").Trim(),
                Name = (rd[1]?.ToString() ?? "").Trim(),
                Um = (rd[2]?.ToString() ?? "").Trim(),
                Categorie = (rd[3]?.ToString() ?? "").Trim(),
                Stoc = ToDecimal(rd[4]),
                PretVanz = ToDecimal(rd[5]),
                Tva = ToDecimal(rd[6])
            });
        }

        return list;
    }

    /// <summary>Număr total linii rețetă (inclusiv ART_ANTE), pentru confirmare la salvare goală.</summary>
    public int CountAllRecipeLinesForArticle(FbConnection conn, string articleCode)
    {
        if (string.IsNullOrWhiteSpace(articleCode) || !TableExists(conn, "SP_SAGA_RECIPE_LINES"))
            return 0;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT COUNT(*) FROM SP_SAGA_RECIPE_LINES
WHERE UPPER(TRIM(ARTICOL_CODE)) = UPPER(TRIM(@C))";
        cmd.Parameters.AddWithValue("@C", articleCode.Trim());
        var o = cmd.ExecuteScalar();
        return o == null || o == DBNull.Value ? 0 : Convert.ToInt32(o);
    }

    /// <summary>Înlocuiește toate liniile de rețetă pentru articol (SP_SAGA_RECIPE_LINES).</summary>
    public void SaveRecipeLines(FbConnection conn, string articolCode, IReadOnlyList<SyncedRecipeLineRow> lines)
    {
        if (string.IsNullOrWhiteSpace(articolCode))
            return;

        var toSave = lines.ToList();
        TryEnrichMissingComponentCodes(conn, toSave);

        using var tx = conn.BeginTransaction();
        try
        {
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = "DELETE FROM SP_SAGA_RECIPE_LINES WHERE UPPER(TRIM(ARTICOL_CODE)) = UPPER(TRIM(@C))";
                cmd.Parameters.AddWithValue("@C", articolCode.Trim());
                cmd.ExecuteNonQuery();
            }

            foreach (var line in toSave)
            {
                var key = string.IsNullOrWhiteSpace(line.LineKey) ? Guid.NewGuid().ToString("N") : line.LineKey.Trim();
                line.LineKey = key;

                using var cmd = conn.CreateCommand();
                cmd.Transaction = tx;
                cmd.CommandText = @"
UPDATE OR INSERT INTO SP_SAGA_RECIPE_LINES
(LINE_KEY, ARTICOL_CODE, SOURCE_TABLE, TIP, GESTIUNE, OPERATIE, COMPONENT_CODE, COMPONENT_NAME, UM, QTY, UPDATED_AT)
VALUES
(@LINE_KEY, @ARTICOL_CODE, @SOURCE_TABLE, @TIP, @GESTIUNE, @OPERATIE, @COMPONENT_CODE, @COMPONENT_NAME, @UM, @QTY, CURRENT_TIMESTAMP)
MATCHING (LINE_KEY)";
                cmd.Parameters.AddWithValue("@LINE_KEY", key);
                cmd.Parameters.AddWithValue("@ARTICOL_CODE", articolCode.Trim());
                cmd.Parameters.AddWithValue("@SOURCE_TABLE", DbOrTrim(line.SourceTable));
                cmd.Parameters.AddWithValue("@TIP", DbOrTrim(line.Tip));
                cmd.Parameters.AddWithValue("@GESTIUNE", DbOrTrim(line.Gestiune));
                cmd.Parameters.AddWithValue("@OPERATIE", DbOrTrim(string.IsNullOrWhiteSpace(line.Operatie) ? "-" : line.Operatie));
                cmd.Parameters.AddWithValue("@COMPONENT_CODE", DbOrTrim(line.ComponentCode));
                cmd.Parameters.AddWithValue("@COMPONENT_NAME", DbOrTrim(line.ComponentName));
                cmd.Parameters.AddWithValue("@UM", DbOrTrim(line.Um));
                cmd.Parameters.AddWithValue("@QTY", line.Quantity);
                cmd.ExecuteNonQuery();
            }

            tx.Commit();
        }
        catch
        {
            try { tx.Rollback(); } catch { /* ignored */ }
            throw;
        }
    }

    private static void TryEnrichMissingComponentCodes(FbConnection conn, List<SyncedRecipeLineRow> lines)
    {
        foreach (var line in lines)
        {
            if (string.Equals(line.SourceTable, "ART_ANTE", StringComparison.OrdinalIgnoreCase)
                && string.IsNullOrWhiteSpace(line.ComponentCode))
            {
                var op = (line.Operatie ?? "").Trim();
                if (op.Length > 0 && !string.Equals(op, "-", StringComparison.OrdinalIgnoreCase))
                    line.ComponentCode = op;
            }
        }

        if (!TableExists(conn, "SP_SAGA_ARTICOLE"))
            return;
        foreach (var line in lines)
        {
            if (!string.IsNullOrWhiteSpace(line.ComponentCode))
                continue;
            var name = (line.ComponentName ?? "").Trim();
            if (name.Length < 2)
                continue;
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
SELECT TRIM(CODE) FROM SP_SAGA_ARTICOLE
WHERE COALESCE(IS_BLOCKED, 0) = 0
  AND UPPER(TRIM(NAME)) = UPPER(TRIM(@N))";
            cmd.Parameters.AddWithValue("@N", name);
            using var rd = cmd.ExecuteReader();
            string? only = null;
            var n = 0;
            while (rd.Read())
            {
                n++;
                only = (rd[0]?.ToString() ?? "").Trim();
            }

            if (n == 1 && !string.IsNullOrEmpty(only))
                line.ComponentCode = only;
        }
    }

    private static object DbOrTrim(string? v)
        => string.IsNullOrWhiteSpace(v) ? DBNull.Value : v.Trim();

    private static string NormalizeTipSagaLocal(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return "";
        var t = value.Trim();
        return t.Length <= 1 ? t : t[..1];
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static bool ColumnExists(FbConnection conn, string table, string column)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATION_FIELDS
WHERE TRIM(RDB$RELATION_NAME) = @T AND TRIM(RDB$FIELD_NAME) = @C ROWS 1";
        cmd.Parameters.AddWithValue("@T", table.Trim().ToUpperInvariant());
        cmd.Parameters.AddWithValue("@C", column.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static int ToInt(object? value)
        => value == null || value == DBNull.Value ? 0 : Convert.ToInt32(value);

    private static decimal ToDecimal(object? value)
        => value == null || value == DBNull.Value ? 0m : Convert.ToDecimal(value);
}

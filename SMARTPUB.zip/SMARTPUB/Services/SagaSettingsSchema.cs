using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

public static class SagaSettingsSchema
{
    public static void EnsureSchema(FbConnection conn)
    {
        EnsureTableSagaSyncSettings(conn);
        EnsureSagaSyncServerColumns(conn);
    }

    private static void EnsureSagaSyncServerColumns(FbConnection conn)
    {
        EnsureColumn(conn, "SAGA_SYNC_SETTINGS", "SAGA_CONN_MODE",
            "VARCHAR(16) DEFAULT 'EMBEDDED'");
        EnsureColumn(conn, "SAGA_SYNC_SETTINGS", "SAGA_SERVER_HOST", "VARCHAR(128)");
        EnsureColumn(conn, "SAGA_SYNC_SETTINGS", "SAGA_SERVER_PORT", "INTEGER DEFAULT 3060");
        EnsureColumn(conn, "SAGA_SYNC_SETTINGS", "SAGA_SERVER_ROOT", "VARCHAR(260)");
    }

    private static bool ColumnExists(FbConnection conn, string table, string column)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATION_FIELDS R
JOIN RDB$RELATIONS L ON L.RDB$RELATION_NAME = R.RDB$RELATION_NAME
WHERE L.RDB$SYSTEM_FLAG = 0
  AND TRIM(L.RDB$RELATION_NAME) = @T
  AND TRIM(R.RDB$FIELD_NAME) = @C
ROWS 1";
        cmd.Parameters.AddWithValue("@T", table.Trim().ToUpperInvariant());
        cmd.Parameters.AddWithValue("@C", column.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static void EnsureColumn(FbConnection conn, string table, string column, string sqlType)
    {
        if (ColumnExists(conn, table, column))
            return;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = $"ALTER TABLE {table} ADD {column} {sqlType}";
        cmd.ExecuteNonQuery();
    }

    private static void EnsureTableSagaSyncSettings(FbConnection conn)
    {
        if (TableExists(conn, "SAGA_SYNC_SETTINGS"))
            return;

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
CREATE TABLE SAGA_SYNC_SETTINGS (
    ID INTEGER NOT NULL,
    SAGA_ROOT_PATH VARCHAR(260),
    FBCLIENT_PATH VARCHAR(260),
    CONFIG_DB_PATH VARCHAR(260),
    COMPANY_CODE VARCHAR(10),
    COMPANY_NAME VARCHAR(100),
    COMPANY_DB_PATH VARCHAR(260),
    CREATED_AT TIMESTAMP,
    UPDATED_AT TIMESTAMP,
    PRIMARY KEY (ID)
)";
            cmd.ExecuteNonQuery();
        }

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
INSERT INTO SAGA_SYNC_SETTINGS (ID, CREATED_AT, UPDATED_AT)
VALUES (1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
";
            cmd.ExecuteNonQuery();
        }
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1
FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0
  AND TRIM(RDB$RELATION_NAME) = @T
ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}


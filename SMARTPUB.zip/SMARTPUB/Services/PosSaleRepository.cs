using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public static class PosSaleRepository
{
    public const string StatusPaid = "PAID";
    public const string SagaReady = "READY";
    public const string SagaSent = "SENT";
    public const string SagaError = "ERROR";
    public const string SagaNone = "NONE";

    public static string CreateSaleFromCart(
        FbConnection conn,
        string tableId,
        string? tableDisplayName,
        string? operatorId,
        string? operatorName,
        string modPlata,
        IReadOnlyList<WaiterCartLine> lines,
        IReadOnlyList<PosSalePaymentInput>? payments = null,
        bool clearTableDraft = true)
    {
        if (lines == null || lines.Count == 0)
            throw new InvalidOperationException("Coșul este gol.");

        SagaArticoleSchemaExtensions.EnsureExtendedColumns(conn);
        ProgramTransferDocSchema.EnsureSchema(conn);
        // Metadate înainte de tranzacție: TableExists pe conexiune fără tx activ (altfel FbCommand cere Transaction).
        var hasGest = TableExists(conn, "SP_SAGA_GESTIUNI");
        var transferCfg = new ProgramExtendedConfigRepository().LoadTransfer(conn);
        var defaultGestiune = ResolveDefaultGestiune(conn, hasGest, transferCfg);
        var paymentRows = NormalizePayments(modPlata, payments, lines.Sum(x => x.LineTotal));
        var saleId = Guid.NewGuid().ToString("N");
        var now = DateTime.Now;

        using var tx = conn.BeginTransaction();
        try
        {
            var orderNo = NextOrderNo(conn, tx);

            decimal sumNet = 0, sumVat = 0, sumTot = 0;
            var n = 0;
            foreach (var ln in lines)
            {
                n++;
                var meta = LookupArticle(conn, tx, hasGest, ln.ProductCode ?? "", defaultGestiune);
                meta = ApplySelectedGestiune(conn, tx, hasGest, meta, ln);
                var net = Math.Round(ln.Qty * ln.UnitPrice, 2, MidpointRounding.AwayFromZero);
                var vat = Math.Round(net * (ln.TvaPct / 100m), 2, MidpointRounding.AwayFromZero);
                var gross = net + vat;
                sumNet += net;
                sumVat += vat;
                sumTot += gross;

                using var insL = conn.CreateCommand();
                insL.Transaction = tx;
                insL.CommandText = @"
INSERT INTO SP_POS_SALE_LINE (
  SALE_ID, LINE_NO, COD_GESTIUNE, DEN_GEST, PRODUCT_CODE, PRODUCT_NAME, UM, TVA_PCT,
  QTY, UNIT_PRICE, VALOARE, VALOARE_TVA, TOTAL
) VALUES (
  @S, @N, @CG, @DG, @PC, @PN, @UM, @TV,
  @Q, @UP, @VN, @VT, @TT
)";
                insL.Parameters.AddWithValue("@S", saleId);
                insL.Parameters.AddWithValue("@N", n);
                insL.Parameters.AddWithValue("@CG", meta.GestiuneCode);
                insL.Parameters.AddWithValue("@DG", meta.GestiuneName);
                insL.Parameters.AddWithValue("@PC", (ln.ProductCode ?? "").Trim());
                insL.Parameters.AddWithValue("@PN", (ln.ProductName ?? "").Trim());
                insL.Parameters.AddWithValue("@UM", meta.Um);
                insL.Parameters.AddWithValue("@TV", ln.TvaPct);
                insL.Parameters.AddWithValue("@Q", ln.Qty);
                insL.Parameters.AddWithValue("@UP", ln.UnitPrice);
                insL.Parameters.AddWithValue("@VN", net);
                insL.Parameters.AddWithValue("@VT", vat);
                insL.Parameters.AddWithValue("@TT", gross);
                insL.ExecuteNonQuery();
            }

            using var insH = conn.CreateCommand();
            insH.Transaction = tx;
            insH.CommandText = @"
INSERT INTO SP_POS_SALE_HEADER (
  ID, ORDER_NO, TABLE_ID, TABLE_DISPLAY_NAME, OPERATOR_ID, OPERATOR_NAME,
  STATUS, VALOARE, VALOARE_TVA, TOTAL, PAID_AT, CREATED_AT, MOD_PLATA,
  SAGA_TRANSFER_STATUS, UPDATED_AT
) VALUES (
  @ID, @ONO, @TID, @TDN, @OID, @ONM,
  @ST, @VN, @VT, @TT, @PA, @CA, @MP,
  @SAG, CURRENT_TIMESTAMP
)";
            insH.Parameters.AddWithValue("@ID", saleId);
            insH.Parameters.AddWithValue("@ONO", orderNo);
            insH.Parameters.AddWithValue("@TID", string.IsNullOrWhiteSpace(tableId) ? DBNull.Value : tableId.Trim());
            insH.Parameters.AddWithValue("@TDN", string.IsNullOrWhiteSpace(tableDisplayName) ? DBNull.Value : tableDisplayName.Trim());
            insH.Parameters.AddWithValue("@OID", string.IsNullOrWhiteSpace(operatorId) ? DBNull.Value : operatorId.Trim());
            insH.Parameters.AddWithValue("@ONM", string.IsNullOrWhiteSpace(operatorName) ? DBNull.Value : operatorName.Trim());
            insH.Parameters.AddWithValue("@ST", StatusPaid);
            insH.Parameters.AddWithValue("@VN", sumNet);
            insH.Parameters.AddWithValue("@VT", sumVat);
            insH.Parameters.AddWithValue("@TT", sumTot);
            insH.Parameters.AddWithValue("@PA", now);
            insH.Parameters.AddWithValue("@CA", now);
            insH.Parameters.AddWithValue("@MP", string.IsNullOrWhiteSpace(modPlata) ? "Numerar" : modPlata.Trim());
            insH.Parameters.AddWithValue("@SAG", SagaReady);
            insH.ExecuteNonQuery();

            var payNo = 0;
            foreach (var pay in paymentRows)
            {
                payNo++;
                using var insP = conn.CreateCommand();
                insP.Transaction = tx;
                insP.CommandText = @"
INSERT INTO SP_POS_SALE_PAYMENT (
  SALE_ID, LINE_NO, METHOD_KEY, AMOUNT
) VALUES (
  @S, @N, @M, @A
)";
                insP.Parameters.AddWithValue("@S", saleId);
                insP.Parameters.AddWithValue("@N", payNo);
                insP.Parameters.AddWithValue("@M", NormalizeMethodKey(pay.MethodKey));
                insP.Parameters.AddWithValue("@A", pay.Amount);
                insP.ExecuteNonQuery();
            }

            if (clearTableDraft && !string.IsNullOrWhiteSpace(tableId))
            {
                using var del = conn.CreateCommand();
                del.Transaction = tx;
                del.CommandText = "DELETE FROM SP_POS_DRAFT_LINE WHERE TABLE_ID = @T";
                del.Parameters.AddWithValue("@T", tableId.Trim());
                del.ExecuteNonQuery();
            }

            tx.Commit();
            return saleId;
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    private static int NextOrderNo(FbConnection conn, FbTransaction tx)
    {
        using var cmd = conn.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = "SELECT COALESCE(MAX(ORDER_NO), 0) + 1 FROM SP_POS_SALE_HEADER";
        var x = cmd.ExecuteScalar();
        return Convert.ToInt32(x ?? 1);
    }

    private sealed record ArticleMeta(string GestiuneCode, string GestiuneName, string Um);

    private static ArticleMeta LookupArticle(
        FbConnection conn,
        FbTransaction tx,
        bool hasGest,
        string productCode,
        ArticleMeta defaultGestiune)
    {
        var code = (productCode ?? "").Trim();
        if (code.Length == 0)
            return defaultGestiune;

        using var cmd = conn.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = hasGest
            ? @"
SELECT TRIM(A.NAME), TRIM(COALESCE(A.UM, '')), TRIM(COALESCE(A.GESTIUNE, '')),
       TRIM(COALESCE(G.NAME, ''))
FROM SP_SAGA_ARTICOLE A
LEFT JOIN SP_SAGA_GESTIUNI G ON TRIM(A.GESTIUNE) = TRIM(G.CODE)
WHERE TRIM(A.CODE) = TRIM(@C)
ROWS 1"
            : @"
SELECT TRIM(A.NAME), TRIM(COALESCE(A.UM, '')), TRIM(COALESCE(A.GESTIUNE, '')), CAST('' AS VARCHAR(100))
FROM SP_SAGA_ARTICOLE A
WHERE TRIM(A.CODE) = TRIM(@C)
ROWS 1";
        cmd.Parameters.AddWithValue("@C", code);
        using var rd = cmd.ExecuteReader();
        if (!rd.Read())
            return defaultGestiune;

        var name = rd[0]?.ToString() ?? "";
        var um = rd[1]?.ToString() ?? "";
        var gCode = rd[2]?.ToString() ?? "";
        var gName = hasGest ? (rd[3]?.ToString() ?? "") : "";
        if (string.IsNullOrWhiteSpace(gCode) && !string.IsNullOrWhiteSpace(defaultGestiune.GestiuneCode))
            return new ArticleMeta(defaultGestiune.GestiuneCode, defaultGestiune.GestiuneName, um);
        return new ArticleMeta(gCode, gName, um);
    }

    private static ArticleMeta ResolveDefaultGestiune(
        FbConnection conn,
        bool hasGest,
        ProgramTransferDocConfig transferCfg)
    {
        var code = (transferCfg.DefaultGestiuneCode ?? "").Trim();
        var name = (transferCfg.DefaultGestiuneName ?? "").Trim();
        if (code.Length == 0)
            return new ArticleMeta("", "", "");

        if (hasGest && name.Length == 0)
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
SELECT TRIM(COALESCE(NAME, ''))
FROM SP_SAGA_GESTIUNI
WHERE TRIM(CODE) = TRIM(@C)
ROWS 1";
            cmd.Parameters.AddWithValue("@C", code);
            name = cmd.ExecuteScalar()?.ToString()?.Trim() ?? "";
        }

        return new ArticleMeta(code, name, "");
    }

    private static ArticleMeta ApplySelectedGestiune(
        FbConnection conn,
        FbTransaction tx,
        bool hasGest,
        ArticleMeta current,
        WaiterCartLine line)
    {
        var code = (line.GestiuneCode ?? "").Trim();
        if (code.Length == 0)
            return current;

        var name = (line.GestiuneName ?? "").Trim();
        if (hasGest && name.Length == 0)
        {
            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = @"
SELECT TRIM(COALESCE(NAME, ''))
FROM SP_SAGA_GESTIUNI
WHERE TRIM(CODE) = TRIM(@C)
ROWS 1";
            cmd.Parameters.AddWithValue("@C", code);
            name = cmd.ExecuteScalar()?.ToString()?.Trim() ?? "";
        }

        return new ArticleMeta(code, name, current.Um);
    }

    private static List<PosSalePaymentInput> NormalizePayments(
        string modPlata,
        IReadOnlyList<PosSalePaymentInput>? payments,
        decimal expectedTotal)
    {
        var rows = (payments ?? Array.Empty<PosSalePaymentInput>())
            .Select(p => new PosSalePaymentInput
            {
                MethodKey = NormalizeMethodKey(p.MethodKey),
                Amount = Math.Round(p.Amount, 2, MidpointRounding.AwayFromZero)
            })
            .Where(p => p.Amount > 0)
            .GroupBy(p => p.MethodKey, StringComparer.OrdinalIgnoreCase)
            .Select(g => new PosSalePaymentInput
            {
                MethodKey = g.Key,
                Amount = g.Sum(x => x.Amount)
            })
            .ToList();

        if (rows.Count == 0)
        {
            rows.Add(new PosSalePaymentInput
            {
                MethodKey = NormalizeMethodKey(modPlata),
                Amount = Math.Round(expectedTotal, 2, MidpointRounding.AwayFromZero)
            });
        }

        return rows;
    }

    public static string NormalizeMethodKey(string? method)
    {
        var m = (method ?? "").Trim().ToUpperInvariant();
        if (m.Length == 0)
            return "NUMERAR";
        if (m.Contains("NUMERAR", StringComparison.Ordinal) || m.Contains("CASH", StringComparison.Ordinal) || m.Contains("CASA", StringComparison.Ordinal))
            return "NUMERAR";
        if (m.Contains("CARD", StringComparison.Ordinal) || m.Contains("POS", StringComparison.Ordinal) || m.Contains("VISA", StringComparison.Ordinal) || m.Contains("MASTERCARD", StringComparison.Ordinal))
            return "CARD";
        return m switch
        {
            "BONURI" or "BON" or "TICHET" or "TICHETE" => "BONURI",
            "CEC" => "CEC",
            "MIXT" or "MIXED" or "METODE MODERNE" or "METODE_MODERNE" => "METODE_MODERNE",
            _ => m.Replace(' ', '_')
        };
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    public static PosSaleHeaderRow? GetHeader(FbConnection conn, string saleId)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT ID, ORDER_NO, TABLE_DISPLAY_NAME, OPERATOR_NAME, STATUS,
       VALOARE, VALOARE_TVA, TOTAL, PAID_AT, CREATED_AT, MOD_PLATA,
       SAGA_TRANSFER_STATUS, SAGA_ID_IESIRE, SAGA_NR_IESIRE, SAGA_ERROR
FROM SP_POS_SALE_HEADER
WHERE ID = @S
ROWS 1";
        cmd.Parameters.AddWithValue("@S", saleId.Trim());
        using var rd = cmd.ExecuteReader();
        if (!rd.Read())
            return null;
        return new PosSaleHeaderRow
        {
            Id = (rd["ID"]?.ToString() ?? "").Trim(),
            OrderNo = Convert.ToInt32(rd["ORDER_NO"] ?? 0),
            TableDisplayName = (rd["TABLE_DISPLAY_NAME"]?.ToString() ?? "").Trim(),
            OperatorName = (rd["OPERATOR_NAME"]?.ToString() ?? "").Trim(),
            Status = (rd["STATUS"]?.ToString() ?? "").Trim(),
            Valoare = ToDec(rd["VALOARE"]),
            ValoareTva = ToDec(rd["VALOARE_TVA"]),
            Total = ToDec(rd["TOTAL"]),
            PaidAt = rd["PAID_AT"] == DBNull.Value ? default : Convert.ToDateTime(rd["PAID_AT"]),
            CreatedAt = rd["CREATED_AT"] == DBNull.Value ? default : Convert.ToDateTime(rd["CREATED_AT"]),
            ModPlata = (rd["MOD_PLATA"]?.ToString() ?? "").Trim(),
            SagaTransferStatus = (rd["SAGA_TRANSFER_STATUS"]?.ToString() ?? "").Trim(),
            SagaIdIesire = rd["SAGA_ID_IESIRE"] == DBNull.Value ? null : ToDec(rd["SAGA_ID_IESIRE"]),
            SagaNrIesire = rd["SAGA_NR_IESIRE"]?.ToString()?.Trim(),
            SagaError = rd["SAGA_ERROR"]?.ToString()?.Trim()
        };
    }

    public static List<PosSaleHeaderRow> ListHeaders(
        FbConnection conn,
        DateTime dateFrom,
        DateTime dateTo,
        string? sagaStatusFilter = null)
    {
        var list = new List<PosSaleHeaderRow>();
        var to = dateTo.Date.AddDays(1).AddSeconds(-1);
        using var cmd = conn.CreateCommand();
        var sql = @"
SELECT ID, ORDER_NO, TABLE_DISPLAY_NAME, OPERATOR_NAME, STATUS,
       VALOARE, VALOARE_TVA, TOTAL, PAID_AT, CREATED_AT, MOD_PLATA,
       SAGA_TRANSFER_STATUS, SAGA_ID_IESIRE, SAGA_NR_IESIRE, SAGA_ERROR
FROM SP_POS_SALE_HEADER
WHERE PAID_AT >= @F AND PAID_AT <= @T ";
        if (!string.IsNullOrWhiteSpace(sagaStatusFilter))
            sql += " AND UPPER(TRIM(SAGA_TRANSFER_STATUS)) = UPPER(TRIM(@SAG)) ";
        sql += " ORDER BY ORDER_NO DESC, PAID_AT DESC";

        cmd.CommandText = sql;
        cmd.Parameters.AddWithValue("@F", dateFrom.Date);
        cmd.Parameters.AddWithValue("@T", to);
        if (!string.IsNullOrWhiteSpace(sagaStatusFilter))
            cmd.Parameters.AddWithValue("@SAG", sagaStatusFilter.Trim());

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new PosSaleHeaderRow
            {
                Id = (rd["ID"]?.ToString() ?? "").Trim(),
                OrderNo = Convert.ToInt32(rd["ORDER_NO"] ?? 0),
                TableDisplayName = (rd["TABLE_DISPLAY_NAME"]?.ToString() ?? "").Trim(),
                OperatorName = (rd["OPERATOR_NAME"]?.ToString() ?? "").Trim(),
                Status = (rd["STATUS"]?.ToString() ?? "").Trim(),
                Valoare = ToDec(rd["VALOARE"]),
                ValoareTva = ToDec(rd["VALOARE_TVA"]),
                Total = ToDec(rd["TOTAL"]),
                PaidAt = rd["PAID_AT"] == DBNull.Value ? default : Convert.ToDateTime(rd["PAID_AT"]),
                CreatedAt = rd["CREATED_AT"] == DBNull.Value ? default : Convert.ToDateTime(rd["CREATED_AT"]),
                ModPlata = (rd["MOD_PLATA"]?.ToString() ?? "").Trim(),
                SagaTransferStatus = (rd["SAGA_TRANSFER_STATUS"]?.ToString() ?? "").Trim(),
                SagaIdIesire = rd["SAGA_ID_IESIRE"] == DBNull.Value ? null : ToDec(rd["SAGA_ID_IESIRE"]),
                SagaNrIesire = rd["SAGA_NR_IESIRE"]?.ToString()?.Trim(),
                SagaError = rd["SAGA_ERROR"]?.ToString()?.Trim()
            });
        }

        return list;
    }

    public static List<PosSaleLineRow> ListLines(FbConnection conn, string saleId)
    {
        var list = new List<PosSaleLineRow>();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT SALE_ID, LINE_NO, COD_GESTIUNE, DEN_GEST, PRODUCT_CODE, PRODUCT_NAME, UM, TVA_PCT,
       QTY, UNIT_PRICE, VALOARE, VALOARE_TVA, TOTAL
FROM SP_POS_SALE_LINE
WHERE SALE_ID = @S
ORDER BY LINE_NO";
        cmd.Parameters.AddWithValue("@S", saleId.Trim());
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new PosSaleLineRow
            {
                SaleId = (rd["SALE_ID"]?.ToString() ?? "").Trim(),
                LineNo = Convert.ToInt32(rd["LINE_NO"] ?? 0),
                CodGestiune = (rd["COD_GESTIUNE"]?.ToString() ?? "").Trim(),
                DenGest = (rd["DEN_GEST"]?.ToString() ?? "").Trim(),
                ProductCode = (rd["PRODUCT_CODE"]?.ToString() ?? "").Trim(),
                ProductName = (rd["PRODUCT_NAME"]?.ToString() ?? "").Trim(),
                Um = (rd["UM"]?.ToString() ?? "").Trim(),
                TvaPct = ToDec(rd["TVA_PCT"]),
                Qty = ToDec(rd["QTY"]),
                UnitPrice = ToDec(rd["UNIT_PRICE"]),
                Valoare = ToDec(rd["VALOARE"]),
                ValoareTva = ToDec(rd["VALOARE_TVA"]),
                Total = ToDec(rd["TOTAL"])
            });
        }

        return list;
    }

    public static List<PosSalePaymentRow> ListPayments(FbConnection conn, string saleId)
    {
        var list = new List<PosSalePaymentRow>();
        if (!TableExists(conn, "SP_POS_SALE_PAYMENT"))
            return list;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT SALE_ID, LINE_NO, METHOD_KEY, AMOUNT
FROM SP_POS_SALE_PAYMENT
WHERE SALE_ID = @S
ORDER BY LINE_NO";
        cmd.Parameters.AddWithValue("@S", saleId.Trim());
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new PosSalePaymentRow
            {
                SaleId = (rd["SALE_ID"]?.ToString() ?? "").Trim(),
                LineNo = Convert.ToInt32(rd["LINE_NO"] ?? 0),
                MethodKey = (rd["METHOD_KEY"]?.ToString() ?? "").Trim(),
                Amount = ToDec(rd["AMOUNT"])
            });
        }

        return list;
    }

    public static void UpdateSagaTransferResult(
        FbConnection conn,
        string saleId,
        string status,
        decimal? sagaIdIesire,
        string? sagaNrIesire,
        string? errorMessage)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
UPDATE SP_POS_SALE_HEADER SET
  SAGA_TRANSFER_STATUS = @ST,
  SAGA_ID_IESIRE = @ID,
  SAGA_NR_IESIRE = @NR,
  SAGA_ERROR = @ER,
  UPDATED_AT = CURRENT_TIMESTAMP
WHERE ID = @S";
        cmd.Parameters.AddWithValue("@ST", TruncateDb(status, 16));
        cmd.Parameters.AddWithValue("@ID", sagaIdIesire.HasValue ? sagaIdIesire.Value : DBNull.Value);
        cmd.Parameters.AddWithValue("@NR", string.IsNullOrWhiteSpace(sagaNrIesire) ? DBNull.Value : TruncateDb(sagaNrIesire, 48));
        cmd.Parameters.AddWithValue("@ER", string.IsNullOrWhiteSpace(errorMessage) ? DBNull.Value : TruncateDb(errorMessage, 1000));
        cmd.Parameters.AddWithValue("@S", TruncateDb(saleId, 36));
        cmd.ExecuteNonQuery();
    }

    private static string TruncateDb(string? value, int maxLength)
    {
        if (maxLength <= 0 || string.IsNullOrWhiteSpace(value))
            return "";
        var text = value.Trim();
        return text.Length <= maxLength ? text : text[..maxLength];
    }

    public static int ResetSagaTransferToReady(FbConnection conn, IEnumerable<string> saleIds)
    {
        var ids = saleIds
            .Select(x => (x ?? "").Trim())
            .Where(x => x.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        if (ids.Count == 0)
            return 0;

        using var tx = conn.BeginTransaction();
        try
        {
            var updated = 0;
            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = @"
UPDATE SP_POS_SALE_HEADER SET
  SAGA_TRANSFER_STATUS = @READY,
  SAGA_ID_IESIRE = NULL,
  SAGA_NR_IESIRE = NULL,
  SAGA_ERROR = NULL,
  UPDATED_AT = CURRENT_TIMESTAMP
WHERE ID = @S
  AND UPPER(TRIM(SAGA_TRANSFER_STATUS)) = UPPER(TRIM(@SENT))";
            cmd.Parameters.AddWithValue("@READY", SagaReady);
            cmd.Parameters.AddWithValue("@S", "");
            cmd.Parameters.AddWithValue("@SENT", SagaSent);

            foreach (var id in ids)
            {
                cmd.Parameters["@S"].Value = id;
                updated += cmd.ExecuteNonQuery();
            }

            tx.Commit();
            return updated;
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    private static decimal ToDec(object? o)
    {
        if (o == null || o == DBNull.Value)
            return 0;
        return Convert.ToDecimal(o);
    }
}

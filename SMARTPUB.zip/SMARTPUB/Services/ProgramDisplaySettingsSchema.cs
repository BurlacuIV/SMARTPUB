using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

public static class ProgramDisplaySettingsSchema
{
    public static void EnsureSchema(FbConnection conn)
    {
        if (TableExists(conn, "SP_PROGRAM_DISPLAY"))
            return;

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
CREATE TABLE SP_PROGRAM_DISPLAY (
    ID INTEGER NOT NULL,
    GRUP_PANEL_HEIGHT INTEGER DEFAULT 120,
    ARTICOL_PANEL_HEIGHT INTEGER DEFAULT 80,
    CREATED_AT TIMESTAMP,
    UPDATED_AT TIMESTAMP,
    PRIMARY KEY (ID)
)";
            cmd.ExecuteNonQuery();
        }

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
INSERT INTO SP_PROGRAM_DISPLAY (ID, GRUP_PANEL_HEIGHT, ARTICOL_PANEL_HEIGHT, CREATED_AT, UPDATED_AT)
VALUES (1, 120, 80, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
            cmd.ExecuteNonQuery();
        }
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

using System.IO;
using System.Linq;
using System.Collections.Generic;
using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

public static class SmartPubDb
{
    public const string DefaultDbPath = @"D:\SMARTPUB\Data\SMARTPUB.FDB";
    public static string? LastSuccessfulClientPath { get; private set; }

    public static FbConnection OpenEmbedded(string? dbPath = null)
    {
        var path = string.IsNullOrWhiteSpace(dbPath) ? DefaultDbPath : dbPath;
        if (!File.Exists(path))
            throw new FileNotFoundException("SMARTPUB.FDB nu există.", path);

        var requiresFb4 = FirebirdOdsHelper.TryReadOdsVersion(path, out var odsMajor, out var odsMinor)
                          && FirebirdOdsHelper.RequiresFirebird4OrNewer(odsMajor);

        var available = FirebirdClientLocator.GetCandidatesForDatabase(path);
        if (available.Count == 0)
        {
            if (requiresFb4)
                throw new FileNotFoundException(
                    $"SMARTPUB.FDB este Firebird 4 (ODS {odsMajor}.{odsMinor}). " +
                    "Instalează clientul Firebird 4.0 sau 5.0 (fbclient.dll în Program Files\\Firebird). " +
                    "Clientul SAGA (Firebird 3) nu poate deschide această bază.",
                    path);

            throw new FileNotFoundException(
                "Nu a fost găsit niciun fbclient.dll compatibil pentru SMARTPUB.FDB.", path);
        }

        var errors = new List<string>();
        var sawOdsMismatch = false;

        foreach (var fbClient in available)
        {
            try
            {
                var cs = new FbConnectionStringBuilder
                {
                    Database = path,
                    UserID = "SYSDBA",
                    Password = "masterkey",
                    ServerType = FbServerType.Embedded,
                    ClientLibrary = fbClient,
                    Pooling = false,
                    Dialect = 3
                };

                var con = new FbConnection(cs.ToString());
                con.Open();
                LastSuccessfulClientPath = fbClient;
                return con;
            }
            catch (Exception ex)
            {
                errors.Add($"{fbClient} -> {ex.Message}");
                if (IsOdsMismatch(ex))
                    sawOdsMismatch = true;
            }
        }

        if (requiresFb4 || sawOdsMismatch)
        {
            throw new InvalidOperationException(
                $"SMARTPUB.FDB necesită Firebird 4+ (ODS {odsMajor}.{odsMinor}). " +
                "Instalează Firebird 4.0 sau 5.0 x64; fbclient din SAGA (Firebird 3) nu este compatibil.\n\n" +
                string.Join("\n", errors));
        }

        throw new InvalidOperationException(
            "Nu s-a putut deschide SMARTPUB.FDB cu niciun client Firebird disponibil.\n" +
            string.Join("\n", errors));
    }

    static bool IsOdsMismatch(Exception ex) =>
        ex.Message.Contains("unsupported on-disk structure", StringComparison.OrdinalIgnoreCase)
        || ex.Message.Contains("found 13.", StringComparison.OrdinalIgnoreCase);
}


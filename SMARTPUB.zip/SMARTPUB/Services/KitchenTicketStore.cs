using SMARTPUB.Models;

namespace SMARTPUB.Services;

/// <summary>
/// Comenzi trimise la bucătărie (KDS). Persistă în SP_POS_KITCHEN_* din SMARTPUB.FDB.
/// Fișierul legacy %LocalAppData%\SMARTPUB\kitchen_tickets.json este importat o singură dată la migrare.
/// </summary>
public sealed class KitchenTicketStore
{
    public static KitchenTicketStore Instance { get; } = new();

    private readonly object _gate = new();
    private List<KitchenTicket> _tickets = new();
    private bool _initialized;

    private KitchenTicketStore()
    {
    }

    public event EventHandler? Changed;

    /// <summary>Calea JSON vechi (doar informativ / migrare).</summary>
    public static string LegacyJsonPath => PosOperationalSchema.LegacyKitchenJsonPath;

    private void EnsureLoaded()
    {
        lock (_gate)
        {
            if (_initialized)
                return;

            using var conn = SmartPubDb.OpenEmbedded();
            PosOperationalSchema.EnsureSchema(conn);
            _tickets = PosKitchenTicketRepository.LoadAll(conn);
            _initialized = true;
        }
    }

    private void ReloadFromDatabase(bool raiseChanged)
    {
        lock (_gate)
        {
            using var conn = SmartPubDb.OpenEmbedded();
            PosOperationalSchema.EnsureSchema(conn);
            _tickets = PosKitchenTicketRepository.LoadAll(conn);
            _initialized = true;
        }

        if (raiseChanged)
            Changed?.Invoke(this, EventArgs.Empty);
    }

    public IReadOnlyList<KitchenTicket> GetSnapshot()
    {
        EnsureLoaded();
        lock (_gate)
            return _tickets.OrderBy(t => t.CreatedAtUtc).ToList();
    }

    /// <summary>Reîncarcă din baza de date (înlocuiește vechiul JSON multi-proces).</summary>
    public void SyncFromDisk(bool raiseChanged = true) => ReloadFromDatabase(raiseChanged);

    public KitchenTicket AddTicket(KitchenTicket ticket)
    {
        EnsureLoaded();
        lock (_gate)
        {
            if (string.IsNullOrWhiteSpace(ticket.Id))
                ticket.Id = Guid.NewGuid().ToString("N");
            ticket.CreatedAtUtc = DateTime.UtcNow;
            ticket.Status = KitchenTicketStatus.New;

            using var conn = SmartPubDb.OpenEmbedded();
            PosKitchenTicketRepository.InsertTicket(conn, ticket);
            _tickets.Add(ticket);
        }

        AuditLogService.Write("KITCHEN", "TicketCreated", ticket.Id);
        Changed?.Invoke(this, EventArgs.Empty);
        return ticket;
    }

    public void UpdateStatus(string ticketId, KitchenTicketStatus status)
    {
        EnsureLoaded();
        lock (_gate)
        {
            var t = _tickets.FirstOrDefault(x => x.Id == ticketId);
            if (t == null)
                return;
            t.Status = status;
            using var conn = SmartPubDb.OpenEmbedded();
            PosKitchenTicketRepository.UpdateStatus(conn, ticketId, status);
        }

        AuditLogService.Write("KITCHEN", "TicketStatus", $"{ticketId}:{status}");
        Changed?.Invoke(this, EventArgs.Empty);
    }
}

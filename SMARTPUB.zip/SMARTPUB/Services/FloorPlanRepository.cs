using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public sealed class FloorPlanRepository
{
    public (List<FloorLevelModel> Levels, List<FloorSpaceModel> Spaces, List<FloorTableModel> Tables) Load(
        FbConnection conn)
    {
        var levels = new List<FloorLevelModel>();
        var spaces = new List<FloorSpaceModel>();
        var tables = new List<FloorTableModel>();

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
SELECT ID, NAME, SORT_ORDER
FROM SP_FLOOR_LEVEL
ORDER BY SORT_ORDER, NAME";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                levels.Add(new FloorLevelModel
                {
                    Id = (rd["ID"]?.ToString() ?? "").Trim(),
                    Name = (rd["NAME"]?.ToString() ?? "").Trim(),
                    SortOrder = ToInt(rd["SORT_ORDER"])
                });
            }
        }

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
SELECT ID, LEVEL_ID, NAME, POS_X, POS_Y, WIDTH, HEIGHT, ZORDER, TINT_ARGB
FROM SP_FLOOR_SPACE
ORDER BY ZORDER, NAME";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                spaces.Add(new FloorSpaceModel
                {
                    Id = (rd["ID"]?.ToString() ?? "").Trim(),
                    LevelId = (rd["LEVEL_ID"]?.ToString() ?? "").Trim(),
                    Name = (rd["NAME"]?.ToString() ?? "").Trim(),
                    X = ToDouble(rd["POS_X"]),
                    Y = ToDouble(rd["POS_Y"]),
                    Width = ToDouble(rd["WIDTH"]),
                    Height = ToDouble(rd["HEIGHT"]),
                    ZOrder = ToInt(rd["ZORDER"]),
                    TintArgb = ToInt(rd["TINT_ARGB"])
                });
            }
        }

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
SELECT ID, LEVEL_ID, NAME, POS_X, POS_Y, WIDTH, HEIGHT, IS_ROUND, SEATS, SPACE_ID
FROM SP_FLOOR_TABLE
ORDER BY NAME";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var sid = rd["SPACE_ID"]?.ToString()?.Trim();
                tables.Add(new FloorTableModel
                {
                    Id = (rd["ID"]?.ToString() ?? "").Trim(),
                    LevelId = (rd["LEVEL_ID"]?.ToString() ?? "").Trim(),
                    Name = (rd["NAME"]?.ToString() ?? "").Trim(),
                    X = ToDouble(rd["POS_X"]),
                    Y = ToDouble(rd["POS_Y"]),
                    Width = ToDouble(rd["WIDTH"]),
                    Height = ToDouble(rd["HEIGHT"]),
                    IsRound = ToInt(rd["IS_ROUND"]) != 0,
                    Seats = ToInt(rd["SEATS"]),
                    SpaceId = string.IsNullOrWhiteSpace(sid) ? null : sid
                });
            }
        }

        return (levels, spaces, tables);
    }

    public void SaveAll(FbConnection conn, IReadOnlyList<FloorLevelModel> levels,
        IReadOnlyList<FloorSpaceModel> spaces, IReadOnlyList<FloorTableModel> tables)
    {
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = "DELETE FROM SP_FLOOR_TABLE";
            cmd.ExecuteNonQuery();
        }

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = "DELETE FROM SP_FLOOR_SPACE";
            cmd.ExecuteNonQuery();
        }

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = "DELETE FROM SP_FLOOR_LEVEL";
            cmd.ExecuteNonQuery();
        }

        foreach (var lv in levels)
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
INSERT INTO SP_FLOOR_LEVEL (ID, NAME, SORT_ORDER, UPDATED_AT)
VALUES (@ID, @N, @S, CURRENT_TIMESTAMP)";
            cmd.Parameters.AddWithValue("@ID", lv.Id);
            cmd.Parameters.AddWithValue("@N", DbOr(lv.Name));
            cmd.Parameters.AddWithValue("@S", lv.SortOrder);
            cmd.ExecuteNonQuery();
        }

        foreach (var s in spaces)
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
INSERT INTO SP_FLOOR_SPACE (ID, LEVEL_ID, NAME, POS_X, POS_Y, WIDTH, HEIGHT, ZORDER, TINT_ARGB, UPDATED_AT)
VALUES (@ID, @LV, @NAME, @X, @Y, @W, @H, @Z, @T, CURRENT_TIMESTAMP)";
            cmd.Parameters.AddWithValue("@ID", s.Id);
            cmd.Parameters.AddWithValue("@LV", DbOr(s.LevelId));
            cmd.Parameters.AddWithValue("@NAME", DbOr(s.Name));
            cmd.Parameters.AddWithValue("@X", s.X);
            cmd.Parameters.AddWithValue("@Y", s.Y);
            cmd.Parameters.AddWithValue("@W", s.Width);
            cmd.Parameters.AddWithValue("@H", s.Height);
            cmd.Parameters.AddWithValue("@Z", s.ZOrder);
            cmd.Parameters.AddWithValue("@T", s.TintArgb);
            cmd.ExecuteNonQuery();
        }

        foreach (var t in tables)
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
INSERT INTO SP_FLOOR_TABLE (ID, LEVEL_ID, NAME, POS_X, POS_Y, WIDTH, HEIGHT, IS_ROUND, SEATS, SPACE_ID, UPDATED_AT)
VALUES (@ID, @LV, @NAME, @X, @Y, @W, @H, @R, @S, @SP, CURRENT_TIMESTAMP)";
            cmd.Parameters.AddWithValue("@ID", t.Id);
            cmd.Parameters.AddWithValue("@LV", DbOr(t.LevelId));
            cmd.Parameters.AddWithValue("@NAME", DbOr(t.Name));
            cmd.Parameters.AddWithValue("@X", t.X);
            cmd.Parameters.AddWithValue("@Y", t.Y);
            cmd.Parameters.AddWithValue("@W", t.Width);
            cmd.Parameters.AddWithValue("@H", t.Height);
            cmd.Parameters.AddWithValue("@R", t.IsRound ? 1 : 0);
            cmd.Parameters.AddWithValue("@S", t.Seats);
            cmd.Parameters.AddWithValue("@SP", string.IsNullOrWhiteSpace(t.SpaceId) ? DBNull.Value : t.SpaceId);
            cmd.ExecuteNonQuery();
        }
    }

    private static object DbOr(string? v)
        => string.IsNullOrWhiteSpace(v) ? DBNull.Value : v.Trim();

    private static double ToDouble(object? v)
        => v == null || v == DBNull.Value ? 0 : Convert.ToDouble(v);

    private static int ToInt(object? v)
        => v == null || v == DBNull.Value ? 0 : Convert.ToInt32(v);
}

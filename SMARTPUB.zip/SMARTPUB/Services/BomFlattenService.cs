using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public sealed class BomFlattenService
{
    private readonly BomLocalRepository _repo = new();

    /// <summary>
    /// Expandă rețeta la materii prime. lineKind 0=MP, 1=sub-produs.
    /// Cantități: pentru fiecare linie, cantitatea efectivă = qty_linie * multiplicator din părinți.
    /// </summary>
    public List<FlattenedBomLine> Flatten(FbConnection conn, string rootArticleCode, bool mergeDuplicates = true)
    {
        var articles = _repo.ListArticles(conn)
            .ToDictionary(a => a.Code.Trim(), a => a, StringComparer.OrdinalIgnoreCase);
        var linesByParent = new Dictionary<string, List<BomLineRow>>(StringComparer.OrdinalIgnoreCase);
        foreach (var a in articles.Keys)
            linesByParent[a] = _repo.ListLines(conn, a);

        if (!articles.ContainsKey(rootArticleCode.Trim()))
            throw new InvalidOperationException($"Articolul BOM „{rootArticleCode}” nu există.");

        var raw = new List<FlattenedBomLine>();
        FlattenRecursive(
            rootArticleCode.Trim(),
            1m,
            new HashSet<string>(StringComparer.OrdinalIgnoreCase),
            linesByParent,
            articles,
            raw,
            conn);

        if (!mergeDuplicates)
            return raw;

        return MergeByComponent(raw);
    }

    private void FlattenRecursive(
        string parentCode,
        decimal parentMultiplier,
        HashSet<string> stack,
        Dictionary<string, List<BomLineRow>> linesByParent,
        Dictionary<string, BomArticleRow> articles,
        List<FlattenedBomLine> output,
        FbConnection conn)
    {
        if (stack.Contains(parentCode))
            throw new InvalidOperationException($"Rețetă circulară: articolul „{parentCode}” apare de două ori în lanț.");

        stack.Add(parentCode);
        try
        {
            if (!linesByParent.TryGetValue(parentCode, out var lines) || lines.Count == 0)
                return;

            foreach (var line in lines.OrderBy(l => l.LineNo))
            {
                var qty = line.Qty * parentMultiplier;
                if (line.LineKind == 0)
                {
                    var name = _repo.TryGetSagaArticleName(conn, line.ComponentCode) ?? line.ComponentCode;
                    output.Add(new FlattenedBomLine
                    {
                        ComponentCode = line.ComponentCode.Trim(),
                        ComponentName = name,
                        Quantity = qty,
                        Um = line.Um.Trim(),
                        Gestiune = line.Gestiune.Trim(),
                        DenTip = line.DenTip.Trim()
                    });
                }
                else
                {
                    if (!articles.ContainsKey(line.ComponentCode.Trim()))
                        throw new InvalidOperationException(
                            $"Sub-produs „{line.ComponentCode}” nu există în BOM local.");

                    FlattenRecursive(
                        line.ComponentCode.Trim(),
                        qty,
                        stack,
                        linesByParent,
                        articles,
                        output,
                        conn);
                }
            }
        }
        finally
        {
            stack.Remove(parentCode);
        }
    }

    private static List<FlattenedBomLine> MergeByComponent(List<FlattenedBomLine> lines)
    {
        var map = new Dictionary<string, FlattenedBomLine>(StringComparer.OrdinalIgnoreCase);
        foreach (var l in lines)
        {
            var key = $"{l.ComponentCode}|{l.Gestiune ?? ""}|{l.DenTip ?? ""}|{l.Um ?? ""}";
            if (!map.TryGetValue(key, out var existing))
            {
                map[key] = new FlattenedBomLine
                {
                    ComponentCode = l.ComponentCode ?? "",
                    ComponentName = l.ComponentName ?? "",
                    Quantity = l.Quantity,
                    Um = l.Um ?? "",
                    Gestiune = l.Gestiune ?? "",
                    DenTip = l.DenTip ?? ""
                };
            }
            else
            {
                existing.Quantity += l.Quantity;
            }
        }

        return map.Values.OrderBy(x => x.ComponentCode, StringComparer.OrdinalIgnoreCase).ToList();
    }
}

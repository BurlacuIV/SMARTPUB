using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

public static class ProgramTransferDocSchema
{
    public static void EnsureSchema(FbConnection conn)
    {
        if (!TableExists(conn, "SP_PROGRAM_TRANSFER_DOC"))
        {
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
CREATE TABLE SP_PROGRAM_TRANSFER_DOC (
    ID INTEGER NOT NULL,
    IMPLICIT_CLIENT VARCHAR(16),
    DEFAULT_GESTIUNE_CODE VARCHAR(24),
    DEFAULT_GESTIUNE_NAME VARCHAR(64),
    CONT_DISCOUNT VARCHAR(12),
    CONT_PROTOCOL VARCHAR(12),
    CONT_BACSIS VARCHAR(12),
    SERIE_FACTURI VARCHAR(24),
    SERIE_BONURI VARCHAR(24),
    AUTO_TRANSFER_AFTER_PAYMENT SMALLINT DEFAULT 0,
    INC_MOD_PE_FACTURA SMALLINT DEFAULT 0,
    TEXT_SUPL_FACTURA VARCHAR(1024),
    CAZ_INC_NOPTII SMALLINT DEFAULT 0,
    CAZ_INC_PERIOADA SMALLINT DEFAULT 0,
    CAZ_INC_CAMERA SMALLINT DEFAULT 0,
    CREATED_AT TIMESTAMP,
    UPDATED_AT TIMESTAMP,
    PRIMARY KEY (ID)
)";
                cmd.ExecuteNonQuery();
            }

            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
INSERT INTO SP_PROGRAM_TRANSFER_DOC (
    ID, CONT_DISCOUNT, CONT_BACSIS, CREATED_AT, UPDATED_AT
) VALUES (1, '667', '462', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
                cmd.ExecuteNonQuery();
            }
        }

        TryAddColumn(conn, "SP_PROGRAM_TRANSFER_DOC", "DEFAULT_GESTIUNE_CODE", "VARCHAR(24)");
        TryAddColumn(conn, "SP_PROGRAM_TRANSFER_DOC", "DEFAULT_GESTIUNE_NAME", "VARCHAR(64)");
        TryAddColumn(conn, "SP_PROGRAM_TRANSFER_DOC", "AUTO_TRANSFER_AFTER_PAYMENT", "SMALLINT DEFAULT 0");

        if (!TableExists(conn, "SP_TRANSFER_MOD_MAP"))
        {
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
CREATE TABLE SP_TRANSFER_MOD_MAP (
    METHOD_KEY VARCHAR(24) NOT NULL PRIMARY KEY,
    CLIENT_CODE VARCHAR(16),
    CONT_TRANSFER VARCHAR(32),
    UPDATED_AT TIMESTAMP
)";
                cmd.ExecuteNonQuery();
            }
        }

        SeedTransferMethods(conn);
    }

    private static void SeedTransferMethods(FbConnection conn)
    {
        foreach (var key in new[] { "NUMERAR", "CARD", "BONURI", "CEC", "METODE_MODERNE" })
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
INSERT INTO SP_TRANSFER_MOD_MAP (METHOD_KEY, CLIENT_CODE, CONT_TRANSFER, UPDATED_AT)
SELECT @K, NULL, NULL, CURRENT_TIMESTAMP FROM RDB$DATABASE
WHERE NOT EXISTS (SELECT 1 FROM SP_TRANSFER_MOD_MAP M WHERE M.METHOD_KEY = @K)";
            cmd.Parameters.AddWithValue("@K", key);
            cmd.ExecuteNonQuery();
        }
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static bool ColumnExists(FbConnection conn, string table, string column)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATION_FIELDS
WHERE TRIM(RDB$RELATION_NAME) = @T AND TRIM(RDB$FIELD_NAME) = @C ROWS 1";
        cmd.Parameters.AddWithValue("@T", table.Trim().ToUpperInvariant());
        cmd.Parameters.AddWithValue("@C", column.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static void TryAddColumn(FbConnection conn, string table, string column, string definition)
    {
        if (ColumnExists(conn, table, column))
            return;
        try
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = $"ALTER TABLE {table} ADD {column} {definition}";
            cmd.ExecuteNonQuery();
        }
        catch
        {
            /* coloana poate exista deja sau versiune Firebird diferită */
        }
    }
}

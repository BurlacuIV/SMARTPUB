using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public static class PosKitchenTicketRepository
{
    public static List<KitchenTicket> LoadAll(FbConnection conn)
    {
        var list = new List<KitchenTicket>();
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
SELECT ID, CREATED_AT_UTC, TABLE_ID, TABLE_DISPLAY_NAME, LEVEL_NAME, SPACE_NAME, SOURCE_OPERATOR, STATUS
FROM SP_POS_KITCHEN_TICKET
ORDER BY CREATED_AT_UTC";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var id = (rd["ID"]?.ToString() ?? "").Trim();
                var t = new KitchenTicket
                {
                    Id = id,
                    CreatedAtUtc = rd["CREATED_AT_UTC"] is DateTime dt ? DateTime.SpecifyKind(dt, DateTimeKind.Utc) : DateTime.UtcNow,
                    TableId = (rd["TABLE_ID"]?.ToString() ?? "").Trim(),
                    TableDisplayName = (rd["TABLE_DISPLAY_NAME"]?.ToString() ?? "").Trim(),
                    LevelName = (rd["LEVEL_NAME"]?.ToString() ?? "").Trim(),
                    SpaceName = string.IsNullOrWhiteSpace(rd["SPACE_NAME"]?.ToString()) ? null : rd["SPACE_NAME"]!.ToString()!.Trim(),
                    SourceOperator = string.IsNullOrWhiteSpace(rd["SOURCE_OPERATOR"]?.ToString()) ? null : rd["SOURCE_OPERATOR"]!.ToString()!.Trim(),
                    Status = ParseStatus(rd["STATUS"]?.ToString())
                };
                list.Add(t);
            }
        }

        AttachLinesBatch(conn, list);
        return list;
    }

    private static void AttachLinesBatch(FbConnection conn, List<KitchenTicket> tickets)
    {
        if (tickets.Count == 0)
            return;

        foreach (var t in tickets)
            t.Lines = new List<KitchenTicketLine>();

        var byId = tickets.ToDictionary(t => t.Id, StringComparer.OrdinalIgnoreCase);
        using var cmd = conn.CreateCommand();
        var hasGest = ColumnExists(conn, "SP_POS_KITCHEN_TICKET_LINE", "GESTIUNE_CODE");
        cmd.CommandText = hasGest
            ? @"
SELECT TICKET_ID, PRODUCT_CODE, PRODUCT_NAME, GESTIUNE_CODE, GESTIUNE_NAME, QTY, UNIT_PRICE, NOTES, LINE_NO
FROM SP_POS_KITCHEN_TICKET_LINE
ORDER BY TICKET_ID, LINE_NO"
            : @"
SELECT TICKET_ID, PRODUCT_CODE, PRODUCT_NAME, QTY, UNIT_PRICE, NOTES, LINE_NO
FROM SP_POS_KITCHEN_TICKET_LINE
ORDER BY TICKET_ID, LINE_NO";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var tid = (rd["TICKET_ID"]?.ToString() ?? "").Trim();
            if (!byId.TryGetValue(tid, out var ticket))
                continue;
            ticket.Lines.Add(new KitchenTicketLine
            {
                ProductCode = (rd["PRODUCT_CODE"]?.ToString() ?? "").Trim(),
                ProductName = (rd["PRODUCT_NAME"]?.ToString() ?? "").Trim(),
                GestiuneCode = hasGest ? (rd["GESTIUNE_CODE"]?.ToString() ?? "").Trim() : "",
                GestiuneName = hasGest ? (rd["GESTIUNE_NAME"]?.ToString() ?? "").Trim() : "",
                Qty = ToDec(rd["QTY"]),
                UnitPrice = ToDec(rd["UNIT_PRICE"]),
                Notes = string.IsNullOrWhiteSpace(rd["NOTES"]?.ToString()) ? null : rd["NOTES"]!.ToString()!.Trim()
            });
        }
    }

    private static List<KitchenTicketLine> LoadLines(FbConnection conn, string ticketId)
    {
        var lines = new List<KitchenTicketLine>();
        using var cmd = conn.CreateCommand();
        var hasGest = ColumnExists(conn, "SP_POS_KITCHEN_TICKET_LINE", "GESTIUNE_CODE");
        cmd.CommandText = hasGest
            ? @"
SELECT PRODUCT_CODE, PRODUCT_NAME, GESTIUNE_CODE, GESTIUNE_NAME, QTY, UNIT_PRICE, NOTES
FROM SP_POS_KITCHEN_TICKET_LINE
WHERE TICKET_ID = @T
ORDER BY LINE_NO"
            : @"
SELECT PRODUCT_CODE, PRODUCT_NAME, QTY, UNIT_PRICE, NOTES
FROM SP_POS_KITCHEN_TICKET_LINE
WHERE TICKET_ID = @T
ORDER BY LINE_NO";
        cmd.Parameters.AddWithValue("@T", ticketId);
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            lines.Add(new KitchenTicketLine
            {
                ProductCode = (rd["PRODUCT_CODE"]?.ToString() ?? "").Trim(),
                ProductName = (rd["PRODUCT_NAME"]?.ToString() ?? "").Trim(),
                GestiuneCode = hasGest ? (rd["GESTIUNE_CODE"]?.ToString() ?? "").Trim() : "",
                GestiuneName = hasGest ? (rd["GESTIUNE_NAME"]?.ToString() ?? "").Trim() : "",
                Qty = ToDec(rd["QTY"]),
                UnitPrice = ToDec(rd["UNIT_PRICE"]),
                Notes = string.IsNullOrWhiteSpace(rd["NOTES"]?.ToString()) ? null : rd["NOTES"]!.ToString()!.Trim()
            });
        }

        return lines;
    }

    public static void InsertTicket(FbConnection conn, KitchenTicket ticket)
    {
        if (string.IsNullOrWhiteSpace(ticket.Id))
            ticket.Id = Guid.NewGuid().ToString("N");
        if (ticket.CreatedAtUtc == default)
            ticket.CreatedAtUtc = DateTime.UtcNow;
        ticket.CreatedAtUtc = DateTime.SpecifyKind(ticket.CreatedAtUtc, DateTimeKind.Utc);

        using var tx = conn.BeginTransaction();
        try
        {
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
INSERT INTO SP_POS_KITCHEN_TICKET (ID, CREATED_AT_UTC, TABLE_ID, TABLE_DISPLAY_NAME, LEVEL_NAME, SPACE_NAME, SOURCE_OPERATOR, STATUS)
VALUES (@ID, @C, @TID, @TD, @LV, @SP, @OP, @ST)";
                cmd.Parameters.AddWithValue("@ID", ticket.Id);
                cmd.Parameters.AddWithValue("@C", ticket.CreatedAtUtc);
                cmd.Parameters.AddWithValue("@TID", DbOrEmpty(ticket.TableId));
                cmd.Parameters.AddWithValue("@TD", DbOrEmpty(ticket.TableDisplayName));
                cmd.Parameters.AddWithValue("@LV", DbOrEmpty(ticket.LevelName));
                cmd.Parameters.AddWithValue("@SP", (object?)ticket.SpaceName ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@OP", (object?)ticket.SourceOperator ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ST", StatusToString(ticket.Status));
                cmd.ExecuteNonQuery();
            }

            var lineNo = 0;
            foreach (var ln in ticket.Lines)
            {
                lineNo++;
                using var cmd = conn.CreateCommand();
                cmd.Transaction = tx;
                cmd.CommandText = @"
INSERT INTO SP_POS_KITCHEN_TICKET_LINE (
  TICKET_ID, LINE_NO, PRODUCT_CODE, PRODUCT_NAME, GESTIUNE_CODE, GESTIUNE_NAME,
  QTY, UNIT_PRICE, NOTES
) VALUES (
  @K, @N, @C, @NM, @GC, @GN,
  @Q, @P, @NT
)";
                cmd.Parameters.AddWithValue("@K", ticket.Id);
                cmd.Parameters.AddWithValue("@N", lineNo);
                cmd.Parameters.AddWithValue("@C", DbOrEmpty(ln.ProductCode));
                cmd.Parameters.AddWithValue("@NM", DbOrEmpty(ln.ProductName));
                cmd.Parameters.AddWithValue("@GC", string.IsNullOrWhiteSpace(ln.GestiuneCode) ? DBNull.Value : ln.GestiuneCode.Trim());
                cmd.Parameters.AddWithValue("@GN", string.IsNullOrWhiteSpace(ln.GestiuneName) ? DBNull.Value : ln.GestiuneName.Trim());
                cmd.Parameters.AddWithValue("@Q", ln.Qty);
                cmd.Parameters.AddWithValue("@P", ln.UnitPrice);
                cmd.Parameters.AddWithValue("@NT", (object?)ln.Notes ?? DBNull.Value);
                cmd.ExecuteNonQuery();
            }

            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    public static void UpdateStatus(FbConnection conn, string ticketId, KitchenTicketStatus status)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "UPDATE SP_POS_KITCHEN_TICKET SET STATUS = @S WHERE ID = @I";
        cmd.Parameters.AddWithValue("@S", StatusToString(status));
        cmd.Parameters.AddWithValue("@I", ticketId);
        cmd.ExecuteNonQuery();
    }

    private static string StatusToString(KitchenTicketStatus s) => s.ToString();

    private static KitchenTicketStatus ParseStatus(string? v)
    {
        if (string.IsNullOrWhiteSpace(v))
            return KitchenTicketStatus.New;
        return Enum.TryParse<KitchenTicketStatus>(v, true, out var x) ? x : KitchenTicketStatus.New;
    }

    private static object DbOrEmpty(string? s) => string.IsNullOrWhiteSpace(s) ? "" : s.Trim();

    private static decimal ToDec(object? o)
    {
        if (o == null || o == DBNull.Value)
            return 0;
        return Convert.ToDecimal(o);
    }

    private static bool ColumnExists(FbConnection conn, string tableName, string columnName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATION_FIELDS
WHERE TRIM(RDB$RELATION_NAME) = @T AND TRIM(RDB$FIELD_NAME) = @C ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        cmd.Parameters.AddWithValue("@C", columnName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public sealed class ProgramSaleSettingsRepository
{
    public ProgramSaleSettingsRow Load(FbConnection conn)
    {
        ProgramSaleSettingsSchema.EnsureSchema(conn);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT
  COALESCE(ULTIMA_GESTIUNE_ART, 1),
  COALESCE(VINDE_LA_SELECT, 1),
  COALESCE(CUMUL_VANZARE, 1),
  COALESCE(CUMUL_NOTA, 0),
  COALESCE(CUMUL_BON_FISCAL, 0),
  COALESCE(ARATA_STOC_NEG, 1),
  COALESCE(ALLOW_NEG_STOC, 1),
  COALESCE(INCASA_FARA_CF, 0),
  COALESCE(ARATA_BTN_CF, 0),
  COALESCE(TIP_AUTO_CF, 1),
  COALESCE(IESIRE_DUPA_VAL, 1),
  COALESCE(INCHIDE_BON_AUTO, 0),
  COALESCE(TIP_AUTO_NOTA, 1),
  COALESCE(TIP_AUTO_BON_INC, 0),
  COALESCE(IESIRE_DUPA_TIP_BF, 0),
  COALESCE(ARATA_GEST_BTN, 0),
  COALESCE(ARATA_PRET_BTN, 0),
  COALESCE(SUNET_MONITOR, 0),
  COALESCE(GEST_IMPLICIT_GRUP, 1),
  COALESCE(INCASARE_RAPIDA, 0),
  COALESCE(TAST_VIRTUALA, 1),
  TRIM(COALESCE(VIEW_ART_MODE, 'Buttons')),
  TRIM(COALESCE(SORT_ART_MODE, 'SalesOrder')),
  TRIM(COALESCE(PRINT_CF_MODE, 'Gestiune')),
  COALESCE(PLAFON_VANZARE, 0)
FROM SP_PROGRAM_SALE_SETTINGS
WHERE ID = 1
ROWS 1";

        using var rd = cmd.ExecuteReader();
        if (!rd.Read())
            return new ProgramSaleSettingsRow();

        static bool B(object? o) => o != null && o != DBNull.Value && Convert.ToInt32(o) != 0;

        return new ProgramSaleSettingsRow
        {
            ArticoleUltimaGestiune = B(rd[0]),
            VindeLaSelectare = B(rd[1]),
            CumuleazaLaVanzare = B(rd[2]),
            CumuleazaPeNota = B(rd[3]),
            CumuleazaPeBonFiscal = B(rd[4]),
            AfiseazaStocNegativ = B(rd[5]),
            PermiteVanzareStocNegativ = B(rd[6]),
            IncasareFaraComandaFerma = B(rd[7]),
            AfiseazaButonComandaFerma = B(rd[8]),
            TiparireAutoComandaFermaLaValidare = B(rd[9]),
            IesireAutoDupaValidare = B(rd[10]),
            InchideBonAutoDupaVanzare = B(rd[11]),
            TiparireAutoNotaFaraPreview = B(rd[12]),
            TiparireAutoBonLaIncasare = B(rd[13]),
            IesireAutoDupaTiparireBonFiscal = B(rd[14]),
            AfiseazaGestiuneModButoane = B(rd[15]),
            AfiseazaPretModButoane = B(rd[16]),
            SuneteMonitorComenzi = B(rd[17]),
            GestiuneImplicitaLaGrupa = B(rd[18]),
            IncasareRapida = B(rd[19]),
            TastaturaVirtuala = B(rd[20]),
            ModVizualizareArticole = NormalizeView(rd[21]?.ToString()),
            ModSortareArticole = NormalizeSort(rd[22]?.ToString()),
            TiparireComandaFerma = NormalizePrintCf(rd[23]?.ToString()),
            PlafonVanzare = rd[24] == null || rd[24] == DBNull.Value ? 0m : Convert.ToDecimal(rd[24])
        };
    }

    public void Save(FbConnection conn, ProgramSaleSettingsRow r)
    {
        ProgramSaleSettingsSchema.EnsureSchema(conn);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
UPDATE OR INSERT INTO SP_PROGRAM_SALE_SETTINGS (
  ID,
  ULTIMA_GESTIUNE_ART, VINDE_LA_SELECT, CUMUL_VANZARE, CUMUL_NOTA, CUMUL_BON_FISCAL,
  ARATA_STOC_NEG, ALLOW_NEG_STOC, INCASA_FARA_CF, ARATA_BTN_CF, TIP_AUTO_CF,
  IESIRE_DUPA_VAL, INCHIDE_BON_AUTO, TIP_AUTO_NOTA, TIP_AUTO_BON_INC, IESIRE_DUPA_TIP_BF,
  ARATA_GEST_BTN, ARATA_PRET_BTN, SUNET_MONITOR, GEST_IMPLICIT_GRUP, INCASARE_RAPIDA, TAST_VIRTUALA,
  VIEW_ART_MODE, SORT_ART_MODE, PRINT_CF_MODE, PLAFON_VANZARE,
  UPDATED_AT
) VALUES (
  1,
  @A1, @A2, @A3, @A4, @A5,
  @A6, @A7, @A8, @A9, @A10,
  @A11, @A12, @A13, @A14, @A15,
  @A16, @A17, @A18, @A19, @A20, @A21,
  @VM, @SM, @PM, @PL,
  CURRENT_TIMESTAMP
)
MATCHING (ID)";

        void P(string n, bool v) => cmd.Parameters.AddWithValue(n, v ? 1 : 0);

        P("@A1", r.ArticoleUltimaGestiune);
        P("@A2", r.VindeLaSelectare);
        P("@A3", r.CumuleazaLaVanzare);
        P("@A4", r.CumuleazaPeNota);
        P("@A5", r.CumuleazaPeBonFiscal);
        P("@A6", r.AfiseazaStocNegativ);
        P("@A7", r.PermiteVanzareStocNegativ);
        P("@A8", r.IncasareFaraComandaFerma);
        P("@A9", r.AfiseazaButonComandaFerma);
        P("@A10", r.TiparireAutoComandaFermaLaValidare);
        P("@A11", r.IesireAutoDupaValidare);
        P("@A12", r.InchideBonAutoDupaVanzare);
        P("@A13", r.TiparireAutoNotaFaraPreview);
        P("@A14", r.TiparireAutoBonLaIncasare);
        P("@A15", r.IesireAutoDupaTiparireBonFiscal);
        P("@A16", r.AfiseazaGestiuneModButoane);
        P("@A17", r.AfiseazaPretModButoane);
        P("@A18", r.SuneteMonitorComenzi);
        P("@A19", r.GestiuneImplicitaLaGrupa);
        P("@A20", r.IncasareRapida);
        P("@A21", r.TastaturaVirtuala);

        cmd.Parameters.AddWithValue("@VM", Truncate(NormalizeView(r.ModVizualizareArticole), 16));
        cmd.Parameters.AddWithValue("@SM", Truncate(NormalizeSort(r.ModSortareArticole), 24));
        cmd.Parameters.AddWithValue("@PM", Truncate(NormalizePrintCf(r.TiparireComandaFerma), 16));
        cmd.Parameters.AddWithValue("@PL", r.PlafonVanzare);
        cmd.ExecuteNonQuery();
    }

    private static string NormalizeView(string? s)
    {
        var t = (s ?? "").Trim();
        return t.Equals("List", StringComparison.OrdinalIgnoreCase) ? "List" : "Buttons";
    }

    private static string NormalizeSort(string? s)
    {
        var t = (s ?? "").Trim();
        return t.Equals("Alphabetical", StringComparison.OrdinalIgnoreCase) ||
               t.Equals("Alpha", StringComparison.OrdinalIgnoreCase)
            ? "Alphabetical"
            : "SalesOrder";
    }

    private static string NormalizePrintCf(string? s)
    {
        var t = (s ?? "").Trim();
        return t.Equals("Printer", StringComparison.OrdinalIgnoreCase) ? "Printer" : "Gestiune";
    }

    private static string Truncate(string s, int max) =>
        s.Length <= max ? s : s[..max];
}

using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public sealed class ProgramSettingsRepository
{
    public ProgramSettingsRow Load(FbConnection conn)
    {
        ProgramSettingsSchema.EnsureSchema(conn);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT
  TRIM(COALESCE(SAGA_CONN_MODE, '')),
  TRIM(COALESCE(SAGA_SERVER_IP, '')),
  TRIM(COALESCE(SAGA_SERVER_DB_FOLDER, '')),
  TRIM(COALESCE(PRINTER_FIRM_ORDER, '')),
  TRIM(COALESCE(PRINTER_BILL, '')),
  TRIM(COALESCE(PRINTER_INVOICE, '')),
  COALESCE(SINGLE_INSTANCE, 1),
  COALESCE(START_FULLSCREEN, 1),
  COALESCE(CHECK_UPDATES_START, 0),
  COALESCE(AUTO_SYNC_NOMENCLATURE, 0),
  COALESCE(AUTO_LOGOUT_SEC, -1),
  COALESCE(HOTEL_MODE, 0),
  TRIM(COALESCE(PRINTER_BAR, '')),
  TRIM(COALESCE(PRINTER_KITCHEN, ''))
FROM SP_PROGRAM_SETTINGS
WHERE ID = 1
ROWS 1";

        using var rd = cmd.ExecuteReader();
        if (!rd.Read())
            return new ProgramSettingsRow();

        static bool I32(object? o) => o != null && o != DBNull.Value && Convert.ToInt32(o) != 0;

        return new ProgramSettingsRow
        {
            SagaConnMode = NormalizeMode(rd[0]?.ToString()),
            SagaServerIp = rd[1]?.ToString() ?? "",
            SagaServerDbFolder = rd[2]?.ToString() ?? "",
            PrinterFirmOrder = rd[3]?.ToString() ?? "",
            PrinterBill = rd[4]?.ToString() ?? "",
            PrinterInvoice = rd[5]?.ToString() ?? "",
            SingleInstance = I32(rd[6]),
            StartFullscreen = I32(rd[7]),
            CheckUpdatesOnStart = I32(rd[8]),
            AutoSyncNomenclature = I32(rd[9]),
            AutoLogoutSec = rd[10] == null || rd[10] == DBNull.Value ? -1 : Convert.ToInt32(rd[10]),
            HotelMode = I32(rd[11]),
            PrinterBar = rd[12]?.ToString() ?? "",
            PrinterKitchen = rd[13]?.ToString() ?? ""
        };
    }

    public void Save(FbConnection conn, ProgramSettingsRow r)
    {
        ProgramSettingsSchema.EnsureSchema(conn);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
UPDATE OR INSERT INTO SP_PROGRAM_SETTINGS (
  ID,
  SAGA_CONN_MODE, SAGA_SERVER_IP, SAGA_SERVER_DB_FOLDER,
  PRINTER_FIRM_ORDER, PRINTER_BILL, PRINTER_INVOICE,
  SINGLE_INSTANCE, START_FULLSCREEN, CHECK_UPDATES_START, AUTO_SYNC_NOMENCLATURE,
  AUTO_LOGOUT_SEC, HOTEL_MODE,
  PRINTER_BAR, PRINTER_KITCHEN,
  UPDATED_AT
)
VALUES (
  1,
  @M, @IP, @FOLD,
  @P1, @P2, @P3,
  @SI, @SF, @CU, @AS,
  @AL, @HM,
  @PBAR, @PKIT,
  CURRENT_TIMESTAMP
)
MATCHING (ID)";

        cmd.Parameters.AddWithValue("@M", Truncate(r.SagaConnMode, 20));
        cmd.Parameters.AddWithValue("@IP", Truncate(r.SagaServerIp, 64));
        cmd.Parameters.AddWithValue("@FOLD", Truncate(r.SagaServerDbFolder, 260));
        cmd.Parameters.AddWithValue("@P1", string.IsNullOrWhiteSpace(r.PrinterFirmOrder) ? DBNull.Value : Truncate(r.PrinterFirmOrder, 260));
        cmd.Parameters.AddWithValue("@P2", string.IsNullOrWhiteSpace(r.PrinterBill) ? DBNull.Value : Truncate(r.PrinterBill, 260));
        cmd.Parameters.AddWithValue("@P3", string.IsNullOrWhiteSpace(r.PrinterInvoice) ? DBNull.Value : Truncate(r.PrinterInvoice, 260));
        cmd.Parameters.AddWithValue("@SI", r.SingleInstance ? 1 : 0);
        cmd.Parameters.AddWithValue("@SF", r.StartFullscreen ? 1 : 0);
        cmd.Parameters.AddWithValue("@CU", r.CheckUpdatesOnStart ? 1 : 0);
        cmd.Parameters.AddWithValue("@AS", r.AutoSyncNomenclature ? 1 : 0);
        cmd.Parameters.AddWithValue("@AL", r.AutoLogoutSec);
        cmd.Parameters.AddWithValue("@HM", r.HotelMode ? 1 : 0);
        cmd.Parameters.AddWithValue("@PBAR", string.IsNullOrWhiteSpace(r.PrinterBar) ? DBNull.Value : Truncate(r.PrinterBar, 260));
        cmd.Parameters.AddWithValue("@PKIT", string.IsNullOrWhiteSpace(r.PrinterKitchen) ? DBNull.Value : Truncate(r.PrinterKitchen, 260));
        cmd.ExecuteNonQuery();
    }

    private static string NormalizeMode(string? s)
    {
        var t = (s ?? "").Trim();
        if (t.Equals("ClientServer", StringComparison.OrdinalIgnoreCase) ||
            t.Equals("Client-Server", StringComparison.OrdinalIgnoreCase))
            return "ClientServer";
        if (t.Equals("Web", StringComparison.OrdinalIgnoreCase))
            return "Web";
        return "Standard";
    }

    private static string Truncate(string? s, int max)
    {
        if (string.IsNullOrEmpty(s))
            return "";
        var t = s.Trim();
        return t.Length <= max ? t : t[..max];
    }
}

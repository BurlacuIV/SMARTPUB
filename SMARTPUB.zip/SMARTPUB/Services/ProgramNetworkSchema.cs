using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

public static class ProgramNetworkSchema
{
    public static void EnsureSchema(FbConnection conn)
    {
        if (!TableExists(conn, "SP_PROGRAM_NETWORK"))
        {
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
CREATE TABLE SP_PROGRAM_NETWORK (
    ID INTEGER NOT NULL,
    ROOT_PATH VARCHAR(260),
    MOBILE_PRINT_CF SMALLINT DEFAULT 0,
    CREATED_AT TIMESTAMP,
    UPDATED_AT TIMESTAMP,
    PRIMARY KEY (ID)
)";
                cmd.ExecuteNonQuery();
            }

            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
INSERT INTO SP_PROGRAM_NETWORK (ID, ROOT_PATH, MOBILE_PRINT_CF, CREATED_AT, UPDATED_AT)
VALUES (1, '', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
                cmd.ExecuteNonQuery();
            }
        }

        if (!TableExists(conn, "SP_NET_SERVER"))
        {
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
CREATE TABLE SP_NET_SERVER (
    ID INTEGER NOT NULL,
    NUME VARCHAR(80),
    IP VARCHAR(45),
    CREATED_AT TIMESTAMP,
    PRIMARY KEY (ID)
)";
                cmd.ExecuteNonQuery();
            }
        }
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

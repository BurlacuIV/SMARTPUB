using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

/// <summary>Indexuri secundare Firebird — create o singură dată per proces.</summary>
public static class SmartPubSchemaIndexes
{
    private static int _ensured;

    public static void EnsurePerformanceIndexes(FbConnection conn)
    {
        if (Interlocked.Exchange(ref _ensured, 1) == 1)
            return;

        TryIndex(conn, "IDX_SP_SAGA_ART_NAME", "SP_SAGA_ARTICOLE", "NAME");
        TryIndex(conn, "IDX_SP_SAGA_ART_BLOCK_NAME", "SP_SAGA_ARTICOLE", "IS_BLOCKED, NAME");
        TryIndex(conn, "IDX_SP_SAGA_ART_GEST", "SP_SAGA_ARTICOLE", "GESTIUNE");
        TryIndex(conn, "IDX_SP_SAGA_ART_GRUPA", "SP_SAGA_ARTICOLE", "GRUPA");
        TryIndex(conn, "IDX_SP_RECIPE_ART", "SP_SAGA_RECIPE_LINES", "ARTICOL_CODE");
        TryIndex(conn, "IDX_SP_RECIPE_ART_SRC", "SP_SAGA_RECIPE_LINES", "ARTICOL_CODE, SOURCE_TABLE");
        TryIndex(conn, "IDX_SP_POS_SALE_PAID", "SP_POS_SALE_HEADER", "PAID_AT");
        TryIndex(conn, "IDX_SP_POS_SALE_STATUS_PAID", "SP_POS_SALE_HEADER", "SAGA_TRANSFER_STATUS, PAID_AT");
        TryIndex(conn, "IDX_SP_KITCHEN_CREATED", "SP_POS_KITCHEN_TICKET", "CREATED_AT_UTC");
        TryIndex(conn, "IDX_SP_KITCHEN_TABLE_STATUS", "SP_POS_KITCHEN_TICKET", "TABLE_ID, STATUS");
        TryIndex(conn, "IDX_SP_DRAFT_TABLE", "SP_POS_DRAFT_LINE", "TABLE_ID");
        TryIndex(conn, "IDX_SP_OPERATOR_ACTIVE_PIN", "SP_POS_OPERATOR", "ACTIVE, PASSWORD_PIN");
    }

    private static void TryIndex(FbConnection conn, string indexName, string table, string columns)
    {
        if (!TableExists(conn, table) || IndexExists(conn, indexName))
            return;
        try
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = $"CREATE INDEX {indexName} ON {table} ({columns})";
            cmd.ExecuteNonQuery();
        }
        catch
        {
            /* există sau tip incompatibil */
        }
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static bool IndexExists(FbConnection conn, string indexName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$INDICES
WHERE TRIM(RDB$INDEX_NAME) = @N ROWS 1";
        cmd.Parameters.AddWithValue("@N", indexName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

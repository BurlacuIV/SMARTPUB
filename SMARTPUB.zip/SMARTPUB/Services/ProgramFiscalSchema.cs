using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

public static class ProgramFiscalSchema
{
    public static void EnsureSchema(FbConnection conn)
    {
        if (!TableExists(conn, "SP_PROGRAM_FISCAL"))
        {
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
CREATE TABLE SP_PROGRAM_FISCAL (
    ID INTEGER NOT NULL,
    MODEL VARCHAR(120),
    DRIVER VARCHAR(80),
    MONITOR_FOLDER VARCHAR(260),
    TRIMITE_CARD_POS SMALLINT DEFAULT 0,
    AFIS_OP_BON SMALLINT DEFAULT 0,
    AFIS_NR_COM_BON SMALLINT DEFAULT 0,
    AFIS_DEN_ART_BON SMALLINT DEFAULT 0,
    TEXT_PUBLICITAR VARCHAR(1024),
    CREATED_AT TIMESTAMP,
    UPDATED_AT TIMESTAMP,
    PRIMARY KEY (ID)
)";
                cmd.ExecuteNonQuery();
            }

            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
INSERT INTO SP_PROGRAM_FISCAL (
    ID, MODEL, DRIVER, CREATED_AT, UPDATED_AT
) VALUES (
    1,
    'ACTIVA (Activa, Total, Zeka, Tremol)',
    'FiscalNet',
    CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
)";
                cmd.ExecuteNonQuery();
            }
        }

        if (!TableExists(conn, "SP_FISCAL_IDX_PLATA"))
        {
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
CREATE TABLE SP_FISCAL_IDX_PLATA (
    METHOD_KEY VARCHAR(24) NOT NULL PRIMARY KEY,
    INDICE INTEGER DEFAULT 0,
    UPDATED_AT TIMESTAMP
)";
                cmd.ExecuteNonQuery();
            }
        }

        if (!TableExists(conn, "SP_FISCAL_IDX_TVA"))
        {
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
CREATE TABLE SP_FISCAL_IDX_TVA (
    TVA_PCT DECIMAL(5,2) NOT NULL PRIMARY KEY,
    INDICE INTEGER DEFAULT 0,
    UPDATED_AT TIMESTAMP
)";
                cmd.ExecuteNonQuery();
            }
        }

        SeedPlata(conn);
        SeedTva(conn);
    }

    private static void SeedPlata(FbConnection conn)
    {
        var seeds = new (string Key, int Idx)[]
        {
            ("NUMERAR", 0), ("BONURI", 1), ("CARD", 3), ("CEC", 4), ("METODE_MODERNE", 5)
        };
        foreach (var (key, idx) in seeds)
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
INSERT INTO SP_FISCAL_IDX_PLATA (METHOD_KEY, INDICE, UPDATED_AT)
SELECT @K, @I, CURRENT_TIMESTAMP FROM RDB$DATABASE
WHERE NOT EXISTS (SELECT 1 FROM SP_FISCAL_IDX_PLATA P WHERE P.METHOD_KEY = @K)";
            cmd.Parameters.AddWithValue("@K", key);
            cmd.Parameters.AddWithValue("@I", idx);
            cmd.ExecuteNonQuery();
        }
    }

    private static void SeedTva(FbConnection conn)
    {
        var seeds = new (decimal Pct, int Idx)[] { (0m, 0), (11m, 2), (21m, 3) };
        foreach (var (pct, idx) in seeds)
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
INSERT INTO SP_FISCAL_IDX_TVA (TVA_PCT, INDICE, UPDATED_AT)
SELECT @P, @I, CURRENT_TIMESTAMP FROM RDB$DATABASE
WHERE NOT EXISTS (SELECT 1 FROM SP_FISCAL_IDX_TVA T WHERE T.TVA_PCT = @P)";
            cmd.Parameters.AddWithValue("@P", pct);
            cmd.Parameters.AddWithValue("@I", idx);
            cmd.ExecuteNonQuery();
        }
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

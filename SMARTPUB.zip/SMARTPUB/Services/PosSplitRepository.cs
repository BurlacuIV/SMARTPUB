using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public static class PosSplitRepository
{
    public sealed record PersistedSession(int PersonCount, List<PersistedBill> Bills, List<PersistedAlloc> Allocs);

    public sealed record PersistedBill(int BillIndex, bool IsPaid, string? SaleId);

    public sealed record PersistedAlloc(
        int BillIndex,
        string PoolLineKey,
        WaiterSplitSourceKind Source,
        string ProductCode,
        string ProductName,
        decimal Qty,
        decimal UnitPrice,
        decimal TvaPct,
        string Notes);

    public static PersistedSession? Load(FbConnection conn, string tableId)
    {
        var tid = tableId.Trim();
        int personCount;
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = "SELECT PERSON_COUNT FROM SP_POS_SPLIT_SESSION WHERE TABLE_ID = @T";
            cmd.Parameters.AddWithValue("@T", tid);
            var x = cmd.ExecuteScalar();
            if (x == null || x == DBNull.Value) return null;
            personCount = Convert.ToInt32(x);
        }

        var bills = new List<PersistedBill>();
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
SELECT BILL_INDEX, IS_PAID, SALE_ID
FROM SP_POS_SPLIT_BILL
WHERE TABLE_ID = @T
ORDER BY BILL_INDEX";
            cmd.Parameters.AddWithValue("@T", tid);
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                bills.Add(new PersistedBill(
                    rd.GetInt32(0),
                    Convert.ToInt32(rd[1]) != 0,
                    rd[2] is DBNull ? null : rd[2]?.ToString()));
            }
        }

        var allocs = new List<PersistedAlloc>();
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
SELECT BILL_INDEX, LINE_KEY, SOURCE_KIND, PRODUCT_CODE, PRODUCT_NAME, QTY, UNIT_PRICE, TVA_PCT, NOTES
FROM SP_POS_SPLIT_ALLOC
WHERE TABLE_ID = @T
ORDER BY BILL_INDEX, LINE_KEY";
            cmd.Parameters.AddWithValue("@T", tid);
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var kind = string.Equals(rd[2]?.ToString(), "SENT", StringComparison.OrdinalIgnoreCase)
                    ? WaiterSplitSourceKind.Sent
                    : WaiterSplitSourceKind.Draft;
                allocs.Add(new PersistedAlloc(
                    rd.GetInt32(0),
                    rd[1]?.ToString() ?? "",
                    kind,
                    rd[3]?.ToString() ?? "",
                    rd[4]?.ToString() ?? "",
                    Convert.ToDecimal(rd[5]),
                    Convert.ToDecimal(rd[6]),
                    rd[7] is DBNull ? 0 : Convert.ToDecimal(rd[7]),
                    rd[8]?.ToString() ?? ""));
            }
        }

        return new PersistedSession(personCount, bills, allocs);
    }

    public static void Save(
        FbConnection conn,
        string tableId,
        int personCount,
        IReadOnlyList<WaiterSplitBill> bills,
        IReadOnlyList<WaiterSplitPoolLine> pool)
    {
        var tid = tableId.Trim();
        using var tx = conn.BeginTransaction();
        try
        {
            using (var delA = conn.CreateCommand())
            {
                delA.Transaction = tx;
                delA.CommandText = "DELETE FROM SP_POS_SPLIT_ALLOC WHERE TABLE_ID = @T";
                delA.Parameters.AddWithValue("@T", tid);
                delA.ExecuteNonQuery();
            }

            using (var delB = conn.CreateCommand())
            {
                delB.Transaction = tx;
                delB.CommandText = "DELETE FROM SP_POS_SPLIT_BILL WHERE TABLE_ID = @T";
                delB.Parameters.AddWithValue("@T", tid);
                delB.ExecuteNonQuery();
            }

            using (var delS = conn.CreateCommand())
            {
                delS.Transaction = tx;
                delS.CommandText = "DELETE FROM SP_POS_SPLIT_SESSION WHERE TABLE_ID = @T";
                delS.Parameters.AddWithValue("@T", tid);
                delS.ExecuteNonQuery();
            }

            using (var insS = conn.CreateCommand())
            {
                insS.Transaction = tx;
                insS.CommandText = @"
INSERT INTO SP_POS_SPLIT_SESSION (TABLE_ID, PERSON_COUNT, UPDATED_AT)
VALUES (@T, @P, CURRENT_TIMESTAMP)";
                insS.Parameters.AddWithValue("@T", tid);
                insS.Parameters.AddWithValue("@P", personCount);
                insS.ExecuteNonQuery();
            }

            foreach (var bill in bills)
            {
                using var insB = conn.CreateCommand();
                insB.Transaction = tx;
                insB.CommandText = @"
INSERT INTO SP_POS_SPLIT_BILL (TABLE_ID, BILL_INDEX, IS_PAID, SALE_ID, UPDATED_AT)
VALUES (@T, @I, @P, @S, CURRENT_TIMESTAMP)";
                insB.Parameters.AddWithValue("@T", tid);
                insB.Parameters.AddWithValue("@I", bill.BillIndex);
                insB.Parameters.AddWithValue("@P", bill.IsPaid ? 1 : 0);
                insB.Parameters.AddWithValue("@S", string.IsNullOrWhiteSpace(bill.SaleId) ? DBNull.Value : bill.SaleId);
                insB.ExecuteNonQuery();

                foreach (var ln in bill.Lines)
                {
                    using var insA = conn.CreateCommand();
                    insA.Transaction = tx;
                    insA.CommandText = @"
INSERT INTO SP_POS_SPLIT_ALLOC (
  TABLE_ID, BILL_INDEX, LINE_KEY, SOURCE_KIND, PRODUCT_CODE, PRODUCT_NAME,
  QTY, UNIT_PRICE, TVA_PCT, NOTES, UPDATED_AT
) VALUES (
  @T, @B, @K, @SK, @PC, @PN, @Q, @UP, @TV, @N, CURRENT_TIMESTAMP
)";
                    insA.Parameters.AddWithValue("@T", tid);
                    insA.Parameters.AddWithValue("@B", bill.BillIndex);
                    insA.Parameters.AddWithValue("@K", ln.PoolLineKey);
                    insA.Parameters.AddWithValue("@SK", ln.Source == WaiterSplitSourceKind.Sent ? "SENT" : "DRAFT");
                    insA.Parameters.AddWithValue("@PC", ln.ProductCode);
                    insA.Parameters.AddWithValue("@PN", ln.ProductName);
                    insA.Parameters.AddWithValue("@Q", ln.Qty);
                    insA.Parameters.AddWithValue("@UP", ln.UnitPrice);
                    insA.Parameters.AddWithValue("@TV", ln.TvaPct);
                    insA.Parameters.AddWithValue("@N", string.IsNullOrWhiteSpace(ln.Notes) ? DBNull.Value : ln.Notes);
                    insA.ExecuteNonQuery();
                }
            }

            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    public static void Clear(FbConnection conn, string tableId)
    {
        var tid = tableId.Trim();
        using var tx = conn.BeginTransaction();
        try
        {
            foreach (var sql in new[]
            {
                "DELETE FROM SP_POS_SPLIT_ALLOC WHERE TABLE_ID = @T",
                "DELETE FROM SP_POS_SPLIT_BILL WHERE TABLE_ID = @T",
                "DELETE FROM SP_POS_SPLIT_SESSION WHERE TABLE_ID = @T"
            })
            {
                using var cmd = conn.CreateCommand();
                cmd.Transaction = tx;
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@T", tid);
                cmd.ExecuteNonQuery();
            }

            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }
}

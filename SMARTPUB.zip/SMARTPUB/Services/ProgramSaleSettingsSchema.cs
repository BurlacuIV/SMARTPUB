using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

public static class ProgramSaleSettingsSchema
{
    public static void EnsureSchema(FbConnection conn)
    {
        if (TableExists(conn, "SP_PROGRAM_SALE_SETTINGS"))
            return;

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
CREATE TABLE SP_PROGRAM_SALE_SETTINGS (
    ID INTEGER NOT NULL,
    ULTIMA_GESTIUNE_ART SMALLINT DEFAULT 1,
    VINDE_LA_SELECT SMALLINT DEFAULT 1,
    CUMUL_VANZARE SMALLINT DEFAULT 1,
    CUMUL_NOTA SMALLINT DEFAULT 0,
    CUMUL_BON_FISCAL SMALLINT DEFAULT 0,
    ARATA_STOC_NEG SMALLINT DEFAULT 1,
    ALLOW_NEG_STOC SMALLINT DEFAULT 1,
    INCASA_FARA_CF SMALLINT DEFAULT 0,
    ARATA_BTN_CF SMALLINT DEFAULT 0,
    TIP_AUTO_CF SMALLINT DEFAULT 1,
    IESIRE_DUPA_VAL SMALLINT DEFAULT 1,
    INCHIDE_BON_AUTO SMALLINT DEFAULT 0,
    TIP_AUTO_NOTA SMALLINT DEFAULT 1,
    TIP_AUTO_BON_INC SMALLINT DEFAULT 0,
    IESIRE_DUPA_TIP_BF SMALLINT DEFAULT 0,
    ARATA_GEST_BTN SMALLINT DEFAULT 0,
    ARATA_PRET_BTN SMALLINT DEFAULT 0,
    SUNET_MONITOR SMALLINT DEFAULT 0,
    GEST_IMPLICIT_GRUP SMALLINT DEFAULT 1,
    INCASARE_RAPIDA SMALLINT DEFAULT 0,
    TAST_VIRTUALA SMALLINT DEFAULT 1,
    VIEW_ART_MODE VARCHAR(16) DEFAULT 'Buttons',
    SORT_ART_MODE VARCHAR(24) DEFAULT 'SalesOrder',
    PRINT_CF_MODE VARCHAR(16) DEFAULT 'Gestiune',
    PLAFON_VANZARE DECIMAL(15,2) DEFAULT 0,
    CREATED_AT TIMESTAMP,
    UPDATED_AT TIMESTAMP,
    PRIMARY KEY (ID)
)";
            cmd.ExecuteNonQuery();
        }

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
INSERT INTO SP_PROGRAM_SALE_SETTINGS (
    ID,
    ULTIMA_GESTIUNE_ART, VINDE_LA_SELECT, CUMUL_VANZARE, CUMUL_NOTA, CUMUL_BON_FISCAL,
    ARATA_STOC_NEG, ALLOW_NEG_STOC, INCASA_FARA_CF, ARATA_BTN_CF, TIP_AUTO_CF,
    IESIRE_DUPA_VAL, INCHIDE_BON_AUTO, TIP_AUTO_NOTA, TIP_AUTO_BON_INC, IESIRE_DUPA_TIP_BF,
    ARATA_GEST_BTN, ARATA_PRET_BTN, SUNET_MONITOR, GEST_IMPLICIT_GRUP, INCASARE_RAPIDA, TAST_VIRTUALA,
    VIEW_ART_MODE, SORT_ART_MODE, PRINT_CF_MODE, PLAFON_VANZARE,
    CREATED_AT, UPDATED_AT
) VALUES (
    1,
    1, 1, 1, 0, 0,
    1, 1, 0, 0, 1,
    1, 0, 1, 0, 0,
    0, 0, 0, 1, 0, 1,
    'Buttons', 'SalesOrder', 'Gestiune', 0,
    CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
)";
            cmd.ExecuteNonQuery();
        }
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1
FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0
  AND TRIM(RDB$RELATION_NAME) = @T
ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

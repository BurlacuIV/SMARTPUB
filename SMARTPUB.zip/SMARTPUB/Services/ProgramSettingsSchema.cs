using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

public static class ProgramSettingsSchema
{
    public static void EnsureSchema(FbConnection conn)
    {
        if (!TableExists(conn, "SP_PROGRAM_SETTINGS"))
        {
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
CREATE TABLE SP_PROGRAM_SETTINGS (
    ID INTEGER NOT NULL,
    SAGA_CONN_MODE VARCHAR(20) DEFAULT 'Standard',
    SAGA_SERVER_IP VARCHAR(64),
    SAGA_SERVER_DB_FOLDER VARCHAR(260),
    PRINTER_FIRM_ORDER VARCHAR(260),
    PRINTER_BILL VARCHAR(260),
    PRINTER_INVOICE VARCHAR(260),
    SINGLE_INSTANCE SMALLINT DEFAULT 1,
    START_FULLSCREEN SMALLINT DEFAULT 1,
    CHECK_UPDATES_START SMALLINT DEFAULT 0,
    AUTO_SYNC_NOMENCLATURE SMALLINT DEFAULT 0,
    AUTO_LOGOUT_SEC INTEGER DEFAULT -1,
    HOTEL_MODE SMALLINT DEFAULT 0,
    CREATED_AT TIMESTAMP,
    UPDATED_AT TIMESTAMP,
    PRIMARY KEY (ID)
)";
                cmd.ExecuteNonQuery();
            }

            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
INSERT INTO SP_PROGRAM_SETTINGS (
    ID, SAGA_CONN_MODE, SINGLE_INSTANCE, START_FULLSCREEN,
    CHECK_UPDATES_START, AUTO_SYNC_NOMENCLATURE, AUTO_LOGOUT_SEC, HOTEL_MODE,
    CREATED_AT, UPDATED_AT
)
VALUES (
    1, 'Standard', 1, 1,
    0, 0, -1, 0,
    CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
)";
                cmd.ExecuteNonQuery();
            }
        }

        // Imprimante rutare comandă (baze existente — adăugate prin ALTER).
        TryAddColumn(conn, "SP_PROGRAM_SETTINGS", "PRINTER_BAR", "VARCHAR(260)");
        TryAddColumn(conn, "SP_PROGRAM_SETTINGS", "PRINTER_KITCHEN", "VARCHAR(260)");
    }

    private static bool ColumnExists(FbConnection conn, string table, string column)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATION_FIELDS
WHERE TRIM(RDB$RELATION_NAME) = @T AND TRIM(RDB$FIELD_NAME) = @C ROWS 1";
        cmd.Parameters.AddWithValue("@T", table.Trim().ToUpperInvariant());
        cmd.Parameters.AddWithValue("@C", column.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static void TryAddColumn(FbConnection conn, string table, string column, string definition)
    {
        if (ColumnExists(conn, table, column))
            return;
        try
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = $"ALTER TABLE {table} ADD {column} {definition}";
            cmd.ExecuteNonQuery();
        }
        catch
        {
            /* coloana poate exista deja sau versiune Firebird diferită */
        }
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1
FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0
  AND TRIM(RDB$RELATION_NAME) = @T
ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

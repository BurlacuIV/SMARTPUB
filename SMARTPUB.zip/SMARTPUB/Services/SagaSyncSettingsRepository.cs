using System.IO;
using FirebirdSql.Data.FirebirdClient;
using SMARTPUB;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public sealed class SagaSyncSettingsRepository
{
    public SagaSyncSettingsData LoadData(FbConnection conn)
    {
        SagaSettingsSchema.EnsureSchema(conn);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT
  SAGA_ROOT_PATH,
  FBCLIENT_PATH,
  COMPANY_CODE,
  COMPANY_NAME,
  COMPANY_DB_PATH,
  TRIM(COALESCE(SAGA_CONN_MODE, 'EMBEDDED')),
  TRIM(COALESCE(SAGA_SERVER_HOST, '')),
  COALESCE(SAGA_SERVER_PORT, 3060),
  TRIM(COALESCE(SAGA_SERVER_ROOT, ''))
FROM SAGA_SYNC_SETTINGS
WHERE ID = 1";

        using var rd = cmd.ExecuteReader();
        if (!rd.Read())
            return new SagaSyncSettingsData();

        var sagaRoot = (rd["SAGA_ROOT_PATH"]?.ToString() ?? "").Trim();
        var fb = (rd["FBCLIENT_PATH"]?.ToString() ?? "").Trim();
        var code = (rd["COMPANY_CODE"]?.ToString() ?? "").Trim();
        var name = (rd["COMPANY_NAME"]?.ToString() ?? "").Trim();
        var db = (rd["COMPANY_DB_PATH"]?.ToString() ?? "").Trim();
        var modeStr = (rd[5]?.ToString() ?? "EMBEDDED").Trim();
        var host = (rd[6]?.ToString() ?? "").Trim();
        var port = rd[7] == null || rd[7] == DBNull.Value ? SagaConnectionDefaults.FirebirdServerPort : Convert.ToInt32(rd[7]);
        var serverRoot = (rd[8]?.ToString() ?? "").Trim();

        SagaCompany? company = null;
        if (!string.IsNullOrWhiteSpace(db) || !string.IsNullOrWhiteSpace(code) || !string.IsNullOrWhiteSpace(name))
        {
            company = new SagaCompany
            {
                Code = code,
                Name = name,
                DatabasePath = db,
                IsBlocked = false
            };
        }

        var mode = modeStr.Equals("SERVER", StringComparison.OrdinalIgnoreCase)
            ? SagaConnectionMode.Server
            : SagaConnectionMode.Embedded;

        return new SagaSyncSettingsData
        {
            ConnectionMode = mode,
            SagaRootPath = sagaRoot,
            FbClientPath = string.IsNullOrWhiteSpace(fb) ? null : fb,
            Company = company,
            ServerHost = string.IsNullOrWhiteSpace(host) ? null : host,
            ServerPort = port <= 0 ? SagaConnectionDefaults.FirebirdServerPort : port,
            ServerSagaRoot = string.IsNullOrWhiteSpace(serverRoot) ? null : serverRoot
        };
    }

    /// <summary>Compatibilitate: încarcă tuple vechi.</summary>
    public (string SagaRootPath, string? FbClientPath, SagaCompany? Company) Load(FbConnection conn)
    {
        var d = LoadData(conn);
        return (d.SagaRootPath, d.FbClientPath, d.Company);
    }

    public void Save(FbConnection conn, string sagaRootPath, string fbClientPath, SagaCompany? company)
    {
        var data = LoadData(conn);
        data.SagaRootPath = sagaRootPath ?? "";
        data.FbClientPath = string.IsNullOrWhiteSpace(fbClientPath) ? null : fbClientPath.Trim();
        data.Company = company;
        Save(conn, data);
    }

    public void Save(FbConnection conn, SagaSyncSettingsData data)
    {
        SagaSettingsSchema.EnsureSchema(conn);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
UPDATE OR INSERT INTO SAGA_SYNC_SETTINGS (
  ID,
  SAGA_ROOT_PATH,
  FBCLIENT_PATH,
  CONFIG_DB_PATH,
  COMPANY_CODE,
  COMPANY_NAME,
  COMPANY_DB_PATH,
  SAGA_CONN_MODE,
  SAGA_SERVER_HOST,
  SAGA_SERVER_PORT,
  SAGA_SERVER_ROOT,
  UPDATED_AT
)
VALUES (
  1,
  @SAGA_ROOT_PATH,
  @FBCLIENT_PATH,
  @CONFIG_DB_PATH,
  @COMPANY_CODE,
  @COMPANY_NAME,
  @COMPANY_DB_PATH,
  @SAGA_CONN_MODE,
  @SAGA_SERVER_HOST,
  @SAGA_SERVER_PORT,
  @SAGA_SERVER_ROOT,
  CURRENT_TIMESTAMP
)
MATCHING (ID)";

        var sagaRoot = data.SagaRootPath?.Trim() ?? "";
        cmd.Parameters.AddWithValue("@SAGA_ROOT_PATH", string.IsNullOrWhiteSpace(sagaRoot) ? DBNull.Value : sagaRoot);
        cmd.Parameters.AddWithValue("@FBCLIENT_PATH",
            string.IsNullOrWhiteSpace(data.FbClientPath) ? DBNull.Value : data.FbClientPath.Trim());

        var configDb = string.IsNullOrWhiteSpace(sagaRoot) ? null : Path.Combine(sagaRoot, "CONFIG.FDB");
        cmd.Parameters.AddWithValue("@CONFIG_DB_PATH", string.IsNullOrWhiteSpace(configDb) ? DBNull.Value : configDb);

        var company = data.Company;
        cmd.Parameters.AddWithValue("@COMPANY_CODE", company == null || string.IsNullOrWhiteSpace(company.Code) ? DBNull.Value : company.Code);
        cmd.Parameters.AddWithValue("@COMPANY_NAME", company == null || string.IsNullOrWhiteSpace(company.Name) ? DBNull.Value : company.Name);
        cmd.Parameters.AddWithValue("@COMPANY_DB_PATH", company == null || string.IsNullOrWhiteSpace(company.DatabasePath) ? DBNull.Value : company.DatabasePath);

        cmd.Parameters.AddWithValue("@SAGA_CONN_MODE",
            data.ConnectionMode == SagaConnectionMode.Server ? "SERVER" : "EMBEDDED");
        cmd.Parameters.AddWithValue("@SAGA_SERVER_HOST",
            string.IsNullOrWhiteSpace(data.ServerHost) ? DBNull.Value : data.ServerHost.Trim());
        cmd.Parameters.AddWithValue("@SAGA_SERVER_PORT", data.ServerPort <= 0 ? SagaConnectionDefaults.FirebirdServerPort : data.ServerPort);
        cmd.Parameters.AddWithValue("@SAGA_SERVER_ROOT",
            string.IsNullOrWhiteSpace(data.ServerSagaRoot) ? DBNull.Value : data.ServerSagaRoot.Trim());

        cmd.ExecuteNonQuery();
    }
}

using System.Collections.ObjectModel;
using System.ComponentModel;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

/// <summary>Coșuri de lucru per masă; persistă în SP_POS_DRAFT_LINE (SMARTPUB.FDB).</summary>
public sealed class WaiterDraftOrderStore
{
    public static WaiterDraftOrderStore Instance { get; } = new();

    private readonly Dictionary<string, ObservableCollection<WaiterCartLine>> _carts =
        new(StringComparer.OrdinalIgnoreCase);

    private readonly object _gate = new();

    private WaiterDraftOrderStore()
    {
    }

    public ObservableCollection<WaiterCartLine> GetCart(string tableId)
    {
        if (string.IsNullOrWhiteSpace(tableId))
            return new ObservableCollection<WaiterCartLine>();

        lock (_gate)
        {
            if (!_carts.TryGetValue(tableId, out var cart))
            {
                cart = new ObservableCollection<WaiterCartLine>();
                try
                {
                    using var conn = SmartPubDb.OpenEmbedded();
                    PosOperationalSchema.EnsureSchema(conn);
                    foreach (var ln in PosDraftOrderRepository.LoadLines(conn, tableId))
                        cart.Add(ln);
                }
                catch
                {
                    /* rămâne gol */
                }

                HookCart(tableId, cart);
                _carts[tableId] = cart;
            }

            return cart;
        }
    }

    private void HookCart(string tableId, ObservableCollection<WaiterCartLine> cart)
    {
        cart.CollectionChanged += (_, e) =>
        {
            if (e.NewItems != null)
            {
                foreach (WaiterCartLine l in e.NewItems)
                    l.PropertyChanged += LinePropertyChanged;
            }

            if (e.OldItems != null)
            {
                foreach (WaiterCartLine l in e.OldItems)
                    l.PropertyChanged -= LinePropertyChanged;
            }

            Persist(tableId, cart);
        };

        foreach (var l in cart)
            l.PropertyChanged += LinePropertyChanged;

        void LinePropertyChanged(object? sender, PropertyChangedEventArgs _) =>
            Persist(tableId, cart);
    }

    private void Persist(string tableId, ObservableCollection<WaiterCartLine> cart)
    {
        List<WaiterCartLine> copy;
        lock (_gate)
            copy = cart.ToList();

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            PosOperationalSchema.EnsureSchema(conn);
            PosDraftOrderRepository.ReplaceAll(conn, tableId, copy);
        }
        catch
        {
            /* nu blocăm UI */
        }
    }

    public bool HasLines(string tableId)
    {
        if (string.IsNullOrWhiteSpace(tableId))
            return false;

        lock (_gate)
        {
            if (_carts.TryGetValue(tableId, out var c) && c.Count > 0)
                return true;
        }

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            PosOperationalSchema.EnsureSchema(conn);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM SP_POS_DRAFT_LINE WHERE TABLE_ID = @T";
            cmd.Parameters.AddWithValue("@T", tableId.Trim());
            return Convert.ToInt32(cmd.ExecuteScalar() ?? 0) > 0;
        }
        catch
        {
            return false;
        }
    }

    public void Clear(string tableId)
    {
        if (string.IsNullOrWhiteSpace(tableId))
            return;

        lock (_gate)
        {
            if (_carts.TryGetValue(tableId, out var c))
            {
                c.Clear();
                return;
            }
        }

        try
        {
            using var conn = SmartPubDb.OpenEmbedded();
            PosOperationalSchema.EnsureSchema(conn);
            PosDraftOrderRepository.Clear(conn, tableId);
        }
        catch
        {
            /* ignore */
        }
    }
}

using System.IO;

namespace SMARTPUB.Services;

/// <summary>Citește versiunea ODS din prima pagină a unui fișier .fdb.</summary>
public static class FirebirdOdsHelper
{
    /// <summary>ODS 13.x = Firebird 4; ODS 12.x = Firebird 3.</summary>
    public const int OdsMajorFirebird4 = 13;

    public static bool TryReadOdsVersion(string dbPath, out int major, out int minor)
    {
        major = 0;
        minor = 0;
        if (string.IsNullOrWhiteSpace(dbPath) || !File.Exists(dbPath))
            return false;

        try
        {
            using var fs = new FileStream(dbPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            Span<byte> hdr = stackalloc byte[19];
            if (fs.Read(hdr) < 19)
                return false;

            major = hdr[17];
            minor = hdr[18];
            return major > 0;
        }
        catch
        {
            return false;
        }
    }

    public static bool RequiresFirebird4OrNewer(int odsMajor) => odsMajor >= OdsMajorFirebird4;
}

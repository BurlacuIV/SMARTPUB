using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace SMARTPUB.Services;

public static class FirebirdClientLocator
{
    private static readonly string[] ModernCandidates =
    {
        // Prefer newer clients (Firebird ADO.NET v10 may require newer exports)
        @"C:\Program Files\Firebird\Firebird_5_0\fbclient.dll",
        @"C:\Program Files\Firebird\Firebird_4_0\fbclient.dll",
        @"C:\Program Files\Firebird\Firebird_4_0_x64\fbclient.dll",
        @"C:\Program Files\Firebird\Firebird_4_0\bin\fbclient.dll",
        @"C:\Program Files\Firebird\Firebird_4_0_x64\bin\fbclient.dll"
    };

    private static readonly string[] LegacyV3Candidates =
    {
        @"C:\Program Files\Firebird\Firebird30_Saga\fbclient.dll",
        @"C:\Program Files (x86)\Firebird\Firebird30_Saga\fbclient.dll",
        @"C:\PubLine\FbClient\fbclient.dll",
        @"C:\Program Files\Firebird\Firebird_3_0\fbclient.dll",
        @"C:\Program Files\Firebird\Firebird_3_0\bin\fbclient.dll"
    };

    public static IReadOnlyList<string> GetExistingCandidates(bool includeLegacyV3 = false)
    {
        var candidates = new List<string>();

        candidates.AddRange(ModernCandidates);
        candidates.AddRange(DiscoverUnderProgramFilesFirebird());
        if (includeLegacyV3)
            candidates.AddRange(LegacyV3Candidates);

        return candidates
            .Where(File.Exists)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    /// <summary>Clienți potriviți pentru un .fdb: ODS 13+ doar FB4/5, nu Firebird30_Saga.</summary>
    public static IReadOnlyList<string> GetCandidatesForDatabase(string dbPath)
    {
        var includeLegacy = true;
        if (FirebirdOdsHelper.TryReadOdsVersion(dbPath, out var odsMajor, out _))
            includeLegacy = !FirebirdOdsHelper.RequiresFirebird4OrNewer(odsMajor);

        return GetExistingCandidates(includeLegacyV3: includeLegacy);
    }

    static IEnumerable<string> DiscoverUnderProgramFilesFirebird()
    {
        const string root = @"C:\Program Files\Firebird";
        if (!Directory.Exists(root))
            yield break;

        IEnumerable<string> paths;
        try
        {
            paths = Directory.EnumerateFiles(root, "fbclient.dll", SearchOption.AllDirectories);
        }
        catch
        {
            yield break;
        }

        foreach (var path in paths.OrderBy(ScoreClientPath))
            yield return path;
    }

    static int ScoreClientPath(string path)
    {
        var p = path.ToUpperInvariant();
        if (p.Contains("FIREBIRD_5")) return 0;
        if (p.Contains("FIREBIRD_4")) return 1;
        if (p.Contains("FIREBIRD30") || p.Contains("FIREBIRD_3")) return 9;
        return 5;
    }

    /// <summary>
    /// Ordine de probă pentru baze SAGA (ODS 12 / Firebird 3): mai întâi clienți FB3 (ex. Firebird30_Saga), apoi FB4/5.
    /// </summary>
    public static IReadOnlyList<string> GetSagaEmbeddedProbeOrder()
    {
        var legacy = LegacyV3Candidates.Where(File.Exists);
        var modern = ModernCandidates.Where(File.Exists);
        return legacy
            .Concat(modern)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    public static string GetFbClientPath()
    {
        foreach (var p in GetExistingCandidates(includeLegacyV3: false))
        {
            if (File.Exists(p))
                return p;
        }

        throw new FileNotFoundException(
            "fbclient.dll nu a fost găsit.\n" +
            "Instalează Firebird 4/5 x64 (client library). Firebird 3 nu este compatibil cu providerul curent.",
            ModernCandidates[0]);
    }
}

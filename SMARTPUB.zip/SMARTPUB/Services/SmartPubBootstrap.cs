using System.IO;
using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

/// <summary>Inițializare schemă SMARTPUB.FDB la pornire (fără dependență PubLine).</summary>
public static class SmartPubBootstrap
{
    private static int _schemaApplied;

    public static void EnsureDatabase()
    {
        if (!File.Exists(SmartPubDb.DefaultDbPath))
            throw new FileNotFoundException(
                $"Lipsește baza de date SMARTPUB. Creați sau copiați SMARTPUB.FDB la:\n{SmartPubDb.DefaultDbPath}",
                SmartPubDb.DefaultDbPath);

        using var conn = SmartPubDb.OpenEmbedded();
        ApplySchema(conn);
    }

    /// <summary>Folosit și după operații care necesită tabele noi pe conexiune deschisă.</summary>
    public static void ApplySchema(FbConnection conn)
    {
        if (Interlocked.Exchange(ref _schemaApplied, 1) == 1)
            return;

        ApplySchemaCore(conn);
    }

    /// <summary>Forțează migrări (salvare setări, versiuni noi).</summary>
    public static void ApplySchemaForce(FbConnection conn) => ApplySchemaCore(conn);

    private static void ApplySchemaCore(FbConnection conn)
    {
        SagaSettingsSchema.EnsureSchema(conn);
        ProgramSettingsSchema.EnsureSchema(conn);
        ProgramSaleSettingsSchema.EnsureSchema(conn);
        ProgramDisplaySettingsSchema.EnsureSchema(conn);
        ProgramTransferDocSchema.EnsureSchema(conn);
        ProgramFiscalSchema.EnsureSchema(conn);
        ProgramNetworkSchema.EnsureSchema(conn);
        new SagaSyncImportService().EnsureSchema(conn);
        FloorPlanSchema.EnsureSchema(conn);
        BomLocalSchema.EnsureSchema(conn);
        PosOperationalSchema.EnsureSchema(conn);
        new PosGestiunePrinterRepository().EnsureSchema(conn);
        new PosProductGestiuneRepository().EnsureSchema(conn);
        PosOperationalSchema.TryImportLegacyKitchenJson(conn);
        PosOperatorRepository.EnsureSeed(conn);
        PosOperatorRepository.RepairMissingRights(conn);
        SmartPubSchemaIndexes.EnsurePerformanceIndexes(conn);
    }
}

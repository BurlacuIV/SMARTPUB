using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public static class PosOperatorRepository
{
    /// <summary>PIN temporar pentru primul login admin când nu există PIN configurat pe administrator.</summary>
    public const string BootstrapAdministratorPin = "0000";

    public static void EnsureSeed(FbConnection conn)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM SP_POS_OPERATOR";
        var n = Convert.ToInt32(cmd.ExecuteScalar() ?? 0);
        if (n > 0)
            return;

        var id = Guid.NewGuid().ToString("N");
        using var ins = conn.CreateCommand();
        ins.CommandText = @"
INSERT INTO SP_POS_OPERATOR (ID, USERNAME, DISPLAY_NAME, PASSWORD_PIN, ROLE, ACTIVE, ACCES_ALL_TABLES, UPDATED_AT)
VALUES (@ID, 'admin', 'Administrator', @P, 'Administrator', 1, 1, CURRENT_TIMESTAMP)";
        ins.Parameters.AddWithValue("@ID", id);
        ins.Parameters.AddWithValue("@P", BootstrapAdministratorPin);
        ins.ExecuteNonQuery();
        ReplaceRights(conn, id, PosOperatorRightsCatalog.DefaultAdministratorRights());
    }

    /// <summary>Administrator activ fără PIN în DB — setează PIN bootstrap ca login-ul normal să funcționeze.</summary>
    public static void EnsureAdministratorBootstrapPin(FbConnection conn)
    {
        if (AnyAdministratorHasConfiguredPin(conn))
            return;
        if (IsPinUsedByOther(conn, BootstrapAdministratorPin, null))
            return;

        var admin = ListActive(conn).FirstOrDefault(x => IsAdministratorRole(x.Role));
        if (admin == null || string.IsNullOrWhiteSpace(admin.Id))
            return;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
UPDATE SP_POS_OPERATOR
SET PASSWORD_PIN = @P, UPDATED_AT = CURRENT_TIMESTAMP
WHERE TRIM(ID) = TRIM(@I)
  AND (PASSWORD_PIN IS NULL OR TRIM(PASSWORD_PIN) = '')";
        cmd.Parameters.AddWithValue("@P", BootstrapAdministratorPin);
        cmd.Parameters.AddWithValue("@I", admin.Id.Trim());
        cmd.ExecuteNonQuery();
    }

    public static bool AnyAdministratorHasConfiguredPin(FbConnection conn)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT FIRST 1 1
FROM SP_POS_OPERATOR
WHERE ACTIVE = 1
  AND UPPER(TRIM(ROLE)) = 'ADMINISTRATOR'
  AND PASSWORD_PIN IS NOT NULL
  AND TRIM(PASSWORD_PIN) <> ''";
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    /// <summary>Login de urgență: 0000 → primul administrator activ, dacă administratorul nu are încă PIN propriu.</summary>
    public static PosOperatorRow? TryBootstrapAdministratorLogin(FbConnection conn, string? pinEntered)
    {
        if (!string.Equals((pinEntered ?? "").Trim(), BootstrapAdministratorPin, StringComparison.Ordinal))
            return null;
        if (AnyAdministratorHasConfiguredPin(conn))
            return null;

        return ListActive(conn).FirstOrDefault(x => IsAdministratorRole(x.Role));
    }

    /// <summary>După migrări: operatori fără rânduri în SP_POS_OPERATOR_RIGHT primesc set implicit după rol.</summary>
    public static void RepairMissingRights(FbConnection conn)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT ID, ROLE FROM SP_POS_OPERATOR";
        var rows = new List<(string Id, string Role)>();
        using (var rd = cmd.ExecuteReader())
        {
            while (rd.Read())
                rows.Add(((rd["ID"]?.ToString() ?? "").Trim(), (rd["ROLE"]?.ToString() ?? "").Trim()));
        }

        foreach (var (id, role) in rows)
        {
            if (string.IsNullOrEmpty(id))
                continue;
            using var c = conn.CreateCommand();
            c.CommandText = "SELECT COUNT(*) FROM SP_POS_OPERATOR_RIGHT WHERE OPERATOR_ID = @I";
            c.Parameters.AddWithValue("@I", id);
            var cnt = Convert.ToInt32(c.ExecuteScalar() ?? 0);
            if (cnt > 0)
                continue;

            var set = IsAdministratorRole(role)
                ? PosOperatorRightsCatalog.DefaultAdministratorRights()
                : PosOperatorRightsCatalog.DefaultWaiterRights();
            ReplaceRights(conn, id, set);
        }
    }

    public static bool IsAdministratorRole(string? role) =>
        string.Equals(role?.Trim(), "Administrator", StringComparison.OrdinalIgnoreCase);

    public static bool IsShiftLeadRole(string? role) =>
        string.Equals(role?.Trim(), "ShiftLead", StringComparison.OrdinalIgnoreCase);

    public static bool HasAnyActivePin(FbConnection conn)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT FIRST 1 1
FROM SP_POS_OPERATOR
WHERE ACTIVE = 1
  AND PASSWORD_PIN IS NOT NULL
  AND TRIM(PASSWORD_PIN) <> ''";
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    public static PosOperatorRow? FindActiveByPin(FbConnection conn, string? pinEntered, out string error)
    {
        error = "";
        var pin = (pinEntered ?? "").Trim();
        if (pin.Length == 0)
        {
            error = "Introduceți PIN-ul.";
            return null;
        }

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT ID, USERNAME, DISPLAY_NAME, PASSWORD_PIN, ROLE, ACTIVE, ACCES_ALL_TABLES,
       CNP, BULETIN, POLITIE, CARD_BARCODE
FROM SP_POS_OPERATOR
WHERE ACTIVE = 1
  AND PASSWORD_PIN IS NOT NULL
  AND TRIM(PASSWORD_PIN) = TRIM(@P)
ORDER BY DISPLAY_NAME";
        cmd.Parameters.AddWithValue("@P", pin);

        var rows = new List<PosOperatorRow>();
        using (var rd = cmd.ExecuteReader())
        {
            while (rd.Read())
                rows.Add(ReadRow(rd));
        }

        if (rows.Count == 1)
            return rows[0];

        if (rows.Count > 1)
            error = "PIN duplicat. Configurați PIN-uri unice pentru operatori.";
        else
            error = "PIN incorect.";
        return null;
    }

    public static bool IsPinUsedByOther(FbConnection conn, string? pin, string? operatorId)
    {
        var p = (pin ?? "").Trim();
        if (p.Length == 0)
            return false;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT FIRST 1 1
FROM SP_POS_OPERATOR
WHERE PASSWORD_PIN IS NOT NULL
  AND TRIM(PASSWORD_PIN) = TRIM(@P)
  AND (@I IS NULL OR TRIM(ID) <> TRIM(@I))";
        cmd.Parameters.AddWithValue("@P", p);
        cmd.Parameters.AddWithValue("@I", string.IsNullOrWhiteSpace(operatorId) ? DBNull.Value : operatorId.Trim());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    public static int CountActiveAdministrators(FbConnection conn, string? exceptOperatorId = null)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT COUNT(*)
FROM SP_POS_OPERATOR
WHERE ACTIVE = 1
  AND UPPER(TRIM(ROLE)) = 'ADMINISTRATOR'
  AND (@I IS NULL OR TRIM(ID) <> TRIM(@I))";
        cmd.Parameters.AddWithValue("@I", string.IsNullOrWhiteSpace(exceptOperatorId) ? DBNull.Value : exceptOperatorId.Trim());
        return Convert.ToInt32(cmd.ExecuteScalar() ?? 0);
    }

    public static bool IsAdministratorRole(FbConnection conn, string operatorId)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT ROLE FROM SP_POS_OPERATOR WHERE ID = @I";
        cmd.Parameters.AddWithValue("@I", operatorId.Trim());
        var r = cmd.ExecuteScalar()?.ToString();
        return IsAdministratorRole(r);
    }

    public static bool HasRight(FbConnection conn, string? operatorId, string rightCode)
    {
        if (string.IsNullOrWhiteSpace(operatorId))
            return true;
        if (IsAdministratorRole(conn, operatorId))
            return true;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT FIRST 1 1 FROM SP_POS_OPERATOR_RIGHT
WHERE OPERATOR_ID = @I AND UPPER(TRIM(RIGHT_CODE)) = UPPER(TRIM(@R))";
        cmd.Parameters.AddWithValue("@I", operatorId.Trim());
        cmd.Parameters.AddWithValue("@R", rightCode.Trim());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    public static List<PosOperatorRow> ListActive(FbConnection conn) => ListInternal(conn, activeOnly: true);

    public static List<PosOperatorRow> ListAll(FbConnection conn) => ListInternal(conn, activeOnly: false);

    private static List<PosOperatorRow> ListInternal(FbConnection conn, bool activeOnly)
    {
        var list = new List<PosOperatorRow>();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT ID, USERNAME, DISPLAY_NAME, PASSWORD_PIN, ROLE, ACTIVE, ACCES_ALL_TABLES,
       CNP, BULETIN, POLITIE, CARD_BARCODE
FROM SP_POS_OPERATOR
" + (activeOnly ? "WHERE ACTIVE = 1 " : "") + @"
ORDER BY " + (activeOnly ? "DISPLAY_NAME" : "ACTIVE DESC, DISPLAY_NAME");
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
            list.Add(ReadRow(rd));

        return list;
    }

    private static PosOperatorRow ReadRow(System.Data.IDataRecord rd) => new()
    {
        Id = (rd["ID"]?.ToString() ?? "").Trim(),
        Username = (rd["USERNAME"]?.ToString() ?? "").Trim(),
        DisplayName = (rd["DISPLAY_NAME"]?.ToString() ?? "").Trim(),
        PasswordPin = rd["PASSWORD_PIN"]?.ToString(),
        Role = (rd["ROLE"]?.ToString() ?? "Waiter").Trim(),
        Active = Convert.ToInt32(rd["ACTIVE"] ?? 0) != 0,
        AccessAllTables = Convert.ToInt32(rd["ACCES_ALL_TABLES"] ?? 1) != 0,
        Cnp = ReadOpt(rd, "CNP"),
        Buletin = ReadOpt(rd, "BULETIN"),
        Politie = ReadOpt(rd, "POLITIE"),
        CardBarcode = ReadOpt(rd, "CARD_BARCODE")
    };

    private static string? ReadOpt(System.Data.IDataRecord rd, string col)
    {
        try
        {
            var i = rd.GetOrdinal(col);
            return rd.IsDBNull(i) ? null : rd.GetString(i)?.Trim();
        }
        catch
        {
            return null;
        }
    }

    public static PosOperatorDetail LoadDetail(FbConnection conn, string operatorId)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT ID, USERNAME, DISPLAY_NAME, PASSWORD_PIN, ROLE, ACTIVE, ACCES_ALL_TABLES,
       CNP, BULETIN, POLITIE, CARD_BARCODE
FROM SP_POS_OPERATOR WHERE ID = @I";
        cmd.Parameters.AddWithValue("@I", operatorId.Trim());
        using var rd = cmd.ExecuteReader();
        if (!rd.Read())
            throw new InvalidOperationException("Operator inexistent.");

        var op = ReadRow(rd);
        return new PosOperatorDetail
        {
            Operator = op,
            GrantedRights = LoadRights(conn, operatorId),
            AllowedTableIds = LoadAllowedTables(conn, operatorId),
            BlockedGestiuni = LoadBlockedGestiuni(conn, operatorId),
            BlockedGrupe = LoadBlockedGrupe(conn, operatorId)
        };
    }

    public static HashSet<string> LoadRights(FbConnection conn, string operatorId)
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT RIGHT_CODE FROM SP_POS_OPERATOR_RIGHT WHERE OPERATOR_ID = @I";
        cmd.Parameters.AddWithValue("@I", operatorId.Trim());
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var c = rd["RIGHT_CODE"]?.ToString()?.Trim();
            if (!string.IsNullOrEmpty(c))
                set.Add(c);
        }

        return set;
    }

    public static HashSet<string> LoadAllowedTables(FbConnection conn, string operatorId)
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT TABLE_ID FROM SP_POS_OPERATOR_TABLE WHERE OPERATOR_ID = @I";
        cmd.Parameters.AddWithValue("@I", operatorId.Trim());
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var c = rd["TABLE_ID"]?.ToString()?.Trim();
            if (!string.IsNullOrEmpty(c))
                set.Add(c);
        }

        return set;
    }

    public static HashSet<string> LoadBlockedGestiuni(FbConnection conn, string operatorId)
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT GESTIUNE_CODE FROM SP_POS_OPERATOR_GEST_BLOCK WHERE OPERATOR_ID = @I";
        cmd.Parameters.AddWithValue("@I", operatorId.Trim());
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var c = rd["GESTIUNE_CODE"]?.ToString()?.Trim();
            if (!string.IsNullOrEmpty(c))
                set.Add(c);
        }

        return set;
    }

    public static HashSet<string> LoadBlockedGrupe(FbConnection conn, string operatorId)
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT GRUPA_CODE FROM SP_POS_OPERATOR_GRUP_BLOCK WHERE OPERATOR_ID = @I";
        cmd.Parameters.AddWithValue("@I", operatorId.Trim());
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var c = rd["GRUPA_CODE"]?.ToString()?.Trim();
            if (!string.IsNullOrEmpty(c))
                set.Add(c);
        }

        return set;
    }

    public static void SaveDetail(FbConnection conn, PosOperatorDetail detail)
    {
        var op = detail.Operator;
        if (string.IsNullOrWhiteSpace(op.Id))
            op.Id = Guid.NewGuid().ToString("N");

        using var tx = conn.BeginTransaction();
        try
        {
            using (var exists = conn.CreateCommand())
            {
                exists.Transaction = tx;
                exists.CommandText = "SELECT COUNT(*) FROM SP_POS_OPERATOR WHERE ID = @I";
                exists.Parameters.AddWithValue("@I", op.Id.Trim());
                var n = Convert.ToInt32(exists.ExecuteScalar() ?? 0);
                if (n == 0)
                    InsertCore(conn, tx, op);
                else
                    UpdateCore(conn, tx, op);
            }

            ReplaceRights(conn, tx, op.Id, detail.GrantedRights);
            ReplaceAllowedTables(conn, tx, op.Id,
                op.AccessAllTables ? new HashSet<string>(StringComparer.OrdinalIgnoreCase) : detail.AllowedTableIds);
            ReplaceGestBlock(conn, tx, op.Id, detail.BlockedGestiuni);
            ReplaceGrupBlock(conn, tx, op.Id, detail.BlockedGrupe);

            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    public static void DeleteOperator(FbConnection conn, string operatorId)
    {
        var id = operatorId.Trim();
        using var tx = conn.BeginTransaction();
        try
        {
            void Run(string sql)
            {
                using var c = conn.CreateCommand();
                c.Transaction = tx;
                c.CommandText = sql;
                c.Parameters.AddWithValue("@I", id);
                c.ExecuteNonQuery();
            }

            Run("DELETE FROM SP_POS_OPERATOR_RIGHT WHERE OPERATOR_ID = @I");
            Run("DELETE FROM SP_POS_OPERATOR_TABLE WHERE OPERATOR_ID = @I");
            Run("DELETE FROM SP_POS_OPERATOR_GEST_BLOCK WHERE OPERATOR_ID = @I");
            Run("DELETE FROM SP_POS_OPERATOR_GRUP_BLOCK WHERE OPERATOR_ID = @I");
            Run("DELETE FROM SP_POS_OPERATOR WHERE ID = @I");
            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    private static void InsertCore(FbConnection conn, FbTransaction tx, PosOperatorRow row)
    {
        using var cmd = conn.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = @"
INSERT INTO SP_POS_OPERATOR (ID, USERNAME, DISPLAY_NAME, PASSWORD_PIN, ROLE, ACTIVE, ACCES_ALL_TABLES,
  CNP, BULETIN, POLITIE, CARD_BARCODE, UPDATED_AT)
VALUES (@ID, @U, @D, @P, @R, @A, @ALL, @CNP, @BUL, @POL, @CARD, CURRENT_TIMESTAMP)";
        AddOperatorParams(cmd, row);
        cmd.ExecuteNonQuery();
    }

    private static void UpdateCore(FbConnection conn, FbTransaction tx, PosOperatorRow row)
    {
        using var cmd = conn.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = @"
UPDATE SP_POS_OPERATOR SET
  USERNAME = @U, DISPLAY_NAME = @D, PASSWORD_PIN = @P, ROLE = @R, ACTIVE = @A, ACCES_ALL_TABLES = @ALL,
  CNP = @CNP, BULETIN = @BUL, POLITIE = @POL, CARD_BARCODE = @CARD, UPDATED_AT = CURRENT_TIMESTAMP
WHERE ID = @ID";
        AddOperatorParams(cmd, row);
        cmd.ExecuteNonQuery();
    }

    private static void AddOperatorParams(FbCommand cmd, PosOperatorRow row)
    {
        cmd.Parameters.AddWithValue("@ID", row.Id.Trim());
        cmd.Parameters.AddWithValue("@U", row.Username.Trim());
        cmd.Parameters.AddWithValue("@D", row.DisplayName.Trim());
        cmd.Parameters.AddWithValue("@P", string.IsNullOrWhiteSpace(row.PasswordPin) ? DBNull.Value : row.PasswordPin.Trim());
        cmd.Parameters.AddWithValue("@R", string.IsNullOrWhiteSpace(row.Role) ? "Waiter" : row.Role.Trim());
        cmd.Parameters.AddWithValue("@A", row.Active ? 1 : 0);
        cmd.Parameters.AddWithValue("@ALL", row.AccessAllTables ? 1 : 0);
        cmd.Parameters.AddWithValue("@CNP", DbOrNull(row.Cnp));
        cmd.Parameters.AddWithValue("@BUL", DbOrNull(row.Buletin));
        cmd.Parameters.AddWithValue("@POL", DbOrNull(row.Politie));
        cmd.Parameters.AddWithValue("@CARD", DbOrNull(row.CardBarcode));
    }

    private static object DbOrNull(string? s) =>
        string.IsNullOrWhiteSpace(s) ? DBNull.Value : s.Trim();

    private static void ReplaceRights(FbConnection conn, string operatorId, HashSet<string> rights)
    {
        using var tx = conn.BeginTransaction();
        try
        {
            ReplaceRights(conn, tx, operatorId, rights);
            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    private static void ReplaceRights(FbConnection conn, FbTransaction tx, string operatorId, HashSet<string> rights)
    {
        using (var del = conn.CreateCommand())
        {
            del.Transaction = tx;
            del.CommandText = "DELETE FROM SP_POS_OPERATOR_RIGHT WHERE OPERATOR_ID = @I";
            del.Parameters.AddWithValue("@I", operatorId.Trim());
            del.ExecuteNonQuery();
        }

        foreach (var code in rights.Where(c => !string.IsNullOrWhiteSpace(c)))
        {
            using var ins = conn.CreateCommand();
            ins.Transaction = tx;
            ins.CommandText = @"
INSERT INTO SP_POS_OPERATOR_RIGHT (OPERATOR_ID, RIGHT_CODE) VALUES (@I, @R)";
            ins.Parameters.AddWithValue("@I", operatorId.Trim());
            ins.Parameters.AddWithValue("@R", code.Trim());
            ins.ExecuteNonQuery();
        }
    }

    private static void ReplaceAllowedTables(FbConnection conn, FbTransaction tx, string operatorId, HashSet<string> tableIds)
    {
        using (var del = conn.CreateCommand())
        {
            del.Transaction = tx;
            del.CommandText = "DELETE FROM SP_POS_OPERATOR_TABLE WHERE OPERATOR_ID = @I";
            del.Parameters.AddWithValue("@I", operatorId.Trim());
            del.ExecuteNonQuery();
        }

        foreach (var tid in tableIds.Where(t => !string.IsNullOrWhiteSpace(t)))
        {
            using var ins = conn.CreateCommand();
            ins.Transaction = tx;
            ins.CommandText = @"
INSERT INTO SP_POS_OPERATOR_TABLE (OPERATOR_ID, TABLE_ID) VALUES (@I, @T)";
            ins.Parameters.AddWithValue("@I", operatorId.Trim());
            ins.Parameters.AddWithValue("@T", tid.Trim());
            ins.ExecuteNonQuery();
        }
    }

    private static void ReplaceGestBlock(FbConnection conn, FbTransaction tx, string operatorId, HashSet<string> codes)
    {
        using (var del = conn.CreateCommand())
        {
            del.Transaction = tx;
            del.CommandText = "DELETE FROM SP_POS_OPERATOR_GEST_BLOCK WHERE OPERATOR_ID = @I";
            del.Parameters.AddWithValue("@I", operatorId.Trim());
            del.ExecuteNonQuery();
        }

        foreach (var c in codes.Where(x => !string.IsNullOrWhiteSpace(x)))
        {
            using var ins = conn.CreateCommand();
            ins.Transaction = tx;
            ins.CommandText = @"
INSERT INTO SP_POS_OPERATOR_GEST_BLOCK (OPERATOR_ID, GESTIUNE_CODE) VALUES (@I, @G)";
            ins.Parameters.AddWithValue("@I", operatorId.Trim());
            ins.Parameters.AddWithValue("@G", c.Trim());
            ins.ExecuteNonQuery();
        }
    }

    private static void ReplaceGrupBlock(FbConnection conn, FbTransaction tx, string operatorId, HashSet<string> codes)
    {
        using (var del = conn.CreateCommand())
        {
            del.Transaction = tx;
            del.CommandText = "DELETE FROM SP_POS_OPERATOR_GRUP_BLOCK WHERE OPERATOR_ID = @I";
            del.Parameters.AddWithValue("@I", operatorId.Trim());
            del.ExecuteNonQuery();
        }

        foreach (var c in codes.Where(x => !string.IsNullOrWhiteSpace(x)))
        {
            using var ins = conn.CreateCommand();
            ins.Transaction = tx;
            ins.CommandText = @"
INSERT INTO SP_POS_OPERATOR_GRUP_BLOCK (OPERATOR_ID, GRUPA_CODE) VALUES (@I, @G)";
            ins.Parameters.AddWithValue("@I", operatorId.Trim());
            ins.Parameters.AddWithValue("@G", c.Trim());
            ins.ExecuteNonQuery();
        }
    }

    public static HashSet<string>? GetAllowedTableIds(FbConnection conn, string operatorId)
    {
        if (string.IsNullOrWhiteSpace(operatorId))
            return null;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT ACCES_ALL_TABLES FROM SP_POS_OPERATOR WHERE ID = @I AND ACTIVE = 1";
        cmd.Parameters.AddWithValue("@I", operatorId.Trim());
        var o = cmd.ExecuteScalar();
        if (o == null || o == DBNull.Value)
            return null;

        if (Convert.ToInt32(o) != 0)
            return null;

        return LoadAllowedTables(conn, operatorId);
    }

    public static bool TryValidatePin(FbConnection conn, string operatorId, string? pinEntered)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT PASSWORD_PIN FROM SP_POS_OPERATOR WHERE ID = @I AND ACTIVE = 1";
        cmd.Parameters.AddWithValue("@I", operatorId.Trim());
        var o = cmd.ExecuteScalar()?.ToString();
        if (string.IsNullOrWhiteSpace(o))
            return true;
        return string.Equals((pinEntered ?? "").Trim(), o.Trim(), StringComparison.Ordinal);
    }

    public static bool TryValidateCard(FbConnection conn, string? cardData)
    {
        if (string.IsNullOrWhiteSpace(cardData))
            return false;
        var c = cardData.Trim();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT FIRST 1 ID FROM SP_POS_OPERATOR WHERE ACTIVE = 1 AND CARD_BARCODE IS NOT NULL AND TRIM(CARD_BARCODE) <> ''
  AND UPPER(TRIM(CARD_BARCODE)) = UPPER(TRIM(@C))";
        cmd.Parameters.AddWithValue("@C", c);
        return cmd.ExecuteScalar() != null;
    }

    public static string? FindOperatorIdByCard(FbConnection conn, string? cardData)
    {
        if (string.IsNullOrWhiteSpace(cardData))
            return null;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT FIRST 1 ID FROM SP_POS_OPERATOR WHERE ACTIVE = 1 AND UPPER(TRIM(CARD_BARCODE)) = UPPER(TRIM(@C))";
        cmd.Parameters.AddWithValue("@C", cardData.Trim());
        return cmd.ExecuteScalar()?.ToString()?.Trim();
    }

    /// <summary>Liste distincte din catalog sincronizat.</summary>
    public static List<string> ListDistinctGestiuni(FbConnection conn)
    {
        if (!TableExists(conn, "SP_SAGA_ARTICOLE"))
            return [];
        SagaArticoleSchemaExtensions.EnsureExtendedColumns(conn);
        var gestColumn = ColumnExists(conn, "SP_SAGA_ARTICOLE", "GESTIUNE")
            ? "GESTIUNE"
            : ColumnExists(conn, "SP_SAGA_ARTICOLE", "COD_GESTIUNE")
                ? "COD_GESTIUNE"
                : "";
        if (gestColumn.Length == 0)
            return [];

        var list = new List<string>();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = $@"
SELECT DISTINCT TRIM({gestColumn}) AS G FROM SP_SAGA_ARTICOLE
WHERE {gestColumn} IS NOT NULL AND TRIM({gestColumn}) <> ''
ORDER BY 1";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var g = rd["G"]?.ToString()?.Trim();
            if (!string.IsNullOrEmpty(g))
                list.Add(g);
        }

        return list;
    }

    public static List<string> ListDistinctGrupe(FbConnection conn)
    {
        if (!TableExists(conn, "SP_SAGA_ARTICOLE"))
            return [];
        var list = new List<string>();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT DISTINCT TRIM(GRUPA) AS G FROM SP_SAGA_ARTICOLE
WHERE GRUPA IS NOT NULL AND TRIM(GRUPA) <> ''
ORDER BY 1";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var g = rd["G"]?.ToString()?.Trim();
            if (!string.IsNullOrEmpty(g))
                list.Add(g);
        }

        return list;
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static bool ColumnExists(FbConnection conn, string tableName, string columnName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATION_FIELDS
WHERE TRIM(RDB$RELATION_NAME) = @T AND TRIM(RDB$FIELD_NAME) = @C ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        cmd.Parameters.AddWithValue("@C", columnName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    // --- Compat API vechi (Insert/Update fără detaliu) ---
    public static void Insert(FbConnection conn, PosOperatorRow row)
    {
        row.Id = string.IsNullOrWhiteSpace(row.Id) ? Guid.NewGuid().ToString("N") : row.Id.Trim();
        using var tx = conn.BeginTransaction();
        try
        {
            InsertCore(conn, tx, row);
            ReplaceRights(conn, tx, row.Id, DefaultRightsForRole(row.Role));
            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    public static void Update(FbConnection conn, PosOperatorRow row)
    {
        using var tx = conn.BeginTransaction();
        try
        {
            UpdateCore(conn, tx, row);
            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    private static HashSet<string> DefaultRightsForRole(string? role)
    {
        if (IsAdministratorRole(role))
            return PosOperatorRightsCatalog.DefaultAdministratorRights();
        if (IsShiftLeadRole(role))
            return PosOperatorRightsCatalog.DefaultShiftLeadRights();
        return PosOperatorRightsCatalog.DefaultWaiterRights();
    }
}

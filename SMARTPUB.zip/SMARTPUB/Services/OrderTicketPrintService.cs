using System.Collections.Generic;
using System.Globalization;
using System.Printing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

/// <summary>Printează bonuri de comandă (bar/bucătărie) la o imprimantă dată, fără dialog.</summary>
public static class OrderTicketPrintService
{
    /// <summary>Printează liniile la imprimanta cu numele dat. Aruncă excepție clară dacă imprimanta lipsește.</summary>
    public static void Print(
        string printerName,
        string destinationLabel,
        string? tableLabel,
        string? operatorName,
        IReadOnlyList<WaiterCartLine> lines)
    {
        if (string.IsNullOrWhiteSpace(printerName))
            throw new InvalidOperationException(
                $"Nu este setată imprimanta pentru {destinationLabel}. Alege-o în Configurare program → Periferice.");

        if (lines == null || lines.Count == 0)
            return;

        PrintQueue queue = ResolveQueue(printerName.Trim());

        var doc = BuildDocument(destinationLabel, tableLabel, operatorName, lines);
        var dlg = new PrintDialog { PrintQueue = queue };
        doc.PageWidth = dlg.PrintableAreaWidth;
        dlg.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, $"Comandă {destinationLabel} SMARTPUB");
    }

    private static PrintQueue ResolveQueue(string printerName)
    {
        var server = new LocalPrintServer();
        try
        {
            return server.GetPrintQueue(printerName);
        }
        catch
        {
            throw new InvalidOperationException(
                $"Imprimanta „{printerName}” nu a fost găsită. Verifică numele în Configurare program → Periferice.");
        }
    }

    private static FlowDocument BuildDocument(
        string destinationLabel,
        string? tableLabel,
        string? operatorName,
        IReadOnlyList<WaiterCartLine> lines)
    {
        var ci = CultureInfo.CurrentCulture;
        var doc = new FlowDocument
        {
            PagePadding = new Thickness(8),
            FontFamily = new FontFamily("Segoe UI"),
            FontSize = 13,
            ColumnWidth = double.PositiveInfinity,
            Foreground = Brushes.Black
        };

        doc.Blocks.Add(new Paragraph(new Run(destinationLabel.ToUpperInvariant()))
        {
            FontSize = 20,
            FontWeight = FontWeights.Bold,
            TextAlignment = TextAlignment.Center,
            Margin = new Thickness(0, 0, 0, 2)
        });

        doc.Blocks.Add(new Paragraph(new Run("Comandă") )
        {
            FontSize = 11,
            TextAlignment = TextAlignment.Center,
            Foreground = Brushes.DimGray,
            Margin = new Thickness(0, 0, 0, 10)
        });

        doc.Blocks.Add(new Paragraph(new Run(DateTime.Now.ToString("dd.MM.yyyy HH:mm", ci)))
        {
            FontSize = 11,
            Margin = new Thickness(0, 0, 0, 2)
        });

        if (!string.IsNullOrWhiteSpace(tableLabel))
            doc.Blocks.Add(new Paragraph(new Run(tableLabel))
            {
                FontSize = 15,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 2)
            });

        if (!string.IsNullOrWhiteSpace(operatorName))
            doc.Blocks.Add(new Paragraph(new Run($"Ospătar: {operatorName}"))
            {
                FontSize = 11,
                Margin = new Thickness(0, 0, 0, 10)
            });

        var table = new Table { CellSpacing = 0 };
        table.Columns.Add(new TableColumn { Width = new GridLength(46) });
        table.Columns.Add(new TableColumn { Width = new GridLength(1, GridUnitType.Star) });

        var body = new TableRowGroup();
        foreach (var line in lines)
        {
            var tr = new TableRow();
            tr.Cells.Add(new TableCell(new Paragraph(new Run(line.Qty.ToString("0.##", ci) + "x"))
            {
                FontWeight = FontWeights.Bold,
                FontSize = 15
            })
            { Padding = new Thickness(2, 4, 6, 4), BorderBrush = Brushes.Gainsboro, BorderThickness = new Thickness(0, 0, 0, 0.5) });

            var namePara = new Paragraph(new Run(line.ProductName))
            {
                FontSize = 15,
                FontWeight = FontWeights.SemiBold
            };
            if (!string.IsNullOrWhiteSpace(line.Notes))
                namePara.Inlines.Add(new Run("\n↳ " + line.Notes.Trim())
                {
                    FontSize = 11,
                    FontStyle = FontStyles.Italic,
                    Foreground = Brushes.DimGray
                });

            tr.Cells.Add(new TableCell(namePara)
            { Padding = new Thickness(2, 4, 2, 4), BorderBrush = Brushes.Gainsboro, BorderThickness = new Thickness(0, 0, 0, 0.5) });

            body.Rows.Add(tr);
        }

        table.RowGroups.Add(body);
        doc.Blocks.Add(table);

        return doc;
    }
}

using System.IO;
using System.Text.Json;
using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

/// <summary>
/// Tabele operaționale SMARTPUB (fără PubLine): operatori, draft comenzi pe masă, KDS în baza încorporată.
/// </summary>
public static class PosOperationalSchema
{
    private static int _roleColumnWidened;
    private static int _saleErrorColumnWidened;

    public static void EnsureSchema(FbConnection conn)
    {
        EnsureTable(conn, "SP_POS_OPERATOR", @"
CREATE TABLE SP_POS_OPERATOR (
  ID VARCHAR(36) NOT NULL,
  USERNAME VARCHAR(40) NOT NULL,
  DISPLAY_NAME VARCHAR(80) NOT NULL,
  PASSWORD_PIN VARCHAR(32),
  ROLE VARCHAR(20) NOT NULL,
  ACTIVE SMALLINT DEFAULT 1 NOT NULL,
  ACCES_ALL_TABLES SMALLINT DEFAULT 1 NOT NULL,
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (ID),
  CONSTRAINT UNQ_SP_POS_OPERATOR_USER UNIQUE (USERNAME)
)");

        EnsureTable(conn, "SP_POS_OPERATOR_TABLE", @"
CREATE TABLE SP_POS_OPERATOR_TABLE (
  OPERATOR_ID VARCHAR(36) NOT NULL,
  TABLE_ID VARCHAR(36) NOT NULL,
  PRIMARY KEY (OPERATOR_ID, TABLE_ID)
)");

        EnsureTable(conn, "SP_POS_DRAFT_LINE", @"
CREATE TABLE SP_POS_DRAFT_LINE (
  TABLE_ID VARCHAR(36) NOT NULL,
  LINE_NO INTEGER NOT NULL,
  PRODUCT_CODE VARCHAR(24) NOT NULL,
  PRODUCT_NAME VARCHAR(120),
  GESTIUNE_CODE VARCHAR(24),
  GESTIUNE_NAME VARCHAR(100),
  QTY NUMERIC(18,4) NOT NULL,
  UNIT_PRICE NUMERIC(18,4) NOT NULL,
  TVA_PCT NUMERIC(18,4),
  NOTES VARCHAR(200),
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (TABLE_ID, LINE_NO)
)");

        EnsureTable(conn, "SP_POS_KITCHEN_TICKET", @"
CREATE TABLE SP_POS_KITCHEN_TICKET (
  ID VARCHAR(36) NOT NULL,
  CREATED_AT_UTC TIMESTAMP NOT NULL,
  TABLE_ID VARCHAR(36),
  TABLE_DISPLAY_NAME VARCHAR(80),
  LEVEL_NAME VARCHAR(80),
  SPACE_NAME VARCHAR(80),
  SOURCE_OPERATOR VARCHAR(80),
  STATUS VARCHAR(20) NOT NULL,
  PRIMARY KEY (ID)
)");

        EnsureTable(conn, "SP_POS_KITCHEN_TICKET_LINE", @"
CREATE TABLE SP_POS_KITCHEN_TICKET_LINE (
  TICKET_ID VARCHAR(36) NOT NULL,
  LINE_NO INTEGER NOT NULL,
  PRODUCT_CODE VARCHAR(24),
  PRODUCT_NAME VARCHAR(120),
  GESTIUNE_CODE VARCHAR(24),
  GESTIUNE_NAME VARCHAR(100),
  QTY NUMERIC(18,4),
  UNIT_PRICE NUMERIC(18,4),
  NOTES VARCHAR(200),
  PRIMARY KEY (TICKET_ID, LINE_NO)
)");

        MigrateOperationalColumns(conn);
        MigratePosOperatorColumns(conn);

        EnsureTable(conn, "SP_POS_OPERATOR_RIGHT", @"
CREATE TABLE SP_POS_OPERATOR_RIGHT (
  OPERATOR_ID VARCHAR(36) NOT NULL,
  RIGHT_CODE VARCHAR(48) NOT NULL,
  PRIMARY KEY (OPERATOR_ID, RIGHT_CODE)
)");

        EnsureTable(conn, "SP_POS_OPERATOR_GEST_BLOCK", @"
CREATE TABLE SP_POS_OPERATOR_GEST_BLOCK (
  OPERATOR_ID VARCHAR(36) NOT NULL,
  GESTIUNE_CODE VARCHAR(24) NOT NULL,
  PRIMARY KEY (OPERATOR_ID, GESTIUNE_CODE)
)");

        EnsureTable(conn, "SP_POS_OPERATOR_GRUP_BLOCK", @"
CREATE TABLE SP_POS_OPERATOR_GRUP_BLOCK (
  OPERATOR_ID VARCHAR(36) NOT NULL,
  GRUPA_CODE VARCHAR(32) NOT NULL,
  PRIMARY KEY (OPERATOR_ID, GRUPA_CODE)
)");

        EnsureTable(conn, "SP_POS_SALE_HEADER", @"
CREATE TABLE SP_POS_SALE_HEADER (
  ID VARCHAR(36) NOT NULL,
  ORDER_NO INTEGER NOT NULL,
  TABLE_ID VARCHAR(36),
  TABLE_DISPLAY_NAME VARCHAR(80),
  OPERATOR_ID VARCHAR(36),
  OPERATOR_NAME VARCHAR(80),
  STATUS VARCHAR(16) NOT NULL,
  VALOARE NUMERIC(18,4) DEFAULT 0 NOT NULL,
  VALOARE_TVA NUMERIC(18,4) DEFAULT 0 NOT NULL,
  TOTAL NUMERIC(18,4) DEFAULT 0 NOT NULL,
  PAID_AT TIMESTAMP NOT NULL,
  CREATED_AT TIMESTAMP,
  MOD_PLATA VARCHAR(32),
  SAGA_TRANSFER_STATUS VARCHAR(16) NOT NULL,
  SAGA_ID_IESIRE NUMERIC(18,0),
  SAGA_NR_IESIRE VARCHAR(48),
  SAGA_ERROR VARCHAR(1000),
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (ID)
)");

        EnsureTable(conn, "SP_POS_SPLIT_SESSION", @"
CREATE TABLE SP_POS_SPLIT_SESSION (
  TABLE_ID VARCHAR(36) NOT NULL,
  PERSON_COUNT INTEGER NOT NULL,
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (TABLE_ID)
)");

        EnsureTable(conn, "SP_POS_SPLIT_BILL", @"
CREATE TABLE SP_POS_SPLIT_BILL (
  TABLE_ID VARCHAR(36) NOT NULL,
  BILL_INDEX INTEGER NOT NULL,
  IS_PAID SMALLINT DEFAULT 0 NOT NULL,
  SALE_ID VARCHAR(36),
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (TABLE_ID, BILL_INDEX)
)");

        EnsureTable(conn, "SP_POS_SPLIT_ALLOC", @"
CREATE TABLE SP_POS_SPLIT_ALLOC (
  TABLE_ID VARCHAR(36) NOT NULL,
  BILL_INDEX INTEGER NOT NULL,
  LINE_KEY VARCHAR(160) NOT NULL,
  SOURCE_KIND VARCHAR(8) NOT NULL,
  PRODUCT_CODE VARCHAR(24) NOT NULL,
  PRODUCT_NAME VARCHAR(120),
  QTY NUMERIC(18,4) NOT NULL,
  UNIT_PRICE NUMERIC(18,4) NOT NULL,
  TVA_PCT NUMERIC(18,4),
  NOTES VARCHAR(200),
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (TABLE_ID, BILL_INDEX, LINE_KEY)
)");

        EnsureTable(conn, "SP_POS_SALE_LINE", @"
CREATE TABLE SP_POS_SALE_LINE (
  SALE_ID VARCHAR(36) NOT NULL,
  LINE_NO INTEGER NOT NULL,
  COD_GESTIUNE VARCHAR(24),
  DEN_GEST VARCHAR(64),
  PRODUCT_CODE VARCHAR(24) NOT NULL,
  PRODUCT_NAME VARCHAR(120),
  UM VARCHAR(8),
  TVA_PCT NUMERIC(18,4),
  QTY NUMERIC(18,4) NOT NULL,
  UNIT_PRICE NUMERIC(18,4) NOT NULL,
  VALOARE NUMERIC(18,4) DEFAULT 0 NOT NULL,
  VALOARE_TVA NUMERIC(18,4) DEFAULT 0 NOT NULL,
  TOTAL NUMERIC(18,4) DEFAULT 0 NOT NULL,
  PRIMARY KEY (SALE_ID, LINE_NO)
)");

        EnsureTable(conn, "SP_POS_SALE_PAYMENT", @"
CREATE TABLE SP_POS_SALE_PAYMENT (
  SALE_ID VARCHAR(36) NOT NULL,
  LINE_NO INTEGER NOT NULL,
  METHOD_KEY VARCHAR(24) NOT NULL,
  AMOUNT NUMERIC(18,4) DEFAULT 0 NOT NULL,
  PRIMARY KEY (SALE_ID, LINE_NO)
)");
    }

    private static void MigratePosOperatorColumns(FbConnection conn)
    {
        if (!TableExists(conn, "SP_POS_OPERATOR"))
            return;

        TryAddColumn(conn, "SP_POS_OPERATOR", "CNP", "VARCHAR(13)");
        TryAddColumn(conn, "SP_POS_OPERATOR", "BULETIN", "VARCHAR(32)");
        TryAddColumn(conn, "SP_POS_OPERATOR", "POLITIE", "VARCHAR(80)");
        TryAddColumn(conn, "SP_POS_OPERATOR", "CARD_BARCODE", "VARCHAR(48)");

        TryAlterRoleWider(conn);
    }

    private static void MigrateOperationalColumns(FbConnection conn)
    {
        if (TableExists(conn, "SP_POS_DRAFT_LINE"))
        {
            TryAddColumn(conn, "SP_POS_DRAFT_LINE", "GESTIUNE_CODE", "VARCHAR(24)");
            TryAddColumn(conn, "SP_POS_DRAFT_LINE", "GESTIUNE_NAME", "VARCHAR(100)");
        }

        if (TableExists(conn, "SP_POS_KITCHEN_TICKET_LINE"))
        {
            TryAddColumn(conn, "SP_POS_KITCHEN_TICKET_LINE", "GESTIUNE_CODE", "VARCHAR(24)");
            TryAddColumn(conn, "SP_POS_KITCHEN_TICKET_LINE", "GESTIUNE_NAME", "VARCHAR(100)");
        }

        TryAlterSaleErrorWider(conn);
    }

    private static void TryAddColumn(FbConnection conn, string table, string column, string typeSql)
    {
        if (ColumnExists(conn, table, column))
            return;
        try
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = $"ALTER TABLE {table} ADD {column} {typeSql}";
            cmd.ExecuteNonQuery();
        }
        catch
        {
            /* coloană există sau versiune FB */
        }
    }

    private static void TryAlterRoleWider(FbConnection conn)
    {
        if (Interlocked.Exchange(ref _roleColumnWidened, 1) == 1)
            return;
        try
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "ALTER TABLE SP_POS_OPERATOR ALTER COLUMN ROLE TYPE VARCHAR(32)";
            cmd.ExecuteNonQuery();
        }
        catch
        {
            /* deja extins sau nu e suportat */
        }
    }

    private static void TryAlterSaleErrorWider(FbConnection conn)
    {
        if (Interlocked.Exchange(ref _saleErrorColumnWidened, 1) == 1)
            return;
        try
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "ALTER TABLE SP_POS_SALE_HEADER ALTER COLUMN SAGA_ERROR TYPE VARCHAR(1000)";
            cmd.ExecuteNonQuery();
        }
        catch
        {
            /* deja extins sau baza nu permite alterarea în acest moment */
        }
    }

    private static bool ColumnExists(FbConnection conn, string tableName, string columnName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATION_FIELDS RF
JOIN RDB$RELATIONS R ON R.RDB$RELATION_NAME = RF.RDB$RELATION_NAME
WHERE R.RDB$SYSTEM_FLAG = 0
  AND TRIM(R.RDB$RELATION_NAME) = @T
  AND TRIM(RF.RDB$FIELD_NAME) = @C
ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        cmd.Parameters.AddWithValue("@C", columnName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    public static string LegacyKitchenJsonPath =>
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "SMARTPUB",
            "kitchen_tickets.json");

    private static readonly JsonSerializerOptions LegacyJsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Converters = { new System.Text.Json.Serialization.JsonStringEnumConverter(JsonNamingPolicy.CamelCase) }
    };

    /// <summary>Import unic din kitchen_tickets.json (legacy) după crearea tabelelor.</summary>
    public static void TryImportLegacyKitchenJson(FbConnection conn)
    {
        var path = LegacyKitchenJsonPath;
        if (!File.Exists(path))
            return;

        using var chk = conn.CreateCommand();
        chk.CommandText = "SELECT COUNT(*) FROM SP_POS_KITCHEN_TICKET";
        var n = Convert.ToInt32(chk.ExecuteScalar() ?? 0);
        if (n > 0)
            return;

        List<KitchenTicket>? tickets;
        try
        {
            var json = File.ReadAllText(path);
            var dto = JsonSerializer.Deserialize<KitchenTicketFileDto>(json, LegacyJsonOptions);
            tickets = dto?.Tickets;
            if (tickets == null || tickets.Count == 0)
                return;
        }
        catch
        {
            return;
        }

        foreach (var t in tickets)
            PosKitchenTicketRepository.InsertTicket(conn, t);

        try
        {
            File.Move(path, path + ".migrated_" + DateTime.Now.ToString("yyyyMMddHHmmss"), overwrite: true);
        }
        catch
        {
            /* păstrăm fișierul */
        }
    }

    private static void EnsureTable(FbConnection conn, string tableName, string ddl)
    {
        if (TableExists(conn, tableName))
            return;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = ddl;
        cmd.ExecuteNonQuery();
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

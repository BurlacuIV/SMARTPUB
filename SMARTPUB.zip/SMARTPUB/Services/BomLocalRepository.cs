using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public sealed class BomLocalRepository
{
    public List<BomArticleRow> ListArticles(FbConnection conn)
    {
        var list = new List<BomArticleRow>();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT TRIM(CODE), TRIM(NAME), TRIM(UM), COALESCE(TVA,0), TRIM(CATEGORIE), COALESCE(PRET_VANZ,0)
FROM SP_BOM_ARTICLE
ORDER BY NAME";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new BomArticleRow
            {
                Code = (rd[0]?.ToString() ?? "").Trim(),
                Name = (rd[1]?.ToString() ?? "").Trim(),
                Um = (rd[2]?.ToString() ?? "").Trim(),
                Tva = ToDecimal(rd[3]),
                Categorie = (rd[4]?.ToString() ?? "").Trim(),
                PretVanz = ToDecimal(rd[5])
            });
        }

        return list;
    }

    public bool ArticleExists(FbConnection conn, string code)
    {
        if (string.IsNullOrWhiteSpace(code))
            return false;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT 1 FROM SP_BOM_ARTICLE WHERE TRIM(CODE) = @C ROWS 1";
        cmd.Parameters.AddWithValue("@C", code.Trim());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    public int CountLines(FbConnection conn, string parentCode)
    {
        if (string.IsNullOrWhiteSpace(parentCode))
            return 0;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM SP_BOM_LINE WHERE PARENT_CODE = @P";
        cmd.Parameters.AddWithValue("@P", parentCode.Trim());
        var o = cmd.ExecuteScalar();
        return o == null || o == DBNull.Value ? 0 : Convert.ToInt32(o);
    }

    public List<BomLineRow> ListLines(FbConnection conn, string parentCode)
    {
        var list = new List<BomLineRow>();
        if (string.IsNullOrWhiteSpace(parentCode))
            return list;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT LINE_NO, LINE_KIND, TRIM(COMPONENT_CODE), COALESCE(QTY,0), TRIM(UM), TRIM(GESTIUNE), TRIM(DEN_TIP)
FROM SP_BOM_LINE
WHERE PARENT_CODE = @P
ORDER BY LINE_NO";
        cmd.Parameters.AddWithValue("@P", parentCode.Trim());
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new BomLineRow
            {
                ParentCode = parentCode.Trim(),
                LineNo = Convert.ToInt32(rd[0]),
                LineKind = Convert.ToInt16(rd[1]),
                ComponentCode = (rd[2]?.ToString() ?? "").Trim(),
                Qty = ToDecimal(rd[3]),
                Um = (rd[4]?.ToString() ?? "").Trim(),
                Gestiune = (rd[5]?.ToString() ?? "").Trim(),
                DenTip = (rd[6]?.ToString() ?? "").Trim()
            });
        }

        return list;
    }

    public void UpsertArticle(FbConnection conn, BomArticleRow a)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
UPDATE OR INSERT INTO SP_BOM_ARTICLE (CODE, NAME, UM, TVA, CATEGORIE, PRET_VANZ, UPDATED_AT)
VALUES (@CODE, @NAME, @UM, @TVA, @CATEGORIE, @PRET_VANZ, CURRENT_TIMESTAMP)
MATCHING (CODE)";
        cmd.Parameters.AddWithValue("@CODE", a.Code.Trim());
        cmd.Parameters.AddWithValue("@NAME", DbOr(a.Name));
        cmd.Parameters.AddWithValue("@UM", DbOr(a.Um));
        cmd.Parameters.AddWithValue("@TVA", a.Tva);
        cmd.Parameters.AddWithValue("@CATEGORIE", DbOr(a.Categorie));
        cmd.Parameters.AddWithValue("@PRET_VANZ", a.PretVanz);
        cmd.ExecuteNonQuery();
    }

    public void DeleteArticle(FbConnection conn, string code)
    {
        if (string.IsNullOrWhiteSpace(code))
            return;

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = "DELETE FROM SP_BOM_LINE WHERE PARENT_CODE = @P";
            cmd.Parameters.AddWithValue("@P", code.Trim());
            cmd.ExecuteNonQuery();
        }

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = "DELETE FROM SP_BOM_ARTICLE WHERE CODE = @C";
            cmd.Parameters.AddWithValue("@C", code.Trim());
            cmd.ExecuteNonQuery();
        }
    }

    public void ReplaceLines(FbConnection conn, string parentCode, IReadOnlyList<BomLineRow> lines)
    {
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = "DELETE FROM SP_BOM_LINE WHERE PARENT_CODE = @P";
            cmd.Parameters.AddWithValue("@P", parentCode.Trim());
            cmd.ExecuteNonQuery();
        }

        var no = 1;
        foreach (var line in lines.OrderBy(l => l.LineNo))
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
INSERT INTO SP_BOM_LINE (PARENT_CODE, LINE_NO, LINE_KIND, COMPONENT_CODE, QTY, UM, GESTIUNE, DEN_TIP, UPDATED_AT)
VALUES (@PARENT, @NO, @KIND, @COMP, @QTY, @UM, @GEST, @TIP, CURRENT_TIMESTAMP)";
            cmd.Parameters.AddWithValue("@PARENT", parentCode.Trim());
            cmd.Parameters.AddWithValue("@NO", no++);
            cmd.Parameters.AddWithValue("@KIND", line.LineKind);
            cmd.Parameters.AddWithValue("@COMP", line.ComponentCode.Trim());
            cmd.Parameters.AddWithValue("@QTY", line.Qty);
            cmd.Parameters.AddWithValue("@UM", DbOr(line.Um));
            cmd.Parameters.AddWithValue("@GEST", DbOr(line.Gestiune));
            cmd.Parameters.AddWithValue("@TIP", DbOr(line.DenTip));
            cmd.ExecuteNonQuery();
        }
    }

    /// <summary>Numele articolului din cache-ul sincronizat SAGA (SP_SAGA_ARTICOLE).</summary>
    public string? TryGetSagaArticleName(FbConnection conn, string code)
    {
        if (string.IsNullOrWhiteSpace(code))
            return null;
        if (!TableExists(conn, "SP_SAGA_ARTICOLE"))
            return null;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT TRIM(NAME) FROM SP_SAGA_ARTICOLE WHERE CODE = @C ROWS 1";
        cmd.Parameters.AddWithValue("@C", code.Trim());
        var o = cmd.ExecuteScalar();
        var s = o?.ToString()?.Trim();
        return string.IsNullOrEmpty(s) ? null : s;
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static object DbOr(string? v)
        => string.IsNullOrWhiteSpace(v) ? DBNull.Value : v.Trim();

    private static decimal ToDecimal(object? v)
        => v == null || v == DBNull.Value ? 0m : Convert.ToDecimal(v);
}

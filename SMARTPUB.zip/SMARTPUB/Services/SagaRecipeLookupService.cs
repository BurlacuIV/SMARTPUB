using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

/// <summary>Liste pentru combobox-uri rețetă (din date sincronizate SAGA).</summary>
public sealed class SagaRecipeLookupService
{
    public List<GestiuneComboOption> ListGestiuni(FbConnection conn)
    {
        var list = new List<GestiuneComboOption>();
        if (!TableExists(conn, "SP_SAGA_GESTIUNI"))
            return list;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT TRIM(CODE), TRIM(COALESCE(NAME, ''))
FROM SP_SAGA_GESTIUNI
ORDER BY CODE";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var code = (rd[0]?.ToString() ?? "").Trim();
            if (string.IsNullOrEmpty(code))
                continue;
            var name = (rd[1]?.ToString() ?? "").Trim();
            list.Add(new GestiuneComboOption(code, string.IsNullOrEmpty(name) ? code : $"{code} — {name}"));
        }

        return list;
    }

    /// <summary>Valori Tip / DEN_TIP: catalog SAGA, articole sincronizate, linii rețetă.</summary>
    public List<string> ListDistinctTip(FbConnection conn)
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var p in SagaArticoleTipCatalog.ToPresetList())
            set.Add(p);

        SagaArticoleSchemaExtensions.EnsureExtendedColumns(conn);
        if (TableExists(conn, "SP_SAGA_ARTICOLE") && ColumnExists(conn, "SP_SAGA_ARTICOLE", "DEN_TIP"))
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
SELECT DISTINCT TRIM(DEN_TIP) FROM SP_SAGA_ARTICOLE
WHERE TRIM(COALESCE(DEN_TIP,'')) <> ''";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var s = (rd[0]?.ToString() ?? "").Trim();
                if (!string.IsNullOrEmpty(s))
                    set.Add(s);
            }
        }

        if (TableExists(conn, "SP_SAGA_RECIPE_LINES"))
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
SELECT DISTINCT TRIM(TIP) FROM SP_SAGA_RECIPE_LINES
WHERE TRIM(COALESCE(TIP,'')) <> ''";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var s = (rd[0]?.ToString() ?? "").Trim();
                if (!string.IsNullOrEmpty(s))
                    set.Add(s);
            }
        }

        return set.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
    }

    /// <summary>Grupuri / categorii articole pentru filtrare (GRUPA + CATEGORIE distincte).</summary>
    public List<string> ListDistinctGrupa(FbConnection conn)
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (!TableExists(conn, "SP_SAGA_ARTICOLE"))
            return set.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();

        SagaArticoleSchemaExtensions.EnsureExtendedColumns(conn);

        var hasGrupa = ColumnExists(conn, "SP_SAGA_ARTICOLE", "GRUPA");
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
SELECT DISTINCT TRIM(COALESCE(CATEGORIE,''))
FROM SP_SAGA_ARTICOLE
WHERE TRIM(COALESCE(CATEGORIE,'')) <> ''";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var s = (rd[0]?.ToString() ?? "").Trim();
                if (!string.IsNullOrEmpty(s))
                    set.Add(s);
            }
        }

        if (hasGrupa)
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
SELECT DISTINCT TRIM(COALESCE(GRUPA,''))
FROM SP_SAGA_ARTICOLE
WHERE TRIM(COALESCE(GRUPA,'')) <> ''";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var s = (rd[0]?.ToString() ?? "").Trim();
                if (!string.IsNullOrEmpty(s))
                    set.Add(s);
            }
        }

        return set.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
    }

    /// <summary>Toate grupele din lookup (SP_SAGA_GRUPARI) + coduri folosite la articole fără denumire; pentru combobox „cod — denumire”.</summary>
    public List<GrupaComboOption> ListGrupaComboOptions(FbConnection conn)
    {
        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        if (TableExists(conn, "SP_SAGA_GRUPARI"))
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
SELECT TRIM(CODE), TRIM(COALESCE(NAME, ''))
FROM SP_SAGA_GRUPARI
ORDER BY TRIM(CODE)";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var code = (rd[0]?.ToString() ?? "").Trim();
                if (string.IsNullOrEmpty(code))
                    continue;
                var name = (rd[1]?.ToString() ?? "").Trim();
                map[code] = name;
            }
        }

        SagaArticoleSchemaExtensions.EnsureExtendedColumns(conn);
        if (TableExists(conn, "SP_SAGA_ARTICOLE") && ColumnExists(conn, "SP_SAGA_ARTICOLE", "GRUPA"))
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
SELECT DISTINCT TRIM(COALESCE(GRUPA, ''))
FROM SP_SAGA_ARTICOLE
WHERE TRIM(COALESCE(GRUPA, '')) <> ''";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var code = (rd[0]?.ToString() ?? "").Trim();
                if (string.IsNullOrEmpty(code))
                    continue;
                if (!map.ContainsKey(code))
                    map[code] = "";
            }
        }

        return map
            .OrderBy(kv => kv.Key, StringComparer.OrdinalIgnoreCase)
            .Select(kv => new GrupaComboOption(kv.Key, kv.Value))
            .ToList();
    }

    public List<RecipeArticolePickRow> ListArticole(FbConnection conn, string? grupaFilter)
    {
        var list = new List<RecipeArticolePickRow>();
        if (!TableExists(conn, "SP_SAGA_ARTICOLE"))
            return list;

        SagaArticoleSchemaExtensions.EnsureExtendedColumns(conn);
        var hasGrupa = ColumnExists(conn, "SP_SAGA_ARTICOLE", "GRUPA");

        using var cmd = conn.CreateCommand();
        var sql = hasGrupa
            ? @"
SELECT TRIM(CODE), TRIM(NAME), TRIM(UM), TRIM(COALESCE(CATEGORIE,'')), TRIM(COALESCE(GRUPA,''))
FROM SP_SAGA_ARTICOLE
WHERE COALESCE(IS_BLOCKED,0) = 0"
            : @"
SELECT TRIM(CODE), TRIM(NAME), TRIM(UM), TRIM(COALESCE(CATEGORIE,'')), ''
FROM SP_SAGA_ARTICOLE
WHERE COALESCE(IS_BLOCKED,0) = 0";

        var term = (grupaFilter ?? "").Trim();
        if (!string.IsNullOrEmpty(term))
        {
            sql += hasGrupa
                ? " AND (TRIM(COALESCE(CATEGORIE,'')) = @G OR TRIM(COALESCE(GRUPA,'')) = @G)"
                : " AND TRIM(COALESCE(CATEGORIE,'')) = @G";
            cmd.Parameters.AddWithValue("@G", term);
        }

        sql += " ORDER BY NAME";
        cmd.CommandText = sql;

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new RecipeArticolePickRow
            {
                Code = (rd[0]?.ToString() ?? "").Trim(),
                Name = (rd[1]?.ToString() ?? "").Trim(),
                Um = (rd[2]?.ToString() ?? "").Trim(),
                Categorie = (rd[3]?.ToString() ?? "").Trim(),
                Grupa = (rd[4]?.ToString() ?? "").Trim()
            });
        }

        return list;
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static bool ColumnExists(FbConnection conn, string table, string column)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATION_FIELDS
WHERE TRIM(RDB$RELATION_NAME) = @T AND TRIM(RDB$FIELD_NAME) = @C ROWS 1";
        cmd.Parameters.AddWithValue("@T", table.Trim().ToUpperInvariant());
        cmd.Parameters.AddWithValue("@C", column.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

public sealed class GestiuneComboOption
{
    public GestiuneComboOption(string code, string display)
    {
        Code = code;
        Display = display;
    }

    public string Code { get; }
    public string Display { get; }
}

/// <summary>Grupă articol: cod SAGA + denumire din GRUPE/GRUPARI sincronizate.</summary>
public sealed class GrupaComboOption
{
    public GrupaComboOption(string code, string name)
    {
        Code = code ?? "";
        Name = name ?? "";
    }

    public string Code { get; }
    public string Name { get; }

    public string Display =>
        string.IsNullOrWhiteSpace(Name) ? Code : $"{Code} — {Name}";

    public override string ToString() => Display;

    /// <summary>Extrage codul din textul combobox-ului editabil (ex. „100.03 — VINURI” → „100.03”).</summary>
    public static string ExtractCodeFromEditorText(string? text)
    {
        var t = (text ?? "").Trim();
        if (string.IsNullOrEmpty(t))
            return "";
        const string sep = " — ";
        var i = t.IndexOf(sep, StringComparison.Ordinal);
        return i > 0 ? t[..i].Trim() : t;
    }
}

public sealed class RecipeArticolePickRow
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Um { get; set; } = "";
    public string Categorie { get; set; } = "";
    public string Grupa { get; set; } = "";

    public string Label => string.IsNullOrWhiteSpace(Code) ? Name : $"{Name} ({Code})";
}

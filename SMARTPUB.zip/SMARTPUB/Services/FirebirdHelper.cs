using System.IO;
using System.Globalization;
using System.Collections.Generic;
using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public static class FirebirdHelper
{
    private const string PLAN_TABEL = "CONTURI";
    private const string PLAN_COL_CONT = "CONT";
    private const string SAGA_CHARSET = "UTF8";

    private static readonly Dictionary<string, string> WorkingClientByDbPath =
        new(StringComparer.OrdinalIgnoreCase);

    public static string BuildConnectionString(string dbPath, string? preferredFbClientPath = null)
    {
        if (string.IsNullOrWhiteSpace(dbPath))
            throw new ArgumentException("dbPath gol.", nameof(dbPath));
        if (!File.Exists(dbPath))
            throw new FileNotFoundException("FDB nu există.", dbPath);

        var fbClientPath = ResolveWorkingFbClientPath(dbPath, preferredFbClientPath);

        var cs = new FbConnectionStringBuilder
        {
            Database = dbPath,
            UserID = "SYSDBA",
            Password = "masterkey",
            ServerType = FbServerType.Embedded,
            ClientLibrary = fbClientPath,
            Pooling = false,
            Dialect = 3,
            Charset = SAGA_CHARSET
        };

        return cs.ToString();
    }

    public static string BuildEmbeddedConnectionString(string dbPath) => BuildConnectionString(dbPath);

    public static FbConnection OpenEmbedded(string dbPath, string? preferredFbClientPath = null)
    {
        var con = new FbConnection(BuildConnectionString(dbPath, preferredFbClientPath));
        con.Open();
        return con;
    }

    public static FbConnection CreateEmbedded(string dbPath, string fbClientPath) =>
        OpenEmbedded(dbPath, fbClientPath);

    private static string ResolveWorkingFbClientPath(string dbPath, string? preferredFbClientPath)
    {
        var cacheKey = dbPath + "\0" + (preferredFbClientPath ?? "");
        if (WorkingClientByDbPath.TryGetValue(cacheKey, out var cached) && File.Exists(cached))
            return cached;

        var candidates = new List<string>();
        var pref = (preferredFbClientPath ?? "").Trim();
        if (pref.Length > 0 && File.Exists(pref))
            candidates.Add(pref);
        foreach (var c in FirebirdClientLocator.GetSagaEmbeddedProbeOrder())
        {
            if (candidates.Exists(x => string.Equals(x, c, StringComparison.OrdinalIgnoreCase)))
                continue;
            candidates.Add(c);
        }

        var errors = new List<string>();

        foreach (var fbClient in candidates)
        {
            try
            {
                var cs = new FbConnectionStringBuilder
                {
                    Database = dbPath,
                    UserID = "SYSDBA",
                    Password = "masterkey",
                    ServerType = FbServerType.Embedded,
                    ClientLibrary = fbClient,
                    Pooling = false,
                    Dialect = 3,
                    Charset = SAGA_CHARSET
                };

                using var probe = new FbConnection(cs.ToString());
                probe.Open();
                WorkingClientByDbPath[cacheKey] = fbClient;
                return fbClient;
            }
            catch (Exception ex)
            {
                errors.Add($"{fbClient} -> {ex.Message}");
            }
        }

        throw new InvalidOperationException(
            "Nu s-a găsit un fbclient.dll compatibil pentru baza SAGA.\n" +
            string.Join("\n", errors));
    }

    // ── Scalar helpers ──

    public static int ScalarInt(
        FbConnection conn, string sql,
        Action<FbCommand>? bind = null,
        FbTransaction? tx = null)
    {
        using var cmd = new FbCommand(sql, conn, tx);
        bind?.Invoke(cmd);
        var obj = cmd.ExecuteScalar();
        return obj == null || obj == DBNull.Value ? 0 : Convert.ToInt32(obj);
    }

    public static long ScalarLong(
        FbConnection conn, string sql,
        Action<FbCommand>? bind = null,
        FbTransaction? tx = null)
    {
        using var cmd = new FbCommand(sql, conn, tx);
        bind?.Invoke(cmd);
        var obj = cmd.ExecuteScalar();
        return obj == null || obj == DBNull.Value ? 0 : Convert.ToInt64(obj);
    }

    public static string? ScalarString(
        FbConnection conn, string sql,
        Action<FbCommand>? bind = null,
        FbTransaction? tx = null,
        bool trim = true)
    {
        using var cmd = new FbCommand(sql, conn, tx);
        bind?.Invoke(cmd);
        var obj = cmd.ExecuteScalar();
        if (obj == null || obj == DBNull.Value) return null;

        var s = obj.ToString();
        if (s == null) return null;
        return trim ? s.Trim() : s;
    }

    public static void Exec(
        FbConnection conn, string sql,
        Action<FbCommand>? bind = null,
        FbTransaction? tx = null)
    {
        using var cmd = new FbCommand(sql, conn, tx);
        bind?.Invoke(cmd);
        cmd.ExecuteNonQuery();
    }

    // ── NewId (SAGA: NEW_ID -> GEN_IE_SAGA fallback) ──

    public static long NewId(FbConnection conn, FbTransaction tx)
    {
        try
        {
            using var cmd = new FbCommand("SELECT NEW_ID FROM RDB$DATABASE", conn, tx);
            var x = cmd.ExecuteScalar();
            if (x != null && x != DBNull.Value)
                return Convert.ToInt64(x);
        }
        catch { }

        EnsureGenerator(conn, tx, "GEN_IE_SAGA");

        using (var cmd = new FbCommand("SELECT CAST(GEN_ID(GEN_IE_SAGA, 1) AS BIGINT) FROM RDB$DATABASE", conn, tx))
        {
            var x = cmd.ExecuteScalar();
            if (x != null && x != DBNull.Value)
                return Convert.ToInt64(x);
        }

        using var cmd2 = new FbCommand("SELECT COALESCE(MAX(RDB$RELATION_ID),0)+1 FROM RDB$RELATIONS", conn, tx);
        return Convert.ToInt64(cmd2.ExecuteScalar() ?? 1);
    }

    public static long NewId(
        FbConnection conn, FbTransaction tx,
        string generatorName, string tableName, string columnName,
        bool ensureGenerator = false)
    {
        if (ensureGenerator)
            EnsureGenerator(conn, tx, generatorName);

        if (GeneratorExists(conn, tx, generatorName))
        {
            try
            {
                using var cmd = new FbCommand(
                    $"SELECT CAST(GEN_ID({generatorName}, 1) AS BIGINT) FROM RDB$DATABASE", conn, tx);
                var obj = cmd.ExecuteScalar();
                if (obj != null && obj != DBNull.Value)
                    return Convert.ToInt64(obj);
            }
            catch { }
        }

        using var cmd2 = new FbCommand($"SELECT COALESCE(MAX({columnName}), 0) FROM {tableName}", conn, tx);
        var max = cmd2.ExecuteScalar();
        return Convert.ToInt64(max ?? 0) + 1;
    }

    private static bool GeneratorExists(FbConnection conn, FbTransaction tx, string genName)
    {
        using var cmd = new FbCommand(@"
SELECT 1 FROM RDB$GENERATORS
WHERE TRIM(RDB$GENERATOR_NAME) = TRIM(@G) ROWS 1", conn, tx);
        cmd.Parameters.AddWithValue("@G", genName);
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    public static void EnsureGenerator(FbConnection conn, FbTransaction tx, string genName)
    {
        if (GeneratorExists(conn, tx, genName))
            return;

        try
        {
            using var cmd = new FbCommand($"CREATE SEQUENCE {genName}", conn, tx);
            cmd.ExecuteNonQuery();
        }
        catch
        {
            using var cmd2 = new FbCommand($"CREATE GENERATOR {genName}", conn, tx);
            cmd2.ExecuteNonQuery();
        }
    }

    // ── REGISTRU: ID_NOTA ──

    public static long GetNextIdNota(FbConnection conn, FbTransaction tx)
    {
        const string gen = "GEN_REGISTRU_ID_NOTA";

        if (GeneratorExists(conn, tx, gen))
        {
            try
            {
                using var cmd = new FbCommand(
                    $"SELECT CAST(GEN_ID({gen}, 1) AS BIGINT) FROM RDB$DATABASE", conn, tx);
                var obj = cmd.ExecuteScalar();
                if (obj != null && obj != DBNull.Value)
                    return Convert.ToInt64(obj);
            }
            catch { }
        }

        using var cmd2 = new FbCommand("SELECT COALESCE(MAX(ID_NOTA),0)+1 FROM REGISTRU", conn, tx);
        return Convert.ToInt64(cmd2.ExecuteScalar() ?? 1);
    }

    // ── BONURI: ID ──

    public static long GetNextBonuriId(FbConnection conn, FbTransaction tx)
    {
        const string gen = "GEN_BONURI_ID";

        if (GeneratorExists(conn, tx, gen))
        {
            try
            {
                using var cmd = new FbCommand(
                    $"SELECT CAST(GEN_ID({gen}, 1) AS BIGINT) FROM RDB$DATABASE", conn, tx);
                var obj = cmd.ExecuteScalar();
                if (obj != null && obj != DBNull.Value)
                    return Convert.ToInt64(obj);
            }
            catch { }
        }

        using var cmd2 = new FbCommand("SELECT COALESCE(MAX(ID),0)+1 FROM BONURI", conn, tx);
        return Convert.ToInt64(cmd2.ExecuteScalar() ?? 1);
    }

    // ── CONTURI ──

    public static bool ContExista(FbConnection conn, string? cont, FbTransaction? tx = null)
    {
        if (string.IsNullOrWhiteSpace(cont)) return false;

        var sql = $@"
SELECT COUNT(*) FROM {PLAN_TABEL}
WHERE TRIM({PLAN_COL_CONT}) = TRIM(@c)";

        return ScalarInt(conn, sql, cmd => cmd.Parameters.AddWithValue("@c", cont), tx) > 0;
    }

    public static void EnsureCont(
        FbConnection conn, FbTransaction tx,
        string? cont, string? denumire = null, string? codValuta = null)
    {
        if (string.IsNullOrWhiteSpace(cont)) return;
        var c = cont.Trim();

        using var cmd = new FbCommand(@"
INSERT INTO CONTURI (CONT, DENUMIRE, COD_VALUTA, BLOCAT)
SELECT @c, @d, @v, 0 FROM RDB$DATABASE
WHERE NOT EXISTS (SELECT 1 FROM CONTURI WHERE CONT = @c)", conn, tx);

        cmd.Parameters.Add("@c", FbDbType.VarChar).Value = c;
        cmd.Parameters.Add("@d", FbDbType.VarChar).Value = denumire ?? c;
        cmd.Parameters.Add("@v", FbDbType.VarChar).Value =
            string.IsNullOrWhiteSpace(codValuta) ? DBNull.Value : codValuta;

        cmd.ExecuteNonQuery();
    }

    // ── MASTERS (FULL) ──

    public static void EnsureClient(FbConnection conn, FbTransaction tx, ClientRow c)
    {
        if (c == null || string.IsNullOrWhiteSpace(c.COD)) return;

        using (var chk = new FbCommand("SELECT 1 FROM CLIENTI WHERE COD=@c ROWS 1", conn, tx))
        {
            chk.Parameters.Add("@c", FbDbType.VarChar).Value = c.COD;
            var v = chk.ExecuteScalar();
            if (v != null && v != DBNull.Value) return;
        }

        using var cmd = new FbCommand(@"
INSERT INTO CLIENTI (
  COD, DENUMIRE, COD_FISCAL, REG_COM, ANALITIC, ZS, DISCOUNT,
  ADRESA, JUDET, BANCA, CONT_BANCA, FILIALA, DELEGAT,
  BI_SERIE, BI_NUMAR, BI_POL, MASINA, INF_SUPL,
  AGENT, DEN_AGENT, GRUPA, TIP_TERT, TARA, TEL, EMAIL,
  IS_TVA, BLOCAT, DATA_V_TVA, CB_CARD, DATA_S_TVA, C_LIMIT,
  LOCALITATE, COD_POST, IS_EFACT, ID_EFACT, C_SAFT
) VALUES (
  @COD, @DENUMIRE, @COD_FISCAL, @REG_COM, @ANALITIC, @ZS, @DISCOUNT,
  @ADRESA, @JUDET, @BANCA, @CONT_BANCA, @FILIALA, @DELEGAT,
  @BI_SERIE, @BI_NUMAR, @BI_POL, @MASINA, @INF_SUPL,
  @AGENT, @DEN_AGENT, @GRUPA, @TIP_TERT, @TARA, @TEL, @EMAIL,
  @IS_TVA, @BLOCAT, @DATA_V_TVA, @CB_CARD, @DATA_S_TVA, @C_LIMIT,
  @LOCALITATE, @COD_POST, @IS_EFACT, @ID_EFACT, @C_SAFT
)", conn, tx);

        cmd.Parameters.Add("@COD", FbDbType.VarChar, 8).Value = FitOrCut(c.COD, 8);
        cmd.Parameters.Add("@DENUMIRE", FbDbType.VarChar, 64).Value = FitOrCut(c.DENUMIRE, 64);
        cmd.Parameters.Add("@COD_FISCAL", FbDbType.VarChar, 16).Value = DbNull(FitOrCutNull(c.COD_FISCAL, 16));
        cmd.Parameters.Add("@REG_COM", FbDbType.VarChar, 20).Value = DbNull(FitOrCutNull(c.REG_COM, 20));
        cmd.Parameters.Add("@ANALITIC", FbDbType.VarChar, 20).Value = DbNull(FitOrCutNull(c.ANALITIC, 20));
        cmd.Parameters.Add("@ZS", FbDbType.SmallInt).Value = c.ZS;
        cmd.Parameters.Add("@DISCOUNT", FbDbType.Decimal).Value = c.DISCOUNT;

        cmd.Parameters.Add("@ADRESA", FbDbType.VarChar, 80).Value = DbNull(FitOrCutNull(c.ADRESA, 80));
        cmd.Parameters.Add("@JUDET", FbDbType.VarChar, 20).Value = DbNull(FitOrCutNull(c.JUDET, 20));
        cmd.Parameters.Add("@BANCA", FbDbType.VarChar, 40).Value = DbNull(FitOrCutNull(c.BANCA, 40));
        cmd.Parameters.Add("@CONT_BANCA", FbDbType.VarChar, 34).Value = DbNull(FitOrCutNull(c.CONT_BANCA, 34));
        cmd.Parameters.Add("@FILIALA", FbDbType.VarChar, 40).Value = DbNull(FitOrCutNull(c.FILIALA, 40));
        cmd.Parameters.Add("@DELEGAT", FbDbType.VarChar, 40).Value = DbNull(FitOrCutNull(c.DELEGAT, 40));

        cmd.Parameters.Add("@BI_SERIE", FbDbType.VarChar, 10).Value = DbNull(FitOrCutNull(c.BI_SERIE, 10));
        cmd.Parameters.Add("@BI_NUMAR", FbDbType.VarChar, 10).Value = DbNull(FitOrCutNull(c.BI_NUMAR, 10));
        cmd.Parameters.Add("@BI_POL", FbDbType.VarChar, 30).Value = DbNull(FitOrCutNull(c.BI_POL, 30));
        cmd.Parameters.Add("@MASINA", FbDbType.VarChar, 20).Value = DbNull(FitOrCutNull(c.MASINA, 20));
        cmd.Parameters.Add("@INF_SUPL", FbDbType.VarChar, 250).Value = DbNull(FitOrCutNull(c.INF_SUPL, 250));

        cmd.Parameters.Add("@AGENT", FbDbType.VarChar, 4).Value = DbNull(FitOrCutNull(c.AGENT, 4));
        cmd.Parameters.Add("@DEN_AGENT", FbDbType.VarChar, 36).Value = DbNull(FitOrCutNull(c.DEN_AGENT, 36));
        cmd.Parameters.Add("@GRUPA", FbDbType.VarChar, 10).Value = DbNull(FitOrCutNull(c.GRUPA, 10));
        cmd.Parameters.Add("@TIP_TERT", FbDbType.Char, 1).Value = DbChar1Exact(c.TIP_TERT);
        cmd.Parameters.Add("@TARA", FbDbType.VarChar, 3).Value = DbNull(FitOrCutNull(c.TARA, 3));
        cmd.Parameters.Add("@TEL", FbDbType.VarChar, 30).Value = DbNull(FitOrCutNull(c.TEL, 30));
        cmd.Parameters.Add("@EMAIL", FbDbType.VarChar, 60).Value = DbNull(FitOrCutNull(c.EMAIL, 60));

        cmd.Parameters.Add("@IS_TVA", FbDbType.SmallInt).Value = c.IS_TVA;
        cmd.Parameters.Add("@BLOCAT", FbDbType.SmallInt).Value = c.BLOCAT;
        cmd.Parameters.Add("@DATA_V_TVA", FbDbType.Date).Value = (object?)c.DATA_V_TVA?.Date ?? DBNull.Value;
        cmd.Parameters.Add("@CB_CARD", FbDbType.Decimal).Value = c.CB_CARD;
        cmd.Parameters.Add("@DATA_S_TVA", FbDbType.Date).Value = (object?)c.DATA_S_TVA?.Date ?? DBNull.Value;
        cmd.Parameters.Add("@C_LIMIT", FbDbType.Decimal).Value = c.C_LIMIT;

        cmd.Parameters.Add("@LOCALITATE", FbDbType.VarChar, 30).Value = DbNull(FitOrCutNull(c.LOCALITATE, 30));
        cmd.Parameters.Add("@COD_POST", FbDbType.VarChar, 10).Value = DbNull(FitOrCutNull(c.COD_POST, 10));
        cmd.Parameters.Add("@IS_EFACT", FbDbType.SmallInt).Value = c.IS_EFACT;
        cmd.Parameters.Add("@ID_EFACT", FbDbType.VarChar, 40).Value = DbNull(FitOrCutNull(c.ID_EFACT, 40));
        cmd.Parameters.Add("@C_SAFT", FbDbType.VarChar, 40).Value = DbNull(FitOrCutNull(c.C_SAFT, 40));

        cmd.ExecuteNonQuery();
    }

    public static void EnsureArticol(FbConnection conn, FbTransaction tx, ArticolRow a)
    {
        if (a == null || string.IsNullOrWhiteSpace(a.COD)) return;

        using (var chk = new FbCommand("SELECT 1 FROM ARTICOLE WHERE COD=@c ROWS 1", conn, tx))
        {
            chk.Parameters.Add("@c", FbDbType.VarChar).Value = a.COD;
            var v = chk.ExecuteScalar();
            if (v != null && v != DBNull.Value) return;
        }

        using var cmd = new FbCommand(@"
INSERT INTO ARTICOLE (
  COD, DENUMIRE, UM, TVA, DEN_TIP, TIP,
  STOC, PRET_VANZ, PRET_V_TVA, PRET_VANZ2, PRET_V_TV2,
  IS_VALUTA, BLOCAT, PLU, COD_BARE, BRUT, CANT_MIN,
  GRUPA, TEXT_SUPL, GARANTIE, GREUTATE, OK, IS_LOT,
  COD_CER, CATEGORIE, COD_FE, COD_CPV, COD_SGR,
  VOLUM, TIP_A, TARA_ORIG, GREUTATE_B
) VALUES (
  @COD, @DENUMIRE, @UM, @TVA, @DEN_TIP, @TIP,
  @STOC, @PRET_VANZ, @PRET_V_TVA, @PRET_VANZ2, @PRET_V_TV2,
  @IS_VALUTA, @BLOCAT, @PLU, @COD_BARE, @BRUT, @CANT_MIN,
  @GRUPA, @TEXT_SUPL, @GARANTIE, @GREUTATE, @OK, @IS_LOT,
  @COD_CER, @CATEGORIE, @COD_FE, @COD_CPV, @COD_SGR,
  @VOLUM, @TIP_A, @TARA_ORIG, @GREUTATE_B
)", conn, tx);

        cmd.Parameters.Add("@COD", FbDbType.VarChar, 16).Value = FitOrCut(a.COD, 16);
        cmd.Parameters.Add("@DENUMIRE", FbDbType.VarChar, 60).Value = FitOrCut(a.DENUMIRE, 60);
        cmd.Parameters.Add("@UM", FbDbType.VarChar, 5).Value = DbNull(FitOrCutNull(a.UM, 5));
        cmd.Parameters.Add("@TVA", FbDbType.SmallInt).Value = a.TVA;
        cmd.Parameters.Add("@DEN_TIP", FbDbType.VarChar, 36).Value = DbNull(FitOrCutNull(a.DEN_TIP, 36));
        cmd.Parameters.Add("@TIP", FbDbType.VarChar, 1).Value = DbNull(FitOrCutNull(a.TIP, 1));

        cmd.Parameters.Add("@STOC", FbDbType.Decimal).Value = (object?)a.STOC ?? DBNull.Value;
        cmd.Parameters.Add("@PRET_VANZ", FbDbType.Decimal).Value = (object?)a.PRET_VANZ ?? DBNull.Value;
        cmd.Parameters.Add("@PRET_V_TVA", FbDbType.Decimal).Value = (object?)a.PRET_V_TVA ?? DBNull.Value;
        cmd.Parameters.Add("@PRET_VANZ2", FbDbType.Decimal).Value = (object?)a.PRET_VANZ2 ?? DBNull.Value;
        cmd.Parameters.Add("@PRET_V_TV2", FbDbType.Decimal).Value = (object?)a.PRET_V_TV2 ?? DBNull.Value;

        cmd.Parameters.Add("@IS_VALUTA", FbDbType.SmallInt).Value = a.IS_VALUTA;
        cmd.Parameters.Add("@BLOCAT", FbDbType.SmallInt).Value = a.BLOCAT;

        cmd.Parameters.Add("@PLU", FbDbType.VarChar, 20).Value = DbNull(FitOrCutNull(a.PLU.ToString(CultureInfo.InvariantCulture), 20));
        cmd.Parameters.Add("@COD_BARE", FbDbType.VarChar, 30).Value = DbNull(FitOrCutNull(a.COD_BARE.ToString(CultureInfo.InvariantCulture), 30));

        cmd.Parameters.Add("@BRUT", FbDbType.Decimal).Value = (object?)a.BRUT ?? DBNull.Value;
        cmd.Parameters.Add("@CANT_MIN", FbDbType.Decimal).Value = (object?)a.CANT_MIN ?? DBNull.Value;

        cmd.Parameters.Add("@GRUPA", FbDbType.VarChar, 10).Value = DbNull(FitOrCutNull(a.GRUPA, 10));
        cmd.Parameters.Add("@TEXT_SUPL", FbDbType.VarChar, 240).Value = DbNull(FitOrCutNull(a.TEXT_SUPL, 240));

        cmd.Parameters.Add("@GARANTIE", FbDbType.Integer).Value = a.GARANTIE;
        cmd.Parameters.Add("@GREUTATE", FbDbType.Decimal).Value = (object?)a.GREUTATE ?? DBNull.Value;
        cmd.Parameters.Add("@OK", FbDbType.SmallInt).Value = a.OK;
        cmd.Parameters.Add("@IS_LOT", FbDbType.SmallInt).Value = a.IS_LOT;

        cmd.Parameters.Add("@COD_CER", FbDbType.VarChar, 10).Value = DbNull(FitOrCutNull(a.COD_CER, 10));
        cmd.Parameters.Add("@CATEGORIE", FbDbType.VarChar, 16).Value = DbNull(FitOrCutNull(a.CATEGORIE, 16));
        cmd.Parameters.Add("@COD_FE", FbDbType.VarChar, 16).Value = DbNull(FitOrCutNull(a.COD_FE, 16));
        cmd.Parameters.Add("@COD_CPV", FbDbType.VarChar, 16).Value = DbNull(FitOrCutNull(a.COD_CPV, 16));
        cmd.Parameters.Add("@COD_SGR", FbDbType.VarChar, 16).Value = DbNull(FitOrCutNull(a.COD_SGR, 16));

        cmd.Parameters.Add("@VOLUM", FbDbType.Decimal).Value = (object?)a.VOLUM ?? DBNull.Value;
        cmd.Parameters.Add("@TIP_A", FbDbType.VarChar, 1).Value = DbNull(FitOrCutNull(a.TIP_A, 1));
        cmd.Parameters.Add("@TARA_ORIG", FbDbType.VarChar, 3).Value = DbNull(FitOrCutNull(a.TARA_ORIG, 3));
        cmd.Parameters.Add("@GREUTATE_B", FbDbType.Decimal).Value = (object?)a.GREUTATE_B ?? DBNull.Value;

        cmd.ExecuteNonQuery();
    }

    public static void EnsureGestiune(FbConnection conn, FbTransaction tx, GestiuneRow g)
    {
        if (g == null || string.IsNullOrWhiteSpace(g.COD)) return;

        using (var chk = new FbCommand("SELECT 1 FROM GESTIUNI WHERE COD=@c ROWS 1", conn, tx))
        {
            chk.Parameters.Add("@c", FbDbType.VarChar).Value = g.COD;
            var v = chk.ExecuteScalar();
            if (v != null && v != DBNull.Value) return;
        }

        using var cmd = new FbCommand(@"
INSERT INTO GESTIUNI (
  COD, DENUMIRE, GESTIONAR, TIP_EVAL,
  GLOB_371, GLOB_378, GLOB_707, GLOB_4428, GLOB_607,
  PROCTVA, CATEGORIE
) VALUES (
  @COD, @DENUMIRE, @GESTIONAR, @TIP_EVAL,
  @G371, @G378, @G707, @G4428, @G607,
  @PROCTVA, @CATEG
)", conn, tx);

        cmd.Parameters.Add("@COD", FbDbType.VarChar, 4).Value = FitOrCut(g.COD, 4);
        cmd.Parameters.Add("@DENUMIRE", FbDbType.VarChar, 24).Value = FitOrCut(g.DENUMIRE, 24);
        cmd.Parameters.Add("@GESTIONAR", FbDbType.VarChar, 40).Value = DbNull(FitOrCutNull(g.GESTIONAR, 40));
        cmd.Parameters.Add("@TIP_EVAL", FbDbType.SmallInt).Value = g.TIP_EVAL;

        cmd.Parameters.Add("@G371", FbDbType.VarChar, 20).Value = DbNull(FitOrCutNull(g.GLOB_371, 20));
        cmd.Parameters.Add("@G378", FbDbType.VarChar, 20).Value = DbNull(FitOrCutNull(g.GLOB_378, 20));
        cmd.Parameters.Add("@G707", FbDbType.VarChar, 20).Value = DbNull(FitOrCutNull(g.GLOB_707, 20));
        cmd.Parameters.Add("@G4428", FbDbType.VarChar, 20).Value = DbNull(FitOrCutNull(g.GLOB_4428, 20));
        cmd.Parameters.Add("@G607", FbDbType.VarChar, 20).Value = DbNull(FitOrCutNull(g.GLOB_607, 20));

        cmd.Parameters.Add("@PROCTVA", FbDbType.Decimal).Value = g.PROCTVA;
        cmd.Parameters.Add("@CATEG", FbDbType.VarChar, 16).Value = DbNull(FitOrCutNull(g.CATEGORIE, 16));

        cmd.ExecuteNonQuery();
    }

    public static object DbChar1Exact(string? s)
    {
        if (s is null) return DBNull.Value;
        if (s.Length == 0) return " ";
        return s.Length == 1 ? s : s.Substring(0, 1);
    }

    // ── REGISTRU CASA CHECK ──

    public static (int Cnt, decimal SumaTot, decimal SumaValTot, long Fingerprint) CheckRegistruCasa(
        FbConnection conn, DateTime d1, DateTime d2, FbTransaction? tx = null)
    {
        const string sql = @"
SELECT count(*) as cnt,
       sum(coalesce(suma,0)) as suma_tot,
       sum(coalesce(suma_val,0)) as suma_val_tot,
       sum(ascii_val(coalesce(tip,' ')) * 1000000
         + ascii_val(substring(coalesce(cont_d,'') from 1 for 1)) * 10000
         + ascii_val(substring(coalesce(cont_c,'') from 1 for 1)) * 100
       ) as fingerprint_hint
FROM registru
WHERE (cont_d starting with '531' or cont_c starting with '531')
  AND data between @d1 and @d2";

        using var cmd = new FbCommand(sql, conn, tx);
        cmd.Parameters.Add("@d1", FbDbType.Date).Value = d1.Date;
        cmd.Parameters.Add("@d2", FbDbType.Date).Value = d2.Date;

        using var rd = cmd.ExecuteReader();
        if (!rd.Read())
            return (0, 0m, 0m, 0L);

        int cnt = rd["cnt"] == DBNull.Value ? 0 : Convert.ToInt32(rd["cnt"]);
        decimal sumaTot = rd["suma_tot"] == DBNull.Value ? 0m : Convert.ToDecimal(rd["suma_tot"]);
        decimal sumaValTot = rd["suma_val_tot"] == DBNull.Value ? 0m : Convert.ToDecimal(rd["suma_val_tot"]);
        long fp = rd["fingerprint_hint"] == DBNull.Value ? 0L : Convert.ToInt64(rd["fingerprint_hint"]);

        return (cnt, sumaTot, sumaValTot, fp);
    }

    // ── String helpers ──

    private static object DbNull(string? s) => string.IsNullOrWhiteSpace(s) ? DBNull.Value : s;

    private static string FitOrCut(string? s, int maxLen)
    {
        s ??= "";
        s = s.Trim();
        return s.Length <= maxLen ? s : s.Substring(0, maxLen);
    }

    private static string? FitOrCutNull(string? s, int maxLen)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        s = s.Trim();
        return s.Length <= maxLen ? s : s.Substring(0, maxLen);
    }
}

using System.Collections.Generic;
using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

/// <summary>Mapare gestiune SAGA → imprimantă Windows (setări locale, nu se suprascrie la sync).</summary>
public sealed class PosGestiunePrinterRepository
{
    public void EnsureSchema(FbConnection conn)
    {
        if (TableExists(conn, "SP_POS_GESTIUNE_PRINTER"))
            return;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
CREATE TABLE SP_POS_GESTIUNE_PRINTER (
    GESTIUNE_CODE VARCHAR(24) NOT NULL,
    PRINTER_NAME VARCHAR(260),
    UPDATED_AT TIMESTAMP,
    PRIMARY KEY (GESTIUNE_CODE)
)";
        cmd.ExecuteNonQuery();
    }

    /// <summary>Cod gestiune (trim) → nume imprimantă.</summary>
    public Dictionary<string, string> LoadMap(FbConnection conn)
    {
        EnsureSchema(conn);
        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT TRIM(GESTIUNE_CODE), TRIM(COALESCE(PRINTER_NAME, ''))
FROM SP_POS_GESTIUNE_PRINTER";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var code = (rd[0]?.ToString() ?? "").Trim();
            var printer = (rd[1]?.ToString() ?? "").Trim();
            if (code.Length > 0 && printer.Length > 0)
                map[code] = printer;
        }

        return map;
    }

    public void SavePrinter(FbConnection conn, string gestiuneCode, string? printerName)
    {
        EnsureSchema(conn);
        var code = (gestiuneCode ?? "").Trim();
        if (code.Length == 0)
            return;

        var printer = (printerName ?? "").Trim();
        using var cmd = conn.CreateCommand();
        if (printer.Length == 0)
        {
            cmd.CommandText = "DELETE FROM SP_POS_GESTIUNE_PRINTER WHERE TRIM(GESTIUNE_CODE) = @C";
            cmd.Parameters.AddWithValue("@C", code);
            cmd.ExecuteNonQuery();
            return;
        }

        cmd.CommandText = @"
UPDATE OR INSERT INTO SP_POS_GESTIUNE_PRINTER (GESTIUNE_CODE, PRINTER_NAME, UPDATED_AT)
VALUES (@C, @P, CURRENT_TIMESTAMP)
MATCHING (GESTIUNE_CODE)";
        cmd.Parameters.AddWithValue("@C", code);
        cmd.Parameters.AddWithValue("@P", Truncate(printer, 260));
        cmd.ExecuteNonQuery();
    }

    /// <summary>Cod articol → cod gestiune (din SP_SAGA_ARTICOLE).</summary>
    public static Dictionary<string, string> LoadArticleGestiuni(FbConnection conn, IEnumerable<string> productCodes)
    {
        var codes = productCodes
            .Select(c => (c ?? "").Trim())
            .Where(c => c.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (codes.Count == 0 || !TableExists(conn, "SP_SAGA_ARTICOLE"))
            return map;

        if (!ColumnExists(conn, "SP_SAGA_ARTICOLE", "GESTIUNE"))
            return map;

        const int batch = 80;
        for (var i = 0; i < codes.Count; i += batch)
        {
            var chunk = codes.Skip(i).Take(batch).ToList();
            var placeholders = string.Join(",", chunk.Select((_, idx) => "@C" + idx));
            using var cmd = conn.CreateCommand();
            cmd.CommandText = $@"
SELECT TRIM(CODE), TRIM(COALESCE(GESTIUNE, ''))
FROM SP_SAGA_ARTICOLE
WHERE TRIM(CODE) IN ({placeholders})";
            for (var j = 0; j < chunk.Count; j++)
                cmd.Parameters.AddWithValue("@C" + j, chunk[j]);

            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var code = (rd[0]?.ToString() ?? "").Trim();
                var gest = (rd[1]?.ToString() ?? "").Trim();
                if (code.Length > 0)
                    map[code] = gest;
            }
        }

        return map;
    }

    private static string Truncate(string s, int max) =>
        s.Length <= max ? s : s[..max];

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static bool ColumnExists(FbConnection conn, string table, string column)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATION_FIELDS
WHERE TRIM(RDB$RELATION_NAME) = @T AND TRIM(RDB$FIELD_NAME) = @C ROWS 1";
        cmd.Parameters.AddWithValue("@T", table.Trim().ToUpperInvariant());
        cmd.Parameters.AddWithValue("@C", column.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

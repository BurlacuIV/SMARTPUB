using System.IO;

namespace SMARTPUB.Services;

/// <summary>
/// Jurnal minimal pentru acțiuni sensibile (extensibil către DB sau SIEM).
/// </summary>
public static class AuditLogService
{
    private static readonly object Gate = new();
    private static string? _path;

    public static string LogFilePath =>
        _path ??= Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "SMARTPUB",
            "audit.log");

    public static void Write(string category, string message, string? detail = null)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(LogFilePath)!);
            var line =
                $"{DateTime.UtcNow:O}\t{category}\t{message}\t{detail ?? ""}{Environment.NewLine}";
            lock (Gate)
                File.AppendAllText(LogFilePath, line);
        }
        catch
        {
            // deliberat: auditul nu blochează fluxul operațional
        }
    }
}

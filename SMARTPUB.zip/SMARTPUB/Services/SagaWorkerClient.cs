using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.Json;
using SMARTPUB;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public readonly record struct SagaWorkerProgress(int Percent, string Message);

public sealed class SagaWorkerClient
{
    private const string ProgressPrefix = "__SMARTPUB_PROGRESS__";

    public (bool Success, string? Error, string? FbClientPath, List<SagaCompany> Companies) Scan(string sagaRootPath)
    {
        var payload = Execute(null, "scan", sagaRootPath);
        return MapCompanies(payload);
    }

    /// <summary>Scanare CONFIG.FDB prin Firebird Server (cale rădăcină SAGA pe mașina serverului).</summary>
    public (bool Success, string? Error, string? FbClientPath, List<SagaCompany> Companies) ScanServer(
        string serverHost, int serverPort, string sagaRootOnServer)
    {
        var payload = Execute(null, "scansrv", serverHost, serverPort.ToString(CultureInfo.InvariantCulture), sagaRootOnServer);
        return MapCompanies(payload);
    }

    private static (bool Success, string? Error, string? FbClientPath, List<SagaCompany> Companies) MapCompanies(WorkerPayload payload)
    {
        return (
            payload.Success,
            payload.Error,
            payload.FbClientPath,
            payload.Companies.Select(c => new SagaCompany
            {
                Code = c.Code ?? "",
                Name = c.Name ?? "",
                DatabasePath = c.DatabasePath ?? "",
                IsBlocked = c.IsBlocked
            }).ToList()
        );
    }

    public (bool Success, string? Error, string? FbClientPath, string? EngineVersion) Test(
        string dbPath, string sagaRootPath, SagaConnectionMode mode,         string? serverHost = null, int serverPort = SagaConnectionDefaults.FirebirdServerPort)
    {
        WorkerPayload payload = mode == SagaConnectionMode.Server && !string.IsNullOrWhiteSpace(serverHost)
            ? Execute(null, "test", dbPath, sagaRootPath, "SERVER", serverHost.Trim(),
                serverPort.ToString(CultureInfo.InvariantCulture))
            : Execute(null, "test", dbPath, sagaRootPath);
        return (payload.Success, payload.Error, payload.FbClientPath, payload.EngineVersion);
    }

    /// <summary>Lista articolelor (preview pentru popup-ul de sincronizare).</summary>
    public (bool Success, string? Error, List<SagaArticleBrief> Articles) ListArticles(
        string dbPath, string sagaRootPath, SagaConnectionMode mode, string? serverHost = null,
        int serverPort = SagaConnectionDefaults.FirebirdServerPort)
    {
        var payload = mode == SagaConnectionMode.Server && !string.IsNullOrWhiteSpace(serverHost)
            ? Execute(null, "artlist", dbPath, sagaRootPath, "SERVER", serverHost.Trim(),
                serverPort.ToString(CultureInfo.InvariantCulture))
            : Execute(null, "artlist", dbPath, sagaRootPath);

        var list = (payload.ArticleList ?? new List<WorkerArticleBriefPayload>())
            .Select(x => new SagaArticleBrief
            {
                Code = x.Code ?? "",
                Name = x.Name ?? "",
                Um = x.Um ?? "",
                Tva = x.Tva,
                PretVanz = x.PretVanz,
                DenTip = x.DenTip ?? "",
                TipSaga = x.TipSaga ?? "",
                IsBlocked = x.IsBlocked
            })
            .ToList();
        return (payload.Success, payload.Error, list);
    }

    public (bool Success, string? Error, List<string> Accounts) ListAccounts(
        string dbPath, string sagaRootPath, SagaConnectionMode mode, string? serverHost = null,
        int serverPort = SagaConnectionDefaults.FirebirdServerPort)
    {
        var payload = mode == SagaConnectionMode.Server && !string.IsNullOrWhiteSpace(serverHost)
            ? Execute(null, "accounts", dbPath, sagaRootPath, "SERVER", serverHost.Trim(),
                serverPort.ToString(CultureInfo.InvariantCulture))
            : Execute(null, "accounts", dbPath, sagaRootPath);

        var list = (payload.AccountList ?? new List<WorkerAccountBriefPayload>())
            .Where(x => !string.IsNullOrWhiteSpace(x.Code))
            .Select(x => string.IsNullOrWhiteSpace(x.Name) ? x.Code!.Trim() : $"{x.Code!.Trim()} - {x.Name!.Trim()}")
            .ToList();
        return (payload.Success, payload.Error, list);
    }

    public (bool Success, string? Error, string? FbClientPath, SagaSyncPayload? Sync) Export(
        string dbPath, string sagaRootPath, SagaConnectionMode mode, string? serverHost = null,
        int serverPort = SagaConnectionDefaults.FirebirdServerPort,
        IReadOnlyList<string>? includeDenTip = null,
        IProgress<SagaWorkerProgress>? progress = null)
    {
        IDictionary<string, string>? env = null;
        string? filterFile = null;
        if (includeDenTip is { Count: > 0 })
        {
            // Transport prin fișier temporar (un tip pe linie) — evită problemele cu newline în variabile de mediu.
            filterFile = Path.Combine(Path.GetTempPath(), "smartpub_saga_dentip_" + Guid.NewGuid().ToString("N") + ".txt");
            File.WriteAllText(filterFile, string.Join("\n", includeDenTip), new UTF8Encoding(false));
            env = new Dictionary<string, string>
            {
                ["SAGA_INCLUDE_DENTIP_FILE"] = filterFile,
                ["SAGA_INCLUDE_DENTIP"] = string.Join("\n", includeDenTip)
            };
        }

        WorkerPayload payload;
        try
        {
            payload = mode == SagaConnectionMode.Server && !string.IsNullOrWhiteSpace(serverHost)
                ? Execute(env, progress, "export", dbPath, sagaRootPath, "SERVER", serverHost.Trim(),
                    serverPort.ToString(CultureInfo.InvariantCulture))
                : Execute(env, progress, "export", dbPath, sagaRootPath);
        }
        finally
        {
            if (filterFile != null)
            {
                try { File.Delete(filterFile); } catch { /* ignore */ }
            }
        }
        if (!payload.Success || payload.Sync == null)
            return (payload.Success, payload.Error, payload.FbClientPath, null);

        var sync = new SagaSyncPayload
        {
            Gestiuni = (payload.Sync.Gestiuni ?? []).Select(x => new SagaSyncGestiune
            {
                Code = x.Code ?? "",
                Name = x.Name ?? "",
                Gestionar = x.Gestionar ?? "",
                TipEval = x.TipEval,
                Categorie = x.Categorie ?? "",
                ProcTva = x.ProcTva
            }).ToList(),
            Grupari = (payload.Sync.Grupari ?? new List<WorkerSyncCodDenumirePayload>()).Select(x => new SagaSyncCodDenumire
            {
                Code = x.Code ?? "",
                Name = x.Name ?? ""
            }).ToList(),
            Categorii = (payload.Sync.Categorii ?? new List<WorkerSyncCodDenumirePayload>()).Select(x => new SagaSyncCodDenumire
            {
                Code = x.Code ?? "",
                Name = x.Name ?? ""
            }).ToList(),
            Articole = (payload.Sync.Articole ?? []).Select(x => new SagaSyncArticol
            {
                Code = x.Code ?? "",
                Name = x.Name ?? "",
                Um = x.Um ?? "",
                Tva = x.Tva,
                Categorie = x.Categorie ?? "",
                Grupa = x.Grupa ?? "",
                Gestiune = x.Gestiune ?? "",
                PretVanz = x.PretVanz,
                IsBlocked = x.IsBlocked,
                DenTip = x.DenTip ?? "",
                TipSaga = x.TipSaga ?? ""
            }).ToList(),
            Clienti = (payload.Sync.Clienti ?? []).Select(x => new SagaSyncClient
            {
                Code = x.Code ?? "",
                Name = x.Name ?? "",
                FiscalCode = x.FiscalCode ?? "",
                RegCom = x.RegCom ?? "",
                Phone = x.Phone ?? "",
                Email = x.Email ?? "",
                Address = x.Address ?? "",
                IsBlocked = x.IsBlocked
            }).ToList(),
            Retete = (payload.Sync.Retete ?? []).Select(x => new SagaSyncReteta
            {
                ArticolCode = x.ArticolCode ?? "",
                Operatie = x.Operatie ?? "",
                Tip = x.Tip ?? "",
                Name = x.Name ?? "",
                Um = x.Um ?? "",
                Quantity = x.Quantity,
                Gestiune = x.Gestiune ?? ""
            }).ToList(),
            ReteteDet = (payload.Sync.ReteteDet ?? []).Select(x => new SagaSyncRetetaDet
            {
                ArticolCode = x.ArticolCode ?? "",
                ComponentCode = x.ComponentCode ?? "",
                ComponentName = x.ComponentName ?? "",
                Quantity = x.Quantity,
                Um = x.Um ?? "",
                Gestiune = x.Gestiune ?? "",
                Tip = x.Tip ?? ""
            }).ToList(),
            RecipeLines = (payload.Sync.RecipeLines ?? []).Select(x => new SagaSyncRecipeLine
            {
                LineKey = x.LineKey ?? "",
                ArticolCode = x.ArticolCode ?? "",
                SourceTable = x.SourceTable ?? "",
                Tip = x.Tip ?? "",
                Gestiune = x.Gestiune ?? "",
                Operatie = x.Operatie ?? "",
                ComponentCode = x.ComponentCode ?? "",
                ComponentName = x.ComponentName ?? "",
                Um = x.Um ?? "",
                Quantity = x.Quantity
            }).ToList()
        };

        return (true, null, payload.FbClientPath, sync);
    }

    public (bool Success, string? Error, string? FbClientPath, string? Detail) ApplyBom(
        string dbPath, string sagaRoot, string jsonPath,
        SagaConnectionMode mode, string? serverHost = null, int serverPort = SagaConnectionDefaults.FirebirdServerPort)
    {
        var payload = mode == SagaConnectionMode.Server && !string.IsNullOrWhiteSpace(serverHost)
            ? Execute(null, "applybom", dbPath, sagaRoot, jsonPath, "SERVER", serverHost.Trim(),
                serverPort.ToString(CultureInfo.InvariantCulture))
            : Execute(null, "applybom", dbPath, sagaRoot, jsonPath);
        return (payload.Success, payload.Error, payload.FbClientPath, payload.Detail);
    }

    /// <summary>Transfer IESIRI/IES_DET în SAGA prin proces separat (Firebird ADO 7.x + fbclient 3, ca PubLine).</summary>
    public (bool Success, string? Error, string? FbClientPath, decimal? IdIesire, string? NrIesire) TransferIesiri(string transferJsonPath)
    {
        var payload = Execute(null, "iesiri", transferJsonPath);
        return (payload.Success, payload.Error, payload.FbClientPath, payload.IdIesire, payload.NrIesire);
    }

    private static WorkerPayload Execute(IDictionary<string, string>? env, params string[] args)
        => Execute(env, null, args);

    private static WorkerPayload Execute(
        IDictionary<string, string>? env,
        IProgress<SagaWorkerProgress>? progress,
        params string[] args)
    {
        if (!TryCreateWorkerProcessStartInfo(args, out var psi))
        {
            return new WorkerPayload
            {
                Success = false,
                Error = "SMARTPUB.SagaWorker nu a fost găsit (exe/dll în SagaWorker\\ sau csproj în soluție)."
            };
        }

        if (env != null)
        {
            foreach (var kv in env)
                psi.Environment[kv.Key] = kv.Value;
        }

        var stdout = new StringBuilder();
        var stderr = new StringBuilder();
        using var proc = Process.Start(psi);
        if (proc == null)
        {
            return new WorkerPayload { Success = false, Error = "Nu am putut porni SagaWorker." };
        }

        proc.OutputDataReceived += (_, e) =>
        {
            if (e.Data != null)
                stdout.AppendLine(e.Data);
        };
        proc.ErrorDataReceived += (_, e) =>
        {
            if (e.Data == null)
                return;

            if (TryParseProgress(e.Data, out var p))
                progress?.Report(p);
            else
                stderr.AppendLine(e.Data);
        };

        proc.BeginOutputReadLine();
        proc.BeginErrorReadLine();
        proc.WaitForExit();
        proc.WaitForExit();

        var stdoutText = stdout.ToString();
        var stderrText = stderr.ToString();
        if (string.IsNullOrWhiteSpace(stdoutText))
        {
            return new WorkerPayload
            {
                Success = false,
                Error = string.IsNullOrWhiteSpace(stderrText) ? "SagaWorker nu a returnat output." : stderrText
            };
        }

        try
        {
            var payload = JsonSerializer.Deserialize<WorkerPayload>(
                stdoutText,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            if (payload == null)
            {
                return new WorkerPayload { Success = false, Error = "Răspuns invalid de la SagaWorker." };
            }

            if (!payload.Success && !string.IsNullOrWhiteSpace(stderrText))
            {
                payload.Error = string.IsNullOrWhiteSpace(payload.Error)
                    ? stderrText
                    : $"{payload.Error}\n{stderrText}";
            }

            return payload;
        }
        catch (Exception ex)
        {
            return new WorkerPayload
            {
                Success = false,
                Error = $"Nu pot parse response SagaWorker: {ex.Message}\nRaw: {stdoutText}"
            };
        }
    }

    private static bool TryParseProgress(string line, out SagaWorkerProgress progress)
    {
        progress = default;
        if (!line.StartsWith(ProgressPrefix, StringComparison.Ordinal))
            return false;

        var raw = line[ProgressPrefix.Length..];
        var sep = raw.IndexOf('|');
        if (sep <= 0 || !int.TryParse(raw[..sep], NumberStyles.Integer, CultureInfo.InvariantCulture, out var percent))
            return false;

        progress = new SagaWorkerProgress(Math.Clamp(percent, 0, 100), raw[(sep + 1)..]);
        return true;
    }

    /// <summary>
    /// Pornește SagaWorker: folosește artefactul cel mai recent (exe sau dll din SagaWorker\),
    /// ca un exe vechi din bin\Debug să nu ignore fix-uri noi din DLL.
    /// </summary>
    private static bool TryCreateWorkerProcessStartInfo(string[] args, out ProcessStartInfo psi)
    {
        psi = new ProcessStartInfo
        {
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        var exe = ResolveWorkerExePath();
        var bundledDll = Path.Combine(AppContext.BaseDirectory, "SagaWorker", "SMARTPUB.SagaWorker.dll");
        var workspaceDll = ResolveWorkerDllPath();
        var workerProject = ResolveWorkerProjectPath();

        var candidates = new List<(DateTime Utc, Action<ProcessStartInfo> Apply)>();

        if (!string.IsNullOrWhiteSpace(exe) && File.Exists(exe))
        {
            var exeUtc = File.GetLastWriteTimeUtc(exe);
            candidates.Add((exeUtc, p =>
            {
                p.FileName = exe;
                p.WorkingDirectory = Path.GetDirectoryName(exe) ?? AppContext.BaseDirectory;
                foreach (var a in args)
                    p.ArgumentList.Add(a);
            }));
        }

        void AddDllCandidate(string? dllPath)
        {
            if (string.IsNullOrWhiteSpace(dllPath) || !File.Exists(dllPath))
                return;
            var dllUtc = File.GetLastWriteTimeUtc(dllPath);
            var dll = dllPath;
            candidates.Add((dllUtc, p =>
            {
                p.FileName = "dotnet";
                p.WorkingDirectory = Path.GetDirectoryName(dll) ?? AppContext.BaseDirectory;
                p.ArgumentList.Add(dll);
                foreach (var a in args)
                    p.ArgumentList.Add(a);
            }));
        }

        AddDllCandidate(File.Exists(bundledDll) ? bundledDll : null);
        if (!string.Equals(workspaceDll, bundledDll, StringComparison.OrdinalIgnoreCase))
            AddDllCandidate(workspaceDll);

        if (candidates.Count > 0)
        {
            candidates.Sort((a, b) => b.Utc.CompareTo(a.Utc));
            candidates[0].Apply(psi);
            return true;
        }

        if (!string.IsNullOrWhiteSpace(workerProject))
        {
            psi.FileName = "dotnet";
            psi.WorkingDirectory = Path.GetDirectoryName(workerProject) ?? AppContext.BaseDirectory;
            psi.ArgumentList.Add("run");
            psi.ArgumentList.Add("--project");
            psi.ArgumentList.Add(workerProject);
            psi.ArgumentList.Add("-c");
            psi.ArgumentList.Add("Release");
            psi.ArgumentList.Add("--no-build");
            psi.ArgumentList.Add("--");
            foreach (var a in args)
                psi.ArgumentList.Add(a);
            return true;
        }

        return false;
    }

    private static string? ResolveWorkerExePath()
    {
        var inSubfolder = Path.Combine(AppContext.BaseDirectory, "SagaWorker", "SMARTPUB.SagaWorker.exe");
        if (File.Exists(inSubfolder))
            return inSubfolder;

        var direct = Path.Combine(AppContext.BaseDirectory, "SMARTPUB.SagaWorker.exe");
        if (File.Exists(direct))
            return direct;

        return null;
    }

    private static string? ResolveWorkerDllPath()
    {
        // Folder separat: aplicația principală are Firebird ADO 10.x; workerul folosește 7.x pentru SAGA/FB3.
        var inSubfolder = Path.Combine(AppContext.BaseDirectory, "SagaWorker", "SMARTPUB.SagaWorker.dll");
        if (File.Exists(inSubfolder))
            return inSubfolder;

        var direct = Path.Combine(AppContext.BaseDirectory, "SMARTPUB.SagaWorker.dll");
        if (File.Exists(direct)) return direct;

        var root = ResolveWorkspaceRoot();
        if (string.IsNullOrWhiteSpace(root))
            return null;

        var debugPath = Path.Combine(root, "SMARTPUB.SagaWorker", "bin", "Debug", "net8.0", "SMARTPUB.SagaWorker.dll");
        if (File.Exists(debugPath)) return debugPath;

        var releasePath = Path.Combine(root, "SMARTPUB.SagaWorker", "bin", "Release", "net8.0", "SMARTPUB.SagaWorker.dll");
        if (File.Exists(releasePath)) return releasePath;

        return null;
    }

    private static string? ResolveWorkerProjectPath()
    {
        var root = ResolveWorkspaceRoot();
        if (string.IsNullOrWhiteSpace(root))
            return null;

        var workerProject = Path.Combine(root, "SMARTPUB.SagaWorker", "SMARTPUB.SagaWorker.csproj");
        return File.Exists(workerProject) ? workerProject : null;
    }

    private static string? ResolveWorkspaceRoot()
    {
        var current = new DirectoryInfo(AppContext.BaseDirectory);
        while (current != null)
        {
            var slnPath = Path.Combine(current.FullName, "SMARTPUB.sln");
            if (File.Exists(slnPath))
                return current.FullName;

            current = current.Parent;
        }

        return null;
    }

    private sealed class WorkerPayload
    {
        public bool Success { get; set; }
        public string? Error { get; set; }
        public string? Detail { get; set; }
        public string? FbClientPath { get; set; }
        public string? EngineVersion { get; set; }
        public decimal? IdIesire { get; set; }
        public string? NrIesire { get; set; }
        public List<WorkerCompanyPayload> Companies { get; set; } = new();
        public WorkerSyncPayload? Sync { get; set; }
        public List<WorkerArticleBriefPayload> ArticleList { get; set; } = new();
        public List<WorkerAccountBriefPayload> AccountList { get; set; } = new();
    }

    private sealed class WorkerArticleBriefPayload
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? Um { get; set; }
        public decimal Tva { get; set; }
        public decimal PretVanz { get; set; }
        public string? DenTip { get; set; }
        public string? TipSaga { get; set; }
        public bool IsBlocked { get; set; }
    }

    private sealed class WorkerAccountBriefPayload
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
    }

    private sealed class WorkerCompanyPayload
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? DatabasePath { get; set; }
        public bool IsBlocked { get; set; }
    }

    private sealed class WorkerSyncPayload
    {
        public List<WorkerSyncGestiunePayload> Gestiuni { get; set; } = new();
        public List<WorkerSyncCodDenumirePayload> Grupari { get; set; } = new();
        public List<WorkerSyncCodDenumirePayload> Categorii { get; set; } = new();
        public List<WorkerSyncArticolPayload> Articole { get; set; } = new();
        public List<WorkerSyncClientPayload> Clienti { get; set; } = new();
        public List<WorkerSyncRetetaPayload> Retete { get; set; } = new();
        public List<WorkerSyncRetetaDetPayload> ReteteDet { get; set; } = new();
        public List<WorkerSyncRecipeLinePayload> RecipeLines { get; set; } = new();
    }

    private sealed class WorkerSyncCodDenumirePayload
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
    }

    private sealed class WorkerSyncGestiunePayload
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? Gestionar { get; set; }
        public int TipEval { get; set; }
        public string? Categorie { get; set; }
        public decimal ProcTva { get; set; }
    }

    private sealed class WorkerSyncArticolPayload
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? Um { get; set; }
        public decimal Tva { get; set; }
        public string? Categorie { get; set; }
        public string? Grupa { get; set; }
        public string? Gestiune { get; set; }
        public decimal PretVanz { get; set; }
        public bool IsBlocked { get; set; }
        public string? DenTip { get; set; }
        public string? TipSaga { get; set; }
    }

    private sealed class WorkerSyncClientPayload
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? FiscalCode { get; set; }
        public string? RegCom { get; set; }
        public string? Phone { get; set; }
        public string? Email { get; set; }
        public string? Address { get; set; }
        public bool IsBlocked { get; set; }
    }

    private sealed class WorkerSyncRetetaPayload
    {
        public string? ArticolCode { get; set; }
        public string? Operatie { get; set; }
        public string? Tip { get; set; }
        public string? Name { get; set; }
        public string? Um { get; set; }
        public decimal Quantity { get; set; }
        public string? Gestiune { get; set; }
    }

    private sealed class WorkerSyncRetetaDetPayload
    {
        public string? ArticolCode { get; set; }
        public string? ComponentCode { get; set; }
        public string? ComponentName { get; set; }
        public decimal Quantity { get; set; }
        public string? Um { get; set; }
        public string? Gestiune { get; set; }
        public string? Tip { get; set; }
    }

    private sealed class WorkerSyncRecipeLinePayload
    {
        public string? LineKey { get; set; }
        public string? ArticolCode { get; set; }
        public string? SourceTable { get; set; }
        public string? Tip { get; set; }
        public string? Gestiune { get; set; }
        public string? Operatie { get; set; }
        public string? ComponentCode { get; set; }
        public string? ComponentName { get; set; }
        public string? Um { get; set; }
        public decimal Quantity { get; set; }
    }
}


using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public sealed class ProgramExtendedConfigRepository
{
    private static readonly string[] TransferMethodOrder =
        { "NUMERAR", "CARD", "BONURI", "CEC", "METODE_MODERNE" };

    private static readonly string[] FiscalPlataOrder =
        { "NUMERAR", "CARD", "BONURI", "CEC", "METODE_MODERNE" };

    public ProgramDisplayConfig LoadDisplay(FbConnection conn)
    {
        ProgramDisplaySettingsSchema.EnsureSchema(conn);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT COALESCE(GRUP_PANEL_HEIGHT, 120), COALESCE(ARTICOL_PANEL_HEIGHT, 80)
FROM SP_PROGRAM_DISPLAY WHERE ID = 1 ROWS 1";
        using var rd = cmd.ExecuteReader();
        if (!rd.Read())
            return new ProgramDisplayConfig();
        return new ProgramDisplayConfig
        {
            GrupPanelHeight = Convert.ToInt32(rd[0]),
            ArticolPanelHeight = Convert.ToInt32(rd[1])
        };
    }

    public void SaveDisplay(FbConnection conn, ProgramDisplayConfig c)
    {
        ProgramDisplaySettingsSchema.EnsureSchema(conn);
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
UPDATE OR INSERT INTO SP_PROGRAM_DISPLAY (ID, GRUP_PANEL_HEIGHT, ARTICOL_PANEL_HEIGHT, UPDATED_AT)
VALUES (1, @G, @A, CURRENT_TIMESTAMP)
MATCHING (ID)";
        cmd.Parameters.AddWithValue("@G", Math.Clamp(c.GrupPanelHeight, 40, 600));
        cmd.Parameters.AddWithValue("@A", Math.Clamp(c.ArticolPanelHeight, 40, 600));
        cmd.ExecuteNonQuery();
    }

    public ProgramTransferDocConfig LoadTransfer(FbConnection conn)
    {
        ProgramTransferDocSchema.EnsureSchema(conn);
        var cfg = new ProgramTransferDocConfig();
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
SELECT
  TRIM(COALESCE(IMPLICIT_CLIENT, '')),
  TRIM(COALESCE(DEFAULT_GESTIUNE_CODE, '')),
  TRIM(COALESCE(DEFAULT_GESTIUNE_NAME, '')),
  TRIM(COALESCE(CONT_DISCOUNT, '')),
  TRIM(COALESCE(CONT_PROTOCOL, '')),
  TRIM(COALESCE(CONT_BACSIS, '')),
  TRIM(COALESCE(SERIE_FACTURI, '')),
  TRIM(COALESCE(SERIE_BONURI, '')),
  COALESCE(AUTO_TRANSFER_AFTER_PAYMENT, 0),
  COALESCE(INC_MOD_PE_FACTURA, 0),
  TRIM(COALESCE(TEXT_SUPL_FACTURA, '')),
  COALESCE(CAZ_INC_NOPTII, 0),
  COALESCE(CAZ_INC_PERIOADA, 0),
  COALESCE(CAZ_INC_CAMERA, 0)
FROM SP_PROGRAM_TRANSFER_DOC WHERE ID = 1 ROWS 1";
            using var rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                cfg.ImplicitClient = rd[0]?.ToString() ?? "";
                cfg.DefaultGestiuneCode = rd[1]?.ToString() ?? "";
                cfg.DefaultGestiuneName = rd[2]?.ToString() ?? "";
                cfg.ContDiscount = rd[3]?.ToString() ?? "";
                cfg.ContProtocol = rd[4]?.ToString() ?? "";
                cfg.ContBacsis = rd[5]?.ToString() ?? "";
                cfg.SerieFacturi = rd[6]?.ToString() ?? "";
                cfg.SerieBonuri = rd[7]?.ToString() ?? "";
                cfg.AutoTransferAfterPayment = ToBool(rd[8]);
                cfg.IncludeModIncasarePeFactura = ToBool(rd[9]);
                cfg.TextSuplimentarFactura = rd[10]?.ToString() ?? "";
                cfg.CazareIncludeNoptii = ToBool(rd[11]);
                cfg.CazareIncludePerioada = ToBool(rd[12]);
                cfg.CazareIncludeCamera = ToBool(rd[13]);
            }
        }

        var map = new Dictionary<string, TransferModMapRow>(StringComparer.OrdinalIgnoreCase);
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
SELECT TRIM(METHOD_KEY), TRIM(COALESCE(CLIENT_CODE,'')), TRIM(COALESCE(CONT_TRANSFER,''))
FROM SP_TRANSFER_MOD_MAP";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var k = rd[0]?.ToString() ?? "";
                if (k.Length == 0)
                    continue;
                map[k] = new TransferModMapRow
                {
                    MethodKey = k,
                    ClientCode = rd[1]?.ToString() ?? "",
                    ContTransfer = rd[2]?.ToString() ?? ""
                };
            }
        }

        foreach (var key in TransferMethodOrder)
        {
            if (!map.TryGetValue(key, out var row))
                row = new TransferModMapRow { MethodKey = key };
            cfg.ModMap.Add(row);
        }

        return cfg;
    }

    public void SaveTransfer(FbConnection conn, ProgramTransferDocConfig c)
    {
        ProgramTransferDocSchema.EnsureSchema(conn);
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
UPDATE OR INSERT INTO SP_PROGRAM_TRANSFER_DOC (
  ID, IMPLICIT_CLIENT, DEFAULT_GESTIUNE_CODE, DEFAULT_GESTIUNE_NAME,
  CONT_DISCOUNT, CONT_PROTOCOL, CONT_BACSIS,
  SERIE_FACTURI, SERIE_BONURI, AUTO_TRANSFER_AFTER_PAYMENT,
  INC_MOD_PE_FACTURA, TEXT_SUPL_FACTURA,
  CAZ_INC_NOPTII, CAZ_INC_PERIOADA, CAZ_INC_CAMERA, UPDATED_AT
) VALUES (
  1, @IC, @DGC, @DGN,
  @CD, @CP, @CB,
  @SF, @SB, @AT,
  @IM, @TX,
  @CN, @CPe, @CC, CURRENT_TIMESTAMP
)
MATCHING (ID)";
            cmd.Parameters.AddWithValue("@IC", NullIfEmpty(c.ImplicitClient));
            cmd.Parameters.AddWithValue("@DGC", NullIfEmpty(c.DefaultGestiuneCode));
            cmd.Parameters.AddWithValue("@DGN", NullIfEmpty(c.DefaultGestiuneName));
            cmd.Parameters.AddWithValue("@CD", NullIfEmpty(c.ContDiscount));
            cmd.Parameters.AddWithValue("@CP", NullIfEmpty(c.ContProtocol));
            cmd.Parameters.AddWithValue("@CB", NullIfEmpty(c.ContBacsis));
            cmd.Parameters.AddWithValue("@SF", NullIfEmpty(c.SerieFacturi));
            cmd.Parameters.AddWithValue("@SB", NullIfEmpty(c.SerieBonuri));
            cmd.Parameters.AddWithValue("@AT", c.AutoTransferAfterPayment ? 1 : 0);
            cmd.Parameters.AddWithValue("@IM", c.IncludeModIncasarePeFactura ? 1 : 0);
            cmd.Parameters.AddWithValue("@TX", string.IsNullOrWhiteSpace(c.TextSuplimentarFactura) ? DBNull.Value : c.TextSuplimentarFactura.Trim());
            cmd.Parameters.AddWithValue("@CN", c.CazareIncludeNoptii ? 1 : 0);
            cmd.Parameters.AddWithValue("@CPe", c.CazareIncludePerioada ? 1 : 0);
            cmd.Parameters.AddWithValue("@CC", c.CazareIncludeCamera ? 1 : 0);
            cmd.ExecuteNonQuery();
        }

        foreach (var row in c.ModMap)
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
UPDATE OR INSERT INTO SP_TRANSFER_MOD_MAP (
  METHOD_KEY, CLIENT_CODE, CONT_TRANSFER, UPDATED_AT
) VALUES (
  @K, @C, @T, CURRENT_TIMESTAMP
)
MATCHING (METHOD_KEY)";
            cmd.Parameters.AddWithValue("@K", row.MethodKey.Trim().ToUpperInvariant());
            cmd.Parameters.AddWithValue("@C", NullIfEmpty(row.ClientCode));
            cmd.Parameters.AddWithValue("@T", NullIfEmpty(row.ContTransfer));
            cmd.ExecuteNonQuery();
        }
    }

    public ProgramFiscalConfig LoadFiscal(FbConnection conn)
    {
        ProgramFiscalSchema.EnsureSchema(conn);
        var c = new ProgramFiscalConfig();
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
SELECT TRIM(COALESCE(MODEL,'')), TRIM(COALESCE(DRIVER,'')), TRIM(COALESCE(MONITOR_FOLDER,'')),
  COALESCE(TRIMITE_CARD_POS,0), COALESCE(AFIS_OP_BON,0), COALESCE(AFIS_NR_COM_BON,0),
  COALESCE(AFIS_DEN_ART_BON,0), TRIM(COALESCE(TEXT_PUBLICITAR,''))
FROM SP_PROGRAM_FISCAL WHERE ID = 1 ROWS 1";
            using var rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                c.Model = rd[0]?.ToString() ?? "";
                c.Driver = rd[1]?.ToString() ?? "";
                c.MonitorFolder = rd[2]?.ToString() ?? "";
                c.TrimiteSumaCardLaPos = ToBool(rd[3]);
                c.AfiseazaOperatorPeBon = ToBool(rd[4]);
                c.AfiseazaNrComandaPeBon = ToBool(rd[5]);
                c.AfiseazaDenumireArticolPeBon = ToBool(rd[6]);
                c.TextPublicitar = rd[7]?.ToString() ?? "";
            }
        }

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = "SELECT TRIM(METHOD_KEY), COALESCE(INDICE,0) FROM SP_FISCAL_IDX_PLATA";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var k = rd[0]?.ToString() ?? "";
                if (k.Length > 0)
                    c.PlataIndices[k] = Convert.ToInt32(rd[1]);
            }
        }

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = "SELECT TVA_PCT, COALESCE(INDICE,0) FROM SP_FISCAL_IDX_TVA";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                var pct = Convert.ToDecimal(rd[0]);
                c.TvaIndices[pct] = Convert.ToInt32(rd[1]);
            }
        }

        foreach (var k in FiscalPlataOrder)
            c.PlataIndices.TryAdd(k, 0);
        foreach (var pct in new[] { 0m, 11m, 21m })
            c.TvaIndices.TryAdd(pct, 0);

        return c;
    }

    public void SaveFiscal(FbConnection conn, ProgramFiscalConfig c)
    {
        ProgramFiscalSchema.EnsureSchema(conn);
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
UPDATE OR INSERT INTO SP_PROGRAM_FISCAL (
  ID, MODEL, DRIVER, MONITOR_FOLDER, TRIMITE_CARD_POS,
  AFIS_OP_BON, AFIS_NR_COM_BON, AFIS_DEN_ART_BON, TEXT_PUBLICITAR, UPDATED_AT
) VALUES (
  1, @M, @D, @F, @TC,
  @O, @N, @A, @TP, CURRENT_TIMESTAMP
)
MATCHING (ID)";
            cmd.Parameters.AddWithValue("@M", NullIfEmpty(c.Model));
            cmd.Parameters.AddWithValue("@D", NullIfEmpty(c.Driver));
            cmd.Parameters.AddWithValue("@F", NullIfEmpty(c.MonitorFolder));
            cmd.Parameters.AddWithValue("@TC", c.TrimiteSumaCardLaPos ? 1 : 0);
            cmd.Parameters.AddWithValue("@O", c.AfiseazaOperatorPeBon ? 1 : 0);
            cmd.Parameters.AddWithValue("@N", c.AfiseazaNrComandaPeBon ? 1 : 0);
            cmd.Parameters.AddWithValue("@A", c.AfiseazaDenumireArticolPeBon ? 1 : 0);
            cmd.Parameters.AddWithValue("@TP", string.IsNullOrWhiteSpace(c.TextPublicitar) ? DBNull.Value : c.TextPublicitar.Trim());
            cmd.ExecuteNonQuery();
        }

        foreach (var k in FiscalPlataOrder)
        {
            var idx = c.PlataIndices.TryGetValue(k, out var i) ? i : 0;
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
UPDATE OR INSERT INTO SP_FISCAL_IDX_PLATA (METHOD_KEY, INDICE, UPDATED_AT)
VALUES (@K, @I, CURRENT_TIMESTAMP)
MATCHING (METHOD_KEY)";
            cmd.Parameters.AddWithValue("@K", k);
            cmd.Parameters.AddWithValue("@I", idx);
            cmd.ExecuteNonQuery();
        }

        foreach (var kv in c.TvaIndices)
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
UPDATE OR INSERT INTO SP_FISCAL_IDX_TVA (TVA_PCT, INDICE, UPDATED_AT)
VALUES (@P, @I, CURRENT_TIMESTAMP)
MATCHING (TVA_PCT)";
            cmd.Parameters.AddWithValue("@P", kv.Key);
            cmd.Parameters.AddWithValue("@I", kv.Value);
            cmd.ExecuteNonQuery();
        }
    }

    public ProgramNetworkConfig LoadNetwork(FbConnection conn)
    {
        ProgramNetworkSchema.EnsureSchema(conn);
        var c = new ProgramNetworkConfig();
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
SELECT TRIM(COALESCE(ROOT_PATH,'')), COALESCE(MOBILE_PRINT_CF,0)
FROM SP_PROGRAM_NETWORK WHERE ID = 1 ROWS 1";
            using var rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                c.RootPath = rd[0]?.ToString() ?? "";
                c.MobilePrintComenziNotaBon = ToBool(rd[1]);
            }
        }

        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = "SELECT ID, TRIM(COALESCE(NUME,'')), TRIM(COALESCE(IP,'')) FROM SP_NET_SERVER ORDER BY ID";
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                c.Servers.Add(new NetworkServerRow
                {
                    Id = Convert.ToInt32(rd[0]),
                    Name = rd[1]?.ToString() ?? "",
                    Ip = rd[2]?.ToString() ?? ""
                });
            }
        }

        return c;
    }

    public void SaveNetwork(FbConnection conn, ProgramNetworkConfig c)
    {
        ProgramNetworkSchema.EnsureSchema(conn);
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = @"
UPDATE OR INSERT INTO SP_PROGRAM_NETWORK (ID, ROOT_PATH, MOBILE_PRINT_CF, UPDATED_AT)
VALUES (1, @R, @M, CURRENT_TIMESTAMP)
MATCHING (ID)";
            cmd.Parameters.AddWithValue("@R", NullIfEmpty(c.RootPath));
            cmd.Parameters.AddWithValue("@M", c.MobilePrintComenziNotaBon ? 1 : 0);
            cmd.ExecuteNonQuery();
        }

        using (var del = conn.CreateCommand())
        {
            del.CommandText = "DELETE FROM SP_NET_SERVER";
            del.ExecuteNonQuery();
        }

        var id = 1;
        foreach (var s in c.Servers)
        {
            if (string.IsNullOrWhiteSpace(s.Name) && string.IsNullOrWhiteSpace(s.Ip))
                continue;
            using var ins = conn.CreateCommand();
            ins.CommandText = @"
INSERT INTO SP_NET_SERVER (ID, NUME, IP, CREATED_AT) VALUES (@I, @N, @P, CURRENT_TIMESTAMP)";
            ins.Parameters.AddWithValue("@I", id++);
            ins.Parameters.AddWithValue("@N", (s.Name ?? "").Trim());
            ins.Parameters.AddWithValue("@P", (s.Ip ?? "").Trim());
            ins.ExecuteNonQuery();
        }
    }

    private static bool ToBool(object? o) =>
        o != null && o != DBNull.Value && Convert.ToInt32(o) != 0;

    private static object NullIfEmpty(string? s)
    {
        var t = (s ?? "").Trim();
        return t.Length == 0 ? DBNull.Value : t;
    }
}

using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

/// <summary>Persistă coșul de lucru per masă (înlocuitor draft PubLine în data.fdb).</summary>
public static class PosDraftOrderRepository
{
    public static List<WaiterCartLine> LoadLines(FbConnection conn, string tableId)
    {
        var list = new List<WaiterCartLine>();
        if (string.IsNullOrWhiteSpace(tableId))
            return list;

        using var cmd = conn.CreateCommand();
        var hasGest = ColumnExists(conn, "SP_POS_DRAFT_LINE", "GESTIUNE_CODE");
        cmd.CommandText = hasGest
            ? @"
SELECT PRODUCT_CODE, PRODUCT_NAME, GESTIUNE_CODE, GESTIUNE_NAME, QTY, UNIT_PRICE, TVA_PCT, NOTES
FROM SP_POS_DRAFT_LINE
WHERE TABLE_ID = @T
ORDER BY LINE_NO"
            : @"
SELECT PRODUCT_CODE, PRODUCT_NAME, QTY, UNIT_PRICE, TVA_PCT, NOTES
FROM SP_POS_DRAFT_LINE
WHERE TABLE_ID = @T
ORDER BY LINE_NO";
        cmd.Parameters.AddWithValue("@T", tableId.Trim());
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new WaiterCartLine
            {
                ProductCode = (rd["PRODUCT_CODE"]?.ToString() ?? "").Trim(),
                ProductName = (rd["PRODUCT_NAME"]?.ToString() ?? "").Trim(),
                GestiuneCode = hasGest ? (rd["GESTIUNE_CODE"]?.ToString() ?? "").Trim() : "",
                GestiuneName = hasGest ? (rd["GESTIUNE_NAME"]?.ToString() ?? "").Trim() : "",
                Qty = ToDec(rd["QTY"]),
                UnitPrice = ToDec(rd["UNIT_PRICE"]),
                TvaPct = ToDec(rd["TVA_PCT"]),
                Notes = (rd["NOTES"]?.ToString() ?? "").Trim()
            });
        }

        return list;
    }

    public static void ReplaceAll(FbConnection conn, string tableId, IReadOnlyList<WaiterCartLine> lines)
    {
        if (string.IsNullOrWhiteSpace(tableId))
            return;

        var tid = tableId.Trim();
        using var tx = conn.BeginTransaction();
        try
        {
            using (var del = conn.CreateCommand())
            {
                del.Transaction = tx;
                del.CommandText = "DELETE FROM SP_POS_DRAFT_LINE WHERE TABLE_ID = @T";
                del.Parameters.AddWithValue("@T", tid);
                del.ExecuteNonQuery();
            }

            var n = 0;
            foreach (var ln in lines)
            {
                n++;
                using var ins = conn.CreateCommand();
                ins.Transaction = tx;
                ins.CommandText = @"
INSERT INTO SP_POS_DRAFT_LINE (
  TABLE_ID, LINE_NO, PRODUCT_CODE, PRODUCT_NAME, GESTIUNE_CODE, GESTIUNE_NAME,
  QTY, UNIT_PRICE, TVA_PCT, NOTES, UPDATED_AT
) VALUES (
  @T, @N, @C, @NM, @GC, @GN,
  @Q, @P, @TV, @NT, CURRENT_TIMESTAMP
)";
                ins.Parameters.AddWithValue("@T", tid);
                ins.Parameters.AddWithValue("@N", n);
                ins.Parameters.AddWithValue("@C", (ln.ProductCode ?? "").Trim());
                ins.Parameters.AddWithValue("@NM", (ln.ProductName ?? "").Trim());
                ins.Parameters.AddWithValue("@GC", string.IsNullOrWhiteSpace(ln.GestiuneCode) ? DBNull.Value : ln.GestiuneCode.Trim());
                ins.Parameters.AddWithValue("@GN", string.IsNullOrWhiteSpace(ln.GestiuneName) ? DBNull.Value : ln.GestiuneName.Trim());
                ins.Parameters.AddWithValue("@Q", ln.Qty);
                ins.Parameters.AddWithValue("@P", ln.UnitPrice);
                ins.Parameters.AddWithValue("@TV", ln.TvaPct);
                ins.Parameters.AddWithValue("@NT", string.IsNullOrWhiteSpace(ln.Notes) ? "" : ln.Notes.Trim());
                ins.ExecuteNonQuery();
            }

            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    public static void Clear(FbConnection conn, string tableId)
    {
        if (string.IsNullOrWhiteSpace(tableId))
            return;
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "DELETE FROM SP_POS_DRAFT_LINE WHERE TABLE_ID = @T";
        cmd.Parameters.AddWithValue("@T", tableId.Trim());
        cmd.ExecuteNonQuery();
    }

    private static decimal ToDec(object? o)
    {
        if (o == null || o == DBNull.Value)
            return 0;
        return Convert.ToDecimal(o);
    }

    private static bool ColumnExists(FbConnection conn, string tableName, string columnName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATION_FIELDS
WHERE TRIM(RDB$RELATION_NAME) = @T AND TRIM(RDB$FIELD_NAME) = @C ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        cmd.Parameters.AddWithValue("@C", columnName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

using System.IO;
using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public sealed class SagaCompanyScanner
{
    public List<SagaCompany> Scan(string sagaRootPath)
    {
        var result = new List<SagaCompany>();

        if (string.IsNullOrWhiteSpace(sagaRootPath) || !Directory.Exists(sagaRootPath))
            return result;

        var configDb = Path.Combine(sagaRootPath, "CONFIG.FDB");
        if (!File.Exists(configDb))
            return result;

        var fbClient = ResolveWorkingFbClientPath(configDb, sagaRootPath);
        if (string.IsNullOrWhiteSpace(fbClient))
            return result;

        using var con = CreateEmbedded(configDb, fbClient);
        con.Open();

        using var cmd = con.CreateCommand();
        cmd.CommandText = @"
SELECT TRIM(COD)      AS COD,
       TRIM(NUME)     AS NUME,
       TRIM(CALE)     AS CALE,
       BLOCAT         AS BLOCAT,
       TRIM(DBD)      AS DBD
FROM FIRME
ORDER BY COD";

        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            var cod = (rd["COD"]?.ToString() ?? "").Trim();
            var nume = (rd["NUME"]?.ToString() ?? "").Trim();
            var cale = (rd["CALE"]?.ToString() ?? "").Trim();
            var dbd = (rd["DBD"]?.ToString() ?? "").Trim();

            var blocat = false;
            try { blocat = Convert.ToInt32(rd["BLOCAT"]) != 0; } catch { }

            if (string.IsNullOrWhiteSpace(cod))
                continue;

            var folder = !string.IsNullOrWhiteSpace(cale) ? cale : cod;
            var firmaDb = ResolveCompanyDbPath(sagaRootPath, folder, dbd);

            if (firmaDb is null)
                continue;

            result.Add(new SagaCompany
            {
                Code = cod,
                Name = string.IsNullOrWhiteSpace(nume) ? cod : nume,
                DatabasePath = firmaDb,
                IsBlocked = blocat
            });
        }

        return result;
    }

    private static string? ResolveCompanyDbPath(string sagaRootPath, string folder, string dbd)
    {
        if (!string.IsNullOrWhiteSpace(dbd))
        {
            if (File.Exists(dbd))
                return dbd;

            var rel = Path.Combine(sagaRootPath, dbd);
            if (File.Exists(rel))
                return rel;
        }

        var firmaDir = Path.Combine(sagaRootPath, folder);
        if (!Directory.Exists(firmaDir))
            return null;

        return Directory.EnumerateFiles(firmaDir, "*.fdb", SearchOption.TopDirectoryOnly)
                        .FirstOrDefault();
    }

    private static string? ResolveWorkingFbClientPath(string dbPath, string sagaRootPath)
    {
        var candidates = FirebirdClientLocator.GetExistingCandidates(includeLegacyV3: false);
        foreach (var fbClient in candidates)
        {
            try
            {
                using var probe = CreateEmbedded(dbPath, fbClient);
                probe.Open();
                return fbClient;
            }
            catch
            {
                // Try next available client.
            }
        }

        return null;
    }

    private static FbConnection CreateEmbedded(string dbPath, string fbClientPath)
    {
        var cs = new FbConnectionStringBuilder
        {
            Database = dbPath,
            UserID = "SYSDBA",
            Password = "masterkey",
            ServerType = FbServerType.Embedded,
            ClientLibrary = fbClientPath,
            Pooling = false,
            Dialect = 3
        };

        return new FbConnection(cs.ToString());
    }
}

using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public static class BomCatalogLoader
{
    public static List<BomCatalogItem> LoadFromSagaMirror(FbConnection conn)
    {
        var list = new List<BomCatalogItem>();
        if (!TableExists(conn, "SP_SAGA_ARTICOLE"))
            return list;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT
  TRIM(CODE),
  TRIM(NAME),
  TRIM(COALESCE(UM, '')),
  TRIM(COALESCE(CATEGORIE, ''))
FROM SP_SAGA_ARTICOLE
ORDER BY NAME";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new BomCatalogItem
            {
                Code = (rd[0]?.ToString() ?? "").Trim(),
                Name = (rd[1]?.ToString() ?? "").Trim(),
                Um = (rd[2]?.ToString() ?? "").Trim(),
                Categorie = (rd[3]?.ToString() ?? "").Trim()
            });
        }

        return list;
    }

    public static List<BomCatalogItem> LoadFromBomArticles(FbConnection conn)
    {
        var list = new List<BomCatalogItem>();
        if (!TableExists(conn, "SP_BOM_ARTICLE"))
            return list;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT TRIM(CODE), TRIM(NAME)
FROM SP_BOM_ARTICLE
ORDER BY NAME";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new BomCatalogItem
            {
                Code = (rd[0]?.ToString() ?? "").Trim(),
                Name = (rd[1]?.ToString() ?? "").Trim()
            });
        }

        return list;
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }
}

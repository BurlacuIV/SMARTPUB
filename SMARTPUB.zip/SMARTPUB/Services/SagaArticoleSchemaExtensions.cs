using FirebirdSql.Data.FirebirdClient;

namespace SMARTPUB.Services;

/// <summary>
/// Adaugă coloane opționale la SP_SAGA_ARTICOLE pentru afișare în grid (stoc, PLU, etc.).
/// </summary>
public static class SagaArticoleSchemaExtensions
{
    private static int _extendedEnsured;
    private static bool? _hasExtendedColumns;

    public static void EnsureExtendedColumns(FbConnection conn)
    {
        if (Interlocked.CompareExchange(ref _extendedEnsured, 1, 0) != 0)
            return;

        if (!TableExists(conn, "SP_SAGA_ARTICOLE"))
            return;

        TryAddColumn(conn, "SP_SAGA_ARTICOLE", "STOC", "NUMERIC(18,4) DEFAULT 0");
        TryAddColumn(conn, "SP_SAGA_ARTICOLE", "COD_BARE", "VARCHAR(32)");
        TryAddColumn(conn, "SP_SAGA_ARTICOLE", "PLU", "INTEGER DEFAULT 0");
        TryAddColumn(conn, "SP_SAGA_ARTICOLE", "GESTIUNE", "VARCHAR(16)");
        TryAddColumn(conn, "SP_SAGA_ARTICOLE", "GRUPA", "VARCHAR(16)");
        TryAddColumn(conn, "SP_SAGA_ARTICOLE", "IMAGE_PATH", "VARCHAR(260)");
        TryAddColumn(conn, "SP_SAGA_ARTICOLE", "DEN_TIP", "VARCHAR(48)");
        TryAddColumn(conn, "SP_SAGA_ARTICOLE", "TIP_SAGA", "VARCHAR(4)");
        // Destinație internă rutare comandă (override per produs): BAR / BUCATARIE / gol = moștenește din grupă.
        TryAddColumn(conn, "SP_SAGA_ARTICOLE", "DESTINATIE", "VARCHAR(16)");
        _hasExtendedColumns = ColumnExists(conn, "SP_SAGA_ARTICOLE", "STOC");
    }

    public static bool HasExtendedArticoleColumns(FbConnection conn)
    {
        if (_hasExtendedColumns.HasValue)
            return _hasExtendedColumns.Value;
        var v = TableExists(conn, "SP_SAGA_ARTICOLE") && ColumnExists(conn, "SP_SAGA_ARTICOLE", "STOC");
        _hasExtendedColumns = v;
        return v;
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0 AND TRIM(RDB$RELATION_NAME) = @T ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static bool ColumnExists(FbConnection conn, string table, string column)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1 FROM RDB$RELATION_FIELDS
WHERE TRIM(RDB$RELATION_NAME) = @T AND TRIM(RDB$FIELD_NAME) = @C ROWS 1";
        cmd.Parameters.AddWithValue("@T", table.Trim().ToUpperInvariant());
        cmd.Parameters.AddWithValue("@C", column.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static void TryAddColumn(FbConnection conn, string table, string column, string definition)
    {
        if (ColumnExists(conn, table, column))
            return;
        try
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = $"ALTER TABLE {table} ADD {column} {definition}";
            cmd.ExecuteNonQuery();
        }
        catch
        {
            /* coloana poate exista deja sau versiune Firebird diferită */
        }
    }
}

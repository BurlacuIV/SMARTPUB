using SMARTPUB.Core.Session;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

/// <summary>
/// Cache în memorie pentru catalogul ospătar (SP_SAGA_ARTICOLE).
/// </summary>
public sealed class WaiterProductCatalogCache
{
    public static WaiterProductCatalogCache Instance { get; } = new();

    private readonly object _gate = new();
    private IReadOnlyList<SyncedProductRow>? _snapshot;
    private IReadOnlyList<SyncedProductRow>? _filteredSnapshot;
    private string? _filteredForOperatorId;
    private volatile bool _preloadRunning;

    private WaiterProductCatalogCache()
    {
    }

    public void Invalidate()
    {
        lock (_gate)
        {
            _snapshot = null;
            _filteredSnapshot = null;
            _filteredForOperatorId = null;
        }
    }

    public IReadOnlyList<SyncedProductRow> GetSnapshot()
    {
        EnsureLoaded();
        lock (_gate)
            return _snapshot ?? Array.Empty<SyncedProductRow>();
    }

    /// <summary>Catalog filtrat după restricțiile operatorului curent (cache per operator).</summary>
    public IReadOnlyList<SyncedProductRow> GetSnapshotForCurrentOperator()
    {
        EnsureLoaded();
        var oid = AppSession.Current.OperatorId;
        lock (_gate)
        {
            if (_snapshot == null)
                return Array.Empty<SyncedProductRow>();

            if (!string.IsNullOrWhiteSpace(oid) &&
                _filteredSnapshot != null &&
                string.Equals(_filteredForOperatorId, oid, StringComparison.OrdinalIgnoreCase))
                return _filteredSnapshot;

            var filtered = FilterInMemory(_snapshot, WaiterOperatorContext.Current);
            if (!string.IsNullOrWhiteSpace(oid))
            {
                _filteredSnapshot = filtered;
                _filteredForOperatorId = oid;
            }

            return filtered;
        }
    }

    public void PreloadAsync()
    {
        if (_preloadRunning)
            return;
        _preloadRunning = true;
        _ = Task.Run(() =>
        {
            try
            {
                LoadFromDatabase();
            }
            catch
            {
                /* GetSnapshot va reîncerca */
            }
            finally
            {
                _preloadRunning = false;
            }
        });
    }

    private void EnsureLoaded()
    {
        lock (_gate)
        {
            if (_snapshot != null)
                return;
        }

        LoadFromDatabase();
    }

    private void LoadFromDatabase()
    {
        using var conn = SmartPubDb.OpenEmbedded();
        var repo = new SyncedProductsRepository();
        var loaded = repo.GetAllForWaiter(conn).Where(p => !p.IsBlocked).ToList();

        lock (_gate)
        {
            _snapshot = loaded;
            _filteredSnapshot = null;
            _filteredForOperatorId = null;
        }
    }

    private static List<SyncedProductRow> FilterInMemory(
        IReadOnlyList<SyncedProductRow> source,
        WaiterOperatorContext? ctx)
    {
        if (ctx == null || ctx.IsAdministrator)
            return source.ToList();

        if (ctx.BlockedGestiuni.Count == 0 && ctx.BlockedGrupe.Count == 0)
            return source.ToList();

        return source.Where(p =>
        {
            var g = Norm(p.Gestiune);
            var gr = Norm(p.Grupa);
            if (ctx.BlockedGestiuni.Count > 0 && ctx.BlockedGestiuni.Contains(g))
                return false;
            if (ctx.BlockedGrupe.Count > 0 && ctx.BlockedGrupe.Contains(gr))
                return false;
            return true;
        }).ToList();
    }

    private static string Norm(string? s) => (s ?? "").Trim().ToUpperInvariant();
}

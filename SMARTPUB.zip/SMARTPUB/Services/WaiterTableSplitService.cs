using System.Collections.ObjectModel;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

/// <summary>Sesiune split note per masă — alocări, persistență, sincronizare cu coșul trimis.</summary>
public sealed class WaiterTableSplitService
{
    public static WaiterTableSplitService Instance { get; } = new();

    private readonly Dictionary<string, TableSplitSession> _sessions = new(StringComparer.OrdinalIgnoreCase);
    private readonly object _gate = new();

    private WaiterTableSplitService() { }

    public TableSplitSession GetSession(string tableId) =>
        EnsureSession(tableId, 2);

    public TableSplitSession EnsureSession(string tableId, int personCount)
    {
        if (string.IsNullOrWhiteSpace(tableId))
            throw new ArgumentException("tableId required", nameof(tableId));

        personCount = Math.Clamp(personCount, 1, 24);

        lock (_gate)
        {
            if (_sessions.TryGetValue(tableId, out var existing))
            {
                existing.EnsureBillCount(personCount);
                return existing;
            }

            var session = new TableSplitSession(tableId, personCount);
            try
            {
                using var conn = SmartPubDb.OpenEmbedded();
                PosOperationalSchema.EnsureSchema(conn);
                var loaded = PosSplitRepository.Load(conn, tableId);
                if (loaded != null)
                {
                    session.PersonCount = Math.Max(personCount, loaded.PersonCount);
                    session.EnsureBillCount(session.PersonCount);
                    foreach (var b in loaded.Bills)
                    {
                        var bill = session.Bills.FirstOrDefault(x => x.BillIndex == b.BillIndex);
                        if (bill == null) continue;
                        bill.IsPaid = b.IsPaid;
                        bill.SaleId = b.SaleId;
                    }

                    foreach (var a in loaded.Allocs)
                    {
                        var bill = session.Bills.FirstOrDefault(x => x.BillIndex == a.BillIndex);
                        if (bill == null) continue;
                        bill.Lines.Add(new WaiterSplitAllocLine
                        {
                            PoolLineKey = a.PoolLineKey,
                            Source = a.Source,
                            ProductCode = a.ProductCode,
                            ProductName = a.ProductName,
                            UnitPrice = a.UnitPrice,
                            TvaPct = a.TvaPct,
                            Notes = a.Notes,
                            Qty = a.Qty
                        });
                    }
                }
            }
            catch
            {
                /* sesiune nouă în memorie */
            }

            session.RebuildConsumedSentFromPaidBills();
            _sessions[tableId] = session;
            return session;
        }
    }

    public void Persist(string tableId)
    {
        lock (_gate)
        {
            if (!_sessions.TryGetValue(tableId, out var session))
                return;
            try
            {
                using var conn = SmartPubDb.OpenEmbedded();
                PosOperationalSchema.EnsureSchema(conn);
                PosSplitRepository.Save(conn, tableId, session.PersonCount, session.Bills, session.Pool);
            }
            catch
            {
                /* nu blocăm UI */
            }
        }
    }

    public void ClearSession(string tableId)
    {
        lock (_gate)
        {
            _sessions.Remove(tableId);
            try
            {
                using var conn = SmartPubDb.OpenEmbedded();
                PosOperationalSchema.EnsureSchema(conn);
                PosSplitRepository.Clear(conn, tableId);
            }
            catch
            {
                /* ignore */
            }
        }
    }

    public sealed class TableSplitSession
    {
        public string TableId { get; }
        public int PersonCount { get; set; }
        public ObservableCollection<WaiterSplitPoolLine> Pool { get; } = new();
        public ObservableCollection<WaiterSplitBill> Bills { get; } = new();

        public TableSplitSession(string tableId, int personCount)
        {
            TableId = tableId;
            PersonCount = personCount;
            EnsureBillCount(personCount);
        }

        public void EnsureBillCount(int count)
        {
            PersonCount = Math.Clamp(count, 1, 24);
            while (Bills.Count < PersonCount)
            {
                var idx = Bills.Count + 1;
                Bills.Add(new WaiterSplitBill { BillIndex = idx });
            }

            while (Bills.Count > PersonCount)
            {
                var last = Bills[^1];
                if (last.IsPaid || last.Lines.Count > 0)
                    break;
                Bills.RemoveAt(Bills.Count - 1);
            }
        }

        public void RebuildPool(
            IEnumerable<(WaiterSplitSourceKind Source, string Code, string Name, decimal Qty, decimal Price, decimal Tva, string? Notes)> sources)
        {
            var dict = new Dictionary<string, WaiterSplitPoolLine>(StringComparer.OrdinalIgnoreCase);
            foreach (var s in sources)
            {
                var key = WaiterSplitPoolLine.BuildKey(s.Source, s.Code, s.Price, s.Notes);
                if (!dict.TryGetValue(key, out var line))
                {
                    line = new WaiterSplitPoolLine
                    {
                        LineKey = key,
                        Source = s.Source,
                        ProductCode = s.Code,
                        ProductName = s.Name,
                        UnitPrice = s.Price,
                        TvaPct = s.Tva,
                        Notes = s.Notes ?? ""
                    };
                    dict[key] = line;
                }

                line.TotalQty = SplitQtyMath.Round(line.TotalQty + s.Qty);
            }

            Pool.Clear();
            foreach (var ln in dict.Values.OrderBy(x => x.ProductName))
                Pool.Add(ln);

            ReconcileAll();
        }

        /// <summary>Sincronizează alocările din note cu pool-ul; elimină linii „praf" sub 0,01 buc.</summary>
        public void ReconcileAll()
        {
            foreach (var bill in Bills)
            {
                var dust = bill.Lines.Where(l => SplitQtyMath.IsEffectivelyZero(l.Qty)).ToList();
                foreach (var d in dust)
                    bill.Lines.Remove(d);
            }

            foreach (var pool in Pool)
            {
                var sum = SplitQtyMath.Round(Bills
                    .SelectMany(b => b.Lines)
                    .Where(l => l.PoolLineKey == pool.LineKey)
                    .Sum(l => l.Qty));

                pool.AllocatedQty = sum;

                var avail = pool.TotalQty - sum;
                if (avail > 0 && SplitQtyMath.IsEffectivelyZero(avail))
                    pool.AllocatedQty = pool.TotalQty;
            }

            foreach (var bill in Bills)
                bill.RefreshTotal();
        }

        public bool TryMoveToBill(string poolLineKey, int billIndex, decimal qty, out string? error)
        {
            error = null;
            var pool = Pool.FirstOrDefault(p => p.LineKey == poolLineKey);
            if (pool == null) { error = "Linia nu mai există în pool."; return false; }

            qty = SplitQtyMath.Round(Math.Min(qty, pool.AvailableQty));
            if (SplitQtyMath.IsEffectivelyZero(qty)) { error = "Cantitate indisponibilă."; return false; }

            var bill = Bills.FirstOrDefault(b => b.BillIndex == billIndex);
            if (bill == null || bill.IsPaid) { error = "Nota este blocată."; return false; }

            var existing = bill.Lines.FirstOrDefault(l => l.PoolLineKey == poolLineKey);
            if (existing != null)
                existing.Qty = SplitQtyMath.Round(existing.Qty + qty);
            else
            {
                bill.Lines.Add(new WaiterSplitAllocLine
                {
                    PoolLineKey = poolLineKey,
                    Source = pool.Source,
                    ProductCode = pool.ProductCode,
                    ProductName = pool.ProductName,
                    UnitPrice = pool.UnitPrice,
                    TvaPct = pool.TvaPct,
                    Notes = pool.Notes,
                    Qty = qty
                });
            }

            ReconcileAll();
            return true;
        }

        public bool TryMoveFromBillToPool(int billIndex, string poolLineKey, decimal? qtyAll, out string? error)
        {
            error = null;
            var bill = Bills.FirstOrDefault(b => b.BillIndex == billIndex);
            if (bill == null || bill.IsPaid) { error = "Nota este blocată."; return false; }

            var alloc = bill.Lines.FirstOrDefault(l => l.PoolLineKey == poolLineKey);
            if (alloc == null) { error = "Linia nu este pe această notă."; return false; }

            var moveQty = SplitQtyMath.Round(qtyAll ?? alloc.Qty);
            moveQty = Math.Min(moveQty, alloc.Qty);
            if (SplitQtyMath.IsEffectivelyZero(moveQty)) return false;

            alloc.Qty = SplitQtyMath.Round(alloc.Qty - moveQty);
            if (SplitQtyMath.IsEffectivelyZero(alloc.Qty))
                bill.Lines.Remove(alloc);

            ReconcileAll();
            return true;
        }

        public void SplitEquallyAcrossBills()
        {
            ReconcileAll();
            var openBills = Bills.Where(b => !b.IsPaid).ToList();
            if (openBills.Count == 0) return;

            foreach (var pool in Pool.ToList())
            {
                var avail = pool.AvailableQty;
                if (SplitQtyMath.IsEffectivelyZero(avail)) continue;

                // Distribuție exactă în sutimi (0,01 buc) — fără praf de rotunjire pe prima notă.
                var units = (int)Math.Round(avail * 100m, MidpointRounding.AwayFromZero);
                var n = openBills.Count;
                var baseUnits = units / n;
                var extra = units % n;

                for (var i = 0; i < n; i++)
                {
                    var billUnits = baseUnits + (i < extra ? 1 : 0);
                    if (billUnits <= 0) continue;
                    var q = billUnits / 100m;
                    TryMoveToBill(pool.LineKey, openBills[i].BillIndex, q, out _);
                }
            }

            ReconcileAll();
        }

        public bool AllBillsPaid => Bills.Count > 0 && Bills.All(b => b.IsPaid || (b.Lines.Count == 0 && !b.IsPaid));

        public bool HasOpenAmount =>
            Pool.Any(p => p.AvailableQty >= 0.01m) ||
            Bills.Any(b => !b.IsPaid && b.Lines.Count > 0);

        public decimal UnallocatedTotal => Pool.Sum(p => p.LineTotal);

        /// <summary>Cantități deja încasate din liniile trimise la bucătărie (cheie pool).</summary>
        public Dictionary<string, decimal> ConsumedSentQty { get; } = new(StringComparer.OrdinalIgnoreCase);

        public void RebuildConsumedSentFromPaidBills()
        {
            ConsumedSentQty.Clear();
            foreach (var bill in Bills.Where(b => b.IsPaid))
            {
                foreach (var ln in bill.Lines.Where(l => l.Source == WaiterSplitSourceKind.Sent))
                {
                    ConsumedSentQty.TryGetValue(ln.PoolLineKey, out var cur);
                    ConsumedSentQty[ln.PoolLineKey] = cur + ln.Qty;
                }
            }
        }
    }
}

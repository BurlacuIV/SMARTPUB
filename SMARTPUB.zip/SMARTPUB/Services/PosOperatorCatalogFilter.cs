using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Core.Session;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

/// <summary>Filtrează catalogul după restricțiile operatorului (gestiuni/grupe blocate).</summary>
public static class PosOperatorCatalogFilter
{
    public static List<SyncedProductRow> FilterProducts(
        FbConnection conn,
        string? operatorId,
        IReadOnlyList<SyncedProductRow> source)
    {
        if (source.Count == 0)
            return source.ToList();

        var ctx = WaiterOperatorContext.Current;
        if (ctx != null && string.Equals(ctx.OperatorId, operatorId?.Trim(), StringComparison.OrdinalIgnoreCase))
            return FilterWithContext(source, ctx);

        if (string.IsNullOrWhiteSpace(operatorId))
            return source.ToList();

        if (PosOperatorRepository.IsAdministratorRole(conn, operatorId))
            return source.ToList();

        var blockedGest = PosOperatorRepository.LoadBlockedGestiuni(conn, operatorId);
        var blockedGrup = PosOperatorRepository.LoadBlockedGrupe(conn, operatorId);
        if (blockedGest.Count == 0 && blockedGrup.Count == 0)
            return source.ToList();

        return source.Where(p =>
        {
            var g = Norm(p.Gestiune);
            var gr = Norm(p.Grupa);
            if (blockedGest.Count > 0 && blockedGest.Contains(g))
                return false;
            if (blockedGrup.Count > 0 && blockedGrup.Contains(gr))
                return false;
            return true;
        }).ToList();
    }

    private static List<SyncedProductRow> FilterWithContext(IReadOnlyList<SyncedProductRow> source, WaiterOperatorContext ctx)
    {
        if (ctx.IsAdministrator || (ctx.BlockedGestiuni.Count == 0 && ctx.BlockedGrupe.Count == 0))
            return source.ToList();

        return source.Where(p =>
        {
            var g = Norm(p.Gestiune);
            var gr = Norm(p.Grupa);
            if (ctx.BlockedGestiuni.Count > 0 && ctx.BlockedGestiuni.Contains(g))
                return false;
            if (ctx.BlockedGrupe.Count > 0 && ctx.BlockedGrupe.Contains(gr))
                return false;
            return true;
        }).ToList();
    }

    private static string Norm(string? s) => (s ?? "").Trim().ToUpperInvariant();
}

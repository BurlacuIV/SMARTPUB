using System.Globalization;
using FirebirdSql.Data.FirebirdClient;
using SMARTPUB.Models;

namespace SMARTPUB.Services;

public sealed class SagaSyncImportService
{
    public void EnsureSchema(FbConnection conn)
    {
        EnsureTable(conn, "SP_SAGA_GESTIUNI", @"
CREATE TABLE SP_SAGA_GESTIUNI (
  CODE VARCHAR(16) NOT NULL,
  NAME VARCHAR(100),
  GESTIONAR VARCHAR(100),
  TIP_EVAL INTEGER,
  CATEGORIE VARCHAR(40),
  PROC_TVA NUMERIC(10,2),
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (CODE)
)");

        EnsureTable(conn, "SP_SAGA_ARTICOLE", @"
CREATE TABLE SP_SAGA_ARTICOLE (
  CODE VARCHAR(24) NOT NULL,
  NAME VARCHAR(120),
  UM VARCHAR(10),
  TVA NUMERIC(10,2),
  CATEGORIE VARCHAR(40),
  PRET_VANZ NUMERIC(18,4),
  IS_BLOCKED SMALLINT,
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (CODE)
)");

        EnsureTable(conn, "SP_SAGA_CLIENTI", @"
CREATE TABLE SP_SAGA_CLIENTI (
  CODE VARCHAR(16) NOT NULL,
  NAME VARCHAR(120),
  FISCAL_CODE VARCHAR(32),
  REG_COM VARCHAR(32),
  PHONE VARCHAR(40),
  EMAIL VARCHAR(120),
  ADDRESS VARCHAR(250),
  IS_BLOCKED SMALLINT,
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (CODE)
)");

        EnsureTable(conn, "SP_SAGA_RETETE", @"
CREATE TABLE SP_SAGA_RETETE (
  ARTICOL_CODE VARCHAR(24) NOT NULL,
  OPERATIE VARCHAR(32) NOT NULL,
  NAME VARCHAR(120),
  UM VARCHAR(10),
  GESTIUNE VARCHAR(16),
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (ARTICOL_CODE, OPERATIE)
)");

        EnsureTable(conn, "SP_SAGA_RETETE_DET", @"
CREATE TABLE SP_SAGA_RETETE_DET (
  ARTICOL_CODE VARCHAR(24) NOT NULL,
  COMPONENT_CODE VARCHAR(24) NOT NULL,
  COMPONENT_NAME VARCHAR(120),
  QTY NUMERIC(18,6),
  UM VARCHAR(10),
  GESTIUNE VARCHAR(16),
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (ARTICOL_CODE, COMPONENT_CODE)
)");

        EnsureTable(conn, "SP_SAGA_RECIPE_LINES", @"
CREATE TABLE SP_SAGA_RECIPE_LINES (
  LINE_KEY VARCHAR(64) NOT NULL,
  ARTICOL_CODE VARCHAR(24) NOT NULL,
  SOURCE_TABLE VARCHAR(24),
  TIP VARCHAR(80),
  GESTIUNE VARCHAR(16),
  OPERATIE VARCHAR(32),
  COMPONENT_CODE VARCHAR(24),
  COMPONENT_NAME VARCHAR(120),
  UM VARCHAR(10),
  QTY NUMERIC(18,6),
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (LINE_KEY)
)");

        EnsureGrupariCategoriiTables(conn);
    }

    /// <summary>Tabele lookup pentru denumiri grupă / categorie (JOIN în catalog articole).</summary>
    public void EnsureGrupariCategoriiTables(FbConnection conn)
    {
        EnsureTable(conn, "SP_SAGA_GRUPARI", @"
CREATE TABLE SP_SAGA_GRUPARI (
  CODE VARCHAR(24) NOT NULL,
  NAME VARCHAR(120),
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (CODE)
)");
        EnsureTable(conn, "SP_SAGA_CATEGORII", @"
CREATE TABLE SP_SAGA_CATEGORII (
  CODE VARCHAR(24) NOT NULL,
  NAME VARCHAR(120),
  UPDATED_AT TIMESTAMP,
  PRIMARY KEY (CODE)
)");
    }

    public (int Gestiuni, int Articole, int Retete, int ReteteDet, int RecipeLines, int Clienti) UpsertAll(FbConnection conn, SagaSyncPayload payload)
    {
        SagaArticoleSchemaExtensions.EnsureExtendedColumns(conn);

        var g = 0;
        var a = 0;
        var r = 0;
        var rd = 0;
        var rl = 0;
        var c = 0;

        // Rețete din SAGA se rescriu complet; MANUAL / IMPORT sunt salvate și reintroduse după inserarea din payload.
        var preservedRecipeLines = ReadPreservedLocalRecipeLines(conn);
        DeleteAll(conn, "SP_SAGA_RECIPE_LINES");
        DeleteAll(conn, "SP_SAGA_RETETE");
        DeleteAll(conn, "SP_SAGA_RETETE_DET");
        DeleteAll(conn, "SP_SAGA_GRUPARI");
        DeleteAll(conn, "SP_SAGA_CATEGORII");

        foreach (var item in payload.Grupari ?? new List<SagaSyncCodDenumire>())
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
UPDATE OR INSERT INTO SP_SAGA_GRUPARI (CODE, NAME, UPDATED_AT)
VALUES (@CODE, @NAME, CURRENT_TIMESTAMP)
MATCHING (CODE)";
            cmd.Parameters.AddWithValue("@CODE", item.Code);
            cmd.Parameters.AddWithValue("@NAME", DbOrValue(item.Name));
            cmd.ExecuteNonQuery();
        }

        foreach (var item in payload.Categorii ?? new List<SagaSyncCodDenumire>())
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
UPDATE OR INSERT INTO SP_SAGA_CATEGORII (CODE, NAME, UPDATED_AT)
VALUES (@CODE, @NAME, CURRENT_TIMESTAMP)
MATCHING (CODE)";
            cmd.Parameters.AddWithValue("@CODE", item.Code);
            cmd.Parameters.AddWithValue("@NAME", DbOrValue(item.Name));
            cmd.ExecuteNonQuery();
        }

        foreach (var item in payload.Gestiuni ?? [])
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
UPDATE OR INSERT INTO SP_SAGA_GESTIUNI
(CODE, NAME, GESTIONAR, TIP_EVAL, CATEGORIE, PROC_TVA, UPDATED_AT)
VALUES
(@CODE, @NAME, @GESTIONAR, @TIP_EVAL, @CATEGORIE, @PROC_TVA, CURRENT_TIMESTAMP)
MATCHING (CODE)";
            cmd.Parameters.AddWithValue("@CODE", item.Code);
            cmd.Parameters.AddWithValue("@NAME", DbOrValue(item.Name));
            cmd.Parameters.AddWithValue("@GESTIONAR", DbOrValue(item.Gestionar));
            cmd.Parameters.AddWithValue("@TIP_EVAL", item.TipEval);
            cmd.Parameters.AddWithValue("@CATEGORIE", DbOrValue(item.Categorie));
            cmd.Parameters.AddWithValue("@PROC_TVA", item.ProcTva);
            cmd.ExecuteNonQuery();
            g++;
        }

        foreach (var item in payload.Articole ?? [])
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
UPDATE OR INSERT INTO SP_SAGA_ARTICOLE
(CODE, NAME, UM, TVA, CATEGORIE, GRUPA, PRET_VANZ, IS_BLOCKED, GESTIUNE, DEN_TIP, TIP_SAGA, UPDATED_AT)
VALUES
(@CODE, @NAME, @UM, @TVA, @CATEGORIE, @GRUPA, @PRET_VANZ, @IS_BLOCKED, @GESTIUNE, @DEN_TIP, @TIP_SAGA, CURRENT_TIMESTAMP)
MATCHING (CODE)";
            cmd.Parameters.AddWithValue("@CODE", item.Code);
            cmd.Parameters.AddWithValue("@NAME", DbOrValue(item.Name));
            cmd.Parameters.AddWithValue("@UM", DbOrValue(item.Um));
            cmd.Parameters.AddWithValue("@TVA", item.Tva);
            cmd.Parameters.AddWithValue("@CATEGORIE", DbOrValue(item.Categorie));
            cmd.Parameters.AddWithValue("@GRUPA", DbOrValue(item.Grupa));
            cmd.Parameters.AddWithValue("@PRET_VANZ", item.PretVanz);
            cmd.Parameters.AddWithValue("@IS_BLOCKED", item.IsBlocked ? 1 : 0);
            cmd.Parameters.AddWithValue("@GESTIUNE", DbOrValue(item.Gestiune));
            cmd.Parameters.AddWithValue("@DEN_TIP", DbOrValue(item.DenTip));
            cmd.Parameters.AddWithValue("@TIP_SAGA", DbOrValue(NormalizeTipSaga(item.TipSaga)));
            cmd.ExecuteNonQuery();
            a++;
        }

        foreach (var item in payload.Clienti ?? [])
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
UPDATE OR INSERT INTO SP_SAGA_CLIENTI
(CODE, NAME, FISCAL_CODE, REG_COM, PHONE, EMAIL, ADDRESS, IS_BLOCKED, UPDATED_AT)
VALUES
(@CODE, @NAME, @FISCAL_CODE, @REG_COM, @PHONE, @EMAIL, @ADDRESS, @IS_BLOCKED, CURRENT_TIMESTAMP)
MATCHING (CODE)";
            cmd.Parameters.AddWithValue("@CODE", item.Code);
            cmd.Parameters.AddWithValue("@NAME", DbOrValue(item.Name));
            cmd.Parameters.AddWithValue("@FISCAL_CODE", DbOrValue(item.FiscalCode));
            cmd.Parameters.AddWithValue("@REG_COM", DbOrValue(item.RegCom));
            cmd.Parameters.AddWithValue("@PHONE", DbOrValue(item.Phone));
            cmd.Parameters.AddWithValue("@EMAIL", DbOrValue(item.Email));
            cmd.Parameters.AddWithValue("@ADDRESS", DbOrValue(item.Address));
            cmd.Parameters.AddWithValue("@IS_BLOCKED", item.IsBlocked ? 1 : 0);
            cmd.ExecuteNonQuery();
            c++;
        }

        foreach (var item in payload.Retete ?? [])
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
UPDATE OR INSERT INTO SP_SAGA_RETETE
(ARTICOL_CODE, OPERATIE, NAME, UM, GESTIUNE, UPDATED_AT)
VALUES
(@ARTICOL_CODE, @OPERATIE, @NAME, @UM, @GESTIUNE, CURRENT_TIMESTAMP)
MATCHING (ARTICOL_CODE, OPERATIE)";
            cmd.Parameters.AddWithValue("@ARTICOL_CODE", item.ArticolCode);
            cmd.Parameters.AddWithValue("@OPERATIE", string.IsNullOrWhiteSpace(item.Operatie) ? "-" : item.Operatie);
            cmd.Parameters.AddWithValue("@NAME", DbOrValue(item.Name));
            cmd.Parameters.AddWithValue("@UM", DbOrValue(item.Um));
            cmd.Parameters.AddWithValue("@GESTIUNE", DbOrValue(item.Gestiune));
            cmd.ExecuteNonQuery();
            r++;
        }

        foreach (var item in payload.ReteteDet ?? [])
        {
            if (string.IsNullOrWhiteSpace(item.ArticolCode) || string.IsNullOrWhiteSpace(item.ComponentCode))
                continue;

            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
UPDATE OR INSERT INTO SP_SAGA_RETETE_DET
(ARTICOL_CODE, COMPONENT_CODE, COMPONENT_NAME, QTY, UM, GESTIUNE, UPDATED_AT)
VALUES
(@ARTICOL_CODE, @COMPONENT_CODE, @COMPONENT_NAME, @QTY, @UM, @GESTIUNE, CURRENT_TIMESTAMP)
MATCHING (ARTICOL_CODE, COMPONENT_CODE)";
            cmd.Parameters.AddWithValue("@ARTICOL_CODE", item.ArticolCode);
            cmd.Parameters.AddWithValue("@COMPONENT_CODE", item.ComponentCode);
            cmd.Parameters.AddWithValue("@COMPONENT_NAME", DbOrValue(item.ComponentName));
            cmd.Parameters.AddWithValue("@QTY", item.Quantity);
            cmd.Parameters.AddWithValue("@UM", DbOrValue(item.Um));
            cmd.Parameters.AddWithValue("@GESTIUNE", DbOrValue(item.Gestiune));
            cmd.ExecuteNonQuery();
            rd++;
        }

        foreach (var line in payload.RecipeLines ?? [])
        {
            if (TryUpsertRecipeLine(conn, line))
                rl++;
        }

        foreach (var line in preservedRecipeLines)
        {
            if (TryUpsertRecipeLine(conn, line))
                rl++;
        }

        return (g, a, r, rd, rl, c);
    }

    private static string NormalizeTipSaga(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return "";
        var t = value.Trim();
        return t.Length <= 1 ? t : t[..1];
    }

    private static object DbOrValue(string? value)
        => string.IsNullOrWhiteSpace(value) ? DBNull.Value : value.Trim();

    private static void EnsureTable(FbConnection conn, string tableName, string ddl)
    {
        if (TableExists(conn, tableName))
            return;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = ddl;
        cmd.ExecuteNonQuery();
    }

    private static bool TableExists(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT 1
FROM RDB$RELATIONS
WHERE RDB$SYSTEM_FLAG = 0
  AND TRIM(RDB$RELATION_NAME) = @T
ROWS 1";
        cmd.Parameters.AddWithValue("@T", tableName.Trim().ToUpperInvariant());
        var x = cmd.ExecuteScalar();
        return x != null && x != DBNull.Value;
    }

    private static void DeleteAll(FbConnection conn, string tableName)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = $"DELETE FROM {tableName}";
        cmd.ExecuteNonQuery();
    }

    private static List<SagaSyncRecipeLine> ReadPreservedLocalRecipeLines(FbConnection conn)
    {
        var list = new List<SagaSyncRecipeLine>();
        if (!TableExists(conn, "SP_SAGA_RECIPE_LINES"))
            return list;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
SELECT
  TRIM(COALESCE(LINE_KEY, '')),
  TRIM(COALESCE(ARTICOL_CODE, '')),
  TRIM(COALESCE(SOURCE_TABLE, '')),
  TRIM(COALESCE(TIP, '')),
  TRIM(COALESCE(GESTIUNE, '')),
  TRIM(COALESCE(OPERATIE, '')),
  TRIM(COALESCE(COMPONENT_CODE, '')),
  TRIM(COALESCE(COMPONENT_NAME, '')),
  TRIM(COALESCE(UM, '')),
  COALESCE(QTY, 0)
FROM SP_SAGA_RECIPE_LINES
WHERE UPPER(TRIM(COALESCE(SOURCE_TABLE, ''))) IN ('MANUAL', 'IMPORT')";
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            list.Add(new SagaSyncRecipeLine
            {
                LineKey = (rd[0]?.ToString() ?? "").Trim(),
                ArticolCode = (rd[1]?.ToString() ?? "").Trim(),
                SourceTable = (rd[2]?.ToString() ?? "").Trim(),
                Tip = (rd[3]?.ToString() ?? "").Trim(),
                Gestiune = (rd[4]?.ToString() ?? "").Trim(),
                Operatie = (rd[5]?.ToString() ?? "").Trim(),
                ComponentCode = (rd[6]?.ToString() ?? "").Trim(),
                ComponentName = (rd[7]?.ToString() ?? "").Trim(),
                Um = (rd[8]?.ToString() ?? "").Trim(),
                Quantity = rd[9] == null || rd[9] == DBNull.Value
                    ? 0m
                    : Convert.ToDecimal(rd[9], CultureInfo.InvariantCulture)
            });
        }

        return list;
    }

    private static bool TryUpsertRecipeLine(FbConnection conn, SagaSyncRecipeLine line)
    {
        if (string.IsNullOrWhiteSpace(line.LineKey) || string.IsNullOrWhiteSpace(line.ArticolCode))
            return false;

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
UPDATE OR INSERT INTO SP_SAGA_RECIPE_LINES
(LINE_KEY, ARTICOL_CODE, SOURCE_TABLE, TIP, GESTIUNE, OPERATIE, COMPONENT_CODE, COMPONENT_NAME, UM, QTY, UPDATED_AT)
VALUES
(@LINE_KEY, @ARTICOL_CODE, @SOURCE_TABLE, @TIP, @GESTIUNE, @OPERATIE, @COMPONENT_CODE, @COMPONENT_NAME, @UM, @QTY, CURRENT_TIMESTAMP)
MATCHING (LINE_KEY)";
        cmd.Parameters.AddWithValue("@LINE_KEY", TruncFb(line.LineKey, 64));
        cmd.Parameters.AddWithValue("@ARTICOL_CODE", TruncFb(line.ArticolCode, 24));
        cmd.Parameters.AddWithValue("@SOURCE_TABLE", DbOrTrunc(line.SourceTable, 24));
        cmd.Parameters.AddWithValue("@TIP", DbOrTrunc(line.Tip, 80));
        cmd.Parameters.AddWithValue("@GESTIUNE", DbOrTrunc(line.Gestiune, 16));
        cmd.Parameters.AddWithValue("@OPERATIE", DbOrTrunc(line.Operatie, 32));
        cmd.Parameters.AddWithValue("@COMPONENT_CODE", DbOrTrunc(line.ComponentCode, 24));
        cmd.Parameters.AddWithValue("@COMPONENT_NAME", DbOrTrunc(line.ComponentName, 120));
        cmd.Parameters.AddWithValue("@UM", DbOrTrunc(line.Um, 10));
        cmd.Parameters.AddWithValue("@QTY", line.Quantity);
        cmd.ExecuteNonQuery();
        return true;
    }

    private static string TruncFb(string? s, int max)
    {
        if (string.IsNullOrWhiteSpace(s))
            return "";
        s = s.Trim();
        return s.Length <= max ? s : s[..max];
    }

    private static object DbOrTrunc(string? value, int max)
    {
        if (string.IsNullOrWhiteSpace(value))
            return DBNull.Value;
        var t = value.Trim();
        if (t.Length > max)
            t = t[..max];
        return t;
    }
}

